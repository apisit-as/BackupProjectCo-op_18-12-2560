package com.java.teacher.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.student.bean.ActivityBean;
import com.java.student.bean.AddressBean;
import com.java.student.bean.CareerBean;
import com.java.student.bean.Coop03Bean;
import com.java.student.bean.EducationBean;
import com.java.student.bean.FamilyBean;
import com.java.student.bean.HistoryStatusBean;
import com.java.student.bean.Language02Bean;
import com.java.student.bean.Language03Bean;
import com.java.student.bean.ProfileBean;
import com.java.student.bean.RelativeBean;
import com.java.student.bean.TrainingBean;
import com.java.student.bean.UserBean;
import com.java.student.dao.TableApprovalStatusDao;
import com.java.student.dao.TableCompleteStatusDocument;
import com.java.student.dao.TableDocumentStatusDao;
import com.java.student.dao.TableHistoryStatusDao;
import com.java.thacher.bean.Coop02Bean;
import com.java.thacher.bean.ProfileStudentSendDocumentBean;
import com.java.thacher.bean.TeacherCheckDocumentBean;
import com.java.thacher.dao.Coop02Dao;
import com.java.thacher.dao.Coop03Dao;
import com.java.thacher.dao.TableStudentSendDocumentDao;
import com.java.thacher.dao.TableTeacherCheckDocumentDao;

/**
 * Servlet implementation class CheckDocument
 */
@WebServlet("/CheckDocument")
public class CheckDocument extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckDocument() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
			HttpSession session = request.getSession();
			String role = session.getAttribute("role").toString();
			String CheckRoleApproveTeacher =  session.getAttribute("CheckRoleApproveTeacher").toString();
			if((role.equals("teacher1")) || (role.equals("teacher2")) && (CheckRoleApproveTeacher.equals("true"))){
				//String UserID = session.getAttribute("UserID").toString();

				int facid = Integer.parseInt(session.getAttribute("facID").toString());
				int divid = Integer.parseInt(session.getAttribute("divID").toString()); 
				int academic_id = Integer.parseInt(session.getAttribute("academic_year_id").toString());

				
				String action = request.getParameter("action");
				int id_student_send_document = Integer.parseInt(request.getParameter("id_student_send_document"));
				TableStudentSendDocumentDao tableStudentSendDocumentDao = new TableStudentSendDocumentDao();
				ProfileStudentSendDocumentBean profileStudentSendDocumentBean = new ProfileStudentSendDocumentBean();
				String checkLevelTeacher = "";
				if(role.equals("teacher1")){
					checkLevelTeacher = "Lv1";
				}else if(role.equals("teacher2")){
					checkLevelTeacher = "Lv2";
				}

				// check division id  teacher != student
				Boolean check_division_student =  tableStudentSendDocumentDao.checkDivisionStudent(id_student_send_document, divid, academic_id, checkLevelTeacher);
				if(!check_division_student && ("coop02".equals(action) || "coop03".equals(action))){
					return;
				}
				
				Coop02Dao coop02Dao = new Coop02Dao();
				AddressBean original_address = new AddressBean();
				AddressBean semester_address = new AddressBean();
				AddressBean parent_address = new AddressBean();
				FamilyBean parent_family = new FamilyBean();
				TableTeacherCheckDocumentDao teacherCheckDocumentDao = new TableTeacherCheckDocumentDao();
				TeacherCheckDocumentBean teacherCheckDocumentBean = new TeacherCheckDocumentBean();

				if("coop02".equals(action)){
					// ��Ǩ�ͺ coop02
					Coop02Bean coop02Bean = new Coop02Bean();
					Language02Bean language02Bean = new Language02Bean();
					profileStudentSendDocumentBean = coop02Dao.SelectDataStudent(facid, divid, academic_id, id_student_send_document,checkLevelTeacher);
					original_address = coop02Dao.SelectAddress(facid, divid, academic_id, id_student_send_document, "original_address",checkLevelTeacher);
					semester_address = coop02Dao.SelectAddress(facid, divid, academic_id, id_student_send_document, "semester_address",checkLevelTeacher);
					parent_address = coop02Dao.SelectAddress(facid, divid, academic_id, id_student_send_document, "parent_address",checkLevelTeacher);
					parent_family = coop02Dao.SelectFamily(facid, divid, academic_id, id_student_send_document, "parent_family",checkLevelTeacher);
					coop02Bean =  coop02Dao.SelectCoop02(facid, divid, academic_id, id_student_send_document,checkLevelTeacher);
					language02Bean = coop02Dao.SelectLanguage02(facid, divid, academic_id, id_student_send_document, checkLevelTeacher);
					teacherCheckDocumentBean = teacherCheckDocumentDao.SelectStatusDocument(facid, divid, academic_id, id_student_send_document, checkLevelTeacher, "02");
					
					request.setAttribute("profileStudentSendDocumentBean", profileStudentSendDocumentBean);
					request.setAttribute("original_address", original_address);
					request.setAttribute("semester_address", semester_address);
					request.setAttribute("parent_address", parent_address);
					request.setAttribute("parent_family", parent_family);
					request.setAttribute("ListProfileBean", coop02Bean);
					request.setAttribute("language02Bean", language02Bean);
					request.setAttribute("teacherCheckDocumentBean", teacherCheckDocumentBean);
					
					request.setAttribute("id_student_send_document", id_student_send_document);
					doViewCheckCoop02(request, response);
					return;
				}
				else if("coop03".equals(action)){
					// ��Ǩ�ͺ coop03
					Coop03Bean coop03Bean = new Coop03Bean();
					Coop03Dao coop03Dao = new Coop03Dao();
					UserBean userBean = new UserBean();
					ProfileBean profileBean = new ProfileBean();
					FamilyBean father_family = new FamilyBean();
					FamilyBean mother_family = new FamilyBean();
					RelativeBean relativeBean1 = new RelativeBean();
					RelativeBean relativeBean2 = new RelativeBean();
					RelativeBean relativeBean3 = new RelativeBean();
					EducationBean educationBean1 = new EducationBean();
					EducationBean educationBean2 = new EducationBean();
					EducationBean educationBean3 = new EducationBean();
					EducationBean educationBean4 = new EducationBean();
					EducationBean educationBean5 = new EducationBean();
					EducationBean educationBean6 = new EducationBean();
					TrainingBean trainingBean1 = new TrainingBean();
					TrainingBean trainingBean2 = new TrainingBean();
					TrainingBean trainingBean3 = new TrainingBean();
					CareerBean careerBean1 = new CareerBean();
					CareerBean careerBean2 = new CareerBean();
					CareerBean careerBean3 = new CareerBean();
					CareerBean careerBean4 = new CareerBean();
					ActivityBean activityBean1 = new ActivityBean();
					ActivityBean activityBean2 = new ActivityBean();
					ActivityBean activityBean3 = new ActivityBean();
					Language03Bean language03Bean = new Language03Bean();
					
					coop03Bean = coop03Dao.SelectCoop03(facid, divid, academic_id, id_student_send_document, checkLevelTeacher);
					userBean = coop03Dao.SelectUser(facid, divid, academic_id, id_student_send_document, checkLevelTeacher);
					profileBean = coop03Dao.SelectProfile(facid, divid, academic_id, id_student_send_document, checkLevelTeacher);
					original_address = coop02Dao.SelectAddress(facid, divid, academic_id, id_student_send_document, "original_address",checkLevelTeacher);
					semester_address = coop02Dao.SelectAddress(facid, divid, academic_id, id_student_send_document, "semester_address",checkLevelTeacher);
					parent_address = coop02Dao.SelectAddress(facid, divid, academic_id, id_student_send_document, "parent_address",checkLevelTeacher);
					parent_family = coop02Dao.SelectFamily(facid, divid, academic_id, id_student_send_document, "parent_family",checkLevelTeacher);
					father_family = coop02Dao.SelectFamily(facid, divid, academic_id, id_student_send_document, "father_family",checkLevelTeacher);
					mother_family = coop02Dao.SelectFamily(facid, divid, academic_id, id_student_send_document, "mother_family",checkLevelTeacher);
					relativeBean1 = coop03Dao.SelectRelative(facid, divid, academic_id, id_student_send_document, "relative_1", checkLevelTeacher);
					relativeBean2 = coop03Dao.SelectRelative(facid, divid, academic_id, id_student_send_document, "relative_2", checkLevelTeacher);
					relativeBean3 = coop03Dao.SelectRelative(facid, divid, academic_id, id_student_send_document, "relative_3", checkLevelTeacher);
					educationBean1 = coop03Dao.SelectEducation(facid, divid, academic_id, id_student_send_document, "Primary", checkLevelTeacher);
					educationBean2 = coop03Dao.SelectEducation(facid, divid, academic_id, id_student_send_document, "Secondary", checkLevelTeacher);
					educationBean3 = coop03Dao.SelectEducation(facid, divid, academic_id, id_student_send_document, "HighSchool", checkLevelTeacher);
					educationBean4 = coop03Dao.SelectEducation(facid, divid, academic_id, id_student_send_document, "Vocation_1", checkLevelTeacher);
					educationBean5 = coop03Dao.SelectEducation(facid, divid, academic_id, id_student_send_document, "Vocation_2", checkLevelTeacher);
					educationBean6 = coop03Dao.SelectEducation(facid, divid, academic_id, id_student_send_document, "Bachelor_degree", checkLevelTeacher);
					trainingBean1 = coop03Dao.SelectTraining(facid, divid, academic_id, id_student_send_document, "training_1", checkLevelTeacher);
					trainingBean2 = coop03Dao.SelectTraining(facid, divid, academic_id, id_student_send_document, "training_2", checkLevelTeacher);
					trainingBean3 = coop03Dao.SelectTraining(facid, divid, academic_id, id_student_send_document, "training_3", checkLevelTeacher);
					careerBean1 = coop03Dao.SelectCareer(facid, divid, academic_id, id_student_send_document, "career_1", checkLevelTeacher);
					careerBean2 = coop03Dao.SelectCareer(facid, divid, academic_id, id_student_send_document, "career_2", checkLevelTeacher);
					careerBean3 = coop03Dao.SelectCareer(facid, divid, academic_id, id_student_send_document, "career_3", checkLevelTeacher);
					careerBean4 = coop03Dao.SelectCareer(facid, divid, academic_id, id_student_send_document, "career_4", checkLevelTeacher);
					activityBean1 = coop03Dao.SelectActivity(facid, divid, academic_id, id_student_send_document, "activity_1", checkLevelTeacher);
					activityBean2 = coop03Dao.SelectActivity(facid, divid, academic_id, id_student_send_document, "activity_2", checkLevelTeacher);
					activityBean3 = coop03Dao.SelectActivity(facid, divid, academic_id, id_student_send_document, "activity_3", checkLevelTeacher);
					language03Bean = coop03Dao.SelectLanguage03(facid, divid, academic_id, id_student_send_document, checkLevelTeacher);
					teacherCheckDocumentBean = teacherCheckDocumentDao.SelectStatusDocument(facid, divid, academic_id, id_student_send_document, checkLevelTeacher, "03");
					
					request.setAttribute("coop03Bean", coop03Bean);
					request.setAttribute("userBean", userBean);
					request.setAttribute("ListProfileBean", profileBean);
					request.setAttribute("original_address", original_address);
					request.setAttribute("semester_address", semester_address);
					request.setAttribute("parent_address", parent_address);
					request.setAttribute("parent_family", parent_family);
					request.setAttribute("father_family", father_family);
					request.setAttribute("mother_family", mother_family);
					request.setAttribute("relativeBean1", relativeBean1);
					request.setAttribute("relativeBean2", relativeBean2);
					request.setAttribute("relativeBean3", relativeBean3);
					request.setAttribute("educationBean1", educationBean1);
					request.setAttribute("educationBean2", educationBean2);
					request.setAttribute("educationBean3", educationBean3);
					request.setAttribute("educationBean4", educationBean4);
					request.setAttribute("educationBean5", educationBean5);
					request.setAttribute("educationBean6", educationBean6);
					request.setAttribute("trainingBean1", trainingBean1);
					request.setAttribute("trainingBean2", trainingBean2);
					request.setAttribute("trainingBean3", trainingBean3);
					request.setAttribute("careerBean1", careerBean1);
					request.setAttribute("careerBean2", careerBean2);
					request.setAttribute("careerBean3", careerBean3);
					request.setAttribute("careerBean4", careerBean4);
					request.setAttribute("activityBean1", activityBean1);
					request.setAttribute("activityBean2", activityBean2);
					request.setAttribute("activityBean3", activityBean3);
					request.setAttribute("language03Bean", language03Bean);
					request.setAttribute("teacherCheckDocumentBean", teacherCheckDocumentBean);
					
					request.setAttribute("id_student_send_document", id_student_send_document);
					doViewCheckCoop03(request, response);
					return;
				}else{			
				   //  Lv1,Lv2_ApStatusID=�ʹ��Թ���(6) ���͹��ѵ�(3)
					// ʶҹ�  ��õ�Ǩ�͡���
					profileStudentSendDocumentBean = tableStudentSendDocumentDao.SelectProfileStudentSendDocument(facid, divid, academic_id, id_student_send_document,checkLevelTeacher);
					request.setAttribute("profileStudentSendDocumentBean", profileStudentSendDocumentBean);
					request.setAttribute("id_student_send_document", id_student_send_document);
					session.setAttribute("status_id_check", profileStudentSendDocumentBean.getLv_ap_status());
					doViewCheckDocument(request, response);
				}
				
			}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		String role = session.getAttribute("role").toString();
		String checkLevelTeacher = "";
		if(role.equals("teacher1")){
			checkLevelTeacher = "Lv1";
		}else if(role.equals("teacher2")){
			checkLevelTeacher = "Lv2";
		}else{
			return;
		}
		
		String action = request.getParameter("action");
		int radio_check = Integer.parseInt(request.getParameter("radio_check"));
		String comment = request.getParameter("comment");
		int id_student_send_document = Integer.parseInt(request.getParameter("id_student_send_document"));
		
		TableTeacherCheckDocumentDao teacherCheckDocumentDao = new TableTeacherCheckDocumentDao();
		TeacherCheckDocumentBean teacherCheckDocumentBean = new TeacherCheckDocumentBean();
		teacherCheckDocumentBean.setLv_status_id(radio_check);
		teacherCheckDocumentBean.setLv_note(comment);
		teacherCheckDocumentBean.setDoc_id(id_student_send_document);
		
		int facid = Integer.parseInt(session.getAttribute("facID").toString());
		int divid = Integer.parseInt(session.getAttribute("divID").toString()); 
		int academic_id = Integer.parseInt(session.getAttribute("academic_year_id").toString());
		
		if(!teacherCheckDocumentDao.CheckTable(facid, divid, academic_id, id_student_send_document)){
			return;
		}

		if("checkCoop02".equals(action)){
			// check coop02
			teacherCheckDocumentDao.UpdateCheckDocument(teacherCheckDocumentBean, "02", checkLevelTeacher);
		}
		else if("checkCoop03".equals(action)){
			// check coop03
			teacherCheckDocumentDao.UpdateCheckDocument(teacherCheckDocumentBean, "03", checkLevelTeacher);
		}
		else if("approveDocument".equals(action)){
			// approve document status
			TableStudentSendDocumentDao tableStudentSendDocumentDao =new TableStudentSendDocumentDao();
			int UserID_sutdent = tableStudentSendDocumentDao.SelectUseridStudent(id_student_send_document);
			int UserID_teacher = Integer.parseInt(session.getAttribute("UserID").toString());
			String date = getDateDefaultToString();
			/**
			 *     getStatusApproval
			 *     2 = ͹��ѵ�     
			 *     4 = �觡�Ѻ���    ,    3 = ���͹��ѵ�����͡��Ժѵԧҹ�ˡԨ�֡�� ,   6 = �ʹ��Թ���    
			 *     
			 *     getStatusDocument
			 *     2 = ������ó�
			 */
			TableDocumentStatusDao tableDocumentStatus = new TableDocumentStatusDao();
			TableApprovalStatusDao tableApprovalStatusDao = new TableApprovalStatusDao();
			
			int status_id_check = Integer.parseInt(session.getAttribute("status_id_check").toString());
			if(status_id_check == radio_check){
				// status_id_check == radio_check
				return;
			}
			
			//update status
			tableStudentSendDocumentDao.UpdateApprovalStatus(radio_check, UserID_teacher, date, id_student_send_document, checkLevelTeacher);
			
			if(role.equals("teacher1")){
				if(radio_check == 2){
					InsertHistory(date, "�Ҩ�������ҹ�ҹ�ˡԨ�֡�ҵ�Ǩ�ͺ�͡���", tableApprovalStatusDao.getStatusApproval(2),UserID_sutdent);
					InsertHistory(date, "���˹���Ң��Ԫҵ�Ǩ�ͺ�͡���", tableApprovalStatusDao.getStatusApproval(6),UserID_sutdent);
				}
				else if(radio_check == 4){
					//  4
					updateStatusCompleteStatusDocument(UserID_sutdent);
					InsertHistory(date, "�Ҩ�������ҹ�ҹ�ˡԨ�֡�ҵ�Ǩ�ͺ�͡���", tableApprovalStatusDao.getStatusApproval(radio_check),UserID_sutdent);
				}
				else{
					//  3
					InsertHistory(date, "�Ҩ�������ҹ�ҹ�ˡԨ�֡�ҵ�Ǩ�ͺ�͡���", tableApprovalStatusDao.getStatusApproval(radio_check),UserID_sutdent);
				}
			}else if(role.equals("teacher2")){
				if(radio_check == 2){
					InsertHistory(date, "���˹���Ң��Ԫҵ�Ǩ�ͺ�͡���", tableApprovalStatusDao.getStatusApproval(2),UserID_sutdent);
					InsertHistory(date, "���͡ʶҹ��Сͺ���", tableDocumentStatus.getStatusDocument(2),UserID_sutdent);
				}
				else if(radio_check == 4){
					//  4
					updateStatusCompleteStatusDocument(UserID_sutdent);
					InsertHistory(date, "���˹���Ң��Ԫҵ�Ǩ�ͺ�͡���", tableApprovalStatusDao.getStatusApproval(radio_check),UserID_sutdent);
				}
				else{
					//  3
					InsertHistory(date, "���˹���Ң��Ԫҵ�Ǩ�ͺ�͡���", tableApprovalStatusDao.getStatusApproval(radio_check),UserID_sutdent);
				}
			}
			return;
		}
		
		out.print(id_student_send_document);
	}
	
	public void updateStatusCompleteStatusDocument(int UserID_sutdent){
		/** insert,update status document **/
		TableCompleteStatusDocument tableCompleteStatusDocument = new TableCompleteStatusDocument();
		String []fieldName = {"DataStudent","DataAddress","DataFamily","DataEducation","DataActivity","DataTalent","DataCareer","DataTranscript"};
		
		for(int i=0; i<fieldName.length; i++){
			//update   3 = ���
			tableCompleteStatusDocument.UpdateCompleteStatusDoc(fieldName[i], 3, UserID_sutdent);
		}

	}
	
	public String getDateDefaultToString(){
		LocalDate localDate = LocalDate.now();
		String date = DateTimeFormatter.ofPattern("dd/MM/yyy").format(localDate);
		String[] dateSplit = date.split("/");
		date = "";
		date = dateSplit[0]+"/"+dateSplit[1]+"/"+(Integer.parseInt(dateSplit[2])+543);
		return date;
	}
	
	public void InsertHistory(String date,String history,String status,int userid){
		HistoryStatusBean historyStatusBean = new HistoryStatusBean();
		historyStatusBean.setDate(date);
		historyStatusBean.setHistory(history);
		historyStatusBean.setStatus(status);
		historyStatusBean.setUserid(userid);
		TableHistoryStatusDao tableHistoryStatus = new TableHistoryStatusDao();
		tableHistoryStatus.InsertHistoryStatus(historyStatusBean);
	}
	
	private void doViewCheckDocument(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/teacher/check_document.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void doViewCheckCoop02(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/teacher/check_coop02.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	private void doViewCheckCoop03(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/teacher/check_coop03.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
}
