package com.java.teacher.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.admin.bean.AcademicYearBean;
import com.java.admin.dao.TableAcademicYear;
import com.java.staff.bean.CompanyBean;
import com.java.staff.bean.RegionBean;
import com.java.staff.dao.TableCompanyDao;
import com.java.staff.dao.TableRegionDao;
import com.java.student.bean.HistoryStatusBean;
import com.java.student.bean.UserBean;
import com.java.student.dao.TableApprovalStatusDao;
import com.java.student.dao.TableHistoryStatusDao;
import com.java.student.dao.TableUserDao;
import com.java.thacher.bean.ListStudentSelectCompanyBean;
import com.java.thacher.dao.TableStudentSelectCompany;

/**
 * Servlet implementation class ApproveCompany
 */
@WebServlet("/ApproveCompany")
public class ApproveCompany extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ApproveCompany() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
			HttpSession session = request.getSession();
			TableUserDao tableUserDao = new TableUserDao();
			UserBean userBean = new UserBean();
			String role = session.getAttribute("role").toString();
			if(role.equals("teacher1")){
				int UserID = Integer.parseInt(session.getAttribute("UserID").toString());
				userBean = tableUserDao.getTableUser(UserID);
				
				// set Academic Year
				TableAcademicYear tableAcademicYear = new TableAcademicYear();
				AcademicYearBean academicYearBean = new AcademicYearBean();
				academicYearBean = tableAcademicYear.getAcademic();
				session.setAttribute("Semester", academicYearBean.getSemester());
				session.setAttribute("Academic_year", academicYearBean.getAcademic_year());
				session.setAttribute("academic_year_id", academicYearBean.getId());
				
				/** get list Student Select Company tab1,2,3 **/
				/**
				 *  1 = ��͹��ѵ�
				 *  2 = ͹��ѵ�
				 *  5 = ���͹��ѵ�
				 */
				TableStudentSelectCompany tableStudentSelectCompany = new TableStudentSelectCompany();
				ArrayList<ListStudentSelectCompanyBean> ListStudentSelectCompanyTab1 = new ArrayList<>();
				ArrayList<ListStudentSelectCompanyBean> ListStudentSelectCompanyTab2 = new ArrayList<>();
				ArrayList<ListStudentSelectCompanyBean> ListStudentSelectCompanyTab3 = new ArrayList<>();
				ListStudentSelectCompanyTab1 = tableStudentSelectCompany.SelectListStudentSelectCompany(1, userBean.getFacid(), userBean.getDivid(), academicYearBean.getId());
				ListStudentSelectCompanyTab2 = tableStudentSelectCompany.SelectListStudentSelectCompany(2, userBean.getFacid(), userBean.getDivid(), academicYearBean.getId());
				ListStudentSelectCompanyTab3 = tableStudentSelectCompany.SelectListStudentSelectCompany(5, userBean.getFacid(), userBean.getDivid(), academicYearBean.getId());
				request.setAttribute("ListStudentSelectCompanyTab1", ListStudentSelectCompanyTab1);
				request.setAttribute("ListStudentSelectCompanyTab2", ListStudentSelectCompanyTab2);
				request.setAttribute("ListStudentSelectCompanyTab3", ListStudentSelectCompanyTab3);
				
				int siez_list_tab1 = ListStudentSelectCompanyTab1.size();
				request.setAttribute("siez_list_tab1", siez_list_tab1);
				/** #get list Student Select Company tab1,2,3 **/
				
				/** check role approve document  
				 *  enable or disable
				 */
				String CheckRoleApproveTeacher = userBean.getApprove_teacher();
				session.setAttribute("CheckRoleApproveTeacher",CheckRoleApproveTeacher);
				
				/** check isEmpty List **/
				if(ListStudentSelectCompanyTab1.isEmpty()){
					session.setAttribute("CheckList","isEmpty");
				}else{
					session.setAttribute("CheckList","Not_isEmpty");
				}
				/** #check isEmpty List **/
				
				doViewApproveCompany(request, response);
			}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		
		String action = request.getParameter("action");
		String CheckRoleApproveTeacher =  session.getAttribute("CheckRoleApproveTeacher").toString();
		String role = session.getAttribute("role").toString();
		if("save_stauts".equals(action) && ("true".equals(CheckRoleApproveTeacher)) && ("teacher1".equals(role))){
			String[] data_select = request.getParameterValues("data_select[]");
			String[] data_text = request.getParameterValues("data_text[]");
			
			if(data_select != null && data_text != null){
				int user_id = Integer.parseInt(session.getAttribute("UserID").toString());
				String date = getDateDefaultToString();
				TableStudentSelectCompany tableStudentSelectCompany = new TableStudentSelectCompany();
				for(int i=0; i<data_select.length; i++){
					String[] data_select_status = data_select[i].split(",");
					int lv1_ap_status_id = Integer.parseInt(data_select_status[0]);
					int user_id_student = Integer.parseInt(data_select_status[1]);
					String comment = data_text[i];
					/**
					 *   1 = ��͹��ѵ�    , 2 = ͹��ѵ�   ,   5 = ���͹��ѵ�
					 */
					if(lv1_ap_status_id == 1 || lv1_ap_status_id == 2 || lv1_ap_status_id == 5){
						// update status
						tableStudentSelectCompany.UpdateApprovalStatus(lv1_ap_status_id, comment, user_id_student, user_id, date);
					}else{
						out.print("error");
						return;
					}
					
					/** insert history **/
					TableApprovalStatusDao tableApprovalStatusDao = new TableApprovalStatusDao();
					if(lv1_ap_status_id == 2){
						// 2 = ͹��ѵ�    ,  6 = �ʹ��Թ���
						InsertHistory(date, "�Ҩ�������ҹ�ҹ�ˡԨ�֡�ҵ�Ǩ�ͺʶҹ��Сͺ���", tableApprovalStatusDao.getStatusApproval(2),user_id_student);
						InsertHistory(date, "���˹�ҷ���ˡԨ�֡�ҨѴ��˹ѧ��ͤ͢���͹���������ѧʶҹ��Сͺ���", tableApprovalStatusDao.getStatusApproval(6),user_id_student);
					}
					else if(lv1_ap_status_id == 5){
						// 5 = ���͹��ѵ�
						InsertHistory(date, "�Ҩ�������ҹ�ҹ�ˡԨ�֡�ҵ�Ǩ�ͺʶҹ��Сͺ���", tableApprovalStatusDao.getStatusApproval(5),user_id_student);
						
						// update value = ''  coop03
						tableStudentSelectCompany.UpdateCoop03(user_id_student);
					}
					/** #insert history **/
					
				}
			}
		}
		
		else if("show_modal".equals(action)){
			int id_company = Integer.parseInt(request.getParameter("id"));
			CompanyBean companyBean = new CompanyBean();
			TableCompanyDao tableCompanyDao = new TableCompanyDao();
			companyBean = tableCompanyDao.SelectCompany(id_company);
			request.setAttribute("companyBean", companyBean);
			
			ArrayList<RegionBean> listRegionCompany = new ArrayList<>();
			TableRegionDao tableRegionDao = new TableRegionDao();
			listRegionCompany = tableRegionDao.SelectListRegion();
			request.setAttribute("listRegionCompany", listRegionCompany);
			
			getPageModalDataCompany(request, response);
		}

		
	}

	private String getDateDefaultToString(){
		LocalDate localDate = LocalDate.now();
		String date = DateTimeFormatter.ofPattern("dd/MM/yyy").format(localDate);
		String[] dateSplit = date.split("/");
		date = "";
		date = dateSplit[0]+"/"+dateSplit[1]+"/"+(Integer.parseInt(dateSplit[2])+543);
		return date;
	}
	private void InsertHistory(String date,String history,String status,int userid){
		HistoryStatusBean historyStatusBean = new HistoryStatusBean();
		historyStatusBean.setDate(date);
		historyStatusBean.setHistory(history);
		historyStatusBean.setStatus(status);
		historyStatusBean.setUserid(userid);
		TableHistoryStatusDao tableHistoryStatus = new TableHistoryStatusDao();
		tableHistoryStatus.InsertHistoryStatus(historyStatusBean);
	}
	private void doViewApproveCompany(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/teacher/approve_company.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	private void getPageModalDataCompany(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/element/data_company.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}

}
