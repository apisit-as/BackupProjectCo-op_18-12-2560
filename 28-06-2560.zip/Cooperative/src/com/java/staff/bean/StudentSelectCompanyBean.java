package com.java.staff.bean;

public class StudentSelectCompanyBean {
	private int id;
	private int rate_company_id;
	private int user_id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getRate_company_id() {
		return rate_company_id;
	}
	public void setRate_company_id(int rate_company_id) {
		this.rate_company_id = rate_company_id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	
}
