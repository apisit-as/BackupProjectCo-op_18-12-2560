package com.java.staff.bean;

public class UserListStudentRateCompanyBean {
	private int user_id;
	private String title_name_th;
	private String firstname_th;
	private String lastname_th;
	private String student_id;
	private String fac_name;
	private String div_name;
	
	public String getFac_name() {
		return fac_name;
	}
	public void setFac_name(String fac_name) {
		this.fac_name = fac_name;
	}
	public String getDiv_name() {
		return div_name;
	}
	public void setDiv_name(String div_name) {
		this.div_name = div_name;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getTitle_name_th() {
		return title_name_th;
	}
	public void setTitle_name_th(String title_name_th) {
		this.title_name_th = title_name_th;
	}
	public String getFirstname_th() {
		return firstname_th;
	}
	public void setFirstname_th(String firstname_th) {
		this.firstname_th = firstname_th;
	}
	public String getLastname_th() {
		return lastname_th;
	}
	public void setLastname_th(String lastname_th) {
		this.lastname_th = lastname_th;
	}
	public String getStudent_id() {
		return student_id;
	}
	public void setStudent_id(String student_id) {
		this.student_id = student_id;
	}
	
	
}
