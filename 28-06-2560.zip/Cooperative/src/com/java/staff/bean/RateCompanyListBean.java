package com.java.staff.bean;

public class RateCompanyListBean {
	// list page rate_company
	private int rate_company_id;
	private int company_id;
	private String name_company;
	private String provice_company;
	private String region_company_name;
	private String fac_name;
	private String div_name;
	private String type_offer_job;
	private int num_student_total;
	private int num_student;
	private String semester;
	private String academic_year;
	public int getRate_company_id() {
		return rate_company_id;
	}
	public void setRate_company_id(int rate_company_id) {
		this.rate_company_id = rate_company_id;
	}
	public int getCompany_id() {
		return company_id;
	}
	public void setCompany_id(int company_id) {
		this.company_id = company_id;
	}
	public String getName_company() {
		return name_company;
	}
	public void setName_company(String name_company) {
		this.name_company = name_company;
	}
	public String getProvice_company() {
		return provice_company;
	}
	public void setProvice_company(String provice_company) {
		this.provice_company = provice_company;
	}
	public String getRegion_company_name() {
		return region_company_name;
	}
	public void setRegion_company_name(String region_company_name) {
		this.region_company_name = region_company_name;
	}
	public String getFac_name() {
		return fac_name;
	}
	public void setFac_name(String fac_name) {
		this.fac_name = fac_name;
	}
	public String getDiv_name() {
		return div_name;
	}
	public void setDiv_name(String div_name) {
		this.div_name = div_name;
	}
	public String getType_offer_job() {
		return type_offer_job;
	}
	public void setType_offer_job(String type_offer_job) {
		this.type_offer_job = type_offer_job;
	}
	public int getNum_student_total() {
		return num_student_total;
	}
	public void setNum_student_total(int num_student_total) {
		this.num_student_total = num_student_total;
	}
	public int getNum_student() {
		return num_student;
	}
	public void setNum_student(int num_student) {
		this.num_student = num_student;
	}
	public String getSemester() {
		return semester;
	}
	public void setSemester(String semester) {
		this.semester = semester;
	}
	public String getAcademic_year() {
		return academic_year;
	}
	public void setAcademic_year(String academic_year) {
		this.academic_year = academic_year;
	}
	
}
