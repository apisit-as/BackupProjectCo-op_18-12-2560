package com.java.staff.bean;

public class DivisionBean {
	private int division_id;
	private String division_code;
	private String division_name;
	private String division_initials;
	private int faculty_id;
	private String faculty_code;
	private String faculty_name;
	public int getDivision_id() {
		return division_id;
	}
	public void setDivision_id(int division_id) {
		this.division_id = division_id;
	}
	public String getDivision_code() {
		return division_code;
	}
	public void setDivision_code(String division_code) {
		this.division_code = division_code;
	}
	public String getDivision_name() {
		return division_name;
	}
	public void setDivision_name(String division_name) {
		this.division_name = division_name;
	}
	public String getDivision_initials() {
		return division_initials;
	}
	public void setDivision_initials(String division_initials) {
		this.division_initials = division_initials;
	}
	public int getFaculty_id() {
		return faculty_id;
	}
	public void setFaculty_id(int faculty_id) {
		this.faculty_id = faculty_id;
	}
	public String getFaculty_code() {
		return faculty_code;
	}
	public void setFaculty_code(String faculty_code) {
		this.faculty_code = faculty_code;
	}
	public String getFaculty_name() {
		return faculty_name;
	}
	public void setFaculty_name(String faculty_name) {
		this.faculty_name = faculty_name;
	}
}
