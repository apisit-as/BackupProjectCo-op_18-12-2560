package com.java.staff.bean;

public class FileManagementBean {
	private int id;
	private String code_file;
	private String name;
	private String type;
	private String path_file;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCode_file() {
		return code_file;
	}
	public void setCode_file(String code_file) {
		this.code_file = code_file;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPath_file() {
		return path_file;
	}
	public void setPath_file(String path_file) {
		this.path_file = path_file;
	}
}
