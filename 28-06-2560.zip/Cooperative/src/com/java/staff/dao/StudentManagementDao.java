package com.java.staff.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.staff.bean.ListStudentTab1Bean;
import com.java.util.PreparedStatementUtil;

public class StudentManagementDao {
	
	public int getAcademicID(int search_semester,int search_academic){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		int academic_id = 0;
		String query = "SELECT  ID "
					   +"FROM tb_academic_year "
					   +"WHERE Semester = :semester_id AND Academic_year = :academic_id ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("semester_id", search_semester);
			preparedStatementUtil.setInt("academic_id", search_academic);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				academic_id = rs.getInt("ID");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return academic_id;
	}	
	
	public ArrayList<ListStudentTab1Bean> SearchListTab1(int search_semester,int search_academic){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		ArrayList<ListStudentTab1Bean> list = new ArrayList<>();
		int academic_id = 0;
		String query = "SELECT  ID "
					   +"FROM tb_academic_year "
					   +"WHERE Semester = :semester_id AND Academic_year = :academic_id ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("semester_id", search_semester);
			preparedStatementUtil.setInt("academic_id", search_academic);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				academic_id = rs.getInt("ID");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		list = SelectListStudentTab1(academic_id);
		return list;
	}	
	
	public ArrayList<ListStudentTab1Bean> SelectListStudentTab1(int academic_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ArrayList<ListStudentTab1Bean> list = new ArrayList<>();
		String query =  "SELECT  tb_user.StudentID,"
						+ "tb_title.Name_th AS titleName_th,"
				        + "tb_user.FirstName_th,"
				        + "tb_user.LastName_th,"
				        + "tb_faculty.Name AS facName,"
				        + "tb_division.Name AS divName,"
				        + "tb_student_select_company.RateCompanyID_Temp,"
				        + "tb_approval_status.Name AS Status,"
				        + "tb_student_select_company.UserID "
				        + "FROM tb_student_select_company "
				        + "JOIN tb_user  ON tb_user.ID = tb_student_select_company.UserID "
				        + "JOIN tb_title  ON tb_title.ID = tb_user.TitleID "
				        + "JOIN tb_faculty  ON tb_faculty.ID = tb_user.FacID "
				        + "JOIN tb_division  ON tb_division.ID = tb_user.DivID "
						+ "JOIN tb_student_send_document  ON tb_student_send_document.UserID = tb_user.ID "
						+ "LEFT JOIN tb_approval_status  ON tb_approval_status.ID = tb_student_select_company.Staff_ApStatusID "
						+ " WHERE (tb_student_send_document.Lv2_ApStatusID = 2) "
						+ "	AND tb_student_select_company.Academic_year = :academic_id  ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("academic_id", academic_id);
			rs = preparedStatementUtil.executeQuery();
			while(rs.next()){
				ListStudentTab1Bean listStudentTab1Bean = new ListStudentTab1Bean();
				int rate_company_id = rs.getInt("RateCompanyID_Temp");
				listStudentTab1Bean.setStudent_id(rs.getString("StudentID"));
				listStudentTab1Bean.setTitle_name_th(rs.getString("titleName_th"));
				listStudentTab1Bean.setFirstname_th(rs.getString("FirstName_th"));
				listStudentTab1Bean.setLastname_th(rs.getString("LastName_th"));
				listStudentTab1Bean.setFac_name(rs.getString("facName"));
				listStudentTab1Bean.setDiv_name(rs.getString("divName"));
				
				/** get data comapny **/
				if(rate_company_id != 0){
					ListStudentTab1Bean tempBean = new ListStudentTab1Bean();
					tempBean = getDataComapny(rate_company_id);
	
					listStudentTab1Bean.setCompany_name(tempBean.getCompany_name());
					listStudentTab1Bean.setCompany_id(tempBean.getCompany_id());
					listStudentTab1Bean.setAddress_company(tempBean.getAddress_company());
					listStudentTab1Bean.setDistrict_company(tempBean.getDistrict_company());
					listStudentTab1Bean.setAmphur_company(tempBean.getAmphur_company());
					listStudentTab1Bean.setProvince_company(tempBean.getProvince_company());
					listStudentTab1Bean.setPost_code_company(tempBean.getPost_code_company());
					listStudentTab1Bean.setTelephone_company(tempBean.getTelephone_company());
					listStudentTab1Bean.setName_contact(tempBean.getName_contact());
					listStudentTab1Bean.setTelephone_contact(tempBean.getTelephone_contact());
				}
				
				listStudentTab1Bean.setStatus(checkStatus(rs.getString("Status")));
				listStudentTab1Bean.setUser_id(rs.getInt("UserID"));
				list.add(listStudentTab1Bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	public ListStudentTab1Bean getDataComapny(int rate_company_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ListStudentTab1Bean listStudentTab1Bean = new ListStudentTab1Bean();
		String query =  "SELECT  tb_company.NameCompany,"
							  + "tb_company.ID AS Company_id,"
							  + "tb_company.AddressCompany, "
							  + "tb_company.DistrictCompany, "
							  + "tb_company.AmphurCompany, "
							  + "tb_company.ProvinceCompany, "
							  + "tb_company.PostcodeCompany, "
							  + "tb_company.TelephoneCompany, "
							  + "tb_company.NameContact, "
							  + "tb_company.TelephoneContact "
				        + "FROM tb_rate_company "
				        + "JOIN tb_company  ON tb_company.ID = tb_rate_company.CompanyID  "
						+ " WHERE tb_rate_company.ID = :rate_company_id ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("rate_company_id", rate_company_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){		
				listStudentTab1Bean.setCompany_name(rs.getString("NameCompany"));
				listStudentTab1Bean.setCompany_id(rs.getInt("Company_id"));
				listStudentTab1Bean.setAddress_company(rs.getString("AddressCompany"));
				listStudentTab1Bean.setDistrict_company(rs.getString("DistrictCompany"));
				listStudentTab1Bean.setAmphur_company(rs.getString("AmphurCompany"));
				listStudentTab1Bean.setProvince_company(rs.getString("ProvinceCompany"));
				listStudentTab1Bean.setPost_code_company(rs.getString("PostcodeCompany"));
				listStudentTab1Bean.setTelephone_company(rs.getString("TelephoneCompany"));
				listStudentTab1Bean.setName_contact(rs.getString("NameContact"));
				listStudentTab1Bean.setTelephone_contact(rs.getString("TelephoneContact"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return listStudentTab1Bean;
	}

	public String checkStatus(String status){
		if("�Դ����Ѻ������".equals(status) || "�͵ͺ�Ѻ".equals(status)){
			status = "�͡������";
		}
		return status;
	}
}
