package com.java.staff.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.staff.bean.ListStudentSelectCompanyBean;
import com.java.staff.bean.StudentSelectComapnyApStatusBean;
import com.java.util.PreparedStatementUtil;

public class TableStudentSelectCompanyDao {
	
	public ArrayList<ListStudentSelectCompanyBean> SelectListStudentSelectCompany(int apStatusID,int academic_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ArrayList<ListStudentSelectCompanyBean> list = new ArrayList<>();
		String query =  "SELECT  tb_user.StudentID,"
						+ "tb_title.Name_th AS titleName_th,"
				        + "tb_user.FirstName_th,"
				        + "tb_user.LastName_th,"
				        + "tb_faculty.Name AS facName,"
				        + "tb_division.Name AS divName,"
				        + "tb_company.NameCompany,"
				        + "tb_company.ID AS Company_id,"
				        + "tb_company.ProvinceCompany,"
				        + "tb_approval_status.Name AS Status,"
				        + "tb_coop03.SendDocuments,"
				        + "tb_student_select_company.Comment,"
				        + "tb_student_select_company.File,"
				        + "tb_student_select_company.UserID "
				        + "FROM tb_student_select_company "
				        + "JOIN tb_user  ON tb_user.ID = tb_student_select_company.UserID "
				        + "JOIN tb_title  ON tb_title.ID = tb_user.TitleID "
				        + "JOIN tb_faculty  ON tb_faculty.ID = tb_user.FacID "
				        + "JOIN tb_division  ON tb_division.ID = tb_user.DivID "
						+ "JOIN tb_rate_company  ON tb_rate_company.ID = tb_student_select_company.RateCompanyID_Temp "
						+ "JOIN tb_company  ON tb_company.ID = tb_rate_company.CompanyID "
						+ "JOIN tb_approval_status  ON tb_approval_status.ID = tb_student_select_company.Staff_ApStatusID "
						+ "JOIN tb_coop03  ON tb_coop03.UserID = tb_user.ID " ;
						
						if(apStatusID == 8){
							// �͡������
							query = query +"WHERE tb_student_select_company.Staff_ApStatusID = 9 OR tb_student_select_company.Staff_ApStatusID = 10 ";
						}
						else{
							query = query +"WHERE tb_student_select_company.Staff_ApStatusID = :ap_statusid ";
						}
				        
						query = query + "AND tb_student_select_company.Lv1_ApStatusID = 2 "
									  + "AND tb_student_select_company.Academic_year = :academic_id "
									  + "AND tb_user.RoleID = 1 ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			if(apStatusID != 8){
				preparedStatementUtil.setInt("ap_statusid", apStatusID);
			}
			preparedStatementUtil.setInt("academic_id", academic_id);
			rs = preparedStatementUtil.executeQuery();
			while(rs.next()){
				ListStudentSelectCompanyBean studentSelectCompanyBean = new ListStudentSelectCompanyBean();			
				studentSelectCompanyBean.setStudent_id(rs.getString("StudentID"));
				studentSelectCompanyBean.setTitle_name_th(rs.getString("titleName_th"));
				studentSelectCompanyBean.setFirstname_th(rs.getString("FirstName_th"));
				studentSelectCompanyBean.setLastname_th(rs.getString("LastName_th"));
				studentSelectCompanyBean.setFaculty_name(rs.getString("facName"));
				studentSelectCompanyBean.setDivision_name(rs.getString("divName"));
				studentSelectCompanyBean.setCompany_name(rs.getString("NameCompany"));
				studentSelectCompanyBean.setCompany_id(rs.getInt("Company_id"));
				studentSelectCompanyBean.setProvice(rs.getString("ProvinceCompany"));
				studentSelectCompanyBean.setStatus(rs.getString("Status"));
				studentSelectCompanyBean.setStatus_send_documents(rs.getString("SendDocuments"));
				studentSelectCompanyBean.setComment(rs.getString("Comment"));
				studentSelectCompanyBean.setFile(rs.getString("File"));
				studentSelectCompanyBean.setUser_id(rs.getInt("UserID"));
				list.add(studentSelectCompanyBean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public ArrayList<ListStudentSelectCompanyBean> SelectListStudentMatchCompany(int academic_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ArrayList<ListStudentSelectCompanyBean> list = new ArrayList<>();
		String query =  "SELECT  tb_user.StudentID,"
						+ "tb_title.Name_th AS titleName_th,"
				        + "tb_user.FirstName_th,"
				        + "tb_user.LastName_th,"
				        + "tb_faculty.Name AS facName,"
				        + "tb_division.Name AS divName,"
				        + "tb_division.ID AS divID,"
				        + "tb_student_select_company.UserID "
				        + "FROM tb_student_select_company "
				        
				        + "JOIN tb_user  ON tb_user.ID = tb_student_select_company.UserID "
				        + "JOIN tb_title  ON tb_title.ID = tb_user.TitleID "
				        + "JOIN tb_faculty  ON tb_faculty.ID = tb_user.FacID "
				        + "JOIN tb_division  ON tb_division.ID = tb_user.DivID "
				        + "JOIN tb_student_send_document  ON tb_student_send_document.UserID = tb_user.ID "
						+ "WHERE "
						+ " (tb_student_select_company.RateCompanyID IS null OR tb_student_select_company.Lv1_ApStatusID = 5 OR tb_student_select_company.Staff_ApStatusID = 12) "
						+ " AND (tb_student_select_company.Academic_year = :academic_id) AND (tb_student_send_document.Lv2_ApStatusID = 2)";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("academic_id", academic_id);
			rs = preparedStatementUtil.executeQuery();
			while(rs.next()){
				ListStudentSelectCompanyBean studentSelectCompanyBean = new ListStudentSelectCompanyBean();			
				studentSelectCompanyBean.setStudent_id(rs.getString("StudentID"));
				studentSelectCompanyBean.setTitle_name_th(rs.getString("titleName_th"));
				studentSelectCompanyBean.setFirstname_th(rs.getString("FirstName_th"));
				studentSelectCompanyBean.setLastname_th(rs.getString("LastName_th"));
				studentSelectCompanyBean.setFaculty_name(rs.getString("facName"));
				studentSelectCompanyBean.setDivision_name(rs.getString("divName"));
				studentSelectCompanyBean.setDivision_id(rs.getInt("divID"));
				studentSelectCompanyBean.setUser_id(rs.getInt("UserID"));
				list.add(studentSelectCompanyBean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public ListStudentSelectCompanyBean SelectStudentSelectCompany(int student_id,int academic_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ListStudentSelectCompanyBean studentSelectCompanyBean = new ListStudentSelectCompanyBean();
		String query =  "SELECT  tb_user.StudentID,"
						+ "tb_title.Name_th AS titleName_th,"
				        + "tb_user.FirstName_th,"
				        + "tb_user.LastName_th,"
				        + "tb_division.Name AS divName,"
				        + "tb_company.NameCompany,"
				        + "tb_company.ID AS Company_id,"
				        + "tb_company.ProvinceCompany,"
				        + "tb_approval_status.Name AS Status,"
				        + "tb_coop03.SendDocuments,"
				        + "tb_student_select_company.Comment,"
				        + "tb_student_select_company.File,"
				        + "tb_student_select_company.UserID "
				        + "FROM tb_student_select_company "
				        + "JOIN tb_user  ON tb_user.ID = tb_student_select_company.UserID "
				        + "JOIN tb_title  ON tb_title.ID = tb_user.TitleID "
				        + "JOIN tb_division  ON tb_division.ID = tb_user.DivID "
						+ "JOIN tb_rate_company  ON tb_rate_company.ID = tb_student_select_company.RateCompanyID_Temp "
						+ "JOIN tb_company  ON tb_company.ID = tb_rate_company.CompanyID "
						+ "JOIN tb_approval_status  ON tb_approval_status.ID = tb_student_select_company.Staff_ApStatusID "
						+ "JOIN tb_coop03  ON tb_coop03.UserID = tb_user.ID " 
						
						+ "WHERE tb_student_select_company.Staff_ApStatusID != 12 "
						+ "AND tb_student_select_company.UserID = :student_id "
						+ "AND tb_student_select_company.Academic_year = :academic_id "
						+ "AND tb_student_select_company.Lv1_ApStatusID = 2 "
						+ "AND tb_user.RoleID = 1 ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("student_id", student_id);
			preparedStatementUtil.setInt("academic_id", academic_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				studentSelectCompanyBean.setStudent_id(rs.getString("StudentID"));
				studentSelectCompanyBean.setTitle_name_th(rs.getString("titleName_th"));
				studentSelectCompanyBean.setFirstname_th(rs.getString("FirstName_th"));
				studentSelectCompanyBean.setLastname_th(rs.getString("LastName_th"));
				studentSelectCompanyBean.setDivision_name(rs.getString("divName"));
				studentSelectCompanyBean.setCompany_name(rs.getString("NameCompany"));
				studentSelectCompanyBean.setCompany_id(rs.getInt("Company_id"));
				studentSelectCompanyBean.setProvice(rs.getString("ProvinceCompany"));
				studentSelectCompanyBean.setStatus(rs.getString("Status"));
				studentSelectCompanyBean.setStatus_send_documents(rs.getString("SendDocuments"));
				studentSelectCompanyBean.setComment(rs.getString("Comment"));
				studentSelectCompanyBean.setFile(rs.getString("File"));
				studentSelectCompanyBean.setUser_id(rs.getInt("UserID"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return studentSelectCompanyBean;
	}
	
	public String SelectFilePath(int user_student_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		String file_path = "";
		String query =  "SELECT  tb_student_select_company.File "
				        + "FROM tb_student_select_company "
						+ "WHERE tb_student_select_company.UserID = :user_student_id ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("user_student_id", user_student_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				file_path = rs.getString("File");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return file_path;
	}
	
	public void UpdateStaffApStatus(StudentSelectComapnyApStatusBean selectComapnyApStatusBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_student_select_company SET ";
				   
				   if(selectComapnyApStatusBean.getStaff_ap_status_id() == 12){
					   // 12 = ���ͺ�Ѻ
					   query = query + "RateCompanyID = null , ";
				   }
				   query = query	+ "Staff_ApStatusID = :staff_ap_status_id,"
					   				+ "Staff_ApStatusBy = :staff_ap_status_by,"
					   				+ "Staff_ApStatusDate = :staff_ap_status_date,"
					   				+ "Comment = :comment,"
					   				+ "File = :file "
					   				+ "WHERE UserID = :user_student_id ";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("staff_ap_status_id",selectComapnyApStatusBean.getStaff_ap_status_id());
		   preparedStatementUtil.setInt("staff_ap_status_by",selectComapnyApStatusBean.getStaff_ap_status_by());
		   preparedStatementUtil.setString("staff_ap_status_date",selectComapnyApStatusBean.getStaff_ap_status_date());
		   preparedStatementUtil.setString("comment",selectComapnyApStatusBean.getComment());
		   preparedStatementUtil.setString("file",selectComapnyApStatusBean.getFile());
		   preparedStatementUtil.setInt("user_student_id",selectComapnyApStatusBean.getUser_student_id());
		   preparedStatementUtil.execute(); 
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void UpdateStaffApStatusNotCheck(StudentSelectComapnyApStatusBean selectComapnyApStatusBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_student_select_company SET "
					   		+ "Staff_ApStatusBy = :staff_ap_status_by,"
					   		+ "Staff_ApStatusDate = :staff_ap_status_date,"
					   		+ "Comment = :comment,"
					   		+ "File = :file "
					   		+ "WHERE UserID = :user_student_id ";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("staff_ap_status_by",selectComapnyApStatusBean.getStaff_ap_status_by());
		   preparedStatementUtil.setString("staff_ap_status_date",selectComapnyApStatusBean.getStaff_ap_status_date());
		   preparedStatementUtil.setString("comment",selectComapnyApStatusBean.getComment());
		   preparedStatementUtil.setString("file",selectComapnyApStatusBean.getFile());
		   preparedStatementUtil.setInt("user_student_id",selectComapnyApStatusBean.getUser_student_id());
		   preparedStatementUtil.execute(); 
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	public String getPathFile(int student_user_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		String file = "";
		String query = "SELECT File "
				+ " FROM tb_student_select_company"
				+ " WHERE UserID = :userid"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("userid", student_user_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				file = rs.getString("File");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return file;
	}
	
	public void UpdateNullFile(int student_user_id){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_student_select_company SET "
					   		+ "File = null "
					   		+ "WHERE UserID = :student_user_id ";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("student_user_id",student_user_id);
		   preparedStatementUtil.execute(); 
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
}
