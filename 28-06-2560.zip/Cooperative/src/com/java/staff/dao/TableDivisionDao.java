package com.java.staff.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.staff.bean.DivisionBean;
import com.java.util.PreparedStatementUtil;

public class TableDivisionDao {
	public ArrayList<DivisionBean> SelectListDivision(){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<DivisionBean> list = new ArrayList<DivisionBean>();
		String query =  "SELECT  tb_division.ID AS division_id,"
				+ "tb_division.Name AS division_name,"
				+ "tb_division.Initials AS division_initials,"
				+ "tb_faculty.ID AS faculty_id,"
				+ "tb_faculty.Name AS faculty_name "
		        + "FROM tb_division "
		        + "JOIN tb_faculty  ON tb_faculty.ID = tb_division.FacID ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			rs = prepareStatementUtil.executeQuery();
			while(rs.next()){
				DivisionBean divisionBean = new DivisionBean();
				divisionBean.setDivision_id(rs.getInt("division_id"));
				divisionBean.setDivision_name(rs.getString("division_name"));
				divisionBean.setDivision_initials(rs.getString("division_initials"));
				divisionBean.setFaculty_id(rs.getInt("faculty_id"));
				divisionBean.setFaculty_name(rs.getString("faculty_name"));
				list.add(divisionBean);
			}
			} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
}
