package com.java.staff.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.java.admin.bean.AcademicYearBean;
import com.java.admin.dao.TableAcademicYear;
import com.java.staff.bean.ListStudentSelectCompanyBean;
import com.java.staff.bean.StudentSelectComapnyApStatusBean;
import com.java.staff.dao.TableStudentSelectCompanyDao;

import com.java.student.bean.HistoryStatusBean;
import com.java.student.dao.TableApprovalStatusDao;
import com.java.student.dao.TableHistoryStatusDao;
import com.java.util.FileUploadUtil;

/**
 * Servlet implementation class EditStatus
 */
@WebServlet("/EditStatus")
public class EditStatus extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditStatus() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
			HttpSession session = request.getSession();
			String role = session.getAttribute("role").toString();
			if(role.equals("staff")){

				// set Academic Year
				TableAcademicYear tableAcademicYear = new TableAcademicYear();
				AcademicYearBean academicYearBean = new AcademicYearBean();
				academicYearBean = tableAcademicYear.getAcademic();
				session.setAttribute("Semester", academicYearBean.getSemester());
				session.setAttribute("Academic_year", academicYearBean.getAcademic_year());
				session.setAttribute("academic_year_id", academicYearBean.getId());
				
				String action = request.getParameter("action");
				
				if("EditCheck".equals(action)){
					//System.out.println("OK EditCheck");
					TableStudentSelectCompanyDao tableStudentSelectCompany = new TableStudentSelectCompanyDao();
					ListStudentSelectCompanyBean profile = new ListStudentSelectCompanyBean();
					int student_id = Integer.parseInt(request.getParameter("student_id"));
					profile = tableStudentSelectCompany.SelectStudentSelectCompany(student_id,academicYearBean.getId());
					session.setAttribute("user_student_id",profile.getUser_id());
					session.setAttribute("student_id",profile.getStudent_id());
					session.setAttribute("send_documents",profile.getStatus_send_documents());
					request.setAttribute("profile", profile);
					
					// check status do_post 㹡ó� status ��� �����ѹ�֡ history
					String ap_status = profile.getStatus();
					if("���ѧ���Թ���".equals(ap_status)){
						session.setAttribute("ap_status","7");
					}else if("�Դ����Ѻ������".equals(ap_status) || "�͵ͺ�Ѻ".equals(ap_status)){
						session.setAttribute("ap_status","8");
					}else if("�ͺ�Ѻ".equals(ap_status)){
						session.setAttribute("ap_status","11");
					}else if("�ѡ�֡�ҵԴ������˹�ҷ��".equals(ap_status)){
						session.setAttribute("ap_status","13");
					}else{
						session.setAttribute("ap_status","not_check");
					}
					
					doViewEditStatus(request, response);
					return;
				}

			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		response.setHeader("Pragma", "no-cache");
		response.setDateHeader("Expires", 0);
		
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		
		List<FileItem> items = null;
		String file = "";

		int user_staff_id = Integer.parseInt(session.getAttribute("UserID").toString());	
		int user_student_id = Integer.parseInt(session.getAttribute("user_student_id").toString());

		if(user_student_id != 0){
			try{
				TableStudentSelectCompanyDao tableStudentSelectCompany = new TableStudentSelectCompanyDao();
				String action = request.getParameter("action");
				if("Delete".equals(action)){
					// delete file
					String pathFile_Company = tableStudentSelectCompany.getPathFile(user_student_id);
					tableStudentSelectCompany.UpdateNullFile(user_student_id);
					FileUploadUtil.deleteFile(request, pathFile_Company);
					return;
				}

				/** get value **/
	        	StudentSelectComapnyApStatusBean selectComapnyApStatusBean = new StudentSelectComapnyApStatusBean();
				items = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
				String status_check = "";
				String comment = "";
				
					for (FileItem item : items) {    // loop item
//					      String fieldname = item.getFieldName();
//					      System.out.println(fieldname);
						
					     if (item.isFormField()) {
					      String fieldname = item.getFieldName();
					      
					      /* input */
					      if("status_check".equals(fieldname))     status_check = item.getString("UTF-8");
					      else if("comment".equals(fieldname))	   comment = item.getString("UTF-8");
					     
					      /* file */
					     }else if(!item.isFormField()){  
					    	// file other!!
					         if (!(item.getName().equals(""))) {
					        	 //System.out.println(item.getName());  // get name file
					        	 //System.out.println(item.getFieldName());  // get input name=uploadBtn
					        	 String student_id = session.getAttribute("student_id").toString();
					        	 file = FileUploadUtil.uploadFile(request, item,"student_company",student_id, Integer.toString(user_student_id),"pdf");
					             //System.out.println(file);
					         }else{
					        	 file = tableStudentSelectCompany.SelectFilePath(user_student_id);
					        	 //System.out.println(file);
					         }
					     }
					}
					/** #get value **/

				
	
				/** update status  **/
				// not check status radio  ,  check ��ӡѹ�Ѻ�ش���   ������ѹ�֡ŧ history
					String ap_status = session.getAttribute("ap_status").toString();
				if(("".equals(status_check)) || (status_check.equals(ap_status))){
					//System.out.println("status equals , status = '' ");
					selectComapnyApStatusBean.setStaff_ap_status_by(user_staff_id);
					selectComapnyApStatusBean.setStaff_ap_status_date(getDateDefaultToString());
					selectComapnyApStatusBean.setComment(comment);
					selectComapnyApStatusBean.setFile(file);
					selectComapnyApStatusBean.setUser_student_id(user_student_id);
					tableStudentSelectCompany.UpdateStaffApStatusNotCheck(selectComapnyApStatusBean);
					out.print("True Save");
					return;
				}
				
				// true check status radio
				int ap_status_id = Integer.parseInt(status_check);
				if(ap_status_id == 8){
					String send_documents = session.getAttribute("send_documents").toString();
					if("�ѡ�֡�����͡����ͧ".equals(send_documents)){
						selectComapnyApStatusBean.setStaff_ap_status_id(9);
					}else if("���ҧ���������͡���".equals(send_documents)){
						selectComapnyApStatusBean.setStaff_ap_status_id(10);
					}
				}else{
					selectComapnyApStatusBean.setStaff_ap_status_id(ap_status_id);
				}
				selectComapnyApStatusBean.setStaff_ap_status_by(user_staff_id);
				selectComapnyApStatusBean.setStaff_ap_status_date(getDateDefaultToString());
				selectComapnyApStatusBean.setComment(comment);
				selectComapnyApStatusBean.setFile(file);
				selectComapnyApStatusBean.setUser_student_id(user_student_id);
				tableStudentSelectCompany.UpdateStaffApStatus(selectComapnyApStatusBean);
				
				/** #update status  **/
				
				/** insert history **/
				/**
				 *  7 = ���ѧ���Թ���   ,  8  = �͡������   ,   11 = �ͺ�Ѻ   ,  12 = ���ͺ�Ѻ  ,   13 = �ѡ�֡�ҵԴ������˹�ҷ��
				 */
				TableApprovalStatusDao tableApprovalStatusDao = new TableApprovalStatusDao();
				String date = getDateDefaultToString();
				if(ap_status_id == 7){
					InsertHistory(date, "���˹�ҷ���ˡԨ�֡�ҨѴ��˹ѧ��ͤ͢���͹���������ѧʶҹ��Сͺ���", tableApprovalStatusDao.getStatusApproval(7),user_student_id);
				}else if(ap_status_id == 8){
					String send_documents = session.getAttribute("send_documents").toString();
					if("�ѡ�֡�����͡����ͧ".equals(send_documents)){
						InsertHistory(date, "���˹�ҷ���ˡԨ�֡�ҨѴ��˹ѧ��ͤ͢���͹���������ѧʶҹ��Сͺ���", tableApprovalStatusDao.getStatusApproval(9),user_student_id);
					}else if("���ҧ���������͡���".equals(send_documents)){
						InsertHistory(date, "�͡�õͺ�Ѻ�ҡʶҹ��Сͺ���", tableApprovalStatusDao.getStatusApproval(10),user_student_id);
					}
				}else if(ap_status_id == 11){
					InsertHistory(date, "�͡�õͺ�Ѻ�ҡʶҹ��Сͺ���", tableApprovalStatusDao.getStatusApproval(11),user_student_id);
				}else if(ap_status_id == 12){
					InsertHistory(date, "�͡�õͺ�Ѻ�ҡʶҹ��Сͺ���", tableApprovalStatusDao.getStatusApproval(12),user_student_id);
				}else if(ap_status_id == 13){
					InsertHistory(date, "�Դ������˹�ҷ���ˡԨ�֡��", tableApprovalStatusDao.getStatusApproval(13),user_student_id);
				}
				/** #insert history **/
				
			}catch(FileUploadException e){
				e.printStackTrace();
			}
			out.print("True Save");
			return;
		}else{
			// user_student_id = 0
			out.print("False Save");
			return;
		}
	}
	
	private void doViewEditStatus(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/staff/edit_status.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private String getDateDefaultToString(){
		LocalDate localDate = LocalDate.now();
		String date = DateTimeFormatter.ofPattern("dd/MM/yyy").format(localDate);
		String[] dateSplit = date.split("/");
		date = "";
		date = dateSplit[0]+"/"+dateSplit[1]+"/"+(Integer.parseInt(dateSplit[2])+543);
		return date;
	}
	
	private void InsertHistory(String date,String history,String status,int userid){
		HistoryStatusBean historyStatusBean = new HistoryStatusBean();
		historyStatusBean.setDate(date);
		historyStatusBean.setHistory(history);
		historyStatusBean.setStatus(status);
		historyStatusBean.setUserid(userid);
		TableHistoryStatusDao tableHistoryStatus = new TableHistoryStatusDao();
		tableHistoryStatus.InsertHistoryStatus(historyStatusBean);
	}
}
