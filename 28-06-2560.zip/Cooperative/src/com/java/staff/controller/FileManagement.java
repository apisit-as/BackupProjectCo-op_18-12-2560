package com.java.staff.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.java.staff.bean.FileManagementBean;
import com.java.staff.dao.TableFileManagementDao;
import com.java.util.FileUploadUtil;

/**
 * Servlet implementation class FileManagement
 */
@WebServlet("/FileManagement")
public class FileManagement extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FileManagement() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
			HttpSession session = request.getSession();
			String role = session.getAttribute("role").toString();
			if(role.equals("staff")){
				
				// get list file
				TableFileManagementDao tableFileManagementDao = new TableFileManagementDao();
				ArrayList<FileManagementBean> listFileManagement = new ArrayList<>();
				listFileManagement = tableFileManagementDao.SelectListFile();
				request.setAttribute("listFileManagement", listFileManagement);
				doViewFileManagement(request, response);
				
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		response.setHeader("Pragma", "no-cache");
		response.setDateHeader("Expires", 0);
		
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		
		List<FileItem> items = null;
		String file = "";
		Boolean check_repeat_value = false;
		
		String role = session.getAttribute("role").toString();
		if(role.equals("staff")){
			try{
				TableFileManagementDao tableFileManagementDao = new TableFileManagementDao();
				
				/** delete file **/
				String action = request.getParameter("action");
				if("Delete".equals(action)){
					// delete file
					int id = Integer.parseInt(request.getParameter("id"));
					String path_file = request.getParameter("path_file");
					tableFileManagementDao.deleteFileTable(id);
					FileUploadUtil.deleteFile(request, path_file);
					return;
				}
				/** #delete file **/
	
				/** get value **/
	        	FileManagementBean fileManagementBean = new FileManagementBean();
				items = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
					for (FileItem item : items) {    // loop item
	//				      String fieldname = item.getFieldName();
	//				      System.out.println(fieldname);
						
					     if (item.isFormField()) {
					      String fieldname = item.getFieldName();
					      
					      /* input */
					      if("code_file".equals(fieldname))     fileManagementBean.setCode_file(item.getString("UTF-8"));
					      else if("name_file".equals(fieldname))	 fileManagementBean.setName(item.getString("UTF-8"));
					      else if("type_file".equals(fieldname))	 fileManagementBean.setType(item.getString("UTF-8"));
					      else if("id_file".equals(fieldname))	 fileManagementBean.setId(Integer.parseInt(item.getString("UTF-8")));
					     
					      /* file */
					     }else if(!item.isFormField()){  
					    	// item other
					         if (!(item.getName().equals(""))) {
					        	 //System.out.println(item.getName());  // get name file
					        	 //System.out.println(item.getFieldName());  // get input name=uploadBtn
					        	 
					        	 /** check repeat_value **/
								 String new_name_file = fileManagementBean.getCode_file()+"_"+fileManagementBean.getName()+"."+fileManagementBean.getType().toLowerCase();
								 if(tableFileManagementDao.CheckRepeatValuePathFile(new_name_file)){
									 // RepeatValue
									out.print("RepeatValue");
									check_repeat_value = true;
									return;
								 }
								 
								 /** upload file **/
					        	 file = FileUploadUtil.uploadFile(request, item,"file_management",fileManagementBean.getCode_file(),fileManagementBean.getName(),fileManagementBean.getType().toLowerCase());
					        	 fileManagementBean.setPath_file(file);
					         }
					     }
					}
					/** #get value **/
	
					/** check repeat value **/
					if(check_repeat_value){
						return;
					}
					/** #check repeat value **/
					
					/** insert,update data **/
					if(!"".equals(file) && fileManagementBean.getId() == 0){
						// insert
						tableFileManagementDao.InsertFileManagement(fileManagementBean);
						//System.out.println("ok insert");
					}else{
						// update
						String old_name_file = tableFileManagementDao.getOldFile(fileManagementBean.getId());
						String new_name_file = fileManagementBean.getCode_file()+"_"+fileManagementBean.getName()+"."+fileManagementBean.getType().toLowerCase();
						
						 /** check repeat_value **/
						if(tableFileManagementDao.CheckRepeatValuePathFile(new_name_file)){
							out.print("RepeatValue");
							return;
						}
						
						/** re name file **/
						String path_file = FileUploadUtil.eidtFileManagement(request,"file_management",old_name_file,new_name_file);
						fileManagementBean.setPath_file(path_file);
//						System.out.println("old_name_file= "+old_name_file);
//						System.out.println("new_name_file= "+new_name_file);
//						System.out.println("path_file= "+path_file);
						tableFileManagementDao.UpdateFileManagement(fileManagementBean);
						//System.out.println("ok update");
					}
					/** #insert,update data **/
					
			}catch(FileUploadException e){
				e.printStackTrace();
			}
		}

	}
	private void doViewFileManagement(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/staff/file_management.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
}
