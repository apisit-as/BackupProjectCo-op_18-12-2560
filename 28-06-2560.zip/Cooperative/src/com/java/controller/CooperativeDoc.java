package com.java.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.admin.bean.AcademicYearBean;
import com.java.admin.dao.TableAcademicYear;
import com.java.staff.bean.FileManagementBean;
import com.java.staff.dao.TableFileManagementDao;

/**
 * Servlet implementation class CheckStatus
 */
@WebServlet("/CooperativeDoc")
public class CooperativeDoc extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CooperativeDoc() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  HttpSession session = request.getSession();

				// set Academic Year
				TableAcademicYear tableAcademicYear = new TableAcademicYear();
				AcademicYearBean academicYearBean = new AcademicYearBean();
				academicYearBean = tableAcademicYear.getAcademic();
				session.setAttribute("Semester", academicYearBean.getSemester());
				session.setAttribute("Academic_year", academicYearBean.getAcademic_year());
				
				// get list file
				TableFileManagementDao tableFileManagementDao = new TableFileManagementDao();
				ArrayList<FileManagementBean> listFileManagement = new ArrayList<>();
				listFileManagement = tableFileManagementDao.SelectListFile();
				request.setAttribute("listFileManagement", listFileManagement);

				doViewCooperativeDocument(request, response);
			
	}

	private void doViewCooperativeDocument(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/other/cooperative_document.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}	
}
