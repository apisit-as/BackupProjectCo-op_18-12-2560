package com.java.admin.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.admin.bean.FacultyBean;
import com.java.admin.dao.TableDivisionDao;
import com.java.admin.dao.TableFacultyDao;
import com.java.admin.dao.NotStudentDeleteUserDao;
import com.java.admin.dao.StudentDeleteUserDao;
import com.java.admin.dao.UserManagementDao;
import com.java.list.bean.FacltyBean;
import com.java.list.dao.FacultySelectListDao;
import com.java.admin.bean.DivisionBean;
import com.java.student.bean.UserBean;
import com.java.util.FileUploadUtil;

/**
 * Servlet implementation class StudentManagement
 */
@WebServlet("/UserManagement")
public class UserManagement extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserManagement() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
		  HttpSession session = request.getSession();
		  String role = session.getAttribute("role").toString();
		  
		  if(role.equals("admin")){
			  session.setAttribute("role_admin", "false");
		  }
		  
		  String role_admin = session.getAttribute("role_admin").toString();
		  
		  // role admin
		  if(role.equals("admin") || role_admin.equals("true")){
				ArrayList<UserBean> userList = new ArrayList<UserBean>();
				ArrayList<FacultyBean> listFaclty = new ArrayList<FacultyBean>();
				
				UserManagementDao tableUserDao = new UserManagementDao();
				TableFacultyDao tableFacultyDao = new TableFacultyDao();

				userList = tableUserDao.getAllUserList(); // not role admin
				listFaclty = tableFacultyDao.getFacultyList(); 

				request.setAttribute("userList", userList);
				request.setAttribute("listFaclty", listFaclty);
				
				doViewUserManagement(request, response);
		  }

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		response.setHeader("Pragma", "no-cache");
		response.setDateHeader("Expires", 0);
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		  String role = session.getAttribute("role").toString();
		  if(role.equals("admin")){
			  session.setAttribute("role_admin", "false");
		  }
		  String role_admin = session.getAttribute("role_admin").toString();
		
		ArrayList<DivisionBean> listDivision = new ArrayList<DivisionBean>();
		TableDivisionDao tableDivisionDao = new TableDivisionDao();

		String action = request.getParameter("action");
		
		/* onchang select Fac to select Division  */
		if("GetListDivision".equals(action)){
			int divid = Integer.parseInt(request.getParameter("divid"));
			listDivision = tableDivisionDao.getDivisionList(divid);
			request.setAttribute("listDivision", listDivision);
			
			doGetListDivisionEdit(request, response);

		}
		/* # onchang select Fac to select Division  */
		
		/* onchang select Fac to select DivisionSearch */
		else if("DivisionSearch".equals(action)){
			int divid = Integer.parseInt(request.getParameter("divid"));
			listDivision = tableDivisionDao.getDivisionList(divid);

			request.setAttribute("listDivision", listDivision);
			doGetListDivisionSearch(request, response);
		}
		/* # onchang select Fac to select DivisionSearch  */
		
		
		/* Update  */
		else if("update".equals(action) && (role.equals("admin") || role_admin.equals("true"))){
			int id = Integer.parseInt(request.getParameter("id"));
			String facid = request.getParameter("facid");
			String divid = request.getParameter("divid");
			String roleid = request.getParameter("roleid");
			
			if(("".equals(facid)) && ("".equals(divid))){
				facid = null;
				divid = null;
			}
			
			UserManagementDao tableUserDao = new UserManagementDao();

			tableUserDao.updateProfile(id, facid, divid, roleid);
			
			checkLogout(request, response, role, id);

		}
		/* # Update  */
		
		/* Delete  */
		else if("Delete".equals(action) && (role.equals("admin") || role.equals("staff") || role_admin.equals("true"))){
			int userid = Integer.parseInt(request.getParameter("id"));  // studentid
			String studentid = request.getParameter("studentid");
			//System.out.println("StudentID = "+studentid);
			if(studentid.equals("") && (role.equals("admin") || role_admin.equals("true"))){
				/**
				 *  delete not student
				 *      teacher1 or teacher2  update null to tb_student_send_document,tb_student_select_company
				 *      staff update null to tb_student_select_company
				 */
				NotStudentDeleteUserDao notStudentDeleteUserDao = new NotStudentDeleteUserDao();
				String role_name = notStudentDeleteUserDao.getRoleName(userid);
				if("teacher1".equals(role_name) || "teacher2".equals(role_name)){
					notStudentDeleteUserDao.updateNullStuentSendDocument(userid);
					notStudentDeleteUserDao.updateNullStuentSelectCompany(userid, "teacher1");
				}else if("staff".equals(role_name)){
					notStudentDeleteUserDao.updateNullStuentSelectCompany(userid, "staff");
				}
				checkLogout(request, response, role, userid);
				notStudentDeleteUserDao.deleteUser(userid);
				//System.out.println("ok delete NOT student");
			}else{
				//System.out.println("OK student");
				/**
				 *   delete student
				 *       tb_student_send_document , tb_teacher_check_document , 
				 *       tb_student_select_company ,
				 *       tb_coop03 , tb_coop_02 , tb_profile , tb_transcript
				 *       tb_complete_status_document ,
				 *       tb_history_status
				 *       tb_user
				 */
				StudentDeleteUserDao studentDeleteUserDao = new StudentDeleteUserDao();
				
				// delete tb_student_send_document , tb_teacher_check_document
				if(studentDeleteUserDao.checkIdStudentSendDocument(userid)){
					int doc_id = studentDeleteUserDao.getIdStudentSendDocument(userid);
					studentDeleteUserDao.deleteCheckDocument(doc_id);
					studentDeleteUserDao.deleteStudentSendDocument(userid);
				}
				// delete tb_student_select_company
				String partFileCompany = studentDeleteUserDao.getFileStudentSelectCompany(userid);
			    FileUploadUtil.deleteFile(request, partFileCompany);
				studentDeleteUserDao.deleteStudentSelectCompany(userid);
				
				// delete tb_coop03
				if(studentDeleteUserDao.checkIdCoop03(userid)){
					int coop03id = studentDeleteUserDao.getIdCoop03(userid);
					String partPic = studentDeleteUserDao.getPictureCoop03(userid);
					FileUploadUtil.deleteFile(request, partPic);
					studentDeleteUserDao.deleteCoop03(userid, coop03id);
				}
				
				// delete tb_coop_02 
				if(studentDeleteUserDao.checkidCoop02(userid)){
					int coop02id = studentDeleteUserDao.getIdCoop02(userid);
					studentDeleteUserDao.deleteCoop02(userid, coop02id);
				}
				
				// delete tb_profile
				if(studentDeleteUserDao.checkIdProfile(userid)){
					int profileid = studentDeleteUserDao.getIdProfile(userid);
					studentDeleteUserDao.deleteProfile(userid, profileid);
				}
				
				// delete transcript file
				String partFileTranscript = studentDeleteUserDao.getTranscript(userid);
				FileUploadUtil.deleteFile(request, partFileTranscript);
				studentDeleteUserDao.deleteTranscript(userid);
				
				// delete copmlete status document
				studentDeleteUserDao.deleteCompleteStatusDocument(userid);
				
				// delete tb_history_status
				studentDeleteUserDao.deleteHistoryStatus(userid);
				
				//delete tb_user , file reprot
			    String nameFile = studentDeleteUserDao.getStudentID(userid)+"_"+Integer.toString(userid);
				FileUploadUtil.deleteReport(request, nameFile+"_coop02");
				FileUploadUtil.deleteReport(request, nameFile+"_coop03");
				FileUploadUtil.deleteReport(request, nameFile+"_coop05");
				studentDeleteUserDao.deleteUser(userid);
				//System.out.println("ok delete");
			}


		}
		/* # Delete  */
		
		else if(action.equals("getListFaculty")){
			ArrayList<FacltyBean> listFaclty = new ArrayList<FacltyBean>();
			FacultySelectListDao facultySelectListDao = new FacultySelectListDao();
			listFaclty = facultySelectListDao.getFacltyList();
			UserBean userBean = new UserBean();
			request.setAttribute("userBean", userBean);
			request.setAttribute("listFaclty", listFaclty);
			doViewListFaculty(request, response);
			return;
		}
		
	}
	
	private void doViewUserManagement(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/admin/user_management.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void doGetListDivisionSearch(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/search/division_list_search.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	private void doGetListDivisionEdit(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/admin/divison_list_edit_user.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void doViewListFaculty(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/faculty_list.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void checkLogout(HttpServletRequest request, HttpServletResponse response,String role,int id) throws IOException {
		HttpSession session = request.getSession();
		int UserID = 0;
		if(session.getAttribute("UserID") != null){
			UserID = Integer.parseInt(session.getAttribute("UserID").toString());
		}
		if((role.equals("staff") || role.equals("teacher1") || role.equals("teacher2")) && (UserID == id)){
			// �ó�  update,delete role �ͧ����ͧ
			PrintWriter out = response.getWriter();
			out.print("logout");
		}
	}

}
