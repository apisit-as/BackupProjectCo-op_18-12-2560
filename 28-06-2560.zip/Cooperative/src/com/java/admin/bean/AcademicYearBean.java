package com.java.admin.bean;

public class AcademicYearBean {
	private int id;
	private String semester;
	private String academic_year;
	private String start_date_recruitment;
	private String stop_date_recruitment;
	private String start_date_workout;
	private String stop_date_workout;
	private String check_select;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSemester() {
		return semester;
	}
	public void setSemester(String semester) {
		this.semester = semester;
	}
	public String getAcademic_year() {
		return academic_year;
	}
	public void setAcademic_year(String academic_year) {
		this.academic_year = academic_year;
	}
	public String getStart_date_recruitment() {
		return start_date_recruitment;
	}
	public void setStart_date_recruitment(String start_date_recruitment) {
		this.start_date_recruitment = start_date_recruitment;
	}
	public String getStop_date_recruitment() {
		return stop_date_recruitment;
	}
	public void setStop_date_recruitment(String stop_date_recruitment) {
		this.stop_date_recruitment = stop_date_recruitment;
	}
	public String getStart_date_workout() {
		return start_date_workout;
	}
	public void setStart_date_workout(String start_date_workout) {
		this.start_date_workout = start_date_workout;
	}
	public String getStop_date_workout() {
		return stop_date_workout;
	}
	public void setStop_date_workout(String stop_date_workout) {
		this.stop_date_workout = stop_date_workout;
	}
	public String getCheck_select() {
		return check_select;
	}
	public void setCheck_select(String check_select) {
		this.check_select = check_select;
	}
	
}
