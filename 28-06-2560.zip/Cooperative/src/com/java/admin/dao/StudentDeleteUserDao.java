package com.java.admin.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.util.PreparedStatementUtil;

public class StudentDeleteUserDao {
	
	public Boolean checkIdCoop03(int userid){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = "SELECT True as isDelete FROM tb_coop03 where UserID = :userid LIMIT 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("userid", userid);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getBoolean("isDelete");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public int getIdCoop03(int userid){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		int value = 0;
		String query = "SELECT ID FROM tb_coop03 where UserID = :userid LIMIT 1 ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("userid", userid);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				value = rs.getInt("ID");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public Boolean checkIdStudentSendDocument(int userid){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = "SELECT True as isDelete FROM tb_student_send_document WHERE UserID = :userid LIMIT 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("userid", userid);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getBoolean("isDelete");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public String getPictureCoop03(int userid){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		String part = "";
		String query = "SELECT Picture FROM tb_coop03 where UserID = :userid LIMIT 1 ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("userid", userid);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				part = rs.getString("Picture");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return part;
	}
	
	public String getTranscript(int userid){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		String part = "";
		String query = "SELECT File FROM tb_transcript where UserID = :userid LIMIT 1 ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("userid", userid);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				part = rs.getString("File");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return part;
	}
	
	public String getFileStudentSelectCompany(int userid){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		String part = "";
		String query = "SELECT File FROM tb_student_select_company where UserID = :userid LIMIT 1 ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("userid", userid);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				part = rs.getString("File");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return part;
	}
	
	

	public Boolean checkidCoop02(int userid){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
	
		Boolean value = false;
		String query = "SELECT True as isDelete FROM tb_coop02 where UserID = :userid LIMIT 1";

		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("userid", userid);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				value = rs.getBoolean("isDelete");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return value;
	}
	
	public int getIdCoop02(int userid){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
	
		int value = 0;
		String query = "SELECT ID FROM tb_coop02 where UserID = :userid LIMIT 1 ";

		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("userid", userid);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				value = rs.getInt("ID");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return value;
	}
	
	
	public Boolean checkIdProfile(int userid){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
	
		Boolean value = false;
		String query = "SELECT True as isDelete FROM tb_profile where UserID = :userid LIMIT 1";

		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("userid", userid);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				value = rs.getBoolean("isDelete");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return value;
	}
	
	public int getIdProfile(int userid){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		int value = 0;
		String query = "SELECT ID FROM tb_profile where UserID = :userid LIMIT 1 ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("userid", userid);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getInt("ID");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public int getIdStudentSendDocument(int userid){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		int value = 0;
		String query = "SELECT ID FROM tb_student_send_document where UserID = :userid LIMIT 1 ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("userid", userid);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getInt("ID");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public String getStudentID(int userid){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		String value = "";
		String query = "SELECT StudentID FROM tb_user where ID = :userid LIMIT 1 ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("userid", userid);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getString("StudentID");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public void deleteUser(int userid){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "DELETE FROM tb_user WHERE ID = :userid";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("userid", userid);
		   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void deleteProfile(int userid, int profileid){
		PreparedStatementUtil preparedStatementUtil = null;
		/**
		 * delete tb_family, tb_address, tb_profile
		 */
		  String query = "";
		  try{
			   query = "DELETE FROM tb_family WHERE ProfileID = :profileid";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("profileid", profileid);
			   preparedStatementUtil.execute(); 
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
		  
		  try{
			   query = "DELETE FROM tb_address WHERE ProfileID = :profileid";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("profileid", profileid);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
		  
		  try{
			   query = "DELETE FROM tb_profile WHERE UserID = :userid";
			   preparedStatementUtil = new PreparedStatementUtil(query);  
			   preparedStatementUtil.setInt("userid", userid);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}

	public void deleteCoop02(int userid, int coop02id){
		PreparedStatementUtil preparedStatementUtil = null;
		/**
		 *  delete  tb_language02, tb_select_job02, tb_coop02
		 */
		String query = "";
		  try{
			   query = "DELETE FROM tb_language02 WHERE Coop02ID = :coop02id";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("coop02id", coop02id);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
		  
		  try{
			   query = "DELETE FROM tb_select_job02 WHERE Coop02ID = :coop02id";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("coop02id", coop02id);
			   preparedStatementUtil.execute();

		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
		  
		  try{
			   query = "DELETE FROM tb_coop02 WHERE UserID = :userid";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("userid", userid);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void deleteTranscript(int UserID){
		PreparedStatementUtil preparedStatementUtil = null;
		String query = "";
		  try{
			   query = "DELETE FROM tb_transcript WHERE UserID = :userid";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("userid", UserID);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void deleteCoop03(int userid, int coop03id){
		/**
		 *  delete   tb_language03 , tb_activity , tb_career , tb_training , tb_relative , tb_education , tb_coop03
		 */
		PreparedStatementUtil preparedStatementUtil = null;
		String query = "";
		  try{
			   query = "DELETE FROM tb_language03 WHERE Coop03ID = :coop03id";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("coop03id", coop03id);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
		
		  try{
			   query = "DELETE FROM tb_activity WHERE Coop03ID = :coop03id";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("coop03id", coop03id);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
		
		  try{   
			   query = "DELETE FROM tb_career WHERE Coop03ID = :coop03id";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("coop03id", coop03id);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
		
		  try{  
			   query = "DELETE FROM tb_training WHERE Coop03ID = :coop03id";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("coop03id", coop03id);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
		
		  try{  
			   query = "DELETE FROM tb_relative WHERE Coop03ID = :coop03id";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("coop03id", coop03id);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
		  
		  try{
			   query = "DELETE FROM tb_education WHERE Coop03ID = :coop03id";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("coop03id", coop03id);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
		  
		  try{
			   query = "DELETE FROM tb_coop03 WHERE UserID = :userid";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("userid", userid);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}

	public void deleteCompleteStatusDocument(int UserID){
		PreparedStatementUtil preparedStatementUtil = null;
		String query = "";
		  try{
			   query = "DELETE FROM tb_complete_status_document WHERE UserID = :userid";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("userid", UserID);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void deleteCheckDocument(int doc_id){
		PreparedStatementUtil preparedStatementUtil = null;
		String query = "";
		  try{
			   query = "DELETE FROM tb_teacher_check_document WHERE DocID = :doc_id";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("doc_id", doc_id);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	public void deleteStudentSendDocument(int userid){
		PreparedStatementUtil preparedStatementUtil = null;
		String query = "";
		  try{
			   query = "DELETE FROM tb_student_send_document WHERE UserID = :userid";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("userid", userid);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void deleteStudentSelectCompany(int userid){
		PreparedStatementUtil preparedStatementUtil = null;
		String query = "";
		  try{
			   query = "DELETE FROM tb_student_select_company WHERE UserID = :userid";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("userid", userid);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void deleteHistoryStatus(int userid){
		PreparedStatementUtil preparedStatementUtil = null;
		String query = "";
		  try{
			   query = "DELETE FROM tb_history_status WHERE UserID = :userid";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("userid", userid);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
}
