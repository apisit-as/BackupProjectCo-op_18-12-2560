package com.java.admin.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.util.PreparedStatementUtil;

public class DeleteStudentSendDocumentDao {
	public ArrayList<Integer> getUserIdStudent(int academic_year_id){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<Integer> user_id = new ArrayList<>();
		String query = "SELECT UserID FROM tb_student_send_document where Academic_year = :academic_year_id LIMIT 1 ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("academic_year_id", academic_year_id);
			rs = prepareStatementUtil.executeQuery();
			while(rs.next()){
				user_id.add(rs.getInt("UserID"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return user_id;
	}
	public ArrayList<Integer> getIdStudentSendDocument(int academic_year_id){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<Integer> number = new ArrayList<>();
		String query = "SELECT ID FROM tb_student_send_document WHERE Academic_year = :academic_year_id LIMIT 1 ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("academic_year_id", academic_year_id);
			rs = prepareStatementUtil.executeQuery();
			while(rs.next()){
				number.add(rs.getInt("ID"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return number;
	}
	public void deleteStudentSendDocument(ArrayList<Integer> student_send_document_id){
		PreparedStatementUtil preparedStatementUtil = null;
		for (Integer number : student_send_document_id) {
			  try{
				   String query = "DELETE FROM tb_teacher_check_document WHERE DocID = :doc_id";
				   preparedStatementUtil = new PreparedStatementUtil(query);
				   preparedStatementUtil.setInt("doc_id", number);
				   preparedStatementUtil.execute();
				  }catch(Exception e){
				     e.printStackTrace();
				  }finally{
				   if(preparedStatementUtil != null)
					try {
						preparedStatementUtil.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				  }
			  
			  try{
				   String query = "DELETE FROM tb_student_send_document WHERE ID = :id";
				   preparedStatementUtil = new PreparedStatementUtil(query);
				   preparedStatementUtil.setInt("id", number);
				   preparedStatementUtil.execute();
				  }catch(Exception e){
				     e.printStackTrace();
				  }finally{
				   if(preparedStatementUtil != null)
					try {
						preparedStatementUtil.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				  }
		}

	}
}
