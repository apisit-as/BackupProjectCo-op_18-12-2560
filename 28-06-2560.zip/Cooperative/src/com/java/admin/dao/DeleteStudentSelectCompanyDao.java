package com.java.admin.dao;

import java.sql.SQLException;

import com.java.util.PreparedStatementUtil;

public class DeleteStudentSelectCompanyDao {
	
	public void deleteStudentSelectCompany(int academic_year_id){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
			   String query = "DELETE FROM tb_student_select_company WHERE Academic_year = :academic_year_id ";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("academic_year_id", academic_year_id);
			   preparedStatementUtil.execute();
			  }catch(Exception e){
			     e.printStackTrace();
			  }finally{
			   if(preparedStatementUtil != null)
				try {
					preparedStatementUtil.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			  }
	}
}
