package com.java.admin.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.util.PreparedStatementUtil;

public class NotStudentDeleteUserDao {
	public String getRoleName(int user_id){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		String role_name = "";
		String query = "SELECT tb_role.NameENG "
				+ " FROM tb_user "
				+ " JOIN tb_role on tb_role.ID = tb_user.RoleID "
				+ " WHERE tb_user.ID = :user_id LIMIT 1 ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("user_id", user_id);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				role_name = rs.getString("NameENG");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return role_name;
	}
	
	public void updateNullStuentSendDocument(int ap_status_by_id){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
			   String query = "UPDATE tb_student_send_document SET "
			   				+ "Lv1_ApStatusBy = null " 
			   				+ "WHERE Lv1_ApStatusBy = :ap_status_by_id";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("ap_status_by_id", ap_status_by_id);
			   preparedStatementUtil.execute();   
			  }catch(Exception e){
			   e.printStackTrace();
			  }finally{
			   if(preparedStatementUtil != null)
				try {
					preparedStatementUtil.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			  }
		  
		  try{
			   String query = "UPDATE tb_student_send_document SET "
			   				+ "Lv2_ApStatusBy = null " 
			   				+ "WHERE Lv2_ApStatusBy = :ap_status_by_id";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("ap_status_by_id", ap_status_by_id);
			   preparedStatementUtil.execute();   
			  }catch(Exception e){
			   e.printStackTrace();
			  }finally{
			   if(preparedStatementUtil != null)
				try {
					preparedStatementUtil.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			  }
	}
	public void updateNullStuentSelectCompany(int ap_status_by_id,String role_name){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		if("teacher1".equals(role_name)){
			  try{
				   String query = "UPDATE tb_student_select_company SET "
				   				+ "Lv1_ApStatusBy = null " 
				   				+ "WHERE Lv1_ApStatusBy = :ap_status_by_id";
				   preparedStatementUtil = new PreparedStatementUtil(query);
				   preparedStatementUtil.setInt("ap_status_by_id", ap_status_by_id);
				   preparedStatementUtil.execute();   
				  }catch(Exception e){
				   e.printStackTrace();
				  }finally{
				   if(preparedStatementUtil != null)
					try {
						preparedStatementUtil.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				  }
		}else if("staff".equals(role_name)){
			  try{
				   String query = "UPDATE tb_student_select_company SET "
				   				+ "Staff_ApStatusBy = null " 
				   				+ "WHERE Staff_ApStatusBy = :ap_status_by_id";
				   preparedStatementUtil = new PreparedStatementUtil(query);
				   preparedStatementUtil.setInt("ap_status_by_id", ap_status_by_id);
				   preparedStatementUtil.execute();   
				  }catch(Exception e){
				   e.printStackTrace();
				  }finally{
				   if(preparedStatementUtil != null)
					try {
						preparedStatementUtil.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				  }
		}
	}
	public void deleteUser(int userid){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "DELETE FROM tb_user WHERE ID = :userid";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("userid", userid);
		   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
}
