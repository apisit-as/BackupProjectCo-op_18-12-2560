package com.java.util;

import java.io.File;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;

public class FileUploadUtil {
	public static String uploadFile(HttpServletRequest request, FileItem item,String nameFolder, String nameFile1, String nameFile2,String type) {
		  String root = request.getServletContext().getRealPath("/");
		  //System.out.println(root); 
		  //  C:\Users\Administrator\Desktop\pj-web\web\eclipse\project\.metadata\.plugins\org.eclipse.wst.server.core\tmp1\wtpwebapps\Cooperative\
		  File file = null;
		  String[] tempCk;
		  String typeFile = "";
		  String nameFile = nameFile1 + "_" + nameFile2;
		  try {
		   if (!item.isFormField()) {
		    file = new File(root, "Upload/File/"+nameFolder);
		    if (!file.exists()) {
		     file.mkdirs();
		    }
		    tempCk = item.getName().split("\\\\");

		    String temp = tempCk[tempCk.length - 1];
		    tempCk = temp.split("\\.");
		  //  typeFile = tempCk[tempCk.length - 1];
		    typeFile = type;
		    file = new File(file, nameFile + "." + typeFile);
		    item.write(file);
		   }

		   return "Upload/File/"+nameFolder + "/" + nameFile + "." + typeFile;
		  } catch (FileUploadException e) {
		   e.printStackTrace();
		   return null;
		  } catch (Exception e) {
		   e.printStackTrace();
		   return null;
		  }
		 }
	
	public static String eidtFileManagement(HttpServletRequest request,String nameFolder,String old_name_file,String new_name_file) {
		  String root = request.getServletContext().getRealPath("/");
		  //System.out.println(root); 
		  //  C:\Users\Administrator\Desktop\pj-web\web\eclipse\project\.metadata\.plugins\org.eclipse.wst.server.core\tmp1\wtpwebapps\Cooperative\
		  try {
			  
			// File (or directory) with old name
			  File file = new File(root, "Upload/File/"+nameFolder+"/"+old_name_file);

			  // File (or directory) with new name
			  File file2 = new File(root, "Upload/File/"+nameFolder+"/"+new_name_file);

			  if (file2.exists())
			     throw new java.io.IOException("file exists");

			  // Rename file (or directory)
			  boolean success = file.renameTo(file2);

			  if (!success) {
			     // File was not successfully renamed
				  System.out.println("fail rename");
			  }
			  
		  } catch (Exception e) {
			   e.printStackTrace();
		  }
		  
		  return "Upload/File/"+nameFolder+"/"+new_name_file;
		 }
	
	
	public static void deleteFile(HttpServletRequest request, String part) {
		  String root = request.getServletContext().getRealPath("/");
		  //System.out.println(root); 
		  //  C:\Users\Administrator\Desktop\pj-web\web\eclipse\project\.metadata\.plugins\org.eclipse.wst.server.core\tmp1\wtpwebapps\Cooperative\
		  File file = null;

		  try {
		    file = new File(root, ""+part);
		    //boolean empty = file.length() == 0;
		   // System.out.println("file = "+empty);  // �� image   == false
		    
		    if(file.delete()){
			    //System.out.println("OK delete PIC");
		    }

		  } catch (Exception e) {
		   e.printStackTrace();
		  }
	}
	
	public static void deleteReport(HttpServletRequest request, String nameFile) {
		// name file   573333013017-1_6_coop02
		
		  String root = request.getServletContext().getRealPath("/");
		  //System.out.println(root); 
		  //  C:\Users\Administrator\Desktop\pj-web\web\eclipse\project\.metadata\.plugins\org.eclipse.wst.server.core\tmp1\wtpwebapps\Cooperative\
		  File file = null;
			  try {
				    file = new File(root, "Upload/File/Report/PDF/"+nameFile+".pdf");
				    //boolean empty = file.length() == 0;
				    //System.out.println("file = "+empty);  // �� image   == false
				    if(file.delete()){
					    //System.out.println("OK delete pdf");
				    }

			  } catch (Exception e) {
				   e.printStackTrace();
			  }
	}
}
