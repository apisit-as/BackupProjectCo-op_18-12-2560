package com.java.student.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.student.bean.ActivityBean;
import com.java.student.bean.AddressBean;
import com.java.student.bean.CareerBean;
import com.java.student.bean.Coop02Bean;
import com.java.student.bean.Coop03Bean;
import com.java.student.bean.EducationBean;
import com.java.student.bean.FamilyBean;
import com.java.student.bean.Language02Bean;
import com.java.student.bean.Language03Bean;
import com.java.student.bean.ProfileBean;
import com.java.student.bean.RelativeBean;
import com.java.student.bean.SelectJob02Bean;
import com.java.student.bean.TrainingBean;
import com.java.student.bean.UserBean;
import com.java.student.dao.TableActivityDao;
import com.java.student.dao.TableAddressDao;
import com.java.student.dao.TableCareerDao;
import com.java.student.dao.TableCompleteStatusDocument;
import com.java.student.dao.TableCoop02Dao;
import com.java.student.dao.TableCoop03Dao;
import com.java.student.dao.TableEducationDao;
import com.java.student.dao.TableFamilyDao;
import com.java.student.dao.TableLanguage02Dao;
import com.java.student.dao.TableLanguage03Dao;
import com.java.student.dao.TableProfileDao;
import com.java.student.dao.TableRelativeDao;
import com.java.student.dao.TableSelectJob02Dao;
import com.java.student.dao.TableTrainingDao;
import com.java.student.dao.TableUserDao;
import com.java.util.report.ReportCoop02;
import com.java.util.report.ReportCoop03;

/**
 * Servlet implementation class CreateReportCoop02
 */
@WebServlet("/CreateReport")
public class CreateReport extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateReport() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		
		
		// check role select company
		int UserID = 0;
		if("staff".equals(session.getAttribute("role").toString())){
			UserID = Integer.parseInt(session.getAttribute("studnet_user_id").toString());
		}else if("student".equals(session.getAttribute("role").toString())){
			UserID = Integer.parseInt(session.getAttribute("UserID").toString());
		}

		String action = request.getParameter("action");
		String part = null;
		TableCompleteStatusDocument tableCompleteStatusDocument = new TableCompleteStatusDocument();
		if(tableCompleteStatusDocument.checkReport(UserID)){
			if(action.equals("createCoop02")){
				 reportCoop02(request, UserID);
				 part = getPartDocument("pdfCoop02", UserID);
			}
			else if(action.equals("createCoop03")){
				 reportCoop03(request, UserID);
				 part = getPartDocument("pdfCoop03", UserID);
			}
			out.print(part);
		}else{
			out.print("ErrorReport");
		}
		
		

	}
	private void reportCoop02(HttpServletRequest request,int userid) {
		TableUserDao tableUserDao = new TableUserDao();
		UserBean userBean = new UserBean();
		userBean = tableUserDao.getTableUser(userid);
		
		TableProfileDao tableProfileDao = new TableProfileDao();
		ProfileBean profileBean = new ProfileBean();
		TableAddressDao tableAddressDao = new TableAddressDao();
		AddressBean addressBean1 = new AddressBean();
		AddressBean addressBean2 = new AddressBean();
		AddressBean addressBean3 = new AddressBean();
		TableFamilyDao tableFamilyDao = new TableFamilyDao();
		FamilyBean familyBean = new FamilyBean();
		
		// tb_profile, tb_address  , tb_family >>tye  parent_family
		profileBean = tableProfileDao.SelectProfile(userid);
		addressBean1 = tableAddressDao.SelectAddressType(profileBean.getId(), "original_address");
		addressBean1.setAmphurname(subString(addressBean1.getAmphurname()));
		addressBean1.setDistrictname(subString(addressBean1.getDistrictname()));

		addressBean2 = tableAddressDao.SelectAddressType(profileBean.getId(), "semester_address");
		addressBean2.setAmphurname(subString(addressBean2.getAmphurname()));
		addressBean2.setDistrictname(subString(addressBean2.getDistrictname()));
		
		addressBean3 = tableAddressDao.SelectAddressType(profileBean.getId(), "parent_address");
		addressBean3.setAmphurname(subString(addressBean3.getAmphurname()));
		addressBean3.setDistrictname(subString(addressBean3.getDistrictname()));
		
		familyBean = tableFamilyDao.SelectFamilyType(profileBean.getId(), "parent_family");
		
		
		TableCoop02Dao tableCoop02Dao2 = new TableCoop02Dao();
		TableSelectJob02Dao tableSelectJob02Dao2 = new TableSelectJob02Dao();
		TableLanguage02Dao tableLanguage02Dao2 = new TableLanguage02Dao();
		Coop02Bean coop02Bean2 = new Coop02Bean();
		SelectJob02Bean selectJob02Bean2 = new SelectJob02Bean();
		Language02Bean language02Bean2 = new Language02Bean();
		
		// coop02, select, language
		coop02Bean2 = tableCoop02Dao2.SelectCoop02(userid);
		selectJob02Bean2 = tableSelectJob02Dao2.SelectJob02(coop02Bean2.getId());
		language02Bean2 = tableLanguage02Dao2.SelectLanguage02(coop02Bean2.getId());
		
		// date
	      Date date = new Date( );
	      SimpleDateFormat ft =  new SimpleDateFormat ("dd.MM.yyyy");
	      String dateText = ft.format(date);
	      String[] dateSplit = dateText.split("[.]");
	      String [] dateMonthNumCheck = {"01","02","03","04","05","06","07","08","09","10","11","12"};
	      String [] dateMonthStrCheck = {"�.�.","�.�.","��.�.","��.�.","�.�.","��.�.","�.�.","�.�.","�.�.","�.�.","�.�.","�.�."};
	      
	      String date_day = dateSplit[0];
	      for(int i=0; i<=8; i++){
	    	  if(dateMonthNumCheck[i].equals(date_day)){
	    		  date_day = Integer.toString(i+1);
	    	  }
	      }
	      
	      String date_month = dateSplit[1];
	      for(int i=0; i<12; i++){
	    	  if(dateMonthNumCheck[i].equals(date_month)){
	    		  date_month = dateMonthStrCheck[i];
	    	  }
	      }

	      String date_year = Integer.toString(Integer.parseInt(dateSplit[2])+543);

		// save report  pdf,docx 
		ReportCoop02 reportCoop02 = new ReportCoop02();
		reportCoop02.insertCoop02Pdf(request,userBean,profileBean,addressBean1,addressBean2,addressBean3,familyBean,coop02Bean2,selectJob02Bean2,language02Bean2,date_day,date_month,date_year);
		//reportCoop02.insertCoop02Docx(request,userBean,profileBean,addressBean1,addressBean2,addressBean3,familyBean,coop02Bean2,selectJob02Bean2,language02Bean2);
		
	}
	
	public void reportCoop03(HttpServletRequest request,int userid) {
		// tb_user, tb_profile, tb_adddress, tb_family, coop03 all
		TableUserDao tableUserDao = new TableUserDao();
		UserBean userBean = new UserBean();
		userBean = tableUserDao.getTableUser(userid);
		
		TableProfileDao tableProfileDao = new TableProfileDao();
		ProfileBean profileBean = new ProfileBean();
		profileBean = tableProfileDao.SelectProfile(userid);
		
		// convert date
		String[] str1 = profileBean.getIssue_date().split("-");    //2016-11-20
		String[] str2 = profileBean.getExpiry_date().split("-");
		String[] str3 = profileBean.getBirthday().split("-");
		profileBean.setIssue_date(str1[2]+"/"+str1[1]+"/"+(Integer.parseInt(str1[0])+543));
		profileBean.setExpiry_date(str2[2]+"/"+str2[1]+"/"+(Integer.parseInt(str2[0])+543));
		profileBean.setBirthday(str3[2]+"/"+str3[1]+"/"+(Integer.parseInt(str3[0])+543));
		
		// address
		TableAddressDao tableAddressDao = new TableAddressDao();
		List<AddressBean> addressBeanList = new ArrayList<AddressBean>();
		
		AddressBean addressBean1 = new AddressBean();
		AddressBean addressBean2 = new AddressBean();
		AddressBean addressBean3 = new AddressBean();
		addressBean1 = tableAddressDao.SelectAddressType(profileBean.getId(), "original_address");
		addressBean1.setAmphurname(subString(addressBean1.getAmphurname()));
		addressBean1.setDistrictname(subString(addressBean1.getDistrictname()));
		
		addressBean2 = tableAddressDao.SelectAddressType(profileBean.getId(), "semester_address");
		addressBean2.setAmphurname(subString(addressBean2.getAmphurname()));
		addressBean2.setDistrictname(subString(addressBean2.getDistrictname()));
		
		addressBean3 = tableAddressDao.SelectAddressType(profileBean.getId(), "parent_address");
		addressBean3.setAmphurname(subString(addressBean3.getAmphurname()));
		addressBean3.setDistrictname(subString(addressBean3.getDistrictname()));
		
		addressBeanList.add(addressBean1);
		addressBeanList.add(addressBean2);
		addressBeanList.add(addressBean3);
		
		// family
		TableFamilyDao tableFamilyDao = new TableFamilyDao();
		List<FamilyBean> familyBeanList = new ArrayList<FamilyBean>();
		familyBeanList.add(tableFamilyDao.SelectFamilyType(profileBean.getId(), "father_family"));
		familyBeanList.add(tableFamilyDao.SelectFamilyType(profileBean.getId(), "mother_family"));
		familyBeanList.add(tableFamilyDao.SelectFamilyType(profileBean.getId(), "parent_family"));
		
		TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
		Coop03Bean coop03Bean = new Coop03Bean();
		int Coop03ID = tableCoop03Dao.getKeyIDCoop03(userid);
		coop03Bean = tableCoop03Dao.SelectCoop03ReportPdf(userid);
		
		TableEducationDao tableEducationDao = new TableEducationDao();
		List<EducationBean> educationBeansList = new ArrayList<EducationBean>();
		educationBeansList.add(tableEducationDao.SelectEducation(Coop03ID, "Primary"));
		educationBeansList.add(tableEducationDao.SelectEducation(Coop03ID, "Secondary"));
		educationBeansList.add(tableEducationDao.SelectEducation(Coop03ID, "HighSchool"));
		educationBeansList.add(tableEducationDao.SelectEducation(Coop03ID, "Vocation_1"));
		educationBeansList.add(tableEducationDao.SelectEducation(Coop03ID, "Vocation_2"));
		educationBeansList.add(tableEducationDao.SelectEducation(Coop03ID, "Bachelor_degree"));
		
		TableRelativeDao tableRelativeDao = new TableRelativeDao();
		List<RelativeBean> relativeBeansList = new ArrayList<RelativeBean>();
		relativeBeansList.add(tableRelativeDao.SelectRelative(Coop03ID, "relative_1"));
		relativeBeansList.add(tableRelativeDao.SelectRelative(Coop03ID, "relative_2"));
		relativeBeansList.add(tableRelativeDao.SelectRelative(Coop03ID, "relative_3"));
		
		TableTrainingDao tableTrainingDao = new TableTrainingDao();
		List<TrainingBean> trainingBeansList = new ArrayList<TrainingBean>();
		trainingBeansList.add(tableTrainingDao.SelectTraining(Coop03ID, "training_1"));
		trainingBeansList.add(tableTrainingDao.SelectTraining(Coop03ID, "training_2"));
		trainingBeansList.add(tableTrainingDao.SelectTraining(Coop03ID, "training_3"));
		
		TableCareerDao tableCareerDao = new TableCareerDao();
		List<CareerBean> careerBeansList = new ArrayList<CareerBean>();
		careerBeansList.add(tableCareerDao.SelectCareer(Coop03ID, "career_1"));
		careerBeansList.add(tableCareerDao.SelectCareer(Coop03ID, "career_2"));
		careerBeansList.add(tableCareerDao.SelectCareer(Coop03ID, "career_3"));
		careerBeansList.add(tableCareerDao.SelectCareer(Coop03ID, "career_4"));
		
		TableActivityDao tableActivityDao = new TableActivityDao();
		List<ActivityBean> activityBeansList = new ArrayList<ActivityBean>();
		activityBeansList.add(tableActivityDao.SelectActivity(Coop03ID, "activity_1"));
		activityBeansList.add(tableActivityDao.SelectActivity(Coop03ID, "activity_2"));
		activityBeansList.add(tableActivityDao.SelectActivity(Coop03ID, "activity_3"));
		
		TableLanguage03Dao tableLanguage03Dao = new TableLanguage03Dao();
		Language03Bean language03Bean = new Language03Bean();
		language03Bean = tableLanguage03Dao.SelectLanguage03(Coop03ID);
		
		// save report  pdf,docx 
		ReportCoop03 reportCoop03 = new ReportCoop03();
		reportCoop03.insertCoop03Pdf(request,userBean,profileBean,addressBeanList,familyBeanList,coop03Bean,educationBeansList,relativeBeansList,trainingBeansList,careerBeansList,activityBeansList,language03Bean);
		//reportCoop03.insertCoop03Docx(request,userBean,profileBean,addressBeanList,familyBeanList,coop03Bean,educationBeansList,relativeBeansList,trainingBeansList,careerBeansList,activityBeansList,language03Bean);
	}
	
	private String subString(String textData){
		String text = textData.trim();
		int count = 0;
		String data = "";
		String sub = ""+text.charAt(0);
	      if("*".equals(sub)){
	    	  //System.out.println(text.substring(1));
	    	  data = ""+text.substring(1);
	    	  count++;
	      }
	      
	      sub = ""+text.charAt(text.length()-1);
	      if("*".equals(sub)){
	    	  //System.out.println(text.substring(0,text.length()-1));
	    	  data = ""+text.substring(0,text.length()-1);
	    	  count++;
	      }
	      
	      if(count == 0){
	    	  data = ""+text;
	    	 // System.out.println(data);
	      }
		return data;
	}
	
	private String getPartDocument(String action,int userid){
		String parth = null;
		TableUserDao tableUserDao = new TableUserDao();
		String studentid = tableUserDao.getTableUserStudentID(userid);
		String nameFile = "";
		nameFile = studentid+"_"+userid;
		if(action.equals("pdfCoop02")){
				parth = "Upload/File/Report/PDF/"+nameFile+"_coop02.pdf";

		}else if(action.equals("pdfCoop03")){
			 	parth = "Upload/File/Report/PDF/"+nameFile+"_coop03.pdf";
		}
		return parth;
	}
}
