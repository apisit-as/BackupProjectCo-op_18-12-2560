package com.java.student.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.admin.bean.AcademicYearBean;
import com.java.admin.dao.TableAcademicYear;
import com.java.student.bean.CheckStatusCompanyBean;
import com.java.student.bean.CheckStatusDocumentBean;
import com.java.student.bean.HistoryStatusBean;
import com.java.student.bean.UserBean;
import com.java.student.dao.CheckStatusDao;
import com.java.student.dao.CheckStepDao;
import com.java.student.dao.TableHistoryStatusDao;
import com.java.student.dao.TableUserDao;

/**
 * Servlet implementation class CheckStatus
 */
@WebServlet("/CheckStatus")
public class CheckStatus extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckStatus() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		    response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		    response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		    response.setHeader("Pragma", "no-cache");
		    response.setDateHeader("Expires", 0);
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
		  
			HttpSession session = request.getSession();
			TableUserDao tableUserDao = new TableUserDao();
			UserBean userBean = new UserBean();
			
			String role = session.getAttribute("role").toString();
			if(role.equals("student")){
				int student_user_id = Integer.parseInt(session.getAttribute("UserID").toString());
			    userBean = tableUserDao.getTableUser(student_user_id);
			    
			    // set title
			    session.setAttribute("titlename_th_session", userBean.getTitlename_th());
			    session.setAttribute("firstname_th_session", userBean.getFirstname_th());
			    session.setAttribute("lastname_th_session", userBean.getLastname_th());
			    session.setAttribute("divName", userBean.getDivname());
			    session.setAttribute("rolename_th_session", userBean.getRolename_th());
				
				// set Academic Year
				TableAcademicYear tableAcademicYear = new TableAcademicYear();
				AcademicYearBean academicYearBean = new AcademicYearBean();
				academicYearBean = tableAcademicYear.getAcademic();
				session.setAttribute("Semester", academicYearBean.getSemester());
				session.setAttribute("Academic_year", academicYearBean.getAcademic_year());

				/**
				 *    get value modal status document , company
				 */
				/* document */
				CheckStatusDao checkStatusDao = new CheckStatusDao();
				CheckStatusDocumentBean statusDocumentBean = new CheckStatusDocumentBean();
				if(checkStatusDao.CheckTableDocumentTeacherLv2(student_user_id)){
					// get value lv2 to Main status document
					statusDocumentBean = checkStatusDao.SelectDocumentTeacherLv2(student_user_id);
				}else{
					// get value lv1 to Main status document
					statusDocumentBean = checkStatusDao.SelectDocumentTeacherLv1(student_user_id);
				}
				request.setAttribute("statusDocumentBean", statusDocumentBean);
				/* #document */
				
				/* company */
				CheckStatusCompanyBean statusCompanyBean = new CheckStatusCompanyBean();
				if(checkStatusDao.CheckTableCompanyTeacherLv2(student_user_id)){
					// get value lv2 to Main status company
					statusCompanyBean = checkStatusDao.SelectCompanyTeacherLv2(student_user_id);
					
				}else{
					// get value lv1 to Main status company
					statusCompanyBean = checkStatusDao.SelectCompanyTeacherLv1(student_user_id);
				}
				request.setAttribute("statusCompanyBean", statusCompanyBean);
				/* #company */
				
				
				// get history list
				ArrayList<HistoryStatusBean> listHistory = new ArrayList<>();
				TableHistoryStatusDao tableHistoryStatusDao = new TableHistoryStatusDao();
				listHistory = tableHistoryStatusDao.SelectHistorySatatus(student_user_id);
				request.setAttribute("listHistory", listHistory);
				
				if(!listHistory.isEmpty()){
					request.setAttribute("History_top", listHistory.get(0));
					request.setAttribute("listHistory", listHistory);
					
					// set color status
					String status_check = listHistory.get(0).getStatus();
					String set_color_status_history_top = "";
					if("�������ó�".equals(status_check) || "���͹��ѵ�".equals(status_check) || "���ͺ�Ѻ".equals(status_check) || "���͹��ѵ�����͡��Ժѵԧҹ�ˡԨ�֡��".equals(status_check)){
						set_color_status_history_top = "red-status";
					}else if("����ó�".equals(status_check) || "͹��ѵ�".equals(status_check) || "�ͺ�Ѻ".equals(status_check)){
						set_color_status_history_top = "green-status";
					}else{
						set_color_status_history_top = "orange-status";
					}
					request.setAttribute("set_color_status_history_top",set_color_status_history_top);
					
					
					// set onclick modal , set link
					String history_check = listHistory.get(0).getHistory();
					String set_onclick = "";
					String check_hide_document = "";
					String check_hide_company = "";
					if(("�Ҩ�������ҹ�ҹ�ˡԨ�֡�ҵ�Ǩ�ͺ�͡���".equals(history_check) || "���˹���Ң��Ԫҵ�Ǩ�ͺ�͡���".equals(history_check)) && ("�ʹ��Թ���".equals(status_check) || "���͹��ѵ�����͡��Ժѵԧҹ�ˡԨ�֡��".equals(status_check))){
						set_onclick = "check_document";	
						check_hide_document = "hide";
						check_hide_company = "hide";
						//System.out.println("1");
					}
					else if(("�Ҩ�������ҹ�ҹ�ˡԨ�֡�ҵ�Ǩ�ͺ�͡���".equals(history_check) || "���˹���Ң��Ԫҵ�Ǩ�ͺ�͡���".equals(history_check)) && ("�觡�Ѻ���".equals(status_check))){
						set_onclick = "check_document";	
						check_hide_document = "open";
						check_hide_company = "hide";
						//System.out.println("2");
					}
					else if(("�Ҩ�������ҹ�ҹ�ˡԨ�֡�ҵ�Ǩ�ͺʶҹ��Сͺ���".equals(history_check) || "���˹�ҷ���ˡԨ�֡�ҨѴ��˹ѧ��ͤ͢���͹���������ѧʶҹ��Сͺ���".equals(history_check) || "�͡�õͺ�Ѻ�ҡʶҹ��Сͺ���".equals(history_check) || "�Դ������˹�ҷ���ˡԨ�֡��".equals(history_check)) 
							&& ("�ʹ��Թ���".equals(status_check) || "���ѧ���Թ���".equals(status_check)  || "�Դ����Ѻ������".equals(status_check) || "�͵ͺ�Ѻ".equals(status_check) || "�ѡ�֡�ҵԴ������˹�ҷ��".equals(status_check) || "�ͺ�Ѻ".equals(status_check))){
						set_onclick = "check_company";	
						check_hide_document = "hide";
						check_hide_company = "hide";
						//System.out.println("3");
					}
					else if(("���͡ʶҹ��Сͺ���".equals(history_check) || "�Ҩ�������ҹ�ҹ�ˡԨ�֡�ҵ�Ǩ�ͺʶҹ��Сͺ���".equals(history_check) || "�͡�õͺ�Ѻ�ҡʶҹ��Сͺ���".equals(history_check)) && ("�������ó�".equals(status_check) || "���͹��ѵ�".equals(status_check) || "���ͺ�Ѻ".equals(status_check))){
						set_onclick = "check_company";	
						check_hide_document = "hide";
						check_hide_company = "open";
						//System.out.println("4");
					}
					request.setAttribute("set_onclick",set_onclick);
					request.setAttribute("check_hide_document",check_hide_document);
					request.setAttribute("check_hide_company",check_hide_company);
					
				}else{
					request.setAttribute("History_top", null);
					request.setAttribute("listHistory", null);
					request.setAttribute("check_step",1);
					request.setAttribute("check_hide_document","hide");
					request.setAttribute("check_hide_company","hide");
					doViewCheckStatus(request, response);
					return;
				}
				
				// set check_step
				CheckStepDao checkStepDao = new CheckStepDao();
				String check_step = checkStepDao.CheckStep(student_user_id);
				request.setAttribute("check_step",check_step);
				doViewCheckStatus(request, response);
			}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	private void doViewCheckStatus(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/student/check_status.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}		
}
