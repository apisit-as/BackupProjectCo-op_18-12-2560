package com.java.student.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.java.student.bean.Coop03Bean;

import com.java.student.bean.ProfileBean;

import com.java.student.bean.UserBean;
import com.java.student.dao.TableCompleteStatusDocument;
import com.java.student.dao.TableCoop03Dao;

import com.java.student.dao.TableProfileDao;

import com.java.student.dao.TableUserDao;
import com.java.util.FileUploadUtil;
import com.java.util.ImageResize;





/**
 * Servlet implementation class DataStudent
 */
@WebServlet("/DataStudent")
public class DataStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DataStudent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		
		HttpSession session = request.getSession();
		TableUserDao tableUserDao = new TableUserDao();
		TableProfileDao tableProfileDao = new TableProfileDao();
		TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
		
		UserBean userBean = new UserBean();
		ProfileBean ListProfileBean = new ProfileBean();
		Coop03Bean coop03Bean = new Coop03Bean();

		String role = session.getAttribute("role").toString();
		if(role.equals("student")){
			int UserID = Integer.parseInt(session.getAttribute("UserID").toString());
			
			/* get tb_user */
			userBean = tableUserDao.getTableUser(UserID);
			request.setAttribute("userBean", userBean);
			session.setAttribute("divID", userBean.getDivid());
			session.setAttribute("divName", userBean.getDivname());
			/* #get tb_user */
			
			/* get tb_profile */
			if(tableProfileDao.CheckProfile(UserID)){
				ListProfileBean = tableProfileDao.SelectProfile(UserID);
				
				if(ListProfileBean.getIssue_date() == null && ListProfileBean.getExpiry_date() == null && ListProfileBean.getBirthday() == null){
					//System.out.println("OK null");
					ListProfileBean.setIssue_date(null);
					ListProfileBean.setExpiry_date(null);
					ListProfileBean.setBirthday(null);
				}else{
					// Split Date ListProfileBean
					ListProfileBean.setIssue_date(splitDate(ListProfileBean.getIssue_date()));
					ListProfileBean.setExpiry_date(splitDate(ListProfileBean.getExpiry_date()));
					ListProfileBean.setBirthday(splitDate(ListProfileBean.getBirthday()));
				}

				request.setAttribute("EditProfile", "false");
			}else{
				request.setAttribute("EditProfile", "true");
			}
			request.setAttribute("ListProfileBean", ListProfileBean);
			/* #get tb_profile */
			
			/* get tb_coop03 */
			coop03Bean.setPicture(tableCoop03Dao.SelectPictureCoop03(UserID));
			request.setAttribute("coop03Bean", coop03Bean);
			/* #get tb_coop03 */
			
			doViewDataStudent(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		
		List<FileItem> items = null;
		String picture;
		Coop03Bean coop03Bean = new Coop03Bean();
		ProfileBean profileBean = new ProfileBean();
		
		int UserID = Integer.parseInt(session.getAttribute("UserID").toString());
		String ClickSave = session.getAttribute("CheckClickSave").toString();
		if("True Save".equals(ClickSave)){
			try{
				items = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
				for (FileItem item : items) {    // loop item
//				      String fieldname = item.getFieldName();
//				      System.out.println(fieldname);
					
				     if (item.isFormField()) {
				      String fieldname = item.getFieldName();
				      
				      /* tb_profile */
				      if("Id_card".equals(fieldname))     profileBean.setId_card(item.getString("UTF-8"));
				      else if("Issue_at".equals(fieldname))	   profileBean.setIssue_at(item.getString("UTF-8"));
				      else if("Issue_date".equals(fieldname))  profileBean.setIssue_date(item.getString("UTF-8"));
				      else if("Expiry_date".equals(fieldname)) profileBean.setExpiry_date(item.getString("UTF-8"));
				      
				      else if("Race".equals(fieldname)) 		profileBean.setRace(item.getString("UTF-8"));
				      else if("Nationality".equals(fieldname))  profileBean.setNationality(item.getString("UTF-8"));
				      else if("Religion".equals(fieldname))     profileBean.setReligion(item.getString("UTF-8"));
				      else if("Age_student".equals(fieldname))  profileBean.setAge(item.getString("UTF-8"));
				      else if("Birthday".equals(fieldname)) 	profileBean.setBirthday(item.getString("UTF-8"));
				      else if("Place_birth".equals(fieldname))  profileBean.setPlace_birth(item.getString("UTF-8"));
				      
				      else if("Sex".equals(fieldname)) 		profileBean.setSex(item.getString("UTF-8"));
				      else if("Height".equals(fieldname))   profileBean.setHeight(item.getString("UTF-8"));
				      else if("Weight".equals(fieldname))   profileBean.setWeight(item.getString("UTF-8"));
				      else if("Congenital_disease".equals(fieldname))    	profileBean.setCongenital_disease(item.getString("UTF-8"));
				     
				      /* tb_coop03 */
				     }else if(!item.isFormField()){  
				    	// file other!!
				         if (!(item.getName().equals(""))) {
				        	 //System.out.println(item.getName());  // get name file
				        	 //System.out.println(item.getFieldName());  // get input name=uploadBtn				        	 
				        	 TableUserDao tableUserDao = new TableUserDao();
				        	 UserBean userBeanStudentID = new UserBean();
				        	 userBeanStudentID = tableUserDao.getTableUser(UserID);
				        	 
				        	 String studentID = userBeanStudentID.getStudentid();
				             picture = FileUploadUtil.uploadFile(request, item,"StudentPic",studentID, Integer.toString(UserID),"png");
				             //System.out.println(picture);
				             coop03Bean.setPicture(picture);
				         }else{
				        	 TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
				        	 picture = tableCoop03Dao.SelectPictureCoop03(UserID);
				        	 coop03Bean.setPicture(picture);
				         }
				     }
				}
				
			}catch(FileUploadException e){
				e.printStackTrace();
			}
			out.print("True Save");
		}
		else if("False Save".equals(ClickSave)){
			out.print("False Save");
			return;
		}

		/* Insert,Update  tb_profile  */
		TableProfileDao tableProfileDao = new TableProfileDao();
		profileBean.setUserid(UserID);
		
		if(tableProfileDao.CheckProfile(UserID)){
			//update
			tableProfileDao.UpdateProfileDataStudent(profileBean);
			//System.out.println("OK Update Profile");
		}else{
			// insert
			tableProfileDao.InsertProfileDataStudent(profileBean);
			//System.out.println("OK Insert Profile");
		}
		/* #Insert,Update  tb_profile  */
		
		/* Insert,Update  tb_coop03  */
		TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
		coop03Bean.setUserid(UserID);
		
		if(tableCoop03Dao.CheckCoop03(UserID)){
			//update
			tableCoop03Dao.UpdateCoop03DataStudent(coop03Bean);
			//System.out.println("OK Update Coop03");
		}else{
			// insert
			tableCoop03Dao.InsertCoop03DataStudent(coop03Bean);
			//System.out.println("OK Insert Coop03");
		}
		
		//out.print(coop03Bean.getPicture());
		ImageResize imageResize = new ImageResize();
		imageResize.Resize(request, UserID);
		/* #Insert,Update  tb_coop03  */
		
		/** insert,update status document **/
		TableCompleteStatusDocument tableCompleteStatusDocument = new TableCompleteStatusDocument();
		if(tableCompleteStatusDocument.checkCompleteStatusDocument(UserID)){
			//update
			tableCompleteStatusDocument.UpdateCompleteStatusDoc("DataStudent", 1, UserID);
		}else{
			//insert
			tableCompleteStatusDocument.InsertCompleteStatusDoc("DataStudent", 1, UserID);
		}
		
	}
	
	
	private void doViewDataStudent(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/student/data_default/data_student.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private String splitDate(String date){
		String[] str = date.split("-");    
		return str[2]+"/"+str[1]+"/"+(Integer.parseInt(str[0])+543);
	}
		
}
