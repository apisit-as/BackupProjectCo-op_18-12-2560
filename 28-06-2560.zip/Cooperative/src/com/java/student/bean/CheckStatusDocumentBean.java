package com.java.student.bean;

public class CheckStatusDocumentBean {
	private String coop02_status;
	private String coop03_status;
	private String coop02_comment;
	private String coop03_comment;
	private String teacher_lv1_status;
	private String teacher_lv2_status;
	public String getCoop02_status() {
		return coop02_status;
	}
	public void setCoop02_status(String coop02_status) {
		this.coop02_status = coop02_status;
	}
	public String getCoop03_status() {
		return coop03_status;
	}
	public void setCoop03_status(String coop03_status) {
		this.coop03_status = coop03_status;
	}
	public String getCoop02_comment() {
		return coop02_comment;
	}
	public void setCoop02_comment(String coop02_comment) {
		this.coop02_comment = coop02_comment;
	}
	public String getCoop03_comment() {
		return coop03_comment;
	}
	public void setCoop03_comment(String coop03_comment) {
		this.coop03_comment = coop03_comment;
	}
	public String getTeacher_lv1_status() {
		return teacher_lv1_status;
	}
	public void setTeacher_lv1_status(String teacher_lv1_status) {
		this.teacher_lv1_status = teacher_lv1_status;
	}
	public String getTeacher_lv2_status() {
		return teacher_lv2_status;
	}
	public void setTeacher_lv2_status(String teacher_lv2_status) {
		this.teacher_lv2_status = teacher_lv2_status;
	}
}
