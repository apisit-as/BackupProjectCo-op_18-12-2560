package com.java.student.dao;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.java.util.PreparedStatementUtil;

public class TableApprovalStatusDao {
	
	public String getStatusApproval(int id){
		String data = null;
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rec = null;
		String sql = "SELECT Name "
				+ " FROM tb_approval_status "
				+ " WHERE ID = :id ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(sql);
			prepareStatementUtil.setInt("id", id);
			rec = prepareStatementUtil.executeQuery();
			while ((rec.next()) && (rec != null)) {
				data = rec.getString("Name");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rec.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return data;
	}
}
