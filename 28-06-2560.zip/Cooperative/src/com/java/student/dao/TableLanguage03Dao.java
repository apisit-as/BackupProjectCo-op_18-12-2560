package com.java.student.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.student.bean.Language03Bean;
import com.java.util.PreparedStatementUtil;

public class TableLanguage03Dao {
	public Boolean CheckLanguage03(int Coop03ID){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
	
		Boolean value = false;
		String query = "SELECT True as isLanguage03 FROM cooperative.tb_language03 WHERE Coop03ID = :coop03id LIMIT 1";
		
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("coop03id", Coop03ID);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				value = rs.getBoolean("isLanguage03");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public void InsertLanguage03(Language03Bean language03Bean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "INSERT INTO tb_language03(Language_eng,"
		   									+ "Level_eng_Listen,"
		   									+ "Level_eng_Speak,"
		   									+ "Level_eng_Write,"
		   									+ "Language_chi,"
		   									+ "Level_chi_Listen,"
		   									+ "Level_chi_Speak,"
		   									+ "Level_chi_Write,"
		   									+ "Language_other,"
		   									+ "Level_other_Listen,"
		   									+ "Level_other_Speak,"
		   									+ "Level_other_Write,"
		   									+ "Input_other,"
		   									+ "Coop03ID) "
					   		+ " VALUES(:language_eng,"   
					   				+ ":level_eng_listen,"
					   				+ ":level_eng_speak,"
					   				+ ":level_eng_write,"
					   				+ ":language_chi,"
					   				+ ":level_chi_listen,"
					   				+ ":level_chi_speak,"
					   				+ ":level_chi_write,"
					   				+ ":language_other,"
					   				+ ":level_other_listen,"
					   				+ ":level_other_speak,"
					   				+ ":level_other_write,"
					   				+ ":input_other,"
					   				+ ":coop03id)";

		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("language_eng", language03Bean.getLanguage_eng());
		   preparedStatementUtil.setString("level_eng_listen", language03Bean.getLevel_eng_listen());
		   preparedStatementUtil.setString("level_eng_speak", language03Bean.getLevel_eng_speak());
		   preparedStatementUtil.setString("level_eng_write", language03Bean.getLevel_eng_write());
		   preparedStatementUtil.setString("language_chi", language03Bean.getLanguage_chi());
		   preparedStatementUtil.setString("level_chi_listen", language03Bean.getLevel_chi_listen());
		   preparedStatementUtil.setString("level_chi_speak", language03Bean.getLevel_chi_speak());
		   preparedStatementUtil.setString("level_chi_write", language03Bean.getLevel_chi_write());
		   preparedStatementUtil.setString("language_other", language03Bean.getLanguage_other());
		   preparedStatementUtil.setString("level_other_listen", language03Bean.getLevel_other_listen());
		   preparedStatementUtil.setString("level_other_speak", language03Bean.getLevel_other_speak());
		   preparedStatementUtil.setString("level_other_write", language03Bean.getLevel_other_write());
		   preparedStatementUtil.setString("input_other", language03Bean.getInput_other());
		   preparedStatementUtil.setInt("coop03id", language03Bean.getCoop03id());
		   preparedStatementUtil.execute();   
		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	
	public void UpdateLanguage03(Language03Bean language03Bean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_language03 SET "
		   				+ "Language_eng = :language_eng,"
		   				+ "Level_eng_Listen = :level_eng_listen,"
		   				+ "Level_eng_Speak = :level_eng_speak,"
		   				+ "Level_eng_Write = :level_eng_write,"
		   				+ "Language_chi = :language_chi,"
		   				+ "Level_chi_Listen = :level_chi_listen,"
		   				+ "Level_chi_Speak = :level_chi_speak,"
		   				+ "Level_chi_Write = :level_chi_write,"
		   				+ "Language_other = :language_other,"
		   				+ "Level_other_Listen = :level_other_listen,"
		   				+ "Level_other_Speak = :level_other_speak,"
		   				+ "Level_other_Write = :level_other_write,"
		   				+ "Input_other = :input_other "
		   				+ "WHERE Coop03ID = :coop03id";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("language_eng",language03Bean.getLanguage_eng());
		   preparedStatementUtil.setString("level_eng_listen", language03Bean.getLevel_eng_listen());
		   preparedStatementUtil.setString("level_eng_speak", language03Bean.getLevel_eng_speak());
		   preparedStatementUtil.setString("level_eng_write", language03Bean.getLevel_eng_write());
		   preparedStatementUtil.setString("language_chi", language03Bean.getLanguage_chi());
		   preparedStatementUtil.setString("level_chi_listen", language03Bean.getLevel_chi_listen());
		   preparedStatementUtil.setString("level_chi_speak", language03Bean.getLevel_chi_speak());
		   preparedStatementUtil.setString("level_chi_write", language03Bean.getLevel_chi_write());
		   preparedStatementUtil.setString("language_other", language03Bean.getLanguage_other());
		   preparedStatementUtil.setString("level_other_listen", language03Bean.getLevel_other_listen());
		   preparedStatementUtil.setString("level_other_speak", language03Bean.getLevel_other_speak());
		   preparedStatementUtil.setString("level_other_write", language03Bean.getLevel_other_write());
		   preparedStatementUtil.setString("input_other", language03Bean.getInput_other());
		   preparedStatementUtil.setInt("coop03id", language03Bean.getCoop03id());
		   preparedStatementUtil.execute();
		   		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public Language03Bean SelectLanguage03(int Coop03ID){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		Language03Bean language03Bean = new Language03Bean();
		String query = "SELECT Language_eng,Level_eng_Listen,Level_eng_Speak,Level_eng_Write,"
				+ "Language_chi,Level_chi_Listen,Level_chi_Speak,Level_chi_Write,"
				+ "Language_other,Level_other_Listen,Level_other_Speak,Level_other_Write,Input_other "
				+ " FROM tb_language03"
				+ " WHERE Coop03ID = :coop03id"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("coop03id", Coop03ID);
			rs = preparedStatementUtil.executeQuery();
			
			if(rs.next()){
				language03Bean.setLanguage_eng(rs.getString("Language_eng"));
				language03Bean.setLevel_eng_listen(rs.getString("Level_eng_Listen"));
				language03Bean.setLevel_eng_speak(rs.getString("Level_eng_Speak"));
				language03Bean.setLevel_eng_write(rs.getString("Level_eng_Write"));
				language03Bean.setLanguage_chi(rs.getString("Language_chi"));
				language03Bean.setLevel_chi_listen(rs.getString("Level_chi_Listen"));
				language03Bean.setLevel_chi_speak(rs.getString("Level_chi_Speak"));
				language03Bean.setLevel_chi_write(rs.getString("Level_chi_Write"));
				language03Bean.setLanguage_other(rs.getString("Language_other"));
				language03Bean.setLevel_other_listen(rs.getString("Level_other_Listen"));
				language03Bean.setLevel_other_speak(rs.getString("Level_other_Speak"));
				language03Bean.setLevel_other_write(rs.getString("Level_other_Write"));
				language03Bean.setInput_other(rs.getString("Input_other"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return language03Bean;
	}
}
