package com.java.student.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.student.bean.Coop02Bean;
import com.java.util.PreparedStatementUtil;

public class TableCoop02Dao {
	
	public Boolean CheckCoop02(int UserID){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
	
		Boolean value = false;
		String query = "SELECT True as isCoop02 FROM cooperative.tb_coop02 WHERE UserID = :userid LIMIT 1";
		
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("userid", UserID);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				value = rs.getBoolean("isCoop02");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return value;
	}
	
	public void InsertCoop02(Coop02Bean  coop02Bean){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "INSERT INTO tb_coop02(Talent,"
		   									+ "Interest,"
		   									+ "Region,"
		   									+ "UserID) "
					   		+ " VALUES(:talent,"  
					   				+ ":interest,"
					   				+ ":region,"
					   				+ ":userid)";

		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setString("talent", coop02Bean.getTalent());
		   preparedStatementUtil.setString("interest", coop02Bean.getInterest());
		   preparedStatementUtil.setString("region", coop02Bean.getRegion());
		   preparedStatementUtil.setInt("userid", coop02Bean.getUserid());

		   preparedStatementUtil.execute();   
		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void InsertCoop02RegionTermAcademicYear(Coop02Bean  coop02Bean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "INSERT INTO tb_coop02(Region,"
		   									+ "Term,"
		   									+ "Academic_year,"
		   									+ "UserID) "
					   		+ " VALUES(:region,"  
					   				+ ":term,"
					   				+ ":academic_year,"
					   				+ ":userid)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("region", coop02Bean.getRegion());
		   preparedStatementUtil.setString("term", coop02Bean.getTerm());
		   preparedStatementUtil.setString("academic_year", coop02Bean.getAcademic_year());
		   preparedStatementUtil.setInt("userid", coop02Bean.getUserid());
		   preparedStatementUtil.execute();   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void InsertCoop02TermAcademicYear(Coop02Bean  coop02Bean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "INSERT INTO tb_coop02(Term,"
		   									+ "Academic_year,"
		   									+ "UserID) "
					   		+ " VALUES(:term,"  
					   				+ ":academic_year,"
					   				+ ":userid)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("term", coop02Bean.getTerm());
		   preparedStatementUtil.setString("academic_year", coop02Bean.getAcademic_year());
		   preparedStatementUtil.setInt("userid", coop02Bean.getUserid());
		   preparedStatementUtil.execute();   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void InsertCoop02Userid(int userid){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "INSERT INTO tb_coop02(UserID) VALUES(:userid)";

		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("userid", userid);
		   preparedStatementUtil.execute();   
		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}

	public void InsertCoop02TalentAndInterest(Coop02Bean  coop02Bean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "INSERT INTO tb_coop02(Talent,"
		   									+ "Interest,"
		   									+ "UserID) "
					   		+ " VALUES(:talent,"  
					   				+ ":interest,"
					   				+ ":userid)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("talent", coop02Bean.getTalent());
		   preparedStatementUtil.setString("interest", coop02Bean.getInterest());
		   preparedStatementUtil.setInt("userid", coop02Bean.getUserid());
		   preparedStatementUtil.execute();   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	
	public void UpdateCoop02(Coop02Bean coop02Bean){
		PreparedStatementUtil preparedStatementUtil = null;
	  
		  try{
		   String query = "UPDATE tb_coop02 SET "
		   				+ "Talent = :talent,"
		   				+ "Interest = :interest,"
		   				+ "Region = :region "
		   				+ "WHERE UserID = :userid";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setString("talent", coop02Bean.getTalent());
		   preparedStatementUtil.setString("interest", coop02Bean.getInterest());
		   preparedStatementUtil.setString("region", coop02Bean.getRegion());
		   preparedStatementUtil.setInt("userid", coop02Bean.getUserid());

		   preparedStatementUtil.execute();
		   		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void UpdateCoop02RegionTermAcademicYear(Coop02Bean coop02Bean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_coop02 SET "
		   				+ "Region = :region,"
		   				+ "Term = :term,"
		   				+ "Academic_year = :academic_year "
		   				+ "WHERE UserID = :userid";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("region", coop02Bean.getRegion());
		   preparedStatementUtil.setString("term", coop02Bean.getTerm());
		   preparedStatementUtil.setString("academic_year", coop02Bean.getAcademic_year());
		   preparedStatementUtil.setInt("userid", coop02Bean.getUserid());
		   preparedStatementUtil.execute(); 
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void UpdateCoop02TermAcademicYear(Coop02Bean coop02Bean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_coop02 SET "
		   				+ "Term = :term,"
		   				+ "Academic_year = :academic_year "
		   				+ "WHERE UserID = :userid";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("term", coop02Bean.getTerm());
		   preparedStatementUtil.setString("academic_year", coop02Bean.getAcademic_year());
		   preparedStatementUtil.setInt("userid", coop02Bean.getUserid());
		   preparedStatementUtil.execute(); 
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void UpdateCoop02TalentAndInterest(Coop02Bean coop02Bean){
		PreparedStatementUtil preparedStatementUtil = null;
	  
		  try{
		   String query = "UPDATE tb_coop02 SET "
		   				+ "Talent = :talent,"
		   				+ "Interest = :interest "
		   				+ "WHERE UserID = :userid";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setString("talent", coop02Bean.getTalent());
		   preparedStatementUtil.setString("interest", coop02Bean.getInterest());
		   preparedStatementUtil.setInt("userid", coop02Bean.getUserid());

		   preparedStatementUtil.execute();
		   		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}	
	
	public Coop02Bean SelectCoop02(int UserID){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		Coop02Bean coop02Bean = new Coop02Bean();
		
		String query = "SELECT ID,Talent,Interest,Region,Term,Academic_year"
				+ " FROM tb_coop02"
				+ " WHERE UserID = :userid"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("userid", UserID);
			rs = preparedStatementUtil.executeQuery();
			
			if(rs.next()){
				coop02Bean.setId(rs.getInt("ID"));
				coop02Bean.setTalent(rs.getString("Talent"));
				coop02Bean.setInterest(rs.getString("Interest"));
				coop02Bean.setRegion(rs.getString("Region"));
				coop02Bean.setTerm(rs.getString("Term"));
				coop02Bean.setAcademic_year(rs.getString("Academic_year"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return coop02Bean;
	} 
	
	public int getKeyIDCoop02(int UserID){
		
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		int key = 0;
		
		String query = "SELECT tb_coop02.ID FROM tb_coop02 WHERE UserID = :userid"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("userid", UserID);
			rs = preparedStatementUtil.executeQuery();
			
			if(rs.next()){
				key = rs.getInt("ID");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return key;
	} 
	
}
