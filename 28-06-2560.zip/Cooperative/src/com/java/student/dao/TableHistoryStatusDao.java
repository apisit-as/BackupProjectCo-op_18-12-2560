package com.java.student.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.student.bean.HistoryStatusBean;
import com.java.util.PreparedStatementUtil;

public class TableHistoryStatusDao {
	
	public void InsertHistoryStatus(HistoryStatusBean historyStatusBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "INSERT INTO tb_history_status"
		   									+ "(Date,"
		   									+ "History,"
		   									+ "Status,"
		   									+ "UserID) "
					   		+ " VALUES(:date,"   
					   				+ ":history,"
					   				+ ":status,"
					   				+ ":userid)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("date",historyStatusBean.getDate());
		   preparedStatementUtil.setString("history",historyStatusBean.getHistory());
		   preparedStatementUtil.setString("status",historyStatusBean.getStatus());
		   preparedStatementUtil.setInt("userid",historyStatusBean.getUserid());
		   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public ArrayList<HistoryStatusBean> SelectHistorySatatus(int student_user_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		ArrayList<HistoryStatusBean> list = new ArrayList<>();
		String query = "SELECT "
							+ "Date,"
							+ "History,"
							+ "Status "
					+ " FROM tb_history_status"
					+ " WHERE tb_history_status.UserID = :student_user_id "
					+ " ORDER BY ID desc "; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("student_user_id", student_user_id);
			rs = preparedStatementUtil.executeQuery();
			while(rs.next()){
				HistoryStatusBean bean = new HistoryStatusBean();
				bean.setDate(rs.getString("Date"));
				bean.setHistory(rs.getString("History"));
				bean.setStatus(rs.getString("Status"));
				list.add(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	} 
}
