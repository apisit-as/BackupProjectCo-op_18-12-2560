package com.java.student.dao;

import com.java.student.bean.ProfileBean;

import com.java.util.PreparedStatementUtil;


import java.sql.ResultSet;
import java.sql.SQLException;
public class TableProfileDao {

	
	public Boolean CheckProfile(int UserID){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
	
		Boolean value = false;
		String query = "SELECT True as isProfile FROM cooperative.tb_profile WHERE UserID = :userid LIMIT 1";
		
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("userid", UserID);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				value = rs.getBoolean("isProfile");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return value;
	}	


	public void InsertProfileDataStudent(ProfileBean profileBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "INSERT INTO tb_profile(Id_card,"
		   									+ "Issue_at,"
		   									+ "Issue_date,"
		   									+ "Expiry_date,"
		   									+ "Race,"
		   									+ "Nationality,"
		   									+ "Religion,"
		   									+ "Age,"
		   									+ "Birthday,"
		   									+ "Place_birth,"
		   									+ "Sex,"
		   									+ "Height,"
		   									+ "Weight,"
		   									+ "Congenital_disease,"
		   									+ "UserID) "
					   		+ " VALUES(:id_card,"    
					   				+ ":issue_at,"
					   				+ ":issue_date,"
					   				+ ":expiry_date,"
					   				+ ":race,"
					   				+ ":nationality,"
					   				+ ":religion,"
					   				+ ":age,"
					   				+ ":birthday,"
					   				+ ":place_birth,"
					   				+ ":sex,"
					   				+ ":height,"
					   				+ ":weight,"
					   				+ ":congenital_disease,"
					   				+ ":userid)";

		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setString("id_card", profileBean.getId_card());
		   preparedStatementUtil.setString("issue_at", profileBean.getIssue_at());
		   preparedStatementUtil.setString("issue_date", profileBean.getIssue_date());
		   preparedStatementUtil.setString("expiry_date", profileBean.getExpiry_date());
		   preparedStatementUtil.setString("race", profileBean.getRace());
		   preparedStatementUtil.setString("nationality", profileBean.getNationality());
		   preparedStatementUtil.setString("religion", profileBean.getReligion());
		   preparedStatementUtil.setString("age", profileBean.getAge());
		   preparedStatementUtil.setString("birthday", profileBean.getBirthday());
		   preparedStatementUtil.setString("place_birth", profileBean.getPlace_birth());
		   preparedStatementUtil.setString("sex", profileBean.getSex());
		   preparedStatementUtil.setString("height", profileBean.getHeight());
		   preparedStatementUtil.setString("weight", profileBean.getWeight());
		   preparedStatementUtil.setString("congenital_disease", profileBean.getCongenital_disease());
		   preparedStatementUtil.setInt("userid", profileBean.getUserid());

		   preparedStatementUtil.execute();   
		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
	}	
	
	public void InsertProfileSetUserid(int UserID){
		PreparedStatementUtil preparedStatementUtil = null;
		try{
		   String query = "INSERT INTO tb_profile(UserID) VALUES(:userid)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("userid", UserID);
		   preparedStatementUtil.execute();   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
	}		
	
	public void InsertProfileEducation(ProfileBean profileBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "INSERT INTO tb_profile(ClassYear,"
		   									+ "GroupStudent,"
		   									+ "TitleID,"
		   									+ "FirstNameAdvisor,"
		   									+ "LastNameAdvisor,"
		   									+ "Grade,"
		   									+ "GradeTotal,"
		   									+ "UserID) "
					   		+ " VALUES(:classyear,"    
					   				+ ":groupstudent,"
					   				+ ":titleid,"
					   				+ ":firstnameadvisor,"
					   				+ ":lastnameadvisor,"
					   				+ ":grade,"
					   				+ ":gradetotal,"
					   				+ ":userid)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("classyear", profileBean.getClassyear());
		   preparedStatementUtil.setString("groupstudent", profileBean.getGroupstudent());
		   preparedStatementUtil.setInt("titleid", profileBean.getTitleid());
		   preparedStatementUtil.setString("firstnameadvisor", profileBean.getFirstnameadvisor());
		   preparedStatementUtil.setString("lastnameadvisor", profileBean.getLastnameadvisor());
		   preparedStatementUtil.setString("grade", profileBean.getGrade());
		   preparedStatementUtil.setString("gradetotal", profileBean.getGradetotal());
		   preparedStatementUtil.setInt("userid", profileBean.getUserid());
		   preparedStatementUtil.execute();   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	

	public void UpdateProfileDataStudent(ProfileBean profileBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "UPDATE tb_profile SET "
		   				+ "Id_card = :id_card,"
		   				+ "Issue_at = :issue_at,"     
		   				+ "Issue_date = :issue_date,"
		   				+ "Expiry_date = :expiry_date,"
		   				+ "Race = :race,"
		   				+ "Nationality = :nationality,"
		   				+ "Religion = :religion,"
		   				+ "Age = :age,"
		   				+ "Birthday = :birthday,"
		   				+ "Place_birth = :place_birth,"
		   				+ "Sex = :sex,"
		   				+ "Height = :height,"
		   				+ "Weight = :weight,"
		   				+ "Congenital_disease = :congenital_disease "
		   				+ "WHERE UserID = :userid";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setString("id_card", profileBean.getId_card());
		   preparedStatementUtil.setString("issue_at", profileBean.getIssue_at());
		   preparedStatementUtil.setString("issue_date", profileBean.getIssue_date());
		   preparedStatementUtil.setString("expiry_date", profileBean.getExpiry_date());
		   preparedStatementUtil.setString("race", profileBean.getRace());
		   preparedStatementUtil.setString("nationality", profileBean.getNationality());
		   preparedStatementUtil.setString("religion", profileBean.getReligion());
		   preparedStatementUtil.setString("age", profileBean.getAge());
		   preparedStatementUtil.setString("birthday", profileBean.getBirthday());
		   preparedStatementUtil.setString("place_birth", profileBean.getPlace_birth());
		   preparedStatementUtil.setString("sex", profileBean.getSex());
		   preparedStatementUtil.setString("height", profileBean.getHeight());
		   preparedStatementUtil.setString("weight", profileBean.getWeight());
		   preparedStatementUtil.setString("congenital_disease", profileBean.getCongenital_disease());
		   preparedStatementUtil.setInt("userid", profileBean.getUserid());
		   

		   preparedStatementUtil.execute();
		   		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
	}	
	
	public void UpdateProfileEducation(ProfileBean profileBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "UPDATE tb_profile SET "
		   				+ "ClassYear = :classyear,"
		   				+ "GroupStudent = :groupstudent,"
		   				+ "TitleID = :titleid,"
		   				+ "FirstNameAdvisor = :firstnameadvisor,"
		   				+ "LastNameAdvisor = :lastNameadvisor,"
		   				+ "Grade = :grade,"
		   				+ "GradeTotal = :gradetotal "
		   				+ "WHERE UserID = :userid";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setString("classyear", profileBean.getClassyear());
		   preparedStatementUtil.setString("groupstudent", profileBean.getGroupstudent());
		   preparedStatementUtil.setInt("titleid", profileBean.getTitleid());
		   preparedStatementUtil.setString("firstnameadvisor", profileBean.getFirstnameadvisor());
		   preparedStatementUtil.setString("lastNameadvisor", profileBean.getLastnameadvisor());
		   preparedStatementUtil.setString("grade", profileBean.getGrade());
		   preparedStatementUtil.setString("gradetotal", profileBean.getGradetotal());
		   preparedStatementUtil.setInt("userid", profileBean.getUserid());
		   preparedStatementUtil.execute();
		   		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
	}
	
	public ProfileBean SelectProfile(int UserID){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		ProfileBean profileBean = new ProfileBean();
		String query = "SELECT tb_profile.ID,ClassYear,GroupStudent,TitleID,FirstNameAdvisor,LastNameAdvisor,Grade,"
				+ "GradeTotal,Id_card,Issue_at,Issue_date,Expiry_date,Race,Nationality,Religion,Age,"
				+ "Birthday,Place_birth,Sex,Height,Weight,Congenital_disease,"
				+ "tb_title.Name_th AS Name_th"
				+ " FROM tb_profile"
				+ " LEFT JOIN tb_title on tb_profile.TitleID = tb_title.ID"
				+ " WHERE UserID = :userid"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("userid", UserID);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				profileBean.setId(rs.getInt("ID"));
				profileBean.setClassyear(rs.getString("ClassYear"));
				profileBean.setGroupstudent(rs.getString("GroupStudent"));
				profileBean.setTitleid(rs.getInt("TitleID"));;
				profileBean.setFirstnameadvisor(rs.getString("FirstNameAdvisor"));
				profileBean.setLastnameadvisor(rs.getString("LastNameAdvisor"));
				profileBean.setGrade(rs.getString("Grade"));
				profileBean.setGradetotal(rs.getString("GradeTotal"));
				profileBean.setId_card(rs.getString("Id_card"));
				profileBean.setIssue_at(rs.getString("Issue_at"));
				profileBean.setIssue_date(rs.getString("Issue_date"));
				profileBean.setExpiry_date(rs.getString("Expiry_date"));
				profileBean.setRace(rs.getString("Race"));
				profileBean.setNationality(rs.getString("Nationality"));
				profileBean.setReligion(rs.getString("Religion"));
				profileBean.setAge(rs.getString("Age"));
				profileBean.setBirthday(rs.getString("Birthday"));
				profileBean.setPlace_birth(rs.getString("Place_birth"));
				profileBean.setSex(rs.getString("Sex"));
				profileBean.setHeight(rs.getString("Height"));
				profileBean.setWeight(rs.getString("Weight"));
				profileBean.setCongenital_disease(rs.getString("Congenital_disease"));
				profileBean.setTitlename_th(rs.getString("Name_th"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return profileBean;
	} 
	
	public int getKeyIDProfile(int UserID){
		
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		int key = 0;
		
		String query = "SELECT tb_profile.ID FROM tb_profile WHERE UserID = :userid"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("userid", UserID);
			rs = preparedStatementUtil.executeQuery();
			
			if(rs.next()){
				key = rs.getInt("ID");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return key;
	} 
	
/* �Ҵ����������ҹ    �ͧ���  */	
	
	public void InsertProfile(ProfileBean profileBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "INSERT INTO tb_profile(ClassYear,"
		   									+ "GroupStudent,"
		   									+ "TitleID,"
		   									+ "FirstNameAdvisor,"
		   									+ "LastNameAdvisor,"
		   									+ "Grade,"
		   									+ "GradeTotal,"
		   									+ "Id_card,"
		   									+ "Issue_at,"
		   									+ "Issue_date,"
		   									+ "Expiry_date,"
		   									+ "Race,"
		   									+ "Nationality,"
		   									+ "Religion,"
		   									+ "Age,"
		   									+ "Birthday,"
		   									+ "Place_birth,"
		   									+ "Sex,"
		   									+ "Height,"
		   									+ "Weight,"
		   									+ "Congenital_disease,"
		   									+ "UserID) "
					   		+ " VALUES(:classyear,"     //////////
					   				+ ":groupstudent,"
					   				+ ":titleid,"
					   				+ ":firstnameadvisor,"
					   				+ ":lastnameadvisor,"
					   				+ ":grade,"
					   				+ ":gradetotal,"
					   				+ ":id_card,"
					   				+ ":issue_at,"
					   				+ ":issue_date,"
					   				+ ":expiry_date,"
					   				+ ":race,"
					   				+ ":nationality,"
					   				+ ":religion,"
					   				+ ":age,"
					   				+ ":birthday,"
					   				+ ":place_birth,"
					   				+ ":sex,"
					   				+ ":height,"
					   				+ ":weight,"
					   				+ ":congenital_disease,"
					   				+ ":userid)";

		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setString("classyear", profileBean.getClassyear());
		   preparedStatementUtil.setString("groupstudent", profileBean.getGroupstudent());
		   preparedStatementUtil.setInt("titleid", profileBean.getTitleid());
		   preparedStatementUtil.setString("firstnameadvisor", profileBean.getFirstnameadvisor());
		   preparedStatementUtil.setString("lastnameadvisor", profileBean.getLastnameadvisor());
		   preparedStatementUtil.setString("grade", profileBean.getGrade());
		   preparedStatementUtil.setString("gradetotal", profileBean.getGradetotal());
		   preparedStatementUtil.setString("id_card", profileBean.getId_card());
		   preparedStatementUtil.setString("issue_at", profileBean.getIssue_at());
		   preparedStatementUtil.setString("issue_date", profileBean.getIssue_date());
		   preparedStatementUtil.setString("expiry_date", profileBean.getExpiry_date());
		   preparedStatementUtil.setString("race", profileBean.getRace());
		   preparedStatementUtil.setString("nationality", profileBean.getNationality());
		   preparedStatementUtil.setString("religion", profileBean.getReligion());
		   preparedStatementUtil.setString("age", profileBean.getAge());
		   preparedStatementUtil.setString("birthday", profileBean.getBirthday());
		   preparedStatementUtil.setString("place_birth", profileBean.getPlace_birth());
		   preparedStatementUtil.setString("sex", profileBean.getSex());
		   preparedStatementUtil.setString("height", profileBean.getHeight());
		   preparedStatementUtil.setString("weight", profileBean.getWeight());
		   preparedStatementUtil.setString("congenital_disease", profileBean.getCongenital_disease());
		   preparedStatementUtil.setInt("userid", profileBean.getUserid());

		   preparedStatementUtil.execute();   
		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
	}
	
	

	public void UpdateProfile(ProfileBean profileBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "UPDATE tb_profile SET "
		   				+ "ClassYear = :classyear,"
		   				+ "GroupStudent = :groupstudent,"
		   				+ "TitleID = :titleid,"
		   				+ "FirstNameAdvisor = :firstnameadvisor,"
		   				+ "LastNameAdvisor = :lastNameadvisor,"
		   				+ "Grade = :grade,"
		   				+ "GradeTotal = :gradetotal,"
		   				+ "Id_card = :id_card,"
		   				+ "Issue_at = :issue_at,"           //////////////////////
		   				+ "Issue_date = :issue_date,"
		   				+ "Expiry_date = :expiry_date,"
		   				+ "Race = :race,"
		   				+ "Nationality = :nationality,"
		   				+ "Religion = :religion,"
		   				+ "Age = :age,"
		   				+ "Birthday = :birthday,"
		   				+ "Place_birth = :place_birth,"
		   				+ "Sex = :sex,"
		   				+ "Height = :height,"
		   				+ "Weight = :weight,"
		   				+ "Congenital_disease = :congenital_disease "
		   				+ "WHERE UserID = :userid";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setString("classyear", profileBean.getClassyear());
		   preparedStatementUtil.setString("groupstudent", profileBean.getGroupstudent());
		   preparedStatementUtil.setInt("titleid", profileBean.getTitleid());
		   preparedStatementUtil.setString("firstnameadvisor", profileBean.getFirstnameadvisor());
		   preparedStatementUtil.setString("lastNameadvisor", profileBean.getLastnameadvisor());
		   preparedStatementUtil.setString("grade", profileBean.getGrade());
		   preparedStatementUtil.setString("gradetotal", profileBean.getGradetotal());
		   preparedStatementUtil.setString("id_card", profileBean.getId_card());
		   preparedStatementUtil.setString("issue_at", profileBean.getIssue_at());
		   preparedStatementUtil.setString("issue_date", profileBean.getIssue_date());
		   preparedStatementUtil.setString("expiry_date", profileBean.getExpiry_date());
		   preparedStatementUtil.setString("race", profileBean.getRace());
		   preparedStatementUtil.setString("nationality", profileBean.getNationality());
		   preparedStatementUtil.setString("religion", profileBean.getReligion());
		   preparedStatementUtil.setString("age", profileBean.getAge());
		   preparedStatementUtil.setString("birthday", profileBean.getBirthday());
		   preparedStatementUtil.setString("place_birth", profileBean.getPlace_birth());
		   preparedStatementUtil.setString("sex", profileBean.getSex());
		   preparedStatementUtil.setString("height", profileBean.getHeight());
		   preparedStatementUtil.setString("weight", profileBean.getWeight());
		   preparedStatementUtil.setString("congenital_disease", profileBean.getCongenital_disease());
		   preparedStatementUtil.setInt("userid", profileBean.getUserid());
		   

		   preparedStatementUtil.execute();
		   		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
	}
	
	
	
}
