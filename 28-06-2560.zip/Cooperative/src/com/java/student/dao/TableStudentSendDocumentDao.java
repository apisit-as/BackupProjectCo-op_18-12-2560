package com.java.student.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.admin.bean.AcademicYearBean;
import com.java.student.bean.StudentSendDocumentBean;
import com.java.util.PreparedStatementUtil;

public class TableStudentSendDocumentDao {
	
	public Boolean CheckTable(int UserID,int AcademicYearID){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = "SELECT True as isTable FROM cooperative.tb_student_send_document"
				+ "  WHERE Academic_year = :academic_year AND "
				       + " UserID = :userid ";
		
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("academic_year", AcademicYearID);
			prepareStatementUtil.setInt("userid", UserID);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				value = rs.getBoolean("isTable");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public Boolean CheckTable(int UserID){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = "SELECT True as isTable FROM cooperative.tb_student_send_document"
				+ "  WHERE UserID = :userid ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("userid", UserID);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getBoolean("isTable");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public void InsertSeandDocumentStudent(StudentSendDocumentBean studentSendDocumentBean){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		int doc_id = 0;
		  try{
			  
			/**
			 *   insert  tb_student_send_document  
			 *   get id 
			 *   to insert id tb_teacher_check_document
			 */
		   String query = "INSERT INTO tb_student_send_document"
		   									+ "(Academic_year,"
		   									+ "Coop02ID,"
		   									+ "Coop03ID,"
		   									+ "TranscriptID,"
		   									+ "ProfileID,"
		   									+ "Lv1_ApStatusID,"
		   									+ "Lv2_ApStatusID,"
		   									+ "UserID) "
					   		+ " VALUES(:academic_year,"   
					   				+ ":coop02id,"
					   				+ ":coop03id,"
					   				+ ":transcriptid,"
					   				+ ":profileid,"
					   				+ ":lv1_apstatusid,"
					   				+ "null,"
					   				+ ":userid)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("academic_year",studentSendDocumentBean.getAcademic_year());
		   preparedStatementUtil.setInt("coop02id",studentSendDocumentBean.getCoop02id());
		   preparedStatementUtil.setInt("coop03id",studentSendDocumentBean.getCoop03id());
		   preparedStatementUtil.setInt("transcriptid",studentSendDocumentBean.getTranscriptid());
		   preparedStatementUtil.setInt("profileid",studentSendDocumentBean.getProfileid());
		   preparedStatementUtil.setInt("lv1_apstatusid",studentSendDocumentBean.getLv1_apstatusid());
		   preparedStatementUtil.setInt("userid",studentSendDocumentBean.getUserid());
		   rs = preparedStatementUtil.executeInsertGetKeys();  
		   while (rs.next()) {
			   doc_id = rs.getInt(1);
			}
		   
		   /**
		    *  insert id  tb_teacher_check_document
		    */
		   query = "INSERT INTO tb_teacher_check_document"
						+ "(Lv1_02StatusID,"
						+ "Lv1_03StatusID,"
						+ "Lv1_02Note,"
						+ "Lv1_03Note,"
						+ "DocID) "
				+ " VALUES(4,"
						+ "4,"
						+ "null,"
						+ "null,"
						+ ":doc_id)";
				preparedStatementUtil = new PreparedStatementUtil(query);
				preparedStatementUtil.setInt("doc_id",doc_id);
				preparedStatementUtil.execute();
		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void UpdateDocumentStudent(StudentSendDocumentBean studentSendDocumentBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_student_send_document SET "
		   				+ "Academic_year = :academic_year,"
		   				+ "Coop02ID = :coop02id,"
		   				+ "Coop03ID = :coop03id,"
		   				+ "TranscriptID = :transcriptid,"
		   				+ "ProfileID = :profileid,"
		   				+ "Lv1_ApStatusID = :lv1_apstatusid,"
		   				+ "Lv2_ApStatusID = null "
		   				+ "WHERE UserID = :userid ";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("academic_year",studentSendDocumentBean.getAcademic_year());
		   preparedStatementUtil.setInt("coop02id",studentSendDocumentBean.getCoop02id());
		   preparedStatementUtil.setInt("coop03id",studentSendDocumentBean.getCoop03id());
		   preparedStatementUtil.setInt("transcriptid",studentSendDocumentBean.getTranscriptid());
		   preparedStatementUtil.setInt("profileid",studentSendDocumentBean.getProfileid());
		   preparedStatementUtil.setInt("lv1_apstatusid",studentSendDocumentBean.getLv1_apstatusid());
		   preparedStatementUtil.setInt("userid",studentSendDocumentBean.getUserid());
		   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
		  
		  // update waiting to check
		  int id_student_send_document = getIDStudentSendDocument(studentSendDocumentBean.getUserid());
		  UpdateWaitingToCheck(id_student_send_document);
	}
	
	public void UpdateWaitingToCheck(int id_student_send_document){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
			  String query = "UPDATE tb_teacher_check_document SET "
		   				+ "Lv1_02StatusID = 4 , "
		   				+ "Lv1_03StatusID = 4 "
			 			+ "WHERE tb_teacher_check_document.DocID = :id_student_send_document ";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("id_student_send_document",id_student_send_document);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public int getIDStudentSendDocument(int UserID){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rec = null;
		int id_student_send_document = 0;
		String sql = "SELECT tb_student_send_document.ID "
				+ " FROM tb_student_send_document "
				+ " WHERE tb_student_send_document.UserID = :userid ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(sql);
			prepareStatementUtil.setInt("userid", UserID);
			rec = prepareStatementUtil.executeQuery();
			if ((rec.next()) && (rec != null)) {
				id_student_send_document = rec.getInt("ID");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rec.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return id_student_send_document;
	}
	
	public AcademicYearBean SelectSemesterAcademicYear(int UserID){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rec = null;
		AcademicYearBean academicYearBean = new AcademicYearBean();
		String sql = "SELECT tb_academic_year.Semester,"
				+ " tb_academic_year.Academic_year "
				+ " FROM tb_student_send_document "
				+ " JOIN tb_academic_year  ON tb_student_send_document.Academic_year = tb_academic_year.ID"
				+ " WHERE tb_student_send_document.UserID = :userid ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(sql);
			prepareStatementUtil.setInt("userid", UserID);
			rec = prepareStatementUtil.executeQuery();
			if ((rec.next()) && (rec != null)) {
				academicYearBean.setSemester(rec.getString("Semester"));
				academicYearBean.setAcademic_year(rec.getString("Academic_year"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rec.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return academicYearBean;
	}
	
	public StudentSendDocumentBean SelectTableCheckStatus(int UserID){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rec = null;
		StudentSendDocumentBean studentSendDocumentBean = new StudentSendDocumentBean();
		String sql = "SELECT Academic_year,"
				+ " Coop02ID, "
				+ " Coop03ID, "
				+ " TranscriptID, "
				+ " ProfileID, "
				+ " Lv1_ApStatusID, "
				+ " Lv2_ApStatusID  "
				+ " FROM tb_student_send_document "
				+ " WHERE tb_student_send_document.UserID = :userid ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(sql);
			prepareStatementUtil.setInt("userid", UserID);
			rec = prepareStatementUtil.executeQuery();
			while ((rec.next()) && (rec != null)) {
				studentSendDocumentBean.setAcademic_year(rec.getInt("Academic_year"));
				studentSendDocumentBean.setCoop02id(rec.getInt("Coop02ID"));
				studentSendDocumentBean.setCoop03id(rec.getInt("Coop03ID"));
				studentSendDocumentBean.setTranscriptid(rec.getInt("TranscriptID"));
				studentSendDocumentBean.setProfileid(rec.getInt("ProfileID"));
				studentSendDocumentBean.setLv1_apstatusid(rec.getInt("Lv1_ApStatusID"));
				studentSendDocumentBean.setLv2_apstatusid(rec.getInt("Lv2_ApStatusID"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rec.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return studentSendDocumentBean;
	}
}
