package com.java.student.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.student.bean.Coop03Bean;
import com.java.student.bean.StudentSelectCompanyBean;
import com.java.util.PreparedStatementUtil;

public class TableCoop03Dao {
	
	public Boolean CheckCoop03(int UserID){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = "SELECT True as isCoop03 FROM cooperative.tb_coop03 WHERE UserID = :userid LIMIT 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("userid", UserID);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				value = rs.getBoolean("isCoop03");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public Boolean CheckCoop03Education(int coop03id){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = "SELECT True as isCoop03Education FROM cooperative.tb_education WHERE Coop03ID = :coop03id LIMIT 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("coop03id", coop03id);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				value = rs.getBoolean("isCoop03Education");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public void InsertCoop03DataStudent(Coop03Bean  coop03Bean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "INSERT INTO tb_coop03(Picture,"
		   									+ "UserID) "
					   		+ " VALUES(:picture,"  
					   				+ ":userid)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("picture", coop03Bean.getPicture());
		   preparedStatementUtil.setInt("userid", coop03Bean.getUserid());
		   preparedStatementUtil.execute();   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void InsertCoop03NumAndMyRelative(Coop03Bean  coop03Bean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "INSERT INTO tb_coop03(Num_relative,"
		   									+ "My_relative,"
		   									+ "UserID) "
					   		+ " VALUES(:num_relative,"  
					   				+ ":my_relative,"
					   				+ ":userid)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("num_relative", coop03Bean.getNum_relative());
		   preparedStatementUtil.setString("my_relative", coop03Bean.getMy_relative());
		   preparedStatementUtil.setInt("userid", coop03Bean.getUserid());
		   preparedStatementUtil.execute();   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	

	
	public void UpdateCoop03DataStudent(Coop03Bean coop03Bean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_coop03 SET "
		   				+ "Picture = :picture "
		   				+ "WHERE UserID = :userid";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("picture", coop03Bean.getPicture());
		   preparedStatementUtil.setInt("userid", coop03Bean.getUserid());
		   preparedStatementUtil.execute(); 		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void UpdateCoop03NumAndMyRelative(Coop03Bean coop03Bean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_coop03 SET "
		   				+ "Num_relative = :num_relative,"
		   				+ "My_relative = :my_relative "
		   				+ "WHERE UserID = :userid";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("num_relative", coop03Bean.getNum_relative());
		   preparedStatementUtil.setString("my_relative", coop03Bean.getMy_relative());
		   preparedStatementUtil.setInt("userid", coop03Bean.getUserid());
		   preparedStatementUtil.execute();	   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	
	public Coop03Bean SelectCoop03(int UserID){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		Coop03Bean coop03Bean = new Coop03Bean();
		String query = "SELECT Num_relative,My_relative,Picture"
				+ " FROM tb_coop03"
				+ " WHERE UserID = :userid"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("userid", UserID);
			rs = preparedStatementUtil.executeQuery();
			
			if(rs.next()){
				coop03Bean.setNum_relative(rs.getString("Num_relative"));
				coop03Bean.setMy_relative(rs.getString("My_relative"));
				coop03Bean.setPicture(rs.getString("Picture"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return coop03Bean;
	} 
	
	public Coop03Bean SelectCoop03ReportPdf(int UserID){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		Coop03Bean coop03Bean = new Coop03Bean();
		String query = "SELECT tb_coop03.Num_relative,"
							+ "tb_coop03.My_relative,"
							+ "tb_coop03.Picture,"
							+ "tb_coop03.Position,"
							+ "tb_coop03.PreTime,"
							+ "tb_coop03.Posttime "
				+ " FROM tb_coop03"
				+ " WHERE UserID = :userid"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("userid", UserID);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				coop03Bean.setNum_relative(rs.getString("Num_relative"));
				coop03Bean.setMy_relative(rs.getString("My_relative"));
				coop03Bean.setPicture(rs.getString("Picture"));
				coop03Bean.setPosition(rs.getString("Position"));
				coop03Bean.setPre_time(rs.getString("PreTime"));
				coop03Bean.setPost_time(rs.getString("Posttime"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
		 query = "SELECT tb_company.NameCompany "
			    + " FROM tb_student_select_company "
			    + "JOIN tb_rate_company  ON tb_rate_company.ID = tb_student_select_company.RateCompanyID_Temp "
			    + "JOIN tb_company  ON tb_company.ID = tb_rate_company.CompanyID " 
				+ " WHERE tb_student_select_company.UserID = :userid"; 
		 
			try {
				preparedStatementUtil = new PreparedStatementUtil(query);
				preparedStatementUtil.setInt("userid", UserID);
				rs = preparedStatementUtil.executeQuery();
				if(rs.next()){
					coop03Bean.setCompany_name(rs.getString("NameCompany"));
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally{
				try {
					preparedStatementUtil.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		return coop03Bean;
	} 
	
	public StudentSelectCompanyBean SelectCoop03Comapny(int UserID){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		StudentSelectCompanyBean studentSelectCompanyBean = new StudentSelectCompanyBean();
		String query = "SELECT PreTime,Posttime,Position,CodeJob,SendDocuments "
				+ " FROM tb_coop03"
				+ " WHERE UserID = :userid"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("userid", UserID);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				studentSelectCompanyBean.setStart_date_workout(rs.getString("PreTime"));
				studentSelectCompanyBean.setStop_date_workout(rs.getString("Posttime"));
				studentSelectCompanyBean.setPosition(rs.getString("Position"));
				studentSelectCompanyBean.setCodeJob(rs.getString("CodeJob"));
				studentSelectCompanyBean.setSend_documents(rs.getString("SendDocuments"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return studentSelectCompanyBean;
	} 
	
	public String SelectPictureCoop03(int UserID){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		String pic = "";
		
		String query = "SELECT Picture"
				+ " FROM tb_coop03"
				+ " WHERE UserID = :userid"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("userid", UserID);
			rs = preparedStatementUtil.executeQuery();
			
			if(rs.next()){
				pic = rs.getString("Picture");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return pic;
	}
	
	
	public int getKeyIDCoop03(int UserID){
		
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		int key = 0;
		
		String query = "SELECT tb_coop03.ID FROM tb_coop03 WHERE UserID = :userid"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("userid", UserID);
			rs = preparedStatementUtil.executeQuery();
			
			if(rs.next()){
				key = rs.getInt("ID");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return key;
	} 
	
	
	
	/* �Ҵ����������ҹ    �ͧ���  */	
	
	public void UpdateCoop03(Coop03Bean coop03Bean){
		PreparedStatementUtil preparedStatementUtil = null;
	  
		  try{
		   String query = "UPDATE tb_coop03 SET "
		   				+ "Num_relative = :num_relative,"
		   				+ "My_relative = :my_relative,"
		   				+ "Picture = :picture "
		   				+ "WHERE UserID = :userid";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setString("num_relative", coop03Bean.getNum_relative());
		   preparedStatementUtil.setString("my_relative", coop03Bean.getMy_relative());
		   preparedStatementUtil.setString("picture", coop03Bean.getPicture());
		   preparedStatementUtil.setInt("userid", coop03Bean.getUserid());

		   preparedStatementUtil.execute();
		   		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void InsertCoop03(Coop03Bean  coop03Bean){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "INSERT INTO tb_coop03(Num_relative,"
		   									+ "My_relative,"
		   									+ "Picture,"
		   									+ "UserID) "
					   		+ " VALUES(:num_relative,"  
					   				+ ":my_relative,"
					   				+ ":picture,"
					   				+ ":userid)";

		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setString("num_relative", coop03Bean.getNum_relative());
		   preparedStatementUtil.setString("my_relative", coop03Bean.getMy_relative());
		   preparedStatementUtil.setString("picture", coop03Bean.getPicture());
		   preparedStatementUtil.setInt("userid", coop03Bean.getUserid());

		   preparedStatementUtil.execute();   
		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void InsertCoop03SetUserid(int  UserID){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "INSERT INTO tb_coop03(UserID) VALUES(:userid)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("userid", UserID);
		   preparedStatementUtil.execute();   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	
}
