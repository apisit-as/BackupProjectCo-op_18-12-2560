package com.java.list.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.list.bean.DivisionBean;

import com.java.util.PreparedStatementUtil;

public class DivisionSelectListDao {
	public ArrayList<DivisionBean> getDivisionList(int FacID) {
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ArrayList<DivisionBean> listDivisionBean = new ArrayList<DivisionBean>();
		  try{
		   String query = "SELECT ID,Code,Name,Initials,FacID FROM cooperative.tb_division "
		   		+ " WHERE FacID = :facid "
		   		+ " ORDER BY Code ASC";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("facid", FacID);
		   rs = preparedStatementUtil.executeQuery();   

		   while(rs.next()){
			   DivisionBean divisionBean = new DivisionBean();
			   divisionBean.setId(rs.getInt("ID"));
			   divisionBean.setCode(rs.getString("Code"));
			   divisionBean.setName(rs.getString("Name"));
			   divisionBean.setInitials(rs.getString("Initials"));
			   divisionBean.setFacID(rs.getInt("FacID"));
			   listDivisionBean.add(divisionBean);
			}
		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
			  try {
				rs.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
		  return listDivisionBean;
	}
}
