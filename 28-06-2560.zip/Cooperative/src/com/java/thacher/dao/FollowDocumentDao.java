package com.java.thacher.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.thacher.bean.ListFollowCompanyBean;
import com.java.util.PreparedStatementUtil;

public class FollowDocumentDao {

	public ArrayList<ListFollowCompanyBean> SelectListStudentSelectCompany(int academic_id,int divid){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ArrayList<ListFollowCompanyBean> list = new ArrayList<>();
		String query =  "SELECT  tb_user.StudentID,"
						+ "tb_title.Name_th AS titleName_th,"
				        + "tb_user.FirstName_th,"
				        + "tb_user.LastName_th,"
				        + "tb_company.NameCompany,"
				        + "tb_company.ID AS Company_id,"
				        + "tb_company.ProvinceCompany,"
				        + "tb_approval_status.Name AS Status,"
				        + "tb_student_select_company.Comment,"
				        + "tb_student_select_company.File "
				        + "FROM tb_student_select_company "
				        + "JOIN tb_user  ON tb_user.ID = tb_student_select_company.UserID "
				        + "JOIN tb_title  ON tb_title.ID = tb_user.TitleID "
						+ "JOIN tb_rate_company  ON tb_rate_company.ID = tb_student_select_company.RateCompanyID_Temp "
						+ "JOIN tb_company  ON tb_company.ID = tb_rate_company.CompanyID "
						+ "JOIN tb_approval_status  ON tb_approval_status.ID = tb_student_select_company.Staff_ApStatusID "
						+ "WHERE tb_student_select_company.Academic_year = :academic_id "
								+ "AND tb_user.DivID= :divid "
								+ "AND tb_user.RoleID = 1 ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("academic_id", academic_id);
			preparedStatementUtil.setInt("divid", divid);
			rs = preparedStatementUtil.executeQuery();
			while(rs.next()){
				ListFollowCompanyBean bean = new ListFollowCompanyBean();			
				bean.setStudent_id(rs.getString("StudentID"));
				bean.setTitle_name_th(rs.getString("titleName_th"));
				bean.setFirstname_th(rs.getString("FirstName_th"));
				bean.setLastname_th(rs.getString("LastName_th"));
				bean.setCompany_name(rs.getString("NameCompany"));
				bean.setCompany_id(rs.getInt("Company_id"));
				bean.setProvice(rs.getString("ProvinceCompany"));
				bean.setStatus(rs.getString("Status"));
				bean.setComment(rs.getString("Comment"));
				bean.setFile(rs.getString("File"));
				list.add(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
}
