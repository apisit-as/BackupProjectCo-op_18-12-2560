package com.java.thacher.bean;

public class ListStudentSendDocumentBean {

	private String student_id;
	private String title_name_th;
	private String firstname;
	private String lastname;
	private String division_name;
	private String grade_total;
	private int id_student_send_document;
	private int userid;
	private String lv_02note;
	private String lv_03note;
	public String getStudent_id() {
		return student_id;
	}
	public void setStudent_id(String student_id) {
		this.student_id = student_id;
	}
	public String getTitle_name_th() {
		return title_name_th;
	}
	public void setTitle_name_th(String title_name_th) {
		this.title_name_th = title_name_th;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getDivision_name() {
		return division_name;
	}
	public void setDivision_name(String division_name) {
		this.division_name = division_name;
	}
	public String getGrade_total() {
		return grade_total;
	}
	public void setGrade_total(String grade_total) {
		this.grade_total = grade_total;
	}
	public int getId_student_send_document() {
		return id_student_send_document;
	}
	public void setId_student_send_document(int id_student_send_document) {
		this.id_student_send_document = id_student_send_document;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getLv_02note() {
		return lv_02note;
	}
	public void setLv_02note(String lv_02note) {
		this.lv_02note = lv_02note;
	}
	public String getLv_03note() {
		return lv_03note;
	}
	public void setLv_03note(String lv_03note) {
		this.lv_03note = lv_03note;
	}
	
	
}
