package com.java.thacher.bean;

public class TeacherCheckDocumentBean {
	private int id;
	private int lv_status_id;
	private String lv_note;
	private int doc_id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getLv_status_id() {
		return lv_status_id;
	}
	public void setLv_status_id(int lv_status_id) {
		this.lv_status_id = lv_status_id;
	}
	public String getLv_note() {
		return lv_note;
	}
	public void setLv_note(String lv_note) {
		this.lv_note = lv_note;
	}
	public int getDoc_id() {
		return doc_id;
	}
	public void setDoc_id(int doc_id) {
		this.doc_id = doc_id;
	}
	
	
}
