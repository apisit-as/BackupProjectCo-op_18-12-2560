package com.java.list.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.list.bean.AmphurBean;

import com.java.util.PreparedStatementUtil;

public class AmphurSelectListDao {
	
	public ArrayList<AmphurBean> getAmphurList(int ProvinceID) {
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ArrayList<AmphurBean> listAmphur = new ArrayList<AmphurBean>();
		  try{
		   String query = "SELECT ID,Name,ProvinceID FROM cooperative.tb_amphur "
		   		+ " WHERE ProvinceID = :provinceid "
		   		+ " ORDER BY Name ASC";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("provinceid", ProvinceID);
		   rs = preparedStatementUtil.executeQuery();   
		   
		   while(rs.next()){
			   AmphurBean amphureBean = new AmphurBean();
			   amphureBean.setId(rs.getInt("ID"));
			   amphureBean.setName(rs.getString("Name"));
			   amphureBean.setProvinceid(rs.getInt("ProvinceID"));
			   listAmphur.add(amphureBean);
			}
		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
			  try {
				rs.close();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
		  return listAmphur;
	}
}
