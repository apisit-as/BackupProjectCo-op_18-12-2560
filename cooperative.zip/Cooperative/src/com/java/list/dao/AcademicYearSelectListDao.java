package com.java.list.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.util.PreparedStatementUtil;

public class AcademicYearSelectListDao {
	
	public ArrayList<Integer> getSearchList(String type) {
		// Semester or Academic_year
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ArrayList<Integer> list = new ArrayList<Integer>();
		  try{
		   String query = "SELECT "+type
		   		+ " FROM tb_academic_year "
		   		+ " GROUP BY "+type
		   		+ " ORDER BY "+type+" DESC ";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   rs = preparedStatementUtil.executeQuery();   
		   while(rs.next()){
			   list.add(rs.getInt(type));
		   }
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
			  try {
				rs.close();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
		  return list;
	}
}
