package com.java.list.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import com.java.list.bean.FooterBean;
import com.java.util.PreparedStatementUtil;

public class FooterDao {
	
	public FooterBean SelectDataFooter(){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		FooterBean footerBean = new FooterBean();
		String query =  "SELECT  row1,row2,row3,row4 FROM tb_footer WHERE ID = 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				footerBean.setRow1(rs.getString("row1"));
				footerBean.setRow2(rs.getString("row2"));
				footerBean.setRow3(rs.getString("row3"));
				footerBean.setRow4(rs.getString("row4"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return footerBean;
	}	
}
