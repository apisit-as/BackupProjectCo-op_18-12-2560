package com.java.list.bean;

public class DistrictBean {
	private int id;
	private String name;
	private int amphurid;
	private int amphurname;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAmphurid() {
		return amphurid;
	}
	public void setAmphurid(int amphurid) {
		this.amphurid = amphurid;
	}
	public int getAmphurname() {
		return amphurname;
	}
	public void setAmphurname(int amphurname) {
		this.amphurname = amphurname;
	}
}
