package com.java.staff.bean;

public class RateCompanyBean {
	private String semester;
	private String academic_year;
	private int num_student_total;
	private String fac_name;
	private String div_name;
	private String type_offer_job;
	public String getSemester() {
		return semester;
	}
	public void setSemester(String semester) {
		this.semester = semester;
	}
	public String getAcademic_year() {
		return academic_year;
	}
	public void setAcademic_year(String academic_year) {
		this.academic_year = academic_year;
	}
	public int getNum_student_total() {
		return num_student_total;
	}
	public void setNum_student_total(int num_student_total) {
		this.num_student_total = num_student_total;
	}
	public String getFac_name() {
		return fac_name;
	}
	public void setFac_name(String fac_name) {
		this.fac_name = fac_name;
	}
	public String getDiv_name() {
		return div_name;
	}
	public void setDiv_name(String div_name) {
		this.div_name = div_name;
	}
	public String getType_offer_job() {
		return type_offer_job;
	}
	public void setType_offer_job(String type_offer_job) {
		this.type_offer_job = type_offer_job;
	}
}
