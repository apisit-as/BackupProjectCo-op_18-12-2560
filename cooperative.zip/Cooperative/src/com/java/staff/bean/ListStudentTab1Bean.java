package com.java.staff.bean;

public class ListStudentTab1Bean {
	private String student_id;
	private String title_name_th;
	private String firstname_th;
	private String lastname_th;
	private String fac_name;
	private String div_name;
	private int company_id;
	private String company_name;
	private String address_company;
	private String district_company;
	private String amphur_company;
	private String province_company;
	private String post_code_company;
	private String telephone_company;
	private String name_contact;
	private String telephone_contact;
	private String status;
	private int user_id;
	public String getStudent_id() {
		return student_id;
	}
	public void setStudent_id(String student_id) {
		this.student_id = student_id;
	}
	public String getTitle_name_th() {
		return title_name_th;
	}
	public void setTitle_name_th(String title_name_th) {
		this.title_name_th = title_name_th;
	}
	public String getFirstname_th() {
		return firstname_th;
	}
	public void setFirstname_th(String firstname_th) {
		this.firstname_th = firstname_th;
	}
	public String getLastname_th() {
		return lastname_th;
	}
	public void setLastname_th(String lastname_th) {
		this.lastname_th = lastname_th;
	}
	public String getFac_name() {
		return fac_name;
	}
	public void setFac_name(String fac_name) {
		this.fac_name = fac_name;
	}
	public String getDiv_name() {
		return div_name;
	}
	public void setDiv_name(String div_name) {
		this.div_name = div_name;
	}
	public int getCompany_id() {
		return company_id;
	}
	public void setCompany_id(int company_id) {
		this.company_id = company_id;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public String getAddress_company() {
		return address_company;
	}
	public void setAddress_company(String address_company) {
		this.address_company = address_company;
	}
	public String getDistrict_company() {
		return district_company;
	}
	public void setDistrict_company(String district_company) {
		this.district_company = district_company;
	}
	public String getAmphur_company() {
		return amphur_company;
	}
	public void setAmphur_company(String amphur_company) {
		this.amphur_company = amphur_company;
	}
	public String getProvince_company() {
		return province_company;
	}
	public void setProvince_company(String province_company) {
		this.province_company = province_company;
	}
	public String getPost_code_company() {
		return post_code_company;
	}
	public void setPost_code_company(String post_code_company) {
		this.post_code_company = post_code_company;
	}
	public String getTelephone_company() {
		return telephone_company;
	}
	public void setTelephone_company(String telephone_company) {
		this.telephone_company = telephone_company;
	}
	public String getName_contact() {
		return name_contact;
	}
	public void setName_contact(String name_contact) {
		this.name_contact = name_contact;
	}
	public String getTelephone_contact() {
		return telephone_contact;
	}
	public void setTelephone_contact(String telephone_contact) {
		this.telephone_contact = telephone_contact;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
}
