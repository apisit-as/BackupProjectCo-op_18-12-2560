package com.java.staff.bean;

public class ListStudentSelectCompanyBean {
	private String student_id;
	private String title_name_th;
	private String firstname_th;
	private String lastname_th;
	private String faculty_name;
	private String division_name;
	private int division_id;
	private String company_name;
	private int company_id;
	private String provice;
	private String status;
	private String status_send_documents;
	private String comment;
	private String file;
	private int user_id;
	public String getStudent_id() {
		return student_id;
	}
	public void setStudent_id(String student_id) {
		this.student_id = student_id;
	}
	public String getTitle_name_th() {
		return title_name_th;
	}
	public void setTitle_name_th(String title_name_th) {
		this.title_name_th = title_name_th;
	}
	public String getFirstname_th() {
		return firstname_th;
	}
	public void setFirstname_th(String firstname_th) {
		this.firstname_th = firstname_th;
	}
	public String getLastname_th() {
		return lastname_th;
	}
	public void setLastname_th(String lastname_th) {
		this.lastname_th = lastname_th;
	}
	public String getFaculty_name() {
		return faculty_name;
	}
	public void setFaculty_name(String faculty_name) {
		this.faculty_name = faculty_name;
	}
	public String getDivision_name() {
		return division_name;
	}
	public void setDivision_name(String division_name) {
		this.division_name = division_name;
	}
	public int getDivision_id() {
		return division_id;
	}
	public void setDivision_id(int division_id) {
		this.division_id = division_id;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public int getCompany_id() {
		return company_id;
	}
	public void setCompany_id(int company_id) {
		this.company_id = company_id;
	}
	public String getProvice() {
		return provice;
	}
	public void setProvice(String provice) {
		this.provice = provice;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatus_send_documents() {
		return status_send_documents;
	}
	public void setStatus_send_documents(String status_send_documents) {
		this.status_send_documents = status_send_documents;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
}
