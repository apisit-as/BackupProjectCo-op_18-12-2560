package com.java.staff.bean;

public class RateCompanyListCompanyBean {
	// list json faculty,divison
	private int company_id;
	private int academic_year_id;
	private int faculty_id;
	private int division_id;
	private int num_student;
	private String type_offer_job;
	private int number;
	public int getCompany_id() {
		return company_id;
	}
	public void setCompany_id(int company_id) {
		this.company_id = company_id;
	}
	public int getAcademic_year_id() {
		return academic_year_id;
	}
	public void setAcademic_year_id(int academic_year_id) {
		this.academic_year_id = academic_year_id;
	}
	public int getFaculty_id() {
		return faculty_id;
	}
	public void setFaculty_id(int faculty_id) {
		this.faculty_id = faculty_id;
	}
	public int getDivision_id() {
		return division_id;
	}
	public void setDivision_id(int division_id) {
		this.division_id = division_id;
	}
	public int getNum_student() {
		return num_student;
	}
	public void setNum_student(int num_student) {
		this.num_student = num_student;
	}
	public String getType_offer_job() {
		return type_offer_job;
	}
	public void setType_offer_job(String type_offer_job) {
		this.type_offer_job = type_offer_job;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
}
