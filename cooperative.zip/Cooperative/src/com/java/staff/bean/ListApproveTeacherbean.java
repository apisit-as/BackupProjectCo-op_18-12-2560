package com.java.staff.bean;

public class ListApproveTeacherbean {
	private String title_name_th;
	private String firstname_th;
	private String lastname_th;
	private String faculty_name;
	private String division_name;
	private String role_name;
	private int user_id;
	private String approve_teacher;
	public String getTitle_name_th() {
		return title_name_th;
	}
	public void setTitle_name_th(String title_name_th) {
		this.title_name_th = title_name_th;
	}
	public String getFirstname_th() {
		return firstname_th;
	}
	public void setFirstname_th(String firstname_th) {
		this.firstname_th = firstname_th;
	}
	public String getLastname_th() {
		return lastname_th;
	}
	public void setLastname_th(String lastname_th) {
		this.lastname_th = lastname_th;
	}
	public String getFaculty_name() {
		return faculty_name;
	}
	public void setFaculty_name(String faculty_name) {
		this.faculty_name = faculty_name;
	}
	public String getDivision_name() {
		return division_name;
	}
	public void setDivision_name(String division_name) {
		this.division_name = division_name;
	}
	public String getRole_name() {
		return role_name;
	}
	public void setRole_name(String role_name) {
		this.role_name = role_name;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getApprove_teacher() {
		return approve_teacher;
	}
	public void setApprove_teacher(String approve_teacher) {
		this.approve_teacher = approve_teacher;
	}
}
