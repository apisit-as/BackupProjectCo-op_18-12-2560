package com.java.staff.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.admin.bean.AcademicYearBean;
import com.java.admin.bean.FacultyBean;
import com.java.admin.dao.TableAcademicYearDao;
import com.java.admin.dao.TableFacultyDao;
import com.java.list.bean.FooterBean;
import com.java.list.dao.AcademicYearSelectListDao;
import com.java.list.dao.FooterDao;
import com.java.staff.bean.CompanyBean;
import com.java.staff.bean.RateCompanyBean;
import com.java.staff.bean.RateCompanyExportExcelListBean;
import com.java.staff.bean.RateCompanyListBean;
import com.java.staff.bean.RegionBean;
import com.java.staff.bean.UserListStudentRateCompanyBean;
import com.java.staff.dao.TableCompanyDao;
import com.java.staff.dao.TableRateCompanyDao;
import com.java.staff.dao.TableRegionDao;
import com.java.util.SessionExpire;

/**
 * Servlet implementation class RateCompany
 */
@WebServlet("/RateCompany")
public class RateCompany extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RateCompany() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
			HttpSession session = request.getSession();
			
			// check role session expire
		    if(session.getAttribute("role") == null){
			  	SessionExpire sessionExpire = new SessionExpire();
				response.sendRedirect(sessionExpire.getSendRedirect()); // send redirect to Login page
				return;
		    }
			
			String role = session.getAttribute("role").toString();
			String action = request.getParameter("action");
			
			if("export_data_rate_company".equals(action) && role.equals("staff")){
				/** export_data_rate_company  */
				  	TableRateCompanyDao tableRateCompanyDao = new TableRateCompanyDao();
				  	ArrayList<RateCompanyExportExcelListBean> ListDataRateCompany = new ArrayList<>();
				  	int search_semester = Integer.parseInt(request.getParameter("search_semester"));
				  	int search_academic = Integer.parseInt(request.getParameter("search_academic"));
				  	ListDataRateCompany = tableRateCompanyDao.SelectListRateCompanyExportExcel(search_semester, search_academic);
					request.setAttribute("ListDataRateCompany", ListDataRateCompany);
					request.setAttribute("semester", search_semester);
					request.setAttribute("academic", search_academic);
					doExportExcel(request, response);
					return;
			}
			
			if(role.equals("staff")){
				
				// set Academic Year
				TableAcademicYearDao tableAcademicYear = new TableAcademicYearDao();
				AcademicYearBean academicYearBean = new AcademicYearBean();
				academicYearBean = tableAcademicYear.getAcademic();
				session.setAttribute("Semester", academicYearBean.getSemester());
				session.setAttribute("Academic_year", academicYearBean.getAcademic_year());
				session.setAttribute("academic_year_id", academicYearBean.getId());
				
				// list rate company
				ArrayList<RateCompanyListBean> rateCompanyListBeans = new ArrayList<>();
				TableRateCompanyDao tableRateCompanyDao = new TableRateCompanyDao();
				rateCompanyListBeans = tableRateCompanyDao.SelectListRateCompany(academicYearBean.getId());
				request.setAttribute("rateCompanyListBeans", rateCompanyListBeans);
				request.setAttribute("searchSemester", academicYearBean.getSemester());
				request.setAttribute("searchAcademic", academicYearBean.getAcademic_year());
				
				// list select semester,academic
				ArrayList<Integer> listSemester = new ArrayList<>();
				ArrayList<Integer> listAcademic = new ArrayList<>();
				AcademicYearSelectListDao academicYearSelectListDao = new AcademicYearSelectListDao();
				listSemester = academicYearSelectListDao.getSearchList("Semester");
				listAcademic = academicYearSelectListDao.getSearchList("Academic_year");
				request.setAttribute("listSemester",listSemester);
				request.setAttribute("listAcademic",listAcademic);
				
				// list select faclty
				ArrayList<FacultyBean> listFaclty = new ArrayList<FacultyBean>();
				TableFacultyDao tableFacultyDao = new TableFacultyDao();
				listFaclty = tableFacultyDao.getFacultyList();
				request.setAttribute("listFaclty", listFaclty);
				
				/** set text footer **/
				FooterBean footerBean = new FooterBean();
				footerBean = new FooterDao().SelectDataFooter();
				request.setAttribute("footerBean", footerBean);
				
				doViewRateCompany(request, response);
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");		
		HttpSession session = request.getSession();
		String role = session.getAttribute("role").toString();
		
		if(role.equals("staff")){
			
			String action = request.getParameter("action");
			if("search_data_company".equals(action)){
				
				/** search_data_company */
				int rate_company_id = Integer.parseInt(request.getParameter("rate_company_id"));
				int company_id = Integer.parseInt(request.getParameter("company_id"));
				
				// data_company
				CompanyBean companyBean = new CompanyBean();
				TableCompanyDao tableCompanyDao = new TableCompanyDao();
				companyBean = tableCompanyDao.SelectCompany(company_id);
				request.setAttribute("companyBean", companyBean);
				
				// rate_company
				RateCompanyBean rateCompanyBean = new RateCompanyBean();
				TableRateCompanyDao tableRateCompanyDao = new TableRateCompanyDao();
				rateCompanyBean = tableRateCompanyDao.SelectRateCompany(rate_company_id);
				request.setAttribute("rateCompanyBean", rateCompanyBean);
				
				// ragion_company
				ArrayList<RegionBean> listRegionCompany = new ArrayList<>();
				TableRegionDao tableRegionDao = new TableRegionDao();
				listRegionCompany = tableRegionDao.SelectListRegion();
				request.setAttribute("listRegionCompany", listRegionCompany);
				
				// list_student
				ArrayList<UserListStudentRateCompanyBean> listStudent = new ArrayList<>();
				listStudent = tableRateCompanyDao.SelectListStudent(rate_company_id);
				request.setAttribute("listStudent", listStudent);
				
				// data  select list  type_company_select,residence_company_select
				CompanyManagement companyManagement = new CompanyManagement();
				companyManagement.listSelectComapny(request, response);
				
				doViewModalDataCompany(request, response);
			}
			else if("save_rate_company".equals(action)){
				/** save_rate_company */
				int rate_company_id = Integer.parseInt(request.getParameter("rate_company_id"));
				int num_student_total = Integer.parseInt(request.getParameter("num_student_total"));
				String type_offer_job = request.getParameter("type_offer_job");
				TableRateCompanyDao tableRateCompanyDao = new TableRateCompanyDao();
				tableRateCompanyDao.UpdateRateCompany(rate_company_id, num_student_total, type_offer_job);
			}
			else if("delete_rate_comapny".equals(action)){
				int rate_company_id = Integer.parseInt(request.getParameter("rate_company_id"));
				TableRateCompanyDao tableRateCompanyDao = new TableRateCompanyDao();
				/**
				 *   insert history
				 *   update null UserID to tb student select company
				 *   delete file student comapny
				 *   delete tb_rate_company  (1 id)
				 */
				int id_company = 0;
				tableRateCompanyDao.deleteRateCompany(rate_company_id,id_company,"delete_rate_company",request);
			}
			else if("search_academic".equals(action)){
				int search_semester = Integer.parseInt(request.getParameter("search_semester"));
				int search_academic = Integer.parseInt(request.getParameter("search_academic"));
				//System.out.println(search_semester+"/"+search_academic);
				
				PrintWriter out = response.getWriter();
				// list rate company
				ArrayList<RateCompanyListBean> rateCompanyListBeans = new ArrayList<>();
				TableRateCompanyDao tableRateCompanyDao = new TableRateCompanyDao();
				rateCompanyListBeans = tableRateCompanyDao.SearchListRateCompany(search_semester, search_academic);
				
				if(rateCompanyListBeans.isEmpty()){
					out.print("Empty");
				}else{
					request.setAttribute("rateCompanyListBeans", rateCompanyListBeans);
					doViewSearchAcademic(request, response);
				}
			}
			
		}	
	}

	private void doViewRateCompany(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/staff/rate_company.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	private void doViewModalDataCompany(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/element/modal_data_company.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	private void doViewSearchAcademic(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/element/staff_rate_company_list_table.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void doExportExcel(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/staff/export_data_rate_company.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
}
