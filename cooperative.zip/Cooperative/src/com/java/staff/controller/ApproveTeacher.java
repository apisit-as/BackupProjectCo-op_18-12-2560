package com.java.staff.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.admin.bean.FacultyBean;
import com.java.admin.dao.TableFacultyDao;
import com.java.list.bean.FooterBean;
import com.java.list.dao.FooterDao;
import com.java.staff.bean.ListApproveTeacherbean;
import com.java.staff.dao.ApproveTeacherDao;
import com.java.util.SessionExpire;

/**
 * Servlet implementation class ApproveTecher
 */
@WebServlet("/ApproveTeacher")
public class ApproveTeacher extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ApproveTeacher() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
			HttpSession session = request.getSession();
			
			// check role session expire
		    if(session.getAttribute("role") == null){
			  	SessionExpire sessionExpire = new SessionExpire();
				response.sendRedirect(sessionExpire.getSendRedirect()); // send redirect to Login page
				return;
		    }			
			
			String role = session.getAttribute("role").toString();
			if(role.equals("staff")){
				
				// list select faclty
				ArrayList<FacultyBean> listFaclty = new ArrayList<FacultyBean>();
				TableFacultyDao tableFacultyDao = new TableFacultyDao();
				listFaclty = tableFacultyDao.getFacultyList();
				request.setAttribute("listFaclty", listFaclty);
				
				// ListApproveTeacher 
				ArrayList<ListApproveTeacherbean> listApproveTeacherBean = new ArrayList<>();
				ApproveTeacherDao approveTeacherDao = new ApproveTeacherDao();
				listApproveTeacherBean = approveTeacherDao.SelectListTeacherApprove();
				request.setAttribute("listApproveTeacherBean", listApproveTeacherBean);
				
				/** set text footer **/
				FooterBean footerBean = new FooterBean();
				footerBean = new FooterDao().SelectDataFooter();
				request.setAttribute("footerBean", footerBean);
				
				doViewApproveTecher(request, response);
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		response.setHeader("Pragma", "no-cache");
		response.setDateHeader("Expires", 0);
		  
		HttpSession session = request.getSession();
		String role = session.getAttribute("role").toString();
		
		if(role.equals("staff")){
			
			String action = request.getParameter("action");
			
			if("update_status".equals(action)){
				String check_value = request.getParameter("check_value");
				int user_id = Integer.parseInt(request.getParameter("user_id"));
				
				if("on".equals(check_value)){
					check_value = "true";
				}else if("off".equals(check_value)){
					check_value = null;
				}else{
					return;
				}

				//System.out.println(check_value);
				ApproveTeacherDao approveTeacherDao = new ApproveTeacherDao();
				
				// update null  division
				approveTeacherDao.UpdateApproveTeacherNull(user_id);
				
				// update true
				approveTeacherDao.UpdateApproveTeacher(check_value, user_id);
				
			}
		}

	}
	private void doViewApproveTecher(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/staff/approve_teacher.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
}
