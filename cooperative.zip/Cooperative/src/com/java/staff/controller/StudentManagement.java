 package com.java.staff.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.admin.bean.AcademicYearBean;
import com.java.admin.bean.FacultyBean;
import com.java.admin.dao.AdminManagementDao;
import com.java.admin.dao.TableAcademicYearDao;
import com.java.admin.dao.TableFacultyDao;
import com.java.list.bean.FooterBean;
import com.java.list.dao.AcademicYearSelectListDao;
import com.java.list.dao.FooterDao;
import com.java.staff.bean.CompanyBean;
import com.java.staff.bean.ListStudentSelectCompanyBean;
import com.java.staff.bean.ListStudentTab1Bean;
import com.java.staff.bean.RegionBean;
import com.java.staff.dao.StudentManagementDao;
import com.java.staff.dao.TableCompanyDao;
import com.java.staff.dao.TableRegionDao;
import com.java.staff.dao.TableStudentSelectCompanyDao;
import com.java.student.bean.HistoryStatusBean;
import com.java.student.bean.UserBean;
import com.java.student.dao.TableApprovalStatusDao;
import com.java.student.dao.TableCompleteStatusDocument;
import com.java.student.dao.TableHistoryStatusDao;
import com.java.student.dao.TableUserDao;
import com.java.util.SessionExpire;

/**
 * Servlet implementation class StudentManagement
 */
@WebServlet("/StudentManagement")
public class StudentManagement extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentManagement() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
			HttpSession session = request.getSession();
			TableUserDao tableUserDao = new TableUserDao();
			UserBean userBean = new UserBean();
			
			// check role session expire
		    if(session.getAttribute("role") == null){
			  	SessionExpire sessionExpire = new SessionExpire();
				response.sendRedirect(sessionExpire.getSendRedirect()); // send redirect to Login page
				return;
		    }			
			
			String role = session.getAttribute("role").toString();
			if(role.equals("staff")){
				int UserID = Integer.parseInt(session.getAttribute("UserID").toString());
			    userBean = tableUserDao.getTableUser(UserID);
			    
			    // set title tab
			    session.setAttribute("titlename_th_session", userBean.getTitlename_th());
			    session.setAttribute("firstname_th_session", userBean.getFirstname_th());
			    session.setAttribute("lastname_th_session", userBean.getLastname_th());
			    session.setAttribute("rolename_th_session", userBean.getRolename_th());
			    
				// list select faclty
				ArrayList<FacultyBean> listFaclty = new ArrayList<FacultyBean>();
				TableFacultyDao tableFacultyDao = new TableFacultyDao();
				listFaclty = tableFacultyDao.getFacultyList();
				request.setAttribute("listFaclty", listFaclty);
			    
			    // set Academic Year
				TableAcademicYearDao tableAcademicYear = new TableAcademicYearDao();
				AcademicYearBean academicYearBean = new AcademicYearBean();
				academicYearBean = tableAcademicYear.getAcademic();
				session.setAttribute("Semester", academicYearBean.getSemester());
				session.setAttribute("Academic_year", academicYearBean.getAcademic_year());
				session.setAttribute("academic_year_id", academicYearBean.getId());
				request.setAttribute("searchSemester", academicYearBean.getSemester());
				request.setAttribute("searchAcademic", academicYearBean.getAcademic_year());
				
				// list select semester,academic
				ArrayList<Integer> listSemester = new ArrayList<>();
				ArrayList<Integer> listAcademic = new ArrayList<>();
				AcademicYearSelectListDao academicYearSelectListDao = new AcademicYearSelectListDao();
				listSemester = academicYearSelectListDao.getSearchList("Semester");
				listAcademic = academicYearSelectListDao.getSearchList("Academic_year");
				request.setAttribute("listSemester",listSemester);
				request.setAttribute("listAcademic",listAcademic);
				
				/** set table list tab1 **/
				ArrayList<ListStudentTab1Bean> listStudentTab1Bean = new ArrayList<>();
				StudentManagementDao studentManagementDao = new StudentManagementDao();
				listStudentTab1Bean = studentManagementDao.SelectListStudentTab1(academicYearBean.getId());
				request.setAttribute("listStudentTab1Bean",listStudentTab1Bean);
				session.setAttribute("academic_year_check_status","true");
				request.setAttribute("salary", "  ");
				/** #set table list tab1 **/
				
				/** set table list tab2 **/
				int search_status_id;
				if(session.getAttribute("set_search_status_id") == null){
					search_status_id = 6;
				}else{
					search_status_id = Integer.parseInt(session.getAttribute("set_search_status_id").toString());
				}
				request.setAttribute("search_status_id", search_status_id);
				/** #set table list tab2 **/
				
				/** set table list tab3 **/
				int academic_id = academicYearBean.getId();
				ArrayList<ListStudentSelectCompanyBean> listStudentSelectCompanyBean_Tab3 = new ArrayList<>();
				TableStudentSelectCompanyDao tableStudentSelectCompany = new TableStudentSelectCompanyDao();
				listStudentSelectCompanyBean_Tab3 = tableStudentSelectCompany.SelectListStudentMatchCompany(academic_id);
				request.setAttribute("listStudentSelectCompanyBean_Tab3", listStudentSelectCompanyBean_Tab3);
				/** #set table list tab3 **/
				
				/** check role admin **/
				AdminManagementDao adminManagementDao = new AdminManagementDao();
				if(adminManagementDao.CheckRoleAdmin(UserID)){
					session.setAttribute("role_admin", "true");
				}else{
					session.setAttribute("role_admin", "false");
				}
				/** #check role admin **/
				
				/** check role approve document  */
				String CheckRoleApproveStaff = userBean.getApprove_role();
				session.setAttribute("CheckRoleApproveStaff",CheckRoleApproveStaff);
				
				if("true".equals(CheckRoleApproveStaff)){
					/** set text footer **/
					FooterBean footerBean = new FooterBean();
					footerBean = new FooterDao().SelectDataFooter();
					request.setAttribute("footerBean", footerBean);
					
					doViewStudentManagement(request, response); // doViewStudentManagement
				}else{
					session.setAttribute("checkRoleStaff", "not_approve_staff");
					response.sendRedirect("Profile"); // doViewProfile
				}
				/** #check role approve document  */
				
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		
		String action = request.getParameter("action");
		if("setTab".equals(action)){
			/** set tab */
			String valueTab = request.getParameter("valueTab");
			session.setAttribute("valueTabApproveDocument",valueTab);
		}
		else if("search_status_tab2".equals(action)){
			/** search_status_tab2 */
			int search_status_id = Integer.parseInt(request.getParameter("search_status_id"));
			int academic_year_id = Integer.parseInt(session.getAttribute("academic_year_id").toString());
			ArrayList<ListStudentSelectCompanyBean> listStudentSelectCompanyBean_Tab2 = new ArrayList<>();
			TableStudentSelectCompanyDao tableStudentSelectCompany = new TableStudentSelectCompanyDao();
			listStudentSelectCompanyBean_Tab2 = tableStudentSelectCompany.SelectListStudentSelectCompany(search_status_id,academic_year_id);
			request.setAttribute("listStudentSelectCompanyBean_Tab2", listStudentSelectCompanyBean_Tab2);
			session.setAttribute("set_search_status_id",search_status_id);
			doViewSearchTableTab2(search_status_id, request, response);
		}
		else if("show_modal".equals(action)){
			
			/** data company */
			int id_company = Integer.parseInt(request.getParameter("id"));
			CompanyBean companyBean = new CompanyBean();
			TableCompanyDao tableCompanyDao = new TableCompanyDao();
			companyBean = tableCompanyDao.SelectCompany(id_company);
			request.setAttribute("companyBean", companyBean);
			
			/** list data region */
			ArrayList<RegionBean> listRegionCompany = new ArrayList<>();
			TableRegionDao tableRegionDao = new TableRegionDao();
			listRegionCompany = tableRegionDao.SelectListRegion();
			request.setAttribute("listRegionCompany", listRegionCompany);
			
			// data  select list  type_company_select,residence_company_select
			CompanyManagement companyManagement = new CompanyManagement();
			companyManagement.listSelectComapny(request, response);
			
			getPageModalDataCompany(request, response);
		}
		else if("search_academic".equals(action)){
			
			/** search_academic  tab 1 */
			int search_semester = Integer.parseInt(request.getParameter("search_semester"));
			int search_academic = Integer.parseInt(request.getParameter("search_academic"));
			//System.out.println(search_semester+"/"+search_academic);
			
			StudentManagementDao studentManagementDao = new StudentManagementDao();
			
			// check tag a link status
			int academic_year_id = Integer.parseInt(session.getAttribute("academic_year_id").toString());
			int academic_year_id_check = studentManagementDao.getAcademicID(search_semester, search_academic);
			if(academic_year_id == academic_year_id_check){
				session.setAttribute("academic_year_check_status","true");
			}else{
				session.setAttribute("academic_year_check_status","false");
			}
			
			// list table tab1
			PrintWriter out = response.getWriter();
			ArrayList<ListStudentTab1Bean> listStudentTab1Bean = new ArrayList<>();
			listStudentTab1Bean = studentManagementDao.SearchListTab1(search_semester, search_academic);
			if(listStudentTab1Bean.isEmpty()){
				out.print("Empty");
			}else{
				request.setAttribute("listStudentTab1Bean",listStudentTab1Bean);
				doViewSearchAcademic(request, response);
			}
		}
		else if("edit_student".equals(action)){
			int UserID_sutdent = Integer.parseInt(request.getParameter("id"));
			
			StudentManagementDao studentManagementDao = new StudentManagementDao();
			
			/** ���˹�ҷ�����ѡ�֡������͡���
			 *  update 4 = �觡�Ѻ���      
			 *  Lv1_ApStatusID = 4  ,  Lv2_ApStatusID = 4 
			 * 
			 *  update null �ѡ�֡�����͡ʶҹ��Сͺ���
			 */
			studentManagementDao.UpdateDocumentStatusStudent(UserID_sutdent);
			
			/**
			 *  insert history
			 */
			String date = getDateDefaultToString();
			TableApprovalStatusDao tableApprovalStatusDao = new TableApprovalStatusDao();
			InsertHistory(date, "�Դ������˹�ҷ������͡���", tableApprovalStatusDao.getStatusApproval(4),UserID_sutdent);
			
			/**
			 *  update status ��¡�â����ž�鹰ҹ   ��� = 3
			 */
			updateStatusCompleteStatusDocument(UserID_sutdent);

		}
	}
	
	public String getDateDefaultToString(){
		LocalDate localDate = LocalDate.now();
		String date = DateTimeFormatter.ofPattern("dd/MM/yyy").format(localDate);
		String[] dateSplit = date.split("/");
		date = "";
		date = dateSplit[0]+"/"+dateSplit[1]+"/"+(Integer.parseInt(dateSplit[2])+543);
		return date;
	}
	
	public void InsertHistory(String date,String history,String status,int userid){
		HistoryStatusBean historyStatusBean = new HistoryStatusBean();
		historyStatusBean.setDate(date);
		historyStatusBean.setHistory(history);
		historyStatusBean.setStatus(status);
		historyStatusBean.setUserid(userid);
		TableHistoryStatusDao tableHistoryStatus = new TableHistoryStatusDao();
		tableHistoryStatus.InsertHistoryStatus(historyStatusBean);
	}
	
	public void updateStatusCompleteStatusDocument(int UserID_sutdent){
		/** insert,update status document **/
		TableCompleteStatusDocument tableCompleteStatusDocument = new TableCompleteStatusDocument();
		String []fieldName = {"DataStudent","DataAddress","DataFamily","DataEducation","DataActivity","DataTalent","DataCareer","DataTranscript"};
		
		for(int i=0; i<fieldName.length; i++){
			//update   3 = ���
			tableCompleteStatusDocument.UpdateCompleteStatusDoc(fieldName[i], 3, UserID_sutdent);
		}
	}
	
	private void doViewSearchAcademic(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/element/staff_tab_student_management/student_management_list_table_tab1.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}

	private void doViewStudentManagement(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/staff/student_management.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	private void doViewSearchTableTab2(int status_id,HttpServletRequest request, HttpServletResponse response) {
		/**
		 *  6 = �ʹ��Թ��� , 7 = ���ѧ���Թ��� , 8 = �͡������ , 11 = �ͺ�Ѻ  , 12 = ���ͺ�Ѻ  ,  13 = �ѡ�֡�ҵԴ������˹�ҷ��
		 *  
		 *  tab2_table_status1 = �ʹ��Թ���
		 *  tab2_table_status2_and_status6 = ���ѧ���Թ��� , �ѡ�֡�ҵԴ������˹�ҷ��
		 *  tab2_table_status3 = �͡������
		 *  tab2_table_status4 = �ͺ�Ѻ
		 *  tab2_table_status5 = ���ͺ�Ѻ
		 */
		String path = "";
		if(status_id == 6){
			path ="/include/element/staff_tab_student_management/tab2_table_status1.jsp";
		}
		else if(status_id == 7 || status_id == 13){
			path ="/include/element/staff_tab_student_management/tab2_table_status2_and_status6.jsp";
		}
		else if(status_id == 8){
			path ="/include/element/staff_tab_student_management/tab2_table_status3.jsp";
		}
		else if(status_id == 11){
			path ="/include/element/staff_tab_student_management/tab2_table_status4.jsp";
		}
		else if(status_id == 12){
			path ="/include/element/staff_tab_student_management/tab2_table_status5.jsp";
		}
		RequestDispatcher rd = request.getRequestDispatcher(path);
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void getPageModalDataCompany(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/element/data_company.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
}
