package com.java.staff.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.list.bean.FooterBean;
import com.java.list.dao.FooterDao;
import com.java.staff.bean.CompanyBean;
import com.java.staff.bean.RegionBean;
import com.java.staff.dao.TableCompanyDao;
import com.java.staff.dao.TableRateCompanyDao;
import com.java.staff.dao.TableRegionDao;
import com.java.util.SessionExpire;

/**
 * Servlet implementation class CompanyManagement
 */
@WebServlet("/CompanyManagement")
public class CompanyManagement extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CompanyManagement() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
		  HttpSession session = request.getSession();
		  
		  // check role session expire
	      if(session.getAttribute("role") == null){
		    	SessionExpire sessionExpire = new SessionExpire();
			  response.sendRedirect(sessionExpire.getSendRedirect()); // send redirect to Login page
			  return;
	      }
		  
		  String role = session.getAttribute("role").toString();
		  
		  String action = request.getParameter("action");
			if("export_data_company".equals(action) && role.equals("staff")){
				  	TableCompanyDao tableCompanyDao = new TableCompanyDao();
				  	ArrayList<CompanyBean> ListDataCompany = new ArrayList<>();
					ListDataCompany = tableCompanyDao.SelectListCompanyExportExcel();
					request.setAttribute("ListDataCompany", ListDataCompany);
					doExportExcel(request, response);
					return;
			}
		  
			if(role.equals("staff")){
				TableCompanyDao tableCompanyDao = new TableCompanyDao();
				ArrayList<CompanyBean> ListDataCompany = new ArrayList<>();
				ListDataCompany = tableCompanyDao.SelectListCompany();
				request.setAttribute("ListDataCompany", ListDataCompany);
				
				ArrayList<RegionBean> listRegionCompany = new ArrayList<>();
				TableRegionDao tableRegionDao = new TableRegionDao();
				listRegionCompany = tableRegionDao.SelectListRegion();
				request.setAttribute("listRegionCompany", listRegionCompany);
				
				// data  select list  type_company_select,residence_company_select
				listSelectComapny(request, response);
				
				/** set text footer **/
				FooterBean footerBean = new FooterBean();
				footerBean = new FooterDao().SelectDataFooter();
				request.setAttribute("footerBean", footerBean);
				
				doViewCompanyManagement(request, response);
				
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String role = session.getAttribute("role").toString();
		
		if(role.equals("staff")){
			
			String action = request.getParameter("action");
			TableCompanyDao tableCompanyDao = new TableCompanyDao();
			CompanyBean companyBean = new CompanyBean();
			
			if("insert".equals(action) || "update".equals(action)){
				companyBean.setId(Integer.parseInt(request.getParameter("id")));
				companyBean.setName_company(request.getParameter("NameCompany"));
				companyBean.setRegion_company_id(Integer.parseInt(request.getParameter("RegionCompany")));
				companyBean.setAddress_company(request.getParameter("AddressCompany"));
				companyBean.setDistrict_company(request.getParameter("DistrictCompany"));
				companyBean.setAmphur_company(request.getParameter("AmphurCompany"));
				companyBean.setProvince_company(request.getParameter("ProvinceCompany"));
				companyBean.setPostcode_company(request.getParameter("PostcodeCompany"));
				companyBean.setTelephone_company(request.getParameter("TelephoneCompany"));
				companyBean.setFax_company(request.getParameter("FaxCompany"));
				companyBean.setEmail_company(request.getParameter("EmailCompany"));
				companyBean.setType_work_company(request.getParameter("TypeWorkCompany"));
				companyBean.setPay_yes_company(request.getParameter("PayYesCompany"));
				companyBean.setType_company(request.getParameter("TypeCompany"));
				companyBean.setEmployees_company(request.getParameter("EmployeesCompany"));
				companyBean.setResidence_company(request.getParameter("ResidenceCompany"));
				companyBean.setWelfar_company(request.getParameter("WelfarCompany"));
				companyBean.setName_contact(request.getParameter("NameContact"));
				companyBean.setTelephone_contact(request.getParameter("TelephoneContact"));
				companyBean.setMobile_contact(request.getParameter("MobileContact"));
				companyBean.setFax_contact(request.getParameter("FaxContact"));
				companyBean.setEmail_contact(request.getParameter("EmailContact"));
				
				if("insert".equals(action)){
					tableCompanyDao.InsertCompany(companyBean);
				}
				else if("update".equals(action)){
					tableCompanyDao.UpdateCompany(companyBean);
				}
			}
			
			else if("delete".equals(action)){
				/**
				 *   select id company
				 *   get list rate_company_id 
				 *   insert history
				 *   update null UserID to tb student select company
				 *   delete rate_company  (multi id company)
				 *   delete tb_company
				 */     

				/** select id company */
				int id_company = Integer.parseInt(request.getParameter("id"));
				TableRateCompanyDao tableRateCompanyDao = new TableRateCompanyDao();
				
				/** get list rate_company_id */ 
				ArrayList<Integer> list_rate_company_id = new ArrayList<>();
				list_rate_company_id = tableRateCompanyDao.SelectListRateCompanyID(id_company);
				
				for (Integer rate_company_id : list_rate_company_id) {
					/**
					 *   loop multi id rate_comapny
					 *   insert history
					 *   update null UserID to tb student select company
					 *   delete rate_company  (multi id company)
					 */
					tableRateCompanyDao.deleteRateCompany(rate_company_id,id_company,"delete_company",request);
				}

				/** delete tb_company */
				tableCompanyDao.deleteCompany(id_company);
			}
			else if("show_modal".equals(action)){
				
				/** data company */
				int id_company = Integer.parseInt(request.getParameter("id"));
				companyBean = tableCompanyDao.SelectCompany(id_company);
				request.setAttribute("companyBean", companyBean);
				
				/** list data region */
				ArrayList<RegionBean> listRegionCompany = new ArrayList<>();
				TableRegionDao tableRegionDao = new TableRegionDao();
				listRegionCompany = tableRegionDao.SelectListRegion();
				request.setAttribute("listRegionCompany", listRegionCompany);
				
				// data  select list  type_company_select,residence_company_select
				listSelectComapny(request, response);
				
				getPageModalDataCompany(request, response);
			}
		}
	}
	private void doViewCompanyManagement(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/staff/company_management.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void doExportExcel(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/staff/export_data_company.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void getPageModalDataCompany(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/element/data_company.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	public void listSelectComapny(HttpServletRequest request,HttpServletResponse response){
		// data  select list  type_company_select,residence_company_select
		TableCompanyDao tableCompanyDao = new TableCompanyDao();
		ArrayList<String> listTypeCompany = new ArrayList<>();
		ArrayList<String> listResidenceCompany = new ArrayList<>();
		listTypeCompany = tableCompanyDao.getListTypeCompany();
		listResidenceCompany = tableCompanyDao.getListResidenceCompany();
		request.setAttribute("listTypeCompany", listTypeCompany);
		request.setAttribute("listResidenceCompany", listResidenceCompany);
	}
}
