package com.java.staff.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.staff.bean.FileManagementBean;
import com.java.util.PreparedStatementUtil;

public class TableFileManagementDao {

	public void InsertFileManagement(FileManagementBean fileManagementBean) {
		PreparedStatementUtil preparedStatementUtil = null;
		try {
			String query = "INSERT INTO tb_file_management(code_file,"
							+ "name,"
							+ "type,"
							+ "path_file) "
							+ " VALUES(:code_file,"
									+ ":name,"
									+ ":type,"
									+ ":path_file)";
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setString("code_file",fileManagementBean.getCode_file());
			preparedStatementUtil.setString("name",fileManagementBean.getName());
			preparedStatementUtil.setString("type",fileManagementBean.getType());
			preparedStatementUtil.setString("path_file",fileManagementBean.getPath_file());
			preparedStatementUtil.execute();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (preparedStatementUtil != null)
				try {
					preparedStatementUtil.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
	}
	
	public void UpdateFileManagement(FileManagementBean fileManagementBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_file_management SET "
		   				+ "code_file = :code_file,"
		   				+ "name = :name, "
		   				+ "path_file = :path_file "
		   				+ "WHERE ID = :id ";
		    preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setString("code_file",fileManagementBean.getCode_file());
			preparedStatementUtil.setString("name",fileManagementBean.getName());
			preparedStatementUtil.setString("path_file",fileManagementBean.getPath_file());
			preparedStatementUtil.setInt("id",fileManagementBean.getId());
		   preparedStatementUtil.execute();	   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public String getOldFile(int id){
		
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		String code_file = "";
		String name = "";
		String type = "";
		String query = "SELECT code_file, "
							+ "name, "
							+ "type "
				+ " FROM tb_file_management "
				+ " WHERE ID = :id  LIMIT 1"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id", id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				code_file = rs.getString("code_file");
				name = rs.getString("name");
				type = rs.getString("type");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return code_file+"_"+name+"."+type.toLowerCase();
	} 
	
	public Boolean CheckRepeatValuePathFile(String path_file){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = "SELECT True as isTrue FROM tb_file_management WHERE path_file = :path_file LIMIT 1";
		
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setString("path_file", "Upload/File/file_management/"+path_file);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				value = rs.getBoolean("isTrue");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}	
	
	public ArrayList<FileManagementBean> SelectListFile(){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		ArrayList<FileManagementBean> list = new ArrayList<>();
		
		String query = "SELECT ID,"
							+ "code_file,"
							+ "name,"
							+ "type,"
							+ "path_file "
					+ " FROM tb_file_management "
					+ " ORDER BY code_file ASC , type ASC ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			rs = preparedStatementUtil.executeQuery();
			while(rs.next()){
				FileManagementBean bean = new FileManagementBean();
				bean.setId(rs.getInt("ID"));
				bean.setCode_file(rs.getString("code_file"));
				bean.setName(rs.getString("name"));
				bean.setType(rs.getString("type"));
				bean.setPath_file(rs.getString("path_file"));
				list.add(bean);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	} 
	
	public void deleteFileTable(int id){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "DELETE FROM tb_file_management WHERE ID = :id";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("id",id);
		   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
}
