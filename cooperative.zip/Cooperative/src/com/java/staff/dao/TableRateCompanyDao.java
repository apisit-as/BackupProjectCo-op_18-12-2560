package com.java.staff.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import com.java.staff.bean.RateCompanyBean;
import com.java.staff.bean.RateCompanyExportExcelListBean;
import com.java.staff.bean.RateCompanyListBean;
import com.java.staff.bean.RateCompanyListCompanyBean;
import com.java.staff.bean.UserListStudentRateCompanyBean;
import com.java.student.bean.HistoryStatusBean;
import com.java.student.dao.TableDocumentStatusDao;
import com.java.student.dao.TableHistoryStatusDao;
import com.java.util.FileUploadUtil;
import com.java.util.PreparedStatementUtil;

public class TableRateCompanyDao {
	
	public ArrayList<UserListStudentRateCompanyBean> SelectListStudent(int facid,int divid,int academic_id){
		/**
		 * select list student
		 * modal select student
		 * rate_company_management
		 */
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ArrayList<UserListStudentRateCompanyBean> list = new ArrayList<>();
		String query =  "SELECT  tb_user.StudentID,"
							  + "tb_title.Name_th AS titleName_th,"
							  + "tb_user.FirstName_th,"
							  + "tb_user.LastName_th,"
							  + "tb_user.ID AS UserID,"
							  + "tb_faculty.Name AS fac_name,"
							  + "tb_division.Name AS div_name  "
				        + "FROM tb_student_select_company "
				        + "JOIN tb_user  ON tb_user.ID = tb_student_select_company.UserID "
				        + "JOIN tb_title  ON tb_title.ID = tb_user.TitleID "
				        + "JOIN tb_faculty  ON tb_faculty.ID = tb_user.FacID "
				        + "JOIN tb_division  ON tb_division.ID = tb_user.DivID "
				        + "JOIN tb_student_send_document  ON tb_student_send_document.UserID = tb_user.ID "
				        	+ "WHERE (tb_user.FacID = :facid  AND  tb_user.DivID = :divid  "
				        				+ "AND tb_student_select_company.Academic_year = :academic_id  "
				        				+ "AND tb_student_send_document.Lv2_ApStatusID = 2"
				        		   + ") "
				        	       + "AND "
				        	       		+ "(tb_student_select_company.Lv1_ApStatusID IS null "
				        	     	      + "OR tb_student_select_company.Lv1_ApStatusID = 5 "
				        	     	   	  + "OR tb_student_select_company.Staff_ApStatusID = 12"
				        	     	   	  + ") ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("facid", facid);
			preparedStatementUtil.setInt("divid", divid);
			preparedStatementUtil.setInt("academic_id", academic_id);
			rs = preparedStatementUtil.executeQuery();
			while(rs.next()){
				UserListStudentRateCompanyBean bean = new UserListStudentRateCompanyBean();
				bean.setStudent_id(rs.getString("StudentID"));
				bean.setTitle_name_th(rs.getString("titleName_th"));
				bean.setFirstname_th(rs.getString("FirstName_th"));
				bean.setLastname_th(rs.getString("LastName_th"));
				bean.setUser_id(rs.getInt("UserID"));
				bean.setFac_name(rs.getString("fac_name"));
				bean.setDiv_name(rs.getString("div_name"));
				list.add(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public ArrayList<UserListStudentRateCompanyBean> SelectListStudent(int rate_company_id){
		/**
		 *  select list student
		 *  show table edit data_rate_company
		 *  rate_company
		 */
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		ArrayList<UserListStudentRateCompanyBean> list = new ArrayList<>();
		String query =  "SELECT  tb_user.StudentID,"
							  + "tb_title.Name_th AS titleName_th,"
							  + "tb_user.FirstName_th,"
							  + "tb_user.LastName_th,"
							  + "tb_faculty.Name AS fac_name,"
							  + "tb_division.Name AS div_name  "
				        + "FROM tb_student_select_company "
				        + "JOIN tb_user  ON tb_user.ID = tb_student_select_company.UserID "
				        + "JOIN tb_title  ON tb_title.ID = tb_user.TitleID "
				        + "JOIN tb_faculty  ON tb_faculty.ID = tb_user.FacID "
				        + "JOIN tb_division  ON tb_division.ID = tb_user.DivID "
				        	+ "WHERE tb_student_select_company.RateCompanyID = :rate_company_id ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("rate_company_id", rate_company_id);
			rs = preparedStatementUtil.executeQuery();
			while(rs.next()){
				UserListStudentRateCompanyBean bean = new UserListStudentRateCompanyBean();
				bean.setStudent_id(rs.getString("StudentID"));
				bean.setTitle_name_th(rs.getString("titleName_th"));
				bean.setFirstname_th(rs.getString("FirstName_th"));
				bean.setLastname_th(rs.getString("LastName_th"));
				bean.setFac_name(rs.getString("fac_name"));
				bean.setDiv_name(rs.getString("div_name"));
				list.add(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public int InsertRateCompany(RateCompanyListCompanyBean companyBean) {
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		int key = 0;
		try {
			String query = "INSERT INTO tb_rate_company(CompanyID,"
							+ "Academic_yearID,"
							+ "FacID,"
							+ "DivID,"
							+ "Num_student,"
							+ "Type_offerjob) "
							+ " VALUES(:company_id,"
									+ ":academic_id,"
									+ ":fac_id,"
									+ ":div_id,"
									+ ":num_student,"
									+ ":type_offer_job)";
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("company_id", companyBean.getCompany_id());
			preparedStatementUtil.setInt("academic_id", companyBean.getAcademic_year_id());
			preparedStatementUtil.setInt("fac_id", companyBean.getFaculty_id());
			preparedStatementUtil.setInt("div_id", companyBean.getDivision_id());
			preparedStatementUtil.setInt("num_student", companyBean.getNum_student());
			preparedStatementUtil.setString("type_offer_job", companyBean.getType_offer_job());
			rs = preparedStatementUtil.executeInsertGetKeys();
			if (rs.next()) {
				key = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (preparedStatementUtil != null)
				try {
					preparedStatementUtil.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return key;
	}
	
	public void UpdateRateCompany(int rate_company_id,int num_student_total,String  type_offer_job){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_rate_company SET "
			   				+ "Num_student = :num_student, "
			   				+ "Type_offerjob = :type_offer_job "
		   				+ "WHERE ID = :rate_company_id ";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("num_student",num_student_total);
		   preparedStatementUtil.setString("type_offer_job",type_offer_job);
		   preparedStatementUtil.setInt("rate_company_id",rate_company_id);
		   preparedStatementUtil.execute();	   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public ArrayList<RateCompanyListBean> SearchListRateCompany(int search_semester,int search_academic){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ArrayList<RateCompanyListBean> list = new ArrayList<>();
		int academic_id = 0;
		String query = "SELECT  ID "
					   +"FROM tb_academic_year "
					   +"WHERE Semester = :semester_id AND Academic_year = :academic_id ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("semester_id", search_semester);
			preparedStatementUtil.setInt("academic_id", search_academic);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				academic_id = rs.getInt("ID");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		list = SelectListRateCompany(academic_id);
		return list;
	}
	public ArrayList<RateCompanyListBean> SelectListRateCompany(int academic_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ArrayList<RateCompanyListBean> list = new ArrayList<>();
		String query = "SELECT  tb_rate_company.ID AS rate_company_id,"
							   +"tb_company.ID AS company_id,"
							   +"tb_company.NameCompany,"
							   +"tb_company.ProvinceCompany,"
							   +"tb_region.Name AS region_name,"
							   +"tb_faculty.Name AS faculty_name,"
							   +"tb_division.Name AS divison_name,"
							   +"tb_rate_company.Type_offerjob,"
							   +"tb_rate_company.Num_student AS num_studnet_total,"
							   +"tb_academic_year.Semester,"
							   +"tb_academic_year.Academic_year	"
					   +"FROM tb_rate_company  "
					   +"JOIN tb_academic_year  ON tb_academic_year.ID = tb_rate_company.Academic_yearID "
					   +"JOIN tb_faculty  ON tb_faculty.ID = tb_rate_company.FacID "
					   +"JOIN tb_division  ON tb_division.ID = tb_rate_company.DivID "
					   +"JOIN tb_company  ON tb_company.ID = tb_rate_company.CompanyID  "
					   +"JOIN tb_region  ON tb_region.ID = tb_company.RegionCompany "
					   +"WHERE tb_rate_company.Academic_yearID = :academic_id ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("academic_id", academic_id);
			rs = preparedStatementUtil.executeQuery();
			while(rs.next()){
				RateCompanyListBean bean = new RateCompanyListBean();
				bean.setRate_company_id(rs.getInt("rate_company_id"));
				bean.setCompany_id(rs.getInt("company_id"));
				bean.setName_company(rs.getString("NameCompany"));
				bean.setProvice_company(rs.getString("ProvinceCompany"));
				bean.setRegion_company_name(rs.getString("region_name"));
				bean.setFac_name(rs.getString("faculty_name"));
				bean.setDiv_name(rs.getString("divison_name"));
				bean.setType_offer_job(rs.getString("Type_offerjob"));
				bean.setNum_student(getNumberStudent(bean.getRate_company_id()));
				bean.setNum_student_total(rs.getInt("num_studnet_total"));
				bean.setSemester(rs.getString("Semester"));
				bean.setAcademic_year(rs.getString("Academic_year"));
				list.add(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	
	public int getNumberStudent(int rate_company_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		int num_student = 0;
		String query = "SELECT  COUNT(tb_student_select_company.RateCompanyID) AS num_student "
							+"FROM tb_student_select_company "
							+"WHERE tb_student_select_company.RateCompanyID = :rate_company_id ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("rate_company_id", rate_company_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				num_student = rs.getInt("num_student");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return num_student;
	}
	
	public RateCompanyBean SelectRateCompany(int rate_company_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		RateCompanyBean bean = new RateCompanyBean();
		String query = "SELECT  tb_academic_year.Semester,"
							   +"tb_academic_year.Academic_year,"
							   +"tb_rate_company.Num_student AS num_studnet_total,"
							   +"tb_faculty.Name AS faculty_name,"
							   +"tb_division.Name AS divison_name,"
							   +"tb_rate_company.Type_offerjob "
					   +"FROM tb_rate_company  "
					   +"JOIN tb_academic_year  ON tb_academic_year.ID = tb_rate_company.Academic_yearID "
					   +"JOIN tb_faculty  ON tb_faculty.ID = tb_rate_company.FacID "
					   +"JOIN tb_division  ON tb_division.ID = tb_rate_company.DivID "
					   +"WHERE tb_rate_company.ID = :rate_company_id  LIMIT 1";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("rate_company_id", rate_company_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				bean.setSemester(rs.getString("Semester"));
				bean.setAcademic_year(rs.getString("Academic_year"));
				bean.setNum_student_total(rs.getInt("num_studnet_total"));
				bean.setFac_name(rs.getString("faculty_name"));
				bean.setDiv_name(rs.getString("divison_name"));
				bean.setType_offer_job(rs.getString("Type_offerjob"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return bean;
	}
	
	public void deleteRateCompany(int rate_company_id,int id_company,String type_delete,HttpServletRequest request){
		  // select list user_id
		 ArrayList<Integer> user_id_list = new ArrayList<>();
		 user_id_list = SelectListUserID(rate_company_id,request);
		
		 // insert history  ʶҹ� ���͡ʶҹ��Сͺ���
		 insertHistory(user_id_list);
		 
		  // update = null student_select_rate_company
		  updateNullStudentSelectRateCompany(rate_company_id);
		  
		  // delete rate_company
		  PreparedStatementUtil preparedStatementUtil = null;
		  
		  if("delete_rate_company".equals(type_delete)){
			  // delete rate_company 1 id
			  try{
				   String query = "DELETE FROM tb_rate_company WHERE ID = :rate_company_id";
				   preparedStatementUtil = new PreparedStatementUtil(query);
				   preparedStatementUtil.setInt("rate_company_id",rate_company_id);
				   preparedStatementUtil.execute();
			  }catch(Exception e){
			   e.printStackTrace();
			  }finally{
			   if(preparedStatementUtil != null)
				try {
					preparedStatementUtil.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			  }
		  }else if("delete_company".equals(type_delete)){
			  // delete rate_company multi id_company
			  try{
				   String query = "DELETE FROM tb_rate_company WHERE CompanyID = :id_company";
				   preparedStatementUtil = new PreparedStatementUtil(query);
				   preparedStatementUtil.setInt("id_company",id_company);
				   preparedStatementUtil.execute();
			  }catch(Exception e){
			   e.printStackTrace();
			  }finally{
			   if(preparedStatementUtil != null)
				try {
					preparedStatementUtil.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			  }
		  }

	}
	
	public void updateNullStudentSelectRateCompany(int rate_company_id){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_student_select_company SET "
		   				+ "RateCompanyID = null , " 
		   				+ "RateCompanyID_Temp = null , "
		   				+ "Lv1_ApStatusID = null , " 
		   				+ "Lv1_ApStatusBy = null , " 
		   				+ "Lv1_ApStatusDate = null , " 
		   				+ "Staff_ApStatusID = null , " 
		   				+ "Staff_ApStatusBy = null , " 
		   				+ "Staff_ApStatusDate = null , " 
		   				+ "Comment = null , " 
		   				+ "File = null  "
		   				+ "WHERE tb_student_select_company.RateCompanyID = :rate_company_id "
		   				+ " OR tb_student_select_company.RateCompanyID_Temp = :rate_company_id ";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("rate_company_id", rate_company_id);
		   preparedStatementUtil.execute();	   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	public ArrayList<Integer> SelectListUserID(int rate_company_id,HttpServletRequest request){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ArrayList<Integer> list = new ArrayList<>();
		String query = "SELECT  tb_student_select_company.UserID,"
								+ "tb_student_select_company.File "
					   +"FROM tb_student_select_company  "
					   +"WHERE tb_student_select_company.RateCompanyID = :rate_company_id ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("rate_company_id", rate_company_id);
			rs = preparedStatementUtil.executeQuery();
			while(rs.next()){
				list.add(rs.getInt("UserID"));
				
				// delete file
				FileUploadUtil.deleteFile(request, rs.getString("File"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	
	public void insertHistory(ArrayList<Integer> user_id_list){
		//update status
		TableDocumentStatusDao tableDocumentStatus = new TableDocumentStatusDao();
		String date = getDateDefaultToString();
		for(int i=0; i<user_id_list.size(); i++){
			InsertHistory(date, "���͡ʶҹ��Сͺ���", tableDocumentStatus.getStatusDocument(2),user_id_list.get(i));
		}
	}
	private String getDateDefaultToString(){
		LocalDate localDate = LocalDate.now();
		String date = DateTimeFormatter.ofPattern("dd/MM/yyy").format(localDate);
		String[] dateSplit = date.split("/");
		date = "";
		date = dateSplit[0]+"/"+dateSplit[1]+"/"+(Integer.parseInt(dateSplit[2])+543);
		return date;
	}
	private void InsertHistory(String date,String history,String status,int userid){
		HistoryStatusBean historyStatusBean = new HistoryStatusBean();
		historyStatusBean.setDate(date);
		historyStatusBean.setHistory(history);
		historyStatusBean.setStatus(status);
		historyStatusBean.setUserid(userid);
		TableHistoryStatusDao tableHistoryStatus = new TableHistoryStatusDao();
		tableHistoryStatus.InsertHistoryStatus(historyStatusBean);
	}
	
	public ArrayList<RateCompanyExportExcelListBean> SelectListRateCompanyExportExcel(int search_semester,int search_academic){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		ArrayList<RateCompanyExportExcelListBean> list = new ArrayList<>();
		int academic_id = 0;
		String query = "SELECT  ID "
					   +"FROM tb_academic_year "
					   +"WHERE Semester = :semester_id AND Academic_year = :academic_id ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("semester_id", search_semester);
			preparedStatementUtil.setInt("academic_id", search_academic);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				academic_id = rs.getInt("ID");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		list = getListRateCompanyExportExcel(academic_id);
		return list;
	}
	public ArrayList<RateCompanyExportExcelListBean> getListRateCompanyExportExcel(int academic_id){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<RateCompanyExportExcelListBean> list = new ArrayList<>();
		String query =  "SELECT  tb_company.NameCompany,"
				+ " tb_region.Name AS regionName,"
				+ " tb_company.AddressCompany,"
				+ " tb_company.DistrictCompany,"
				+ " tb_company.AmphurCompany,"
				+ " tb_company.ProvinceCompany,"
				+ " tb_company.PostcodeCompany,"
				+ " tb_company.TelephoneCompany,"
				+ " tb_company.FaxCompany,"
				+ " tb_company.EmailCompany,"
				+ " tb_company.TypeWorkCompany,"
				+ " tb_company.PayYesCompany,"
				+ " tb_company.TypeCompany,"
				+ " tb_company.EmployeesCompany,"
				+ " tb_company.ResidenceCompany,"
				+ " tb_company.WelfarCompany,"
				+ " tb_company.NameContact,"
				+ " tb_company.TelephoneContact,"
				+ " tb_company.MobileContact,"
				+ " tb_company.FaxContact,"
				+ " tb_company.EmailContact, "
				
				+ " tb_academic_year.Semester, "
				+ " tb_academic_year.Academic_year, "
				+ " tb_rate_company.Num_student, "
				+ " tb_faculty.Name AS faculty_name,"
				+ " tb_division.Name AS divison_name,"
				+ " tb_rate_company.Type_offerjob "
				
		        + "FROM tb_rate_company "
		        +"JOIN tb_academic_year  ON tb_academic_year.ID = tb_rate_company.Academic_yearID " 
		        +"JOIN tb_faculty  ON tb_faculty.ID = tb_rate_company.FacID "
		        +"JOIN tb_division  ON tb_division.ID = tb_rate_company.DivID "
		        +"JOIN tb_company  ON tb_company.ID = tb_rate_company.CompanyID  "
		        + "JOIN tb_region  ON tb_region.ID = tb_company.RegionCompany "
		        +"WHERE tb_rate_company.Academic_yearID = :academic_id ";

		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("academic_id", academic_id);
			rs = prepareStatementUtil.executeQuery();
			while(rs.next()){
				RateCompanyExportExcelListBean rateCompanyBean = new RateCompanyExportExcelListBean();
				rateCompanyBean.setName_company(rs.getString("NameCompany"));
				rateCompanyBean.setRegion_company_name(rs.getString("regionName"));
				rateCompanyBean.setAddress_company(rs.getString("AddressCompany"));
				rateCompanyBean.setDistrict_company(rs.getString("DistrictCompany"));
				rateCompanyBean.setAmphur_company(rs.getString("AmphurCompany"));
				rateCompanyBean.setProvince_company(rs.getString("ProvinceCompany"));
				rateCompanyBean.setPostcode_company(rs.getString("PostcodeCompany"));
				rateCompanyBean.setTelephone_company(rs.getString("TelephoneCompany"));
				rateCompanyBean.setFax_company(rs.getString("FaxCompany"));
				rateCompanyBean.setEmail_company(rs.getString("EmailCompany"));
				rateCompanyBean.setType_work_company(rs.getString("TypeWorkCompany"));
				rateCompanyBean.setPay_yes_company(rs.getString("PayYesCompany"));
				rateCompanyBean.setType_company(rs.getString("TypeCompany"));
				rateCompanyBean.setEmployees_company(rs.getString("EmployeesCompany"));
				rateCompanyBean.setResidence_company(rs.getString("ResidenceCompany"));
				rateCompanyBean.setWelfar_company(rs.getString("WelfarCompany"));
				rateCompanyBean.setName_contact(rs.getString("NameContact"));
				rateCompanyBean.setTelephone_contact(rs.getString("TelephoneContact"));
				rateCompanyBean.setMobile_contact(rs.getString("MobileContact"));
				rateCompanyBean.setFax_contact(rs.getString("FaxContact"));
				rateCompanyBean.setEmail_contact(rs.getString("EmailContact"));

				rateCompanyBean.setSemester(rs.getString("Semester"));
				rateCompanyBean.setAcademic_year(rs.getString("Academic_year"));
				rateCompanyBean.setNum_student_total(rs.getInt("Num_student"));
				rateCompanyBean.setFac_name(rs.getString("faculty_name"));
				rateCompanyBean.setDiv_name(rs.getString("divison_name"));
				rateCompanyBean.setType_offer_job(rs.getString("Type_offerjob"));
				list.add(rateCompanyBean);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public ArrayList<Integer> SelectListRateCompanyID(int company_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ArrayList<Integer> list_list_rate_company_id = new ArrayList<>();
		String query = "SELECT  ID "
					   +"FROM tb_rate_company  "
					   +"WHERE CompanyID = :company_id ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("company_id", company_id);
			rs = preparedStatementUtil.executeQuery();
			while(rs.next()){
				list_list_rate_company_id.add(rs.getInt("ID"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list_list_rate_company_id;
	}
}
