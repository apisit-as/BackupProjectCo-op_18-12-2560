package com.java.staff.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.staff.bean.RegionBean;
import com.java.util.PreparedStatementUtil;

public class TableRegionDao {
	public ArrayList<RegionBean> SelectListRegion(){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<RegionBean> list = new ArrayList<>();
		String query =  "SELECT  tb_region.ID,"
						+ " tb_region.Name "
				        + "FROM tb_region ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			rs = prepareStatementUtil.executeQuery();
			
			while(rs.next()){
				RegionBean regionBean = new RegionBean();
				regionBean.setId(rs.getInt("ID"));
				regionBean.setName(rs.getString("Name"));
				list.add(regionBean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}	
}
