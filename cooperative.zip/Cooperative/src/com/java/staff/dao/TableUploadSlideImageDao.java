package com.java.staff.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.staff.bean.UploadSlideImageBean;
import com.java.util.PreparedStatementUtil;

public class TableUploadSlideImageDao {
	
	public void InsertImage(UploadSlideImageBean uploadSlideImageBean) {
		PreparedStatementUtil preparedStatementUtil = null;
		try {
			String query = "INSERT INTO tb_upload_slide_image(name,"
								+ "type,"
								+ "path_file,"
								+ "check_show) "
							+ " VALUES(:name,"
									+ ":type,"
									+ ":path_file,"
									+ ":check_show)";
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setString("name",uploadSlideImageBean.getName());
			preparedStatementUtil.setString("type",uploadSlideImageBean.getType());
			preparedStatementUtil.setString("path_file",uploadSlideImageBean.getPath_file());
			preparedStatementUtil.setString("check_show",uploadSlideImageBean.getCheck_show());
			preparedStatementUtil.execute();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (preparedStatementUtil != null)
				try {
					preparedStatementUtil.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
	}
	
	public void UpdateImage(UploadSlideImageBean uploadSlideImageBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_upload_slide_image SET "
		   				+ "name = :name, "
		   				+ "path_file = :path_file "
		   				+ "WHERE ID = :id ";
		    preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setString("name",uploadSlideImageBean.getName());
			preparedStatementUtil.setString("path_file",uploadSlideImageBean.getPath_file());
			preparedStatementUtil.setInt("id",uploadSlideImageBean.getId());
		   preparedStatementUtil.execute();	   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void UpdateCheckShow(int id ,String value_check){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_upload_slide_image SET "
		   				+ "check_show = :value_check "
		   				+ "WHERE ID = :id ";
		    preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setString("value_check",value_check);
			preparedStatementUtil.setInt("id",id);
		   preparedStatementUtil.execute();	   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public Boolean CheckRepeatValuePathFile(String path_file){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = "SELECT True as isTrue FROM tb_upload_slide_image WHERE path_file = :path_file LIMIT 1";
		
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setString("path_file", "Upload/File/slide_image/"+path_file);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				value = rs.getBoolean("isTrue");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public String getOldFile(int id){
		
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		String name = "";
		String type = "";
		String query = "SELECT name, "
							+ "type "
				+ " FROM tb_upload_slide_image "
				+ " WHERE ID = :id  LIMIT 1"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id", id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				name = rs.getString("name");
				type = rs.getString("type");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return name+"_image."+type.toLowerCase();
	} 
	
	public ArrayList<UploadSlideImageBean> SelectListFileSlideImage(){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		ArrayList<UploadSlideImageBean> list = new ArrayList<>();
		String query = "SELECT ID,"
							+ "name,"
							+ "type,"
							+ "path_file,"
							+ "check_show "
					+ " FROM tb_upload_slide_image "
					+ " WHERE check_show = 'true' "
					+ " ORDER BY ID ASC ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			rs = preparedStatementUtil.executeQuery();
			while(rs.next()){
				UploadSlideImageBean bean = new UploadSlideImageBean();
				bean.setId(rs.getInt("ID"));
				bean.setName(rs.getString("name"));
				bean.setType(rs.getString("type"));
				bean.setPath_file(rs.getString("path_file"));
				bean.setCheck_show(rs.getString("check_show"));
				list.add(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	} 
	
	public ArrayList<UploadSlideImageBean> SelectListFileTable(){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ArrayList<UploadSlideImageBean> list = new ArrayList<>();
		String query = "SELECT ID,"
							+ "name,"
							+ "type,"
							+ "path_file,"
							+ "check_show "
					+ " FROM tb_upload_slide_image "
					+ " ORDER BY ID ASC ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			rs = preparedStatementUtil.executeQuery();
			while(rs.next()){
				UploadSlideImageBean bean = new UploadSlideImageBean();
				bean.setId(rs.getInt("ID"));
				bean.setName(rs.getString("name"));
				bean.setType(rs.getString("type"));
				bean.setPath_file(rs.getString("path_file"));
				bean.setCheck_show(rs.getString("check_show"));
				list.add(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	} 
	
	public int getNumberCheckImage(){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		int num_check = 0;
		String query = "SELECT  COUNT(tb_upload_slide_image.check_show) AS num_check "
							+"FROM tb_upload_slide_image "
							+"WHERE tb_upload_slide_image.check_show = 'true' ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				num_check = rs.getInt("num_check");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return num_check;
	}
	
	public void deleteFileTable(int id){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "DELETE FROM tb_upload_slide_image WHERE ID = :id";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("id",id);
		   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
}
