package com.java.admin.bean;

public class ListApproveStaffBean {
	private String title_name_th;
	private String firstname_th;
	private String lastname_th;
	private String role_name;
	private int user_id;
	private String approve_staff;
	public String getTitle_name_th() {
		return title_name_th;
	}
	public void setTitle_name_th(String title_name_th) {
		this.title_name_th = title_name_th;
	}
	public String getFirstname_th() {
		return firstname_th;
	}
	public void setFirstname_th(String firstname_th) {
		this.firstname_th = firstname_th;
	}
	public String getLastname_th() {
		return lastname_th;
	}
	public void setLastname_th(String lastname_th) {
		this.lastname_th = lastname_th;
	}
	public String getRole_name() {
		return role_name;
	}
	public void setRole_name(String role_name) {
		this.role_name = role_name;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getApprove_staff() {
		return approve_staff;
	}
	public void setApprove_staff(String approve_staff) {
		this.approve_staff = approve_staff;
	}
}
