package com.java.admin.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import com.java.admin.bean.DivisionBean;
import com.java.staff.dao.TableRateCompanyDao;
import com.java.util.PreparedStatementUtil;

public class TableDivisionDao {
	public void editDivision(DivisionBean dvisionBean) {
		PreparedStatementUtil preparedStatementUtil = null;
		try {
			String query = "UPDATE tb_division SET "
						+ " Code = :code,"
						+ " Name = :name,"
						+ " Initials = :initials "
						+ " Where ID = :id";
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setString("code", dvisionBean.getCode().trim());
			preparedStatementUtil.setString("name", dvisionBean.getName().trim());
			preparedStatementUtil.setString("initials", dvisionBean.getInitials().trim());
			preparedStatementUtil.setInt("id", dvisionBean.getId());
			preparedStatementUtil.execute();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (preparedStatementUtil != null)
				try {
					preparedStatementUtil.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
	}
	
	public void deleteDivision(int divid,HttpServletRequest request){
		DeleteRateCompanyDao deleteRateCompanyDao = new DeleteRateCompanyDao();
		TableRateCompanyDao tableRateCompanyDao = new TableRateCompanyDao();
		
		ArrayList<Integer> list_rate_company_id = new ArrayList<>();
		list_rate_company_id = deleteRateCompanyDao.getIdRateCompany(divid, "DivID");
		
		for (Integer rate_company_id : list_rate_company_id) {
			/**
			 *  loop multi id rate_comapny
			 */
			// insrt history
			 ArrayList<Integer> user_id_list = new ArrayList<>();
			 user_id_list = tableRateCompanyDao.SelectListUserID(rate_company_id, request);
			 tableRateCompanyDao.insertHistory(user_id_list);
			 
			// set null  tb_student_select_company  (RateCompanyID,RateCompanyID_temmp)
			deleteRateCompanyDao.updateNullStuentSelectCompany(rate_company_id);
			
			// delete tb_rate_company
			deleteRateCompanyDao.deleteRateCompany(rate_company_id);
		}
		
		 // set null tb_user  DivID
		 UserManagementDao userManagementDao = new UserManagementDao();
		 userManagementDao.updateNullDivsionUser(divid);
		
		 // delete tb_divison
		 DeleteDivision(divid);
	}
	
	public void addDivision(DivisionBean divisionBean) {
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "INSERT INTO tb_division(Code,Name,Initials,FacID) VALUES(:code,:name,:initials,:facid)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("code", divisionBean.getCode().trim());
		   preparedStatementUtil.setString("name", divisionBean.getName().trim());
		   preparedStatementUtil.setString("initials", divisionBean.getInitials().trim());
		   preparedStatementUtil.setInt("facid", divisionBean.getFacid());
		   preparedStatementUtil.execute();   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public ArrayList<DivisionBean> getDivisionList(int facid){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<DivisionBean> divisionList = new ArrayList<DivisionBean>();
		String query = "SELECT ID,Code,Name,Initials,FacID FROM tb_division "
				+ " WHERE tb_division.FacID = :facid "
				+ " ORDER BY tb_division.Code ASC ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("facid", facid);
			rs = prepareStatementUtil.executeQuery();
			while(rs.next()){
				DivisionBean divisionBean = new DivisionBean();
				divisionBean.setId(rs.getInt("ID"));
				divisionBean.setCode(rs.getString("Code"));
				divisionBean.setName(rs.getString("Name"));
				divisionBean.setInitials(rs.getString("Initials"));
				divisionBean.setFacid(rs.getInt("FacID"));
				divisionList.add(divisionBean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return divisionList;
	}
	
	public DivisionBean retrieveDivision(int id){   
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		DivisionBean divisionBean = new DivisionBean();
		String query = "SELECT ID,Code,Name,Initials FROM tb_division"
				+ " WHERE ID = :id LIMIT 1";  
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id", id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				divisionBean.setId(rs.getInt("ID"));
				divisionBean.setCode(rs.getString("Code"));
				divisionBean.setName(rs.getString("Name"));
				divisionBean.setInitials(rs.getString("Initials"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return divisionBean;
	}
	
	public void DeleteDivision(int divid){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
			   String query = "DELETE FROM tb_division WHERE ID = :id";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("id", divid);
			   preparedStatementUtil.execute();
			  }catch(Exception e){
				 System.out.println("ERROR FK");
			     e.printStackTrace();
			  }finally{
			   if(preparedStatementUtil != null)
				try {
					preparedStatementUtil.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			  }
	}
}
