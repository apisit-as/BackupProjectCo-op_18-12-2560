package com.java.student.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.admin.bean.AcademicYearBean;
import com.java.list.bean.FooterBean;
import com.java.list.dao.FooterDao;
import com.java.student.bean.CareerBean;
import com.java.student.bean.Coop02Bean;
import com.java.student.bean.ProfileBean;
import com.java.student.bean.SelectJob02Bean;
import com.java.student.bean.UserBean;
import com.java.student.dao.TableCareerDao;
import com.java.student.dao.TableCompleteStatusDocument;
import com.java.student.dao.TableCoop02Dao;
import com.java.student.dao.TableCoop03Dao;
import com.java.student.dao.TableProfileDao;
import com.java.student.dao.TableSelectJob02Dao;
import com.java.student.dao.TableStudentSendDocumentDao;
import com.java.student.dao.TableUserDao;
import com.java.util.SessionExpire;

/**
 * Servlet implementation class CheckStatus
 */
@WebServlet("/DataCareer")
public class DataCareer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DataCareer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		
		HttpSession session = request.getSession();
		TableUserDao tableUserDao = new TableUserDao();
		UserBean userBean = new UserBean();
		
		// check role session expire
	    if(session.getAttribute("role") == null){
		  	SessionExpire sessionExpire = new SessionExpire();
			response.sendRedirect(sessionExpire.getSendRedirect()); // send redirect to Login page
			return;
	    }

		String role = session.getAttribute("role").toString();
		if(role.equals("student")){
			int UserID = Integer.parseInt(session.getAttribute("UserID").toString());
			userBean = tableUserDao.getTableUser(UserID);
			request.setAttribute("userBean", userBean);
			session.setAttribute("divID", userBean.getDivid());
			session.setAttribute("divName", userBean.getDivname());
			
			// coop02 detail
			Coop02Bean coop02Bean = new Coop02Bean();
			SelectJob02Bean selectJob02Bean = new SelectJob02Bean();
			TableCoop02Dao tableCoop02Dao = new TableCoop02Dao();
			TableSelectJob02Dao tableSelectJob02Dao = new TableSelectJob02Dao();
			
			coop02Bean = tableCoop02Dao.SelectCoop02(UserID);
			int Coop02ID = tableCoop02Dao.getKeyIDCoop02(UserID);
			selectJob02Bean = tableSelectJob02Dao.SelectJob02(Coop02ID);

			request.setAttribute("coop02Bean", coop02Bean);
			request.setAttribute("selectJob02Bean", selectJob02Bean);
			
			// coop03 detail
			TableCareerDao tableCareerDao = new TableCareerDao();
			TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
			int Coop03ID = tableCoop03Dao.getKeyIDCoop03(UserID);
			for(int i=1; i<=4; i++){
				CareerBean careerBean = new CareerBean();
				careerBean = tableCareerDao.SelectCareer(Coop03ID,"career_"+i);
				request.setAttribute("careerBean"+i, careerBean);
			}
			
			// select  profile dao   
			ProfileBean ListProfileBean = new ProfileBean();
			TableProfileDao tableProfileDao = new TableProfileDao();
			if(tableProfileDao.CheckProfile(UserID)){
				ListProfileBean = tableProfileDao.SelectProfile(UserID);
				request.setAttribute("ListProfileBean", ListProfileBean);
			}
			
			// select term, academic_year
			AcademicYearBean academicYearBean = new AcademicYearBean();
			TableStudentSendDocumentDao tableStudentSendDocumentDao = new TableStudentSendDocumentDao();
			if(tableStudentSendDocumentDao.CheckTable(UserID)){
				academicYearBean = tableStudentSendDocumentDao.SelectSemesterAcademicYear(UserID);
			}else{
				Coop02Bean coop02BeanAcademic = new Coop02Bean();
				coop02BeanAcademic = tableCoop02Dao.SelectCoop02(UserID);
				academicYearBean.setSemester(coop02BeanAcademic.getTerm());
				academicYearBean.setAcademic_year(coop02BeanAcademic.getAcademic_year());
			}
			request.setAttribute("academicYearBean", academicYearBean);
			
			/** set text footer **/
			FooterBean footerBean = new FooterBean();
			footerBean = new FooterDao().SelectDataFooter();
			request.setAttribute("footerBean", footerBean);
			
			doViewDataCareer(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		String action = request.getParameter("action");
		
		if("Insert".equals(action)){
			
			String ClickSave = session.getAttribute("CheckClickSave").toString();
			if("True Save".equals(ClickSave)){
				out.print("True Save");
				InsertCareer(request, response);
			}
			else if("False Save".equals(ClickSave)){
				out.print("False Save");
				return;
			}
		}

	}
	private void doViewDataCareer(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/student/data_default/data_career.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void InsertCareer(HttpServletRequest request, HttpServletResponse response){
		HttpSession session = request.getSession();
		
		Coop02Bean coop02Bean = new Coop02Bean();
		SelectJob02Bean selectJob02Bean = new SelectJob02Bean();
		TableCoop02Dao tableCoop02Dao = new TableCoop02Dao();
		TableSelectJob02Dao tableSelectJob02Dao = new TableSelectJob02Dao();
		TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
		TableCareerDao tableCareerDao = new TableCareerDao();
		
		int UserID = Integer.parseInt(session.getAttribute("UserID").toString());
		
		/** check insert tb_coop02 **/
		coop02Bean.setRegion(request.getParameter("region"));
		coop02Bean.setTerm(request.getParameter("Semester"));
		coop02Bean.setAcademic_year(request.getParameter("Academic_year"));
		coop02Bean.setUserid(UserID);
		if(tableCoop02Dao.CheckCoop02(UserID)){
			// update region,term  to tb_coop02
			tableCoop02Dao.UpdateCoop02RegionTermAcademicYear(coop02Bean);
		}else{
			// insert region,term to tb_coop02
			tableCoop02Dao.InsertCoop02RegionTermAcademicYear(coop02Bean);
		}
		int coop02id = tableCoop02Dao.getKeyIDCoop02(UserID);
		
		/** check insert tb_select_job02 **/
		selectJob02Bean.setJob(request.getParameter("SelectJob"));
		selectJob02Bean.setOther(request.getParameter("Other"));
		selectJob02Bean.setCoop02id(coop02id);
		if(tableSelectJob02Dao.CheckSelectJob02(coop02id)){
			// update SelectJob,Other
			tableSelectJob02Dao.UpdateSelectJob02(selectJob02Bean);
		}else{
			// insert SelectJob,Other
			tableSelectJob02Dao.InsertSelectJob02(selectJob02Bean);
		}
		
		/** check tb_coop03 **/
		if(!tableCoop03Dao.CheckCoop03(UserID))	tableCoop03Dao.InsertCoop03SetUserid(UserID);
		int coop03id = tableCoop03Dao.getKeyIDCoop03(UserID);
		
		/** check insert tb_career **/
		Boolean checkCareer = tableCareerDao.CheckCareer(coop03id);
		for(int i=1; i<=4; i++){
			
			String num_text = Integer.toString(i);
			
			CareerBean careerBean = new CareerBean();
			careerBean.setName(request.getParameter("career_name"+num_text));
			careerBean.setType("career_"+num_text);
			careerBean.setCoop03id(coop03id);
			if(checkCareer){
				
				Boolean checkCareerType = tableCareerDao.CheckCareerType("career_"+num_text);
				if(checkCareerType){
					// update tb_career
					tableCareerDao.UpdateCareer(careerBean);
				}else{
					// insert tb_career �ó� insert �����á�������ó�
					tableCareerDao.InsertCareer(careerBean);
				}
				
			}else{
				// insert tb_career
				tableCareerDao.InsertCareer(careerBean);
			}
			
			num_text = null;
		}
		
		/** insert,update status document **/
		TableCompleteStatusDocument tableCompleteStatusDocument = new TableCompleteStatusDocument();
		if(tableCompleteStatusDocument.checkCompleteStatusDocument(UserID)){
			//update
			tableCompleteStatusDocument.UpdateCompleteStatusDoc("DataCareer", 1, UserID);
		}else{
			//insert
			tableCompleteStatusDocument.InsertCompleteStatusDoc("DataCareer", 1, UserID);
		}
	}

}
