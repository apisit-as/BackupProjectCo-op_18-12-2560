package com.java.student.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.list.bean.AmphurBean;
import com.java.list.bean.DistrictBean;
import com.java.list.bean.DivisionBean;
import com.java.list.bean.FacltyBean;
import com.java.list.bean.FooterBean;
import com.java.list.bean.ProvinceBean;
import com.java.list.dao.AmphurSelectListDao;
import com.java.list.dao.DistrictSelectListDao;
import com.java.list.dao.DivisionSelectListDao;
import com.java.list.dao.FacultySelectListDao;
import com.java.list.dao.FooterDao;
import com.java.list.dao.ProvinceSelectListDao;
import com.java.student.bean.AddressBean;
import com.java.student.bean.Coop03Bean;
import com.java.student.bean.FamilyBean;
import com.java.student.bean.RelativeBean;
import com.java.student.bean.UserBean;
import com.java.student.dao.TableAddressDao;
import com.java.student.dao.TableCompleteStatusDocument;
import com.java.student.dao.TableCoop03Dao;
import com.java.student.dao.TableFamilyDao;
import com.java.student.dao.TableProfileDao;
import com.java.student.dao.TableRelativeDao;
import com.java.student.dao.TableUserDao;
import com.java.util.SessionExpire;

/**
 * Servlet implementation class CheckStatus
 */
@WebServlet("/DataFamily")
public class DataFamily extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DataFamily() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		
		HttpSession session = request.getSession();
		TableUserDao tableUserDao = new TableUserDao();
		UserBean userBean = new UserBean();

		// check role session expire
	    if(session.getAttribute("role") == null){
		  	SessionExpire sessionExpire = new SessionExpire();
			response.sendRedirect(sessionExpire.getSendRedirect()); // send redirect to Login page
			return;
	    }
		
		String role = session.getAttribute("role").toString();
		if(role.equals("student")){
				int UserID = Integer.parseInt(session.getAttribute("UserID").toString());
				userBean = tableUserDao.getTableUser(UserID);
				request.setAttribute("userBean", userBean);
				session.setAttribute("divID", userBean.getDivid());
				session.setAttribute("divName", userBean.getDivname());
				
				// select list Faclty
				ArrayList<FacltyBean> listFaclty = new ArrayList<FacltyBean>();
				FacultySelectListDao facultySelectListDao = new FacultySelectListDao();			
				listFaclty = facultySelectListDao.getFacltyList();
				request.setAttribute("listFaclty", listFaclty);
	
				// select list Division
	 			DivisionSelectListDao divisionSelectListDao = new DivisionSelectListDao();
				ArrayList<DivisionBean> listDivision = new ArrayList<DivisionBean>();
				listDivision = divisionSelectListDao.getDivisionList((userBean.getFacid()));
				request.setAttribute("listDivision", listDivision);
			
				// select address type parent_address
				TableProfileDao checkKeyProfile = new TableProfileDao();
				int keyProfile = checkKeyProfile.getKeyIDProfile(UserID);
				TableAddressDao addressDao = new TableAddressDao();
				AddressBean parent_address = new AddressBean();
				parent_address = addressDao.SelectAddressType(keyProfile, "parent_address");
				request.setAttribute("parent_address", parent_address);
				
				// family
				FamilyBean father_family = new FamilyBean();
				FamilyBean mother_family = new FamilyBean();
				FamilyBean parent_family = new FamilyBean();
				TableFamilyDao tableFamilyDao = new TableFamilyDao();
				father_family = tableFamilyDao.SelectFamilyType(keyProfile, "father_family");
				mother_family = tableFamilyDao.SelectFamilyType(keyProfile, "mother_family");
				parent_family = tableFamilyDao.SelectFamilyType(keyProfile, "parent_family");
				request.setAttribute("father_family", father_family);
				request.setAttribute("mother_family", mother_family);
				request.setAttribute("parent_family", parent_family);
				// #family

				// parent_address
				{
				ArrayList<ProvinceBean> parent_provinceList = new ArrayList<ProvinceBean>(); 
				ProvinceSelectListDao parent_provinceSelectListDao = new ProvinceSelectListDao();
				parent_provinceList = parent_provinceSelectListDao.getProvinceList();
				
				ArrayList<AmphurBean> parent_amphurList = new ArrayList<AmphurBean>(); 
				AmphurSelectListDao parent_amphurSelectListDao = new AmphurSelectListDao();
				parent_amphurList = parent_amphurSelectListDao.getAmphurList(parent_address.getProvinceid());
				
				ArrayList<DistrictBean> parent_districtList = new ArrayList<DistrictBean>(); 
				DistrictSelectListDao parent_districtSelectListDao = new DistrictSelectListDao();
				parent_districtList = parent_districtSelectListDao.getDistrictList(parent_address.getAmphurid());
				
				request.setAttribute("listProvince_parent_address", parent_provinceList);
				request.setAttribute("listAmphur_parent_address", parent_amphurList);
				request.setAttribute("listDistrict_parent_address", parent_districtList);
				
				session.setAttribute("amphur_parent_address_id", parent_address.getAmphurid());
				session.setAttribute("amphur_parent_address_name", parent_address.getAmphurname());
				session.setAttribute("district_parent_address_id", parent_address.getDistrictid());
				session.setAttribute("district_parent_address_name", parent_address.getDistrictname());
				}
				//  # parent_address
				
				// relative	
				TableRelativeDao tableRelativeDao = new TableRelativeDao();
				TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
				Coop03Bean coop03Bean = new Coop03Bean();
				RelativeBean relativeBean1 = new RelativeBean();
				RelativeBean relativeBean2 = new RelativeBean();
				RelativeBean relativeBean3 = new RelativeBean();
				int Coop03ID = tableCoop03Dao.getKeyIDCoop03(UserID);
				
				coop03Bean = tableCoop03Dao.SelectCoop03(UserID);
				relativeBean1 = tableRelativeDao.SelectRelative(Coop03ID,"relative_1");
				relativeBean2 = tableRelativeDao.SelectRelative(Coop03ID,"relative_2");
				relativeBean3 = tableRelativeDao.SelectRelative(Coop03ID,"relative_3");
				request.setAttribute("coop03Bean", coop03Bean);
				request.setAttribute("relativeBean1", relativeBean1);
				request.setAttribute("relativeBean2", relativeBean2);
				request.setAttribute("relativeBean3", relativeBean3);
				// #relative	

				/** set text footer **/
				FooterBean footerBean = new FooterBean();
				footerBean = new FooterDao().SelectDataFooter();
				request.setAttribute("footerBean", footerBean);
				
				doViewDataFamily(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		
		String action_family = request.getParameter("action_family");
		String action_onchange = request.getParameter("action_onchange");

		// save
		if("family".equals(action_family)){
			String ClickSave = session.getAttribute("CheckClickSave").toString();
			if("True Save".equals(ClickSave)){
				out.print("True Save");
				insertFamily(request, response);
			}
			else if("False Save".equals(ClickSave)){
				out.print("False Save");
				return;
			}
		}
		
		// get select list Amphur_parent
		else if("clickProvince_parent".equals(action_onchange)){
			String ProvinceID_parent = request.getParameter("ProvinceID_parent");
			AmphurSelectListDao amphurSelectListDao = new AmphurSelectListDao();
			ArrayList<AmphurBean> amphurBeans = new ArrayList<AmphurBean>();
			amphurBeans = amphurSelectListDao.getAmphurList(Integer.parseInt(ProvinceID_parent));
			request.setAttribute("listAmphur_parent_address", amphurBeans);
			session.setAttribute("amphur_parent_address_id", 0);
			session.setAttribute("amphur_parent_address_name", 0);       //  session
			doViewAmphur_parentList(request, response);
			return;
		}
		//get select list District_parent
		else if("clickAmphur_parent".equals(action_onchange)){
			String AmphurID_parent = request.getParameter("AmphurID_parent");
			DistrictSelectListDao districtSelectListDao = new DistrictSelectListDao();
			ArrayList<DistrictBean> districtBeans = new ArrayList<DistrictBean>();
			districtBeans = districtSelectListDao.getDistrictList(Integer.parseInt(AmphurID_parent));
			request.setAttribute("listDistrict_parent_address", districtBeans);
			session.setAttribute("district_parent_address_id", 0);
			session.setAttribute("district_parent_address_name", 0);       //  session
			doViewDistrict_parentlList(request, response);
			return;
		}
		
	}
	private void doViewDataFamily(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/student/data_default/data_family.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void doViewAmphur_parentList(HttpServletRequest request, HttpServletResponse response) {

		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/amphur/amphur_parent_address.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void doViewDistrict_parentlList(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/district/district_parent_address.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void insertFamily(HttpServletRequest request, HttpServletResponse response){
		
		HttpSession session = request.getSession();
		int UserID = Integer.parseInt(session.getAttribute("UserID").toString());
		TableProfileDao tableProfileDao = new TableProfileDao();

		/* check tb_profile */
		if(tableProfileDao.CheckProfile(UserID)){
			/** update **/
			int keyProfile = tableProfileDao.getKeyIDProfile(UserID);
			actionInsert(request, response, keyProfile,UserID);
		}else{
			/** insert **/
			tableProfileDao.InsertProfileSetUserid(UserID);
			int keyProfile = tableProfileDao.getKeyIDProfile(UserID);
			actionInsert(request, response, keyProfile,UserID);
		}
		
		/** insert,update status document **/
		TableCompleteStatusDocument tableCompleteStatusDocument = new TableCompleteStatusDocument();
		if(tableCompleteStatusDocument.checkCompleteStatusDocument(UserID)){
			//update
			tableCompleteStatusDocument.UpdateCompleteStatusDoc("DataFamily", 1, UserID);
		}else{
			//insert
			tableCompleteStatusDocument.InsertCompleteStatusDoc("DataFamily", 1, UserID);
		}
	}
	
	private void actionInsert(HttpServletRequest request, HttpServletResponse response, int keyProfile, int UserID){
		/* insert family */
		TableFamilyDao tableFamilyDao = new TableFamilyDao();
		boolean checkFamily = tableFamilyDao.CheckFamily(keyProfile);
		for(int i = 1; i<=3; i++){
			FamilyBean familyBean = new FamilyBean();
			if(i == 1){
				familyBean.setTitleid(Integer.parseInt(request.getParameter("TitleID_th_family_father").toString()));
				familyBean.setFirstname(request.getParameter("FirstName_family_father").toString());
				familyBean.setLastname(request.getParameter("LastName_family_father").toString());
				familyBean.setAge(request.getParameter("Age_family_father").toString());
				familyBean.setOccupation(request.getParameter("Occupation_family_father").toString());
				familyBean.setType("father_family");
			}else if(i == 2){
				familyBean.setTitleid(Integer.parseInt(request.getParameter("TitleID_th_family_mother").toString()));
				familyBean.setFirstname(request.getParameter("FirstName_family_mother").toString());
				familyBean.setLastname(request.getParameter("LastName_family_mother").toString());
				familyBean.setAge(request.getParameter("Age_family_mother").toString());
				familyBean.setOccupation(request.getParameter("Occupation_family_mother").toString());
				familyBean.setType("mother_family");
			}else if(i == 3){
				familyBean.setTitleid(Integer.parseInt(request.getParameter("TitleID_th_family_parent").toString()));
				familyBean.setFirstname(request.getParameter("FirstName_family_parent").toString());
				familyBean.setLastname(request.getParameter("LastName_family_parent").toString());
				familyBean.setRelation(request.getParameter("RelationID_parent").toString());
				familyBean.setOccupation(request.getParameter("Occupation_parent").toString());
				familyBean.setPlace_occupation(request.getParameter("PlaceOccupation_parent").toString());
				familyBean.setType("parent_family");
			}
				familyBean.setProfileid(keyProfile);
				if(checkFamily){
					tableFamilyDao.updateFamily(familyBean);
					//System.out.println("update family");
				}else{
					tableFamilyDao.InsertFamily(familyBean);
					//System.out.println("insert family");
				}
		}			
		/* #insert family */
		
		/* address */ 
		TableAddressDao tableAddressDao = new TableAddressDao();
		boolean checkAddressParent =   tableAddressDao.CheckAddressParent(keyProfile,"parent_address");
			AddressBean addressBean = new AddressBean();
			addressBean.setId_num(request.getParameter("Id_num3").toString());
			addressBean.setNum_mu(request.getParameter("Num_Mu3").toString());
			addressBean.setRoad(request.getParameter("Road3").toString());
			addressBean.setProvinceid(Integer.parseInt(request.getParameter("ProvinceID3").toString()));
			addressBean.setAmphurid(Integer.parseInt(request.getParameter("AmphurID3").toString()));
			addressBean.setDistrictid(Integer.parseInt(request.getParameter("DistrictID3").toString()));
			addressBean.setPostcode(request.getParameter("Postcode3").toString());
			addressBean.setTelephone(request.getParameter("Telephone3").toString());
			addressBean.setMobile(request.getParameter("Mobile3").toString());
			addressBean.setFax(request.getParameter("Fax3").toString());
			addressBean.setEmail(request.getParameter("Email3").toString());
			addressBean.setType("parent_address");
			addressBean.setProfilelid(keyProfile);
			if(checkAddressParent){
				tableAddressDao.updateAddress(addressBean);
				//System.out.println("update address");
			}else{
				tableAddressDao.InsertAddress(addressBean);
				//System.out.println("insert address");
			}
		   /* #address */ 
		

		/* check coop03 */
			Coop03Bean coop03Bean = new Coop03Bean();
			TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
			coop03Bean.setUserid(UserID);
			coop03Bean.setNum_relative(request.getParameter("Num_relative").toString());
			coop03Bean.setMy_relative(request.getParameter("My_relative").toString());
			
			if(tableCoop03Dao.CheckCoop03(UserID)){
				// update coop03
				tableCoop03Dao.UpdateCoop03NumAndMyRelative(coop03Bean);
				int coop03id = tableCoop03Dao.getKeyIDCoop03(UserID);
				//System.out.println("Update relative");
				relativeCheck(request, response, coop03id);
			}else{
				// insert coop03
				tableCoop03Dao.InsertCoop03NumAndMyRelative(coop03Bean);
				int coop03id = tableCoop03Dao.getKeyIDCoop03(UserID);	
				//System.out.println("OK Insert relative");
				relativeCheck(request, response, coop03id);
			}			
	}
	
	private void relativeCheck(HttpServletRequest request, HttpServletResponse response,int coop03id){
		TableRelativeDao tableRelativeDao = new TableRelativeDao();
		Boolean relativeCheck = tableRelativeDao.CheckRelative(coop03id);
		for(int i=1; i<=3; i++){
			
			String num_text = Integer.toString(i);
			
			RelativeBean relativeBean = new RelativeBean();
			relativeBean.setTitleid(Integer.parseInt(request.getParameter("relative_TitleID_Th"+num_text).toString()));
			relativeBean.setFirstname(request.getParameter("relative_FirstName"+num_text).toString());
			relativeBean.setLastname(request.getParameter("relative_LastName"+num_text).toString());
			relativeBean.setAge(request.getParameter("relative_Age"+num_text).toString());
			relativeBean.setOccupation(request.getParameter("relative_Occupation"+num_text).toString());
			relativeBean.setPosition(request.getParameter("relative_Position"+num_text).toString());
			relativeBean.setType("relative_"+num_text);
			relativeBean.setCoop03id(coop03id);
			if(relativeCheck){
				
				Boolean checkRelativeType = tableRelativeDao.CheckRelativeType("relative_"+num_text);
				if(checkRelativeType){
					// update
					tableRelativeDao.UpdateRelative(relativeBean);
				}else{
					// insert �ó� insert �����á�������ó�
					tableRelativeDao.InsertRelative(relativeBean);
				}
				
			}else{
				// insert
				tableRelativeDao.InsertRelative(relativeBean);
			}
			
			num_text = null;
	   }
	}

}
