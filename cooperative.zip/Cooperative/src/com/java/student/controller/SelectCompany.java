package com.java.student.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.admin.bean.AcademicYearBean;
import com.java.admin.dao.TableAcademicYearDao;
import com.java.list.bean.FooterBean;
import com.java.list.dao.FooterDao;
import com.java.staff.bean.CompanyBean;
import com.java.staff.bean.RateCompanyBean;
import com.java.staff.bean.RateCompanyListBean;
import com.java.staff.bean.RegionBean;
import com.java.staff.bean.UserListStudentRateCompanyBean;
import com.java.staff.controller.CompanyManagement;
import com.java.staff.dao.TableCompanyDao;
import com.java.staff.dao.TableRateCompanyDao;
import com.java.staff.dao.TableRegionDao;
import com.java.student.bean.HistoryStatusBean;
import com.java.student.bean.StudentSelectCompanyBean;
import com.java.student.dao.TableApprovalStatusDao;
import com.java.student.dao.TableCoop03Dao;
import com.java.student.dao.TableDocumentStatusDao;
import com.java.student.dao.TableHistoryStatusDao;
import com.java.student.dao.TableStudentSelectCompanyDao;
import com.java.student.dao.TableUserDao;
import com.java.util.FileUploadUtil;
import com.java.util.SessionExpire;

/**
 * Servlet implementation class CheckStatus
 */
@WebServlet("/SelectCompany")
public class SelectCompany extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SelectCompany() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
			HttpSession session = request.getSession();
			TableUserDao tableUserDao = new TableUserDao();
			
			// check role session expire
		    if(session.getAttribute("role") == null){
			  	SessionExpire sessionExpire = new SessionExpire();
				response.sendRedirect(sessionExpire.getSendRedirect()); // send redirect to Login page
				return;
		    }			
	
			String role = session.getAttribute("role").toString();
			if(role.equals("student")){
				int user_id = Integer.parseInt(session.getAttribute("UserID").toString());
				
				// set Academic Year
				TableAcademicYearDao tableAcademicYear = new TableAcademicYearDao();
				AcademicYearBean academicYearBean = new AcademicYearBean();
				academicYearBean = tableAcademicYear.getAcademic();
				session.setAttribute("Semester", academicYearBean.getSemester());
				session.setAttribute("Academic_year", academicYearBean.getAcademic_year());
				
				 /**  check academic select company **/
				int division_id = tableUserDao.getDivisonID(user_id);
				TableStudentSelectCompanyDao tableStudentSelectCompanyDao = new TableStudentSelectCompanyDao();
				int academic_year_id = tableStudentSelectCompanyDao.getAcademicID(user_id);
				ArrayList<RateCompanyListBean> rateCompanyListBeans = new ArrayList<>();
				String check_academic_year = null ;
				if(academic_year_id != 0){
						/**
						 *  student select academic
						 */
						if(academicYearBean.getId() != academic_year_id){
							// check 㹡ó�  �ջѨ�غѹ != �շ����Ѥ�
							check_academic_year = "disable_button";
						}
						
						// set start_data_workout , stop
						session.setAttribute("start_date_workout",splitDate(academicYearBean.getStart_date_workout()));
						session.setAttribute("stop_date_workout",splitDate(academicYearBean.getStop_date_workout()));
						//session.setAttribute("academic_year_id", academic_year_id);
						
						// list company
						rateCompanyListBeans = tableStudentSelectCompanyDao.SelectListRateCompany(academic_year_id, division_id);
						
						// get rate_company_id
						int rate_company_id = tableStudentSelectCompanyDao.SelectRateCompanyID(user_id);
						request.setAttribute("rate_company_id",rate_company_id);
						
						// set academic_year
						academicYearBean = tableAcademicYear.getAcademic(academic_year_id);
						request.setAttribute("get_semester",academicYearBean.getSemester());
						request.setAttribute("get_academic_year",academicYearBean.getAcademic_year());
				}else{
					/**
					 * student not select academic
					 */
						
					// set list company
					rateCompanyListBeans = tableStudentSelectCompanyDao.SelectListRateCompany(academicYearBean.getId(), division_id);
					request.setAttribute("rate_company_id",0);
					
					// set academic_year
					request.setAttribute("get_semester",academicYearBean.getSemester());
					request.setAttribute("get_academic_year",academicYearBean.getAcademic_year());	
				}
				request.setAttribute("rateCompanyListBeans", rateCompanyListBeans);
				/**  #check academic select company **/

				
				/**  check  button save select company   **/
				if(tableStudentSelectCompanyDao.checkSelectCompany(user_id)){
					/** enable button  
					 * �ó�   1. ��ҹ���͹��ѵ��͡��èҡ LV2  
					 *    2. �ѧ������͡ʶҹ��Сͺ���   rate_comapny_id = null
					 *    3. ʶҹ�  ���͹��ѵ� , ���ͺ�Ѻ  
					 */
					request.setAttribute("rate_company_id",0);
					session.setAttribute("checkButtonSelectCompany","enable_button");
				}else{
					/** 
					 * 㹡ó�   ���͡ʶҹ��Сͺ�������
					 */
					session.setAttribute("checkButtonSelectCompany","disable_button");
				}
				
				if("disable_button".equals(check_academic_year)){
					/**
					 * 㹡ó�  �Ҥ���¹��к�  != �Ҥ���¹�Ѩ�غѹ
					 */
					session.setAttribute("checkButtonSelectCompany","disable_button");
					//   rate_company_id = 0
				}
				
				// check empty list
				if(rateCompanyListBeans.isEmpty()){
					/**
					 * list ����բ�����
					 */
					session.setAttribute("checkButtonSelectCompany","disable_button");
				}
				/**  #check  button save select company   **/  
				

				/** listRegionCompany to select region data_table **/
				ArrayList<RegionBean> listRegionCompany = new ArrayList<>();
				TableRegionDao tableRegionDao = new TableRegionDao();
				listRegionCompany = tableRegionDao.SelectListRegion();
				request.setAttribute("listRegionCompany", listRegionCompany);
				/** #listRegionCompany to select region data_table **/
				
				/** set text footer **/
				FooterBean footerBean = new FooterBean();
				footerBean = new FooterDao().SelectDataFooter();
				request.setAttribute("footerBean", footerBean);
				
				doViewSelectCompany(request, response);
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");	
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();

		String action = request.getParameter("action");
		
		// search_data_company_modal , search_data_company_tab2
		if("search_data_company_modal".equals(action) || "search_data_company_tab2".equals(action)){
			SearchDataComapny(action, request, response);
			return;
		}

		String checkButtonSelectCompany = session.getAttribute("checkButtonSelectCompany").toString();
		if("enable_button".equals(checkButtonSelectCompany)){
			
			// save_select_company
			if("save_select_company".equals(action)){

				int user_id = Integer.parseInt(session.getAttribute("UserID").toString());
				
				// check role select company
				if("staff".equals(session.getAttribute("role").toString())){
					user_id = Integer.parseInt(session.getAttribute("studnet_user_id").toString());
				}else if("student".equals(session.getAttribute("role").toString())){
					user_id = Integer.parseInt(session.getAttribute("UserID").toString());
				}
				
				/** get value */
				String position = request.getParameter("position");
				String send_documents = request.getParameter("send_documents");
				String start_date_workout = session.getAttribute("start_date_workout").toString();
				String stop_date_workout = session.getAttribute("stop_date_workout").toString();
				int rate_company_id = Integer.parseInt(request.getParameter("rate_company_id"));
				StudentSelectCompanyBean studentSelectCompanyBean = new StudentSelectCompanyBean();
				studentSelectCompanyBean.setUser_id(user_id);
				studentSelectCompanyBean.setPosition(position);
				if("9".equals(send_documents)){
					send_documents = "�ѡ�֡�����͡����ͧ";
				}else if("10".equals(send_documents)){
					send_documents = "���ҧ����Է������ ���͡���";
				}else{
					out.print("Error");
					return;
				}
				studentSelectCompanyBean.setSend_documents(send_documents);
				studentSelectCompanyBean.setStart_date_workout(start_date_workout);
				studentSelectCompanyBean.setStop_date_workout(stop_date_workout);
				studentSelectCompanyBean.setRate_company_id(rate_company_id);
				/** #get value */
				
				TableStudentSelectCompanyDao tableStudentSelectCompanyDao = new TableStudentSelectCompanyDao();
				
				/** check num student **/
				int num_student_select = tableStudentSelectCompanyDao.getNumberStudent(rate_company_id);
				num_student_select = num_student_select + 1;
				int num_total_student = tableStudentSelectCompanyDao.getNumberTotalStudent(rate_company_id);
				if(num_student_select > num_total_student){
					out.print("Error");
					return;
				}
				/** #chek num stuent **/
				
				/** check division , academic **/
				// 㹡ó�  hard code
				Boolean check_division = tableStudentSelectCompanyDao.checkDivision(rate_company_id, user_id);
				if(!check_division){
					/**
					 * 		false
					 * 			1. �Ң��Ԫ� rate_company ���ç�Ѻ  �ҢҢͧ�ѡ�֡��
					 * 			2. ��辺�Ң��Ԫ�
					 * 			3. �շ����Ѥ�   ���ç�ѹ�Ѻ   �շ������ rate_company
					 */
					out.print("Error");
					return;
				}
				/** #check division , academic **/

				// delete file
				String partFile_Company = tableStudentSelectCompanyDao.getPathFile(user_id);
				FileUploadUtil.deleteFile(request, partFile_Company);
				
				// update
				tableStudentSelectCompanyDao.updateStudentSelectCompany(studentSelectCompanyBean);
				
	 			 /**  **history**
	 			  *   status document  =  1   (����ó�)
	 			  *   status approval  =  1   ��͹��ѵ� (�ʴ����ǹ�ͧ�Ҩ����)  ,  6 = �ʹ��Թ��� (�ʴ����ǹ�ѡ�֡��)
	 			  */
	 			 String date = getDateDefaultToString();
	 			 TableApprovalStatusDao tableApprovalStatusDao = new TableApprovalStatusDao();
	 			 TableDocumentStatusDao tableDocumentStatus = new TableDocumentStatusDao();
	 			 InsertHistory(date, "���͡ʶҹ��Сͺ���", tableDocumentStatus.getStatusDocument(1),user_id);
	 			 InsertHistory(date, "�Ҩ�������ҹ�ҹ�ˡԨ�֡�ҵ�Ǩ�ͺʶҹ��Сͺ���", tableApprovalStatusDao.getStatusApproval(6),user_id);
			}

			out.print("True Save");
		}
		else if("disable_button".equals(checkButtonSelectCompany)){
			out.print("Error");
		}
	}
	
	private void SearchDataComapny(String action,HttpServletRequest request,HttpServletResponse response){

		if("search_data_company_modal".equals(action)){
			
			/** get data company modal **/
			int rate_company_id = Integer.parseInt(request.getParameter("rate_company_id"));
			int company_id = Integer.parseInt(request.getParameter("company_id"));
			
			// companyBean
			CompanyBean companyBean = new CompanyBean();
			TableCompanyDao tableCompanyDao = new TableCompanyDao();
			companyBean = tableCompanyDao.SelectCompany(company_id);
			request.setAttribute("companyBean", companyBean);
			
			// rate_company
			RateCompanyBean rateCompanyBean = new RateCompanyBean();
			TableRateCompanyDao tableRateCompanyDao = new TableRateCompanyDao();
			rateCompanyBean = tableRateCompanyDao.SelectRateCompany(rate_company_id);
			request.setAttribute("rateCompanyBean", rateCompanyBean);
			
			// listRegionCompany
			ArrayList<RegionBean> listRegionCompany = new ArrayList<>();
			TableRegionDao tableRegionDao = new TableRegionDao();
			listRegionCompany = tableRegionDao.SelectListRegion();
			request.setAttribute("listRegionCompany", listRegionCompany);
			
			// list_student
			ArrayList<UserListStudentRateCompanyBean> listStudent = new ArrayList<>();
			listStudent = tableRateCompanyDao.SelectListStudent(rate_company_id);
			request.setAttribute("listStudent", listStudent);
			
			// data  select list  type_company_select,residence_company_select
			CompanyManagement companyManagement = new CompanyManagement();
			companyManagement.listSelectComapny(request, response);
			
			doViewModalDataCompany(request, response);
			/** #get data company modal **/
		}
		else if("search_data_company_tab2".equals(action)){
			
			/** get data company tab2 **/
			HttpSession session = request.getSession();
			int user_id = Integer.parseInt(session.getAttribute("UserID").toString());
			
			// studentSelectCompanyBean
			StudentSelectCompanyBean studentSelectCompanyBean = new StudentSelectCompanyBean();
			TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
			studentSelectCompanyBean = tableCoop03Dao.SelectCoop03Comapny(user_id);
			request.setAttribute("studentSelectCompanyBean",studentSelectCompanyBean);
			
			// companyBean
			TableStudentSelectCompanyDao tableStudentSelectCompanyDao = new TableStudentSelectCompanyDao();
			TableCompanyDao tableCompanyDao = new TableCompanyDao();
			CompanyBean companyBean = new CompanyBean();
			int id_company = tableStudentSelectCompanyDao.SelectCompanyID(user_id);
			companyBean = tableCompanyDao.SelectCompany(id_company);
			request.setAttribute("companyBean", companyBean);
			
			// rate_company
			RateCompanyBean rateCompanyBean = new RateCompanyBean();
			rateCompanyBean = tableStudentSelectCompanyDao.SelectRateCompany(user_id);
			request.setAttribute("rateCompanyBean", rateCompanyBean);
			
			// listRegionCompany
			ArrayList<RegionBean> listRegionCompany = new ArrayList<>();
			TableRegionDao tableRegionDao = new TableRegionDao();
			listRegionCompany = tableRegionDao.SelectListRegion();
			request.setAttribute("listRegionCompany", listRegionCompany);
			
			// list_student
			TableRateCompanyDao tableRateCompanyDao = new TableRateCompanyDao();
			ArrayList<UserListStudentRateCompanyBean> listStudent = new ArrayList<>();
			int rate_company_id = tableStudentSelectCompanyDao.SelectRateCompanyID(user_id);
			listStudent = tableRateCompanyDao.SelectListStudent(rate_company_id);
			request.setAttribute("listStudent", listStudent);
			
			// data  select list  type_company_select,residence_company_select
			CompanyManagement companyManagement = new CompanyManagement();
			companyManagement.listSelectComapny(request, response);
			
			doViewDataCompanyTab2(request, response);
			/** #get data company tab2 **/
		}
	}
	
	private void doViewModalDataCompany(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/element/modal_data_company.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	private void doViewDataCompanyTab2(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/element/student_select_company_tab2.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void InsertHistory(String date,String history,String status,int userid){
		HistoryStatusBean historyStatusBean = new HistoryStatusBean();
		historyStatusBean.setDate(date);
		historyStatusBean.setHistory(history);
		historyStatusBean.setStatus(status);
		historyStatusBean.setUserid(userid);
		TableHistoryStatusDao tableHistoryStatus = new TableHistoryStatusDao();
		tableHistoryStatus.InsertHistoryStatus(historyStatusBean);
	}
	
	private String getDateDefaultToString(){
		LocalDate localDate = LocalDate.now();
		String date = DateTimeFormatter.ofPattern("dd/MM/yyy").format(localDate);
		String[] dateSplit = date.split("/");
		date = "";
		date = dateSplit[0]+"/"+dateSplit[1]+"/"+(Integer.parseInt(dateSplit[2])+543);
		return date;
	}
	
	private String splitDate(String date){
		String[] str = date.split("-");    
		return str[2]+"/"+str[1]+"/"+(Integer.parseInt(str[0])+543);
	}
	private void doViewSelectCompany(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/student/select_company.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
}
