package com.java.student.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.student.bean.CheckStatusCompanyBean;
import com.java.student.bean.CheckStatusDocumentBean;
import com.java.util.PreparedStatementUtil;

public class CheckStatusDao {

	public Boolean CheckTableDocumentTeacherLv2(int student_user_id){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = "SELECT True as isTable "
					+ " FROM tb_student_send_document "
					+ " WHERE UserID = :student_user_id "
					+ " AND NOT Lv2_ApStatusID IS null "
					+ " LIMIT 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("student_user_id", student_user_id);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getBoolean("isTable");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public Boolean CheckTableCompanyTeacherLv2(int student_user_id){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = "SELECT True as isTable "
					+ " FROM tb_student_select_company "
					+ " WHERE UserID = :student_user_id "
					+ " AND NOT Staff_ApStatusID IS null "
					+ " LIMIT 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("student_user_id", student_user_id);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getBoolean("isTable");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public CheckStatusDocumentBean SelectDocumentTeacherLv2(int student_user_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		CheckStatusDocumentBean bean = new CheckStatusDocumentBean();
		String query = "SELECT  tb_student_send_document.Lv1_ApStatusID,"
							+ " tb_student_send_document.Lv2_ApStatusID,"
							+ " tb_teacher_check_document.Lv2_02StatusID,"
							+ " tb_teacher_check_document.Lv2_03StatusID,"
							+ " tb_teacher_check_document.Lv2_02Note,"
							+ " tb_teacher_check_document.Lv2_03Note "
					+ " FROM tb_student_send_document "
					+ "JOIN tb_teacher_check_document  ON tb_teacher_check_document.DocID = tb_student_send_document.ID "	
					+ " WHERE tb_student_send_document.UserID = :student_user_id  LIMIT 1"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("student_user_id", student_user_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				bean.setTeacher_lv1_status(getNameApprovalStatus(rs.getInt("Lv1_ApStatusID")));
				bean.setTeacher_lv2_status(getNameApprovalStatus(rs.getInt("Lv2_ApStatusID")));
				bean.setCoop02_status(getNameDocumentStatus(rs.getInt("Lv2_02StatusID")));
				bean.setCoop03_status(getNameDocumentStatus(rs.getInt("Lv2_03StatusID")));
				bean.setCoop02_comment(rs.getString("Lv2_02Note"));
				bean.setCoop03_comment(rs.getString("Lv2_03Note"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return bean;
	}
	public CheckStatusCompanyBean SelectCompanyTeacherLv2(int student_user_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		CheckStatusCompanyBean bean = new CheckStatusCompanyBean();
		String query = "SELECT  tb_student_select_company.Staff_ApStatusID, "
							+ " tb_student_select_company.Lv1_ApStatusID, "
							+ " tb_student_select_company.Comment, "
							+ " tb_student_select_company.File "
					+ " FROM tb_student_select_company "	
					+ " WHERE tb_student_select_company.UserID = :student_user_id  LIMIT 1"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("student_user_id", student_user_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				bean.setStaff_status(getNameApprovalStatus(rs.getInt("Staff_ApStatusID")));
				bean.setTeacher_lv1_status(getNameApprovalStatus(rs.getInt("Lv1_ApStatusID")));
				bean.setComment(rs.getString("Comment"));
				bean.setFile(rs.getString("File"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return bean;
	}
	
	public CheckStatusCompanyBean SelectCompanyTeacherLv1(int student_user_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		CheckStatusCompanyBean bean = new CheckStatusCompanyBean();
		String query = "SELECT  tb_student_select_company.Lv1_ApStatusID, "
							+ " tb_student_select_company.Comment "
					+ " FROM tb_student_select_company "	
					+ " WHERE tb_student_select_company.UserID = :student_user_id  LIMIT 1"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("student_user_id", student_user_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				bean.setTeacher_lv1_status(getNameApprovalStatus(rs.getInt("Lv1_ApStatusID")));
				bean.setComment(rs.getString("Comment"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return bean;
	}
	
	public CheckStatusDocumentBean SelectDocumentTeacherLv1(int student_user_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		CheckStatusDocumentBean bean = new CheckStatusDocumentBean();
		String query = "SELECT  tb_student_send_document.Lv1_ApStatusID,"
							+ " tb_student_send_document.Lv2_ApStatusID,"
							+ " tb_teacher_check_document.Lv1_02StatusID,"
							+ " tb_teacher_check_document.Lv1_03StatusID,"
							+ " tb_teacher_check_document.Lv1_02Note,"
							+ " tb_teacher_check_document.Lv1_03Note "
					+ " FROM tb_student_send_document "
					+ "JOIN tb_teacher_check_document  ON tb_teacher_check_document.DocID = tb_student_send_document.ID "	
					+ " WHERE tb_student_send_document.UserID = :student_user_id  LIMIT 1"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("student_user_id", student_user_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				bean.setTeacher_lv1_status(getNameApprovalStatus(rs.getInt("Lv1_ApStatusID")));
				bean.setTeacher_lv2_status(getNameApprovalStatus(rs.getInt("Lv2_ApStatusID")));
				bean.setCoop02_status(getNameDocumentStatus(rs.getInt("Lv1_02StatusID")));
				bean.setCoop03_status(getNameDocumentStatus(rs.getInt("Lv1_03StatusID")));
				bean.setCoop02_comment(rs.getString("Lv1_02Note"));
				bean.setCoop03_comment(rs.getString("Lv1_03Note"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return bean;
	}
	public String getNameApprovalStatus(int approval_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		String approval_name = "";
		String query = "SELECT  tb_approval_status.Name"
					+ " FROM tb_approval_status "
					+ " WHERE tb_approval_status.ID = :approval_id  LIMIT 1"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("approval_id", approval_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				approval_name = rs.getString("Name");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return approval_name;
	}
	public String getNameDocumentStatus(int document_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		String document_name = "";
		String query = "SELECT  tb_document_status.Name"
					+ " FROM tb_document_status "
					+ " WHERE tb_document_status.ID = :document_id LIMIT 1"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("document_id", document_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				document_name = rs.getString("Name");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return document_name;
	}
}
