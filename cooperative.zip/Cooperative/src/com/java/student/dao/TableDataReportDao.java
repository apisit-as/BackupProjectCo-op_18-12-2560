package com.java.student.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.student.bean.DataReportBean;
import com.java.util.PreparedStatementUtil;

public class TableDataReportDao {
	public Boolean CheckTable(int user_id){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = "SELECT True as isTable FROM cooperative.tb_data_report WHERE UserID = :user_id LIMIT 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("user_id", user_id);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getBoolean("isTable");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public void InsertDataReport(DataReportBean dataReportBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "INSERT INTO tb_data_report(date,"
		   									+ "teacher1_name,"
		   									+ "teacher2_name,"
		   									+ "UserID) "
					   		+ " VALUES(:date,"   
					   				+ ":teacher1_name,"
					   				+ ":teacher2_name,"
					   				+ ":user_id)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("date",dataReportBean.getDate());
		   preparedStatementUtil.setString("teacher1_name",dataReportBean.getTeacher1_name());
		   preparedStatementUtil.setString("teacher2_name",dataReportBean.getTeacher2_name());
		   preparedStatementUtil.setInt("user_id",dataReportBean.getUser_id());
		   preparedStatementUtil.execute();   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void UpdateDataReport(DataReportBean dataReportBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_data_report SET "
		   				+ "date = :date ,"
		   				+ "teacher1_name = :teacher1_name ,"
		   				+ "teacher2_name = :teacher2_name "
		   				+ "WHERE UserID = :user_id ";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("date",dataReportBean.getDate());
		   preparedStatementUtil.setString("teacher1_name",dataReportBean.getTeacher1_name());
		   preparedStatementUtil.setString("teacher2_name",dataReportBean.getTeacher2_name());
		   preparedStatementUtil.setInt("user_id",dataReportBean.getUser_id());
		   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public DataReportBean SelectDataReport(int user_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		DataReportBean dataReportBean = new DataReportBean();
		String query = "SELECT date,"
							+ "teacher1_name,"
							+ "teacher2_name "
					+ " FROM tb_data_report"
					+ " WHERE UserID = :user_id LIMIT 1"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("user_id",user_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				dataReportBean.setDate(rs.getString("date"));
				dataReportBean.setTeacher1_name(rs.getString("teacher1_name"));
				dataReportBean.setTeacher2_name(rs.getString("teacher2_name"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return dataReportBean;
	}
	
	public String getNameTeacher(int user_id,String type){
		
		// get division id
		TableUserDao tableUserDao = new TableUserDao();
		int division_id = tableUserDao.getDivisonID(user_id);
		
		// check role id
		int role_id = 0;
		if("teacher1".equals(type)){
			role_id = 4;
		}else if("teacher2".equals(type)){
			role_id = 5;
		}
		
		// get name teacher
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		String name_teacher = "";
		String query = "SELECT tb_title.Name_th AS titleName_th,"
							+ "tb_user.FirstName_th,"
							+ "tb_user.LastName_th "
					+ " FROM tb_user "
					+ " JOIN tb_title ON tb_user.TitleID = tb_title.ID"
					+ " WHERE tb_user.DivID = :division_id "
							+ "AND tb_user.RoleID = :role_id "
							+ "AND tb_user.ApproveRole = 'true' "
							+ " LIMIT 1 ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("division_id",division_id);
			preparedStatementUtil.setInt("role_id",role_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				//String title_name = rs.getString("titleName_th");
				String first_name = rs.getString("FirstName_th");
				String last_name = rs.getString("LastName_th");
				//name_teacher = title_name+""+first_name+"     "+last_name;
				name_teacher = first_name+"     "+last_name;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return name_teacher;
	}
}
