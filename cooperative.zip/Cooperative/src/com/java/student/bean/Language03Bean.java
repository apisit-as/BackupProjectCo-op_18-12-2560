package com.java.student.bean;

public class Language03Bean {
	private int id;
	private String language_eng;
	private String level_eng_listen;
	private String level_eng_speak;
	private String level_eng_write;
	private String language_chi;
	private String level_chi_listen;
	private String level_chi_speak;
	private String level_chi_write;
	private String language_other;
	private String level_other_listen;
	private String level_other_speak;
	private String level_other_write;
	private String input_other;
	private int coop03id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getLanguage_eng() {
		return language_eng;
	}
	public void setLanguage_eng(String language_eng) {
		this.language_eng = language_eng;
	}
	public String getLevel_eng_listen() {
		return level_eng_listen;
	}
	public void setLevel_eng_listen(String level_eng_listen) {
		this.level_eng_listen = level_eng_listen;
	}
	public String getLevel_eng_speak() {
		return level_eng_speak;
	}
	public void setLevel_eng_speak(String level_eng_speak) {
		this.level_eng_speak = level_eng_speak;
	}
	public String getLevel_eng_write() {
		return level_eng_write;
	}
	public void setLevel_eng_write(String level_eng_write) {
		this.level_eng_write = level_eng_write;
	}
	public String getLanguage_chi() {
		return language_chi;
	}
	public void setLanguage_chi(String language_chi) {
		this.language_chi = language_chi;
	}
	public String getLevel_chi_listen() {
		return level_chi_listen;
	}
	public void setLevel_chi_listen(String level_chi_listen) {
		this.level_chi_listen = level_chi_listen;
	}
	public String getLevel_chi_speak() {
		return level_chi_speak;
	}
	public void setLevel_chi_speak(String level_chi_speak) {
		this.level_chi_speak = level_chi_speak;
	}
	public String getLevel_chi_write() {
		return level_chi_write;
	}
	public void setLevel_chi_write(String level_chi_write) {
		this.level_chi_write = level_chi_write;
	}
	public String getLanguage_other() {
		return language_other;
	}
	public void setLanguage_other(String language_other) {
		this.language_other = language_other;
	}
	public String getLevel_other_listen() {
		return level_other_listen;
	}
	public void setLevel_other_listen(String level_other_listen) {
		this.level_other_listen = level_other_listen;
	}
	public String getLevel_other_speak() {
		return level_other_speak;
	}
	public void setLevel_other_speak(String level_other_speak) {
		this.level_other_speak = level_other_speak;
	}
	public String getLevel_other_write() {
		return level_other_write;
	}
	public void setLevel_other_write(String level_other_write) {
		this.level_other_write = level_other_write;
	}
	public String getInput_other() {
		return input_other;
	}
	public void setInput_other(String input_other) {
		this.input_other = input_other;
	}
	public int getCoop03id() {
		return coop03id;
	}
	public void setCoop03id(int coop03id) {
		this.coop03id = coop03id;
	}
}
