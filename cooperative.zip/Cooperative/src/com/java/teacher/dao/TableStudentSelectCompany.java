package com.java.teacher.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.teacher.bean.ListStudentSelectCompanyBean;
import com.java.util.PreparedStatementUtil;

public class TableStudentSelectCompany {

	public ArrayList<ListStudentSelectCompanyBean> SelectListStudentSelectCompany(int lv_apStatusID,int facid,int divid,int academic_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ArrayList<ListStudentSelectCompanyBean> list = new ArrayList<>();
		String query =  "SELECT  tb_user.StudentID,"
						+ "tb_title.Name_th AS titleName_th,"
				        + "tb_user.FirstName_th,"
				        + "tb_user.LastName_th,"
				        + "tb_division.Name AS divName,"
				        + "tb_company.NameCompany,"
				        + "tb_company.ID AS Company_id,"
				        + "tb_company.ProvinceCompany,"
				        + "tb_student_select_company.UserID,"
				        + "tb_student_select_company.Comment "
				        + "FROM tb_student_select_company "
				        + "JOIN tb_user  ON tb_user.ID = tb_student_select_company.UserID "
				        + "JOIN tb_title  ON tb_title.ID = tb_user.TitleID "
				        + "JOIN tb_division  ON tb_division.ID = tb_user.DivID "
				        + "JOIN tb_profile  ON tb_profile.UserID = tb_user.ID "
						+ "JOIN tb_rate_company  ON tb_rate_company.ID = tb_student_select_company.RateCompanyID_Temp "
						+ "JOIN tb_company  ON tb_company.ID = tb_rate_company.CompanyID "
				        + "WHERE tb_student_select_company.Lv1_ApStatusID = :lv_ap_statusid "
					    	+ "AND tb_user.FacID = :facid AND tb_user.DivID = :divid "
				            + "AND tb_student_select_company.Academic_year = :academic_id "
				            + "AND tb_user.RoleID = 1 ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("lv_ap_statusid", lv_apStatusID);
			preparedStatementUtil.setInt("facid", facid);
			preparedStatementUtil.setInt("divid", divid);
			preparedStatementUtil.setInt("academic_id", academic_id);
			rs = preparedStatementUtil.executeQuery();
			while(rs.next()){
				ListStudentSelectCompanyBean studentSelectCompanyBean = new ListStudentSelectCompanyBean();
				studentSelectCompanyBean.setStudent_id(rs.getString("StudentID"));
				studentSelectCompanyBean.setTitle_name_th(rs.getString("titleName_th"));
				studentSelectCompanyBean.setFirstname_th(rs.getString("FirstName_th"));
				studentSelectCompanyBean.setLastname_th(rs.getString("LastName_th"));
				studentSelectCompanyBean.setDivision_name(rs.getString("divName"));
				studentSelectCompanyBean.setCompany_name(rs.getString("NameCompany"));
				studentSelectCompanyBean.setCompany_id(rs.getString("Company_id"));
				studentSelectCompanyBean.setProvice(rs.getString("ProvinceCompany"));
				studentSelectCompanyBean.setComment(rs.getString("Comment"));
				studentSelectCompanyBean.setUser_id(rs.getInt("UserID"));
				list.add(studentSelectCompanyBean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public void UpdateApprovalStatus(int lv1_ap_status_id,String comment,int user_id_student,int ap_status_by,String ap_status_date){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
			  String query = "UPDATE tb_student_select_company SET "
							+ "Lv1_ApStatusID = :lv1_ap_status_id,"
			   				+ "Lv1_ApStatusBy = :ap_status_by, "
			   				+ "Lv1_ApStatusDate = :ap_status_date, ";
			   				
					  if(lv1_ap_status_id == 5){
						  //  5 = ���͹��ѵ�
						  query = query + "RateCompanyID = null , ";
					  }
					  else if(lv1_ap_status_id == 2){
						  // 2 = ͹��ѵ�  , 6 = �ʹ��Թ���
						  query = query + "Staff_ApStatusID = 6 , ";
						  comment = null;
					  }
			  		 query = query + "Comment = :comment ";
					 query = query + "WHERE tb_student_select_company.UserID = :user_id_student ";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("lv1_ap_status_id",lv1_ap_status_id);
			   preparedStatementUtil.setInt("ap_status_by",ap_status_by);
			   preparedStatementUtil.setString("ap_status_date",ap_status_date);
			   preparedStatementUtil.setString("comment",comment);
			   preparedStatementUtil.setInt("user_id_student",user_id_student);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void UpdateCoop03(int user_id_student){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
			  String query = "UPDATE tb_coop03 SET "
							+ "Position = '',"
			   				+ "CodeJob = '', "
			   				+ "SendDocuments = '' "
					 		+ "WHERE tb_coop03.UserID = :user_id_student ";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("user_id_student",user_id_student);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
}
