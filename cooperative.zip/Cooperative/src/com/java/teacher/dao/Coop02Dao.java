package com.java.teacher.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.student.bean.AddressBean;
import com.java.student.bean.FamilyBean;
import com.java.student.bean.Language02Bean;
import com.java.teacher.bean.Coop02Bean;
import com.java.teacher.bean.ProfileStudentSendDocumentBean;
import com.java.util.PreparedStatementUtil;

public class Coop02Dao {

	public ProfileStudentSendDocumentBean SelectDataStudent(int facid,int divid,int academic_id,int id_student_send_document,String checkLevelTeacher){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ProfileStudentSendDocumentBean profileStudentSendDocumentBean = new ProfileStudentSendDocumentBean();
		String query =	"SELECT	tb_user.StudentID,"
						+ "tb_title.Name_th AS titleName_th,"
					    + "tb_user.FirstName_th,"
					    + "tb_user.LastName_th,"
					    + "tb_title.Name_eng AS titleName_eng,"
					    + "tb_user.FirstName_eng,"
					    + "tb_user.LastName_eng,"
					    + "tb_profile.ClassYear,"
					    + "tb_profile.GroupStudent,"
					    + "tb_division.Name AS divName "
					+ "FROM tb_student_send_document "
					    + "JOIN tb_user  ON tb_user.ID = tb_student_send_document.UserID "
					    + "JOIN tb_title  ON tb_title.ID = tb_user.TitleID "
					    + "JOIN tb_division  ON tb_division.ID = tb_user.DivID "
					    + "JOIN tb_profile  ON tb_profile.ID = tb_student_send_document.ProfileID "
					    
					    + "WHERE   tb_student_send_document.ID = :id_student_send_document  "
 								+ "AND (tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 6 OR tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 3) "		
							    + "AND tb_user.FacID = :facid AND tb_user.DivID = :divid "
					            + "AND tb_student_send_document.Academic_year = :academic_id "
					            + "AND tb_user.RoleID = 1  LIMIT 1 ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id_student_send_document", id_student_send_document);
			preparedStatementUtil.setInt("facid", facid);
			preparedStatementUtil.setInt("divid", divid);
			preparedStatementUtil.setInt("academic_id", academic_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				profileStudentSendDocumentBean.setStudent_id(rs.getString("StudentID"));
				profileStudentSendDocumentBean.setTitle_name_th(rs.getString("titleName_th"));
				profileStudentSendDocumentBean.setFirstname_th(rs.getString("FirstName_th"));
				profileStudentSendDocumentBean.setLastname_th(rs.getString("LastName_th"));
				profileStudentSendDocumentBean.setTitle_name_eng(rs.getString("titleName_eng"));
				profileStudentSendDocumentBean.setFirstname_eng(rs.getString("FirstName_eng"));
				profileStudentSendDocumentBean.setLastname_eng(rs.getString("LastName_eng"));
				profileStudentSendDocumentBean.setClassyear(rs.getString("ClassYear"));
				profileStudentSendDocumentBean.setGroupstudent(rs.getString("GroupStudent"));
				profileStudentSendDocumentBean.setDivision_name(rs.getString("divName"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return profileStudentSendDocumentBean;
	}
	
	public AddressBean SelectAddress(int facid,int divid,int academic_id,int id_student_send_document,String address_type,String checkLevelTeacher){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		AddressBean addressBean = new AddressBean();
		String query =	  "SELECT	tb_address.Id_num,"
						+ "tb_address.Num_Mu,"
						+ "tb_address.Road,"
						+ "tb_province.Name AS province_name,"
						+ "tb_amphur.Name AS amphur_name,"
						+ "tb_district.Name AS district_name,"
						+ "tb_address.Postcode,"
						+ "tb_address.Telephone,"
						+ "tb_address.Mobile,"
						+ "tb_address.Fax,"
						+ "tb_address.Email "
					+ "FROM tb_student_send_document "
					+ "JOIN tb_user ON tb_user.ID = tb_student_send_document.UserID "
					+ "JOIN tb_profile  ON tb_profile.ID = tb_student_send_document.ProfileID "
					+ "JOIN tb_address  ON tb_address.ProfileID = tb_profile.ID "
					+ "JOIN tb_province  ON tb_province.ID = tb_address.ProvinceID "
					+ "JOIN tb_amphur  ON tb_amphur.ID = tb_address.AmphurID "
					+ "JOIN tb_district  ON tb_district.ID = tb_address.DistrictID "
			    
			   	+ "WHERE   tb_student_send_document.ID = :id_student_send_document "
			   			  + "AND (tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 6 OR tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 3) "
						  + "AND tb_address.Type = :type "
						  + "AND tb_user.FacID = :facid AND tb_user.DivID = :divid  "
			              + "AND tb_student_send_document.Academic_year = :academic_id "
			              + "AND tb_user.RoleID = 1  LIMIT 1 ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id_student_send_document", id_student_send_document);
			preparedStatementUtil.setInt("facid", facid);
			preparedStatementUtil.setInt("divid", divid);
			preparedStatementUtil.setInt("academic_id", academic_id);
			preparedStatementUtil.setString("type", address_type);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				addressBean.setId_num(rs.getString("Id_num"));
				addressBean.setNum_mu(rs.getString("Num_Mu"));
				addressBean.setRoad(rs.getString("Road"));
				addressBean.setProvincename(rs.getString("province_name"));
				addressBean.setAmphurname(rs.getString("amphur_name"));
				addressBean.setDistrictname(rs.getString("district_name"));
				addressBean.setPostcode(rs.getString("Postcode"));
				addressBean.setTelephone(rs.getString("Telephone"));
				addressBean.setMobile(rs.getString("Mobile"));
				addressBean.setFax(rs.getString("Fax"));
				addressBean.setEmail(rs.getString("Email"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return addressBean;
	}
	
	public FamilyBean SelectFamily(int facid,int divid,int academic_id,int id_student_send_document,String family_type,String checkLevelTeacher){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		FamilyBean familyBean = new FamilyBean();
		String query =    "SELECT  tb_title.Name_th,"
						+ "tb_family.FirstName,"
						+ "tb_family.LastName,"
				        + "tb_family.Age,"
				        + "tb_family.Relation,"
				        + "tb_family.Occupation,"
				        + "tb_family.PlaceOccupation "
					+ "FROM tb_student_send_document "
					     + "JOIN tb_user  ON tb_user.ID = tb_student_send_document.UserID "
						 + "JOIN tb_profile  ON tb_profile.ID = tb_student_send_document.ProfileID "
					     + "JOIN tb_family  ON tb_family.ProfileID = tb_profile.ID "
					     + "JOIN tb_title  ON tb_title.ID = tb_family.TitleID "
				     
				     + "WHERE 		tb_student_send_document.ID = :id_student_send_document  "
							  + "AND (tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 6 OR tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 3) " 
							  + "AND tb_family.Type = :type "
							  + "AND tb_user.FacID = :facid AND tb_user.DivID = :divid  "
				              + "AND tb_student_send_document.Academic_year = :academic_id "
				              + "AND tb_user.RoleID = 1  LIMIT 1 ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id_student_send_document", id_student_send_document);
			preparedStatementUtil.setInt("facid", facid);
			preparedStatementUtil.setInt("divid", divid);
			preparedStatementUtil.setInt("academic_id", academic_id);
			preparedStatementUtil.setString("type", family_type);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				familyBean.setTitlename(rs.getString("Name_th"));
				familyBean.setFirstname(rs.getString("FirstName"));
				familyBean.setLastname(rs.getString("LastName"));
				familyBean.setAge(rs.getString("Age"));
				familyBean.setRelation(rs.getString("Relation"));
				familyBean.setOccupation(rs.getString("Occupation"));
				familyBean.setPlace_occupation(rs.getString("PlaceOccupation"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return familyBean;
	}
	
	public Coop02Bean SelectCoop02(int facid,int divid,int academic_id,int id_student_send_document,String checkLevelTeacher){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		Coop02Bean coop02Bean = new Coop02Bean();
		String query = "SELECT  tb_coop02.Talent,"
						+ "tb_coop02.Region,"
				        + "tb_select_job02.Job,"
				        + "tb_select_job02.Other,"
				        + "tb_coop02.Interest,"
				        + "tb_profile.Grade,"
				        + "tb_profile.GradeTotal,"
				        + "tb_coop02.Term,"
				        + "tb_coop02.Academic_year "
				    + "FROM tb_student_send_document "
				    + "JOIN tb_user  ON tb_user.ID = tb_student_send_document.UserID "
					+ "JOIN tb_coop02  ON tb_coop02.ID = tb_student_send_document.Coop02ID "
				    + "JOIN tb_select_job02  ON tb_select_job02.Coop02ID = tb_coop02.ID "
				    + "JOIN tb_profile  ON tb_profile.ID = tb_student_send_document.ProfileID "
				    
				    + "WHERE 		tb_student_send_document.ID = :id_student_send_document "
							  + "AND (tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 6 OR tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 3) " 
							  + "AND tb_user.FacID = :facid AND tb_user.DivID = :divid "
				              + "AND tb_student_send_document.Academic_year = :academic_id "
				              + "AND tb_user.RoleID = 1  LIMIT 1 ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id_student_send_document", id_student_send_document);
			preparedStatementUtil.setInt("facid", facid);
			preparedStatementUtil.setInt("divid", divid);
			preparedStatementUtil.setInt("academic_id", academic_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				coop02Bean.setTalent(rs.getString("Talent"));
				coop02Bean.setRegion(rs.getString("Region"));
				
				if("���� �ô�к�".equals(rs.getString("Job"))){
					coop02Bean.setSelect_job(rs.getString("Other"));
				}else{
					coop02Bean.setSelect_job(rs.getString("Job"));
				}
				
				coop02Bean.setInterest(rs.getString("Interest"));
				coop02Bean.setGrade(rs.getString("Grade"));
				coop02Bean.setGradetotal(rs.getString("GradeTotal"));
				coop02Bean.setSemester(rs.getString("Term"));
				coop02Bean.setAcademic_year(rs.getString("Academic_year"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return coop02Bean;
	}
	
	public Language02Bean SelectLanguage02(int facid,int divid,int academic_id,int id_student_send_document,String checkLevelTeacher){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		Language02Bean language02Bean = new Language02Bean();
		String query = "SELECT  tb_language02.Language_eng,"
						+ "tb_language02.Level_eng,"
						+ "tb_language02.Language_jap,"
				        + "tb_language02.Level_jap,"
				        + "tb_language02.Language_chi,"
				        + "tb_language02.Level_chi,"
				        + "tb_language02.Language_other,"
				        + "tb_language02.Level_other,"
				        + "tb_language02.other "
				    + "FROM tb_student_send_document "
				    + "JOIN tb_user  ON tb_user.ID = tb_student_send_document.UserID "
					+ "JOIN tb_coop02  ON tb_coop02.ID = tb_student_send_document.Coop02ID "
				    + "JOIN tb_language02  ON tb_language02.Coop02ID = tb_coop02.ID "
				    
				    + "WHERE 	tb_student_send_document.ID = :id_student_send_document  "
							  + "AND (tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 6 OR tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 3) "
							  + "AND tb_user.FacID = :facid AND tb_user.DivID = :divid "
				              + "AND tb_student_send_document.Academic_year = :academic_id "
				              + "AND tb_user.RoleID = 1  LIMIT 1 ";

		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id_student_send_document", id_student_send_document);
			preparedStatementUtil.setInt("facid", facid);
			preparedStatementUtil.setInt("divid", divid);
			preparedStatementUtil.setInt("academic_id", academic_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				language02Bean.setLanguage_eng(rs.getString("Language_eng"));
				language02Bean.setLeve_eng(rs.getString("Level_eng"));
				language02Bean.setLanguage_jap(rs.getString("Language_jap"));
				language02Bean.setLeve_jap(rs.getString("Level_jap"));
				language02Bean.setLanguage_chi(rs.getString("Language_chi"));
				language02Bean.setLeve_chi(rs.getString("Level_chi"));
				language02Bean.setLanguage_other(rs.getString("Language_other"));
				language02Bean.setLeve_other(rs.getString("Level_other"));
				language02Bean.setOther(rs.getString("other"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return language02Bean;
	}
}
