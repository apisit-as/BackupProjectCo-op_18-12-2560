package com.java.teacher.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.admin.bean.AcademicYearBean;
import com.java.admin.dao.TableAcademicYearDao;
import com.java.list.bean.FooterBean;
import com.java.list.dao.FooterDao;
import com.java.staff.bean.RateCompanyListBean;
import com.java.student.dao.TableStudentSelectCompanyDao;
import com.java.util.SessionExpire;

/**
 * Servlet implementation class ListCompany
 */
@WebServlet("/ListCompany")
public class ListCompany extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListCompany() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
			HttpSession session = request.getSession();
			
			// check role session expire
		    if(session.getAttribute("role") == null){
			  	SessionExpire sessionExpire = new SessionExpire();
				response.sendRedirect(sessionExpire.getSendRedirect()); // send redirect to Login page
				return;
		    }
			
			String role = session.getAttribute("role").toString();
			if((role.equals("teacher0")) || (role.equals("teacher1")) || (role.equals("teacher2"))){
				
				// set Academic Year
				TableAcademicYearDao tableAcademicYear = new TableAcademicYearDao();
				AcademicYearBean academicYearBean = new AcademicYearBean();
				academicYearBean = tableAcademicYear.getAcademic();
				session.setAttribute("Semester", academicYearBean.getSemester());
				session.setAttribute("Academic_year", academicYearBean.getAcademic_year());
				session.setAttribute("academic_year_id", academicYearBean.getId());
				
				// list company
				ArrayList<RateCompanyListBean> rateCompanyListBeans = new ArrayList<>();
				TableStudentSelectCompanyDao tableStudentSelectCompanyDao = new TableStudentSelectCompanyDao();
				int divid = Integer.parseInt(session.getAttribute("divID").toString()); 
				rateCompanyListBeans = tableStudentSelectCompanyDao.SelectListRateCompany(academicYearBean.getId(),divid);
				
				//  rate_company_id == 0
				request.setAttribute("rate_company_id", 0);
				request.setAttribute("rateCompanyListBeans", rateCompanyListBeans);
				
				/** set text footer **/
				FooterBean footerBean = new FooterBean();
				footerBean = new FooterDao().SelectDataFooter();
				request.setAttribute("footerBean", footerBean);
				
				doViewListCompany(request, response);
				
			}
		
	}

	private void doViewListCompany(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/teacher/list_company.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
}
