package com.java.util.report;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import com.java.staff.bean.CompanyBean;
import com.java.student.bean.AddressBean;
import com.java.student.bean.Coop02Bean;
import com.java.student.bean.FamilyBean;
import com.java.student.bean.UserBean;

import com.java.util.report.ThaiExporterManager;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;

import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;

import javax.servlet.http.HttpServletRequest;


public class ReportCoop05{

	public void insertCoop05Pdf(HttpServletRequest request,UserBean userBean,FamilyBean familyBean,AddressBean addressBean3,Coop02Bean coop02Bean,String date_day,String date_month,String date_year,CompanyBean companyBean){
		try {
			/* User home directory location */
			String userHomeDirectory = request.getServletContext().getRealPath("/");
			
			String studentid = userBean.getStudentid();
			String userid =  Integer.toString(userBean.getId());
			
			/* Output file location */
			String filename = studentid+"_"+userid;
			String fileShow = "Upload/File/Report/PDF/" + filename +"_coop05.pdf";
			String outputFile = userHomeDirectory + File.separatorChar + "/" + fileShow;

			
			/* Create path  */
		    File file = new File(userHomeDirectory, "Upload/File/Report/PDF/");
		    if (!file.exists()) {
		     file.mkdirs();
		    }
			
			/* Convert List to JRBeanCollectionDataSource */
//			JRBeanCollectionDataSource userList = new JRBeanCollectionDataSource(userBeanList);

			/* Map to hold Jasper report Parameters */
			Map<String, Object> parameters = new HashMap<String, Object>();
			
			// �����ŷ����
			parameters.put("titleName_th", userBean.getTitlename_th());
			parameters.put("firstName_th",userBean.getFirstname_th());
			parameters.put("lastName_th",userBean.getLastname_th());
			parameters.put("studentID",userBean.getStudentid());
			parameters.put("divisionName",userBean.getDivname());
			parameters.put("FacultyName", userBean.getFacname());
			parameters.put("titleName_parent",familyBean.getTitlename());
			parameters.put("firstName_parent",familyBean.getFirstname());
			parameters.put("lastName_parent",familyBean.getLastname());
			parameters.put("relation_parent",familyBean.getRelation());
			// #�����ŷ����
			
			// ʶҹ���Դ��ͼ�黡��ͧ���дǡ
			parameters.put("id_num3",addressBean3.getId_num());
			parameters.put("road3",addressBean3.getRoad());
			parameters.put("districtName3",addressBean3.getDistrictname());
			parameters.put("amphurName3",addressBean3.getAmphurname());
			parameters.put("provinceName3",addressBean3.getProvincename());
			parameters.put("postCode3",addressBean3.getPostcode());
			parameters.put("telephone3",addressBean3.getTelephone());
			parameters.put("mobile3",addressBean3.getMobile());
			// #ʶҹ���Դ��ͼ�黡��ͧ���дǡ
			

			// academice year
			parameters.put("term",coop02Bean.getTerm());
			parameters.put("academic_year",coop02Bean.getAcademic_year());
			// #academice year

			// date
			parameters.put("date_day",date_day);
			parameters.put("date_month",date_month);
			parameters.put("date_year",date_year);
			
			// set data company
			parameters.put("NameCompany",companyBean.getName_company());
			parameters.put("AddressCompany",companyBean.getAddress_company());
			parameters.put("DistrictCompany",companyBean.getDistrict_company());
			parameters.put("AmphurCompany",companyBean.getAmphur_company());
			parameters.put("ProvinceCompany",companyBean.getProvince_company());
			parameters.put("PostcodeCompany",companyBean.getPostcode_company());
			parameters.put("TelephoneCompany",companyBean.getTelephone_company());
			parameters.put("FaxCompany",companyBean.getFax_company());
			parameters.put("EmailCompany",companyBean.getEmail_company());
			
			/*
			 * Using compiled version(.jasper) of Jasper report to generate PDF
			 */
			JasperPrint jasperPrint = JasperFillManager.fillReport(request.getServletContext().getRealPath("/views/pages/student/report/Coop05_pdf.jasper")
										, parameters,new JREmptyDataSource());
			
			/* outputStream to create PDF */
			OutputStream outputStream = new FileOutputStream(new File(outputFile));
			ThaiExporterManager.exportReportToPdfStream(jasperPrint, outputStream);

			//System.out.println(fileShow);

		} catch (JRException ex) {
			ex.printStackTrace();
		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		}
	}	
}
