package com.java.util;

import java.io.File;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;

public class FileUploadUtil {
	public static String uploadFile(HttpServletRequest request, FileItem item,String nameFolder, String nameFile1, String nameFile2,String type) {
		  String root = request.getServletContext().getRealPath("/");
		  //System.out.println(root); 
		  //  ....\eclipse\project\.metadata\.plugins\org.eclipse.wst.server.core\tmp1\wtpwebapps\Cooperative\
		  File file = null;
		  String typeFile = "";
		  String nameFile = nameFile1 + "_" + nameFile2;
		  try {
		   if (!item.isFormField()) {
		    file = new File(root, "Upload/File/"+nameFolder);
		    if (!file.exists()) {
		     file.mkdirs();
		    }
		    typeFile = type;
		    file = new File(file, nameFile + "." + typeFile);
		    item.write(file);
		   }

		   return "Upload/File/"+nameFolder + "/" + nameFile + "." + typeFile;
		  } catch (FileUploadException e) {
		   e.printStackTrace();
		   return null;
		  } catch (Exception e) {
		   e.printStackTrace();
		   return null;
		  }
		 }
	
	public static String eidtFileManagement(HttpServletRequest request,String nameFolder,String old_name_file,String new_name_file) {
		  String root = request.getServletContext().getRealPath("/");
		  try {
			  
			  // File (or directory) with old name
			  File old_file = new File(root, "Upload/File/"+nameFolder+"/"+old_name_file);

			  // File (or directory) with new name
			  File new_file = new File(root, "Upload/File/"+nameFolder+"/"+new_name_file);

			  if (new_file.exists())
			     throw new java.io.IOException("file exists");

			  // Rename file (or directory)
			  boolean success = old_file.renameTo(new_file);

			  if (!success) {
			     // File was not successfully renamed
				 //System.out.println("fail rename");
			  }
			  
		  } catch (Exception e) {
			   e.printStackTrace();
		  }
		  
		  return "Upload/File/"+nameFolder+"/"+new_name_file;
		 }
	
	
	public static void deleteFile(HttpServletRequest request, String part) {
		  String root = request.getServletContext().getRealPath("/");
		  File file = null;
		  try {
		    file = new File(root, ""+part);
		    if(file.delete()){
			    //System.out.println("OK delete file");
		    }

		  } catch (Exception e) {
		   e.printStackTrace();
		  }
	}
	
	public static void deleteReport(HttpServletRequest request, String nameFile) {
		  String root = request.getServletContext().getRealPath("/");
		  File file = null;
			  try {
				    file = new File(root, "Upload/File/Report/PDF/"+nameFile+".pdf");
				    if(file.delete()){
					    //System.out.println("OK delete pdf");
				    }
			  } catch (Exception e) {
				   e.printStackTrace();
			  }
	}
}
