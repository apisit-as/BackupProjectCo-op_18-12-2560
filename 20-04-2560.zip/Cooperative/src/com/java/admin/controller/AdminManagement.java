package com.java.admin.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.admin.bean.FacultyBean;
import com.java.admin.dao.TableDivisionDao;
import com.java.admin.dao.TableFacultyDao;

import com.java.admin.dao.UserManagementDao;

import com.java.admin.bean.DivisionBean;
import com.java.student.bean.UserBean;


/**
 * Servlet implementation class StudentManagement
 */
@WebServlet("/AdminManagement")
public class AdminManagement extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminManagement() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
		  HttpSession session = request.getSession();
		  String role = session.getAttribute("role").toString();
		
		  // role admin
		  if(role.equals("admin")){

				
			  doViewAdminManagement(request, response);
		  }

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		ArrayList<DivisionBean> listDivision = new ArrayList<DivisionBean>();
		TableDivisionDao tableDivisionDao = new TableDivisionDao();
		PrintWriter out = response.getWriter();

		String action = request.getParameter("action");
			
	}
	
	private void doViewAdminManagement(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/admin/admin_management.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	/***  paging student list***/
//	private void doViewUserList(HttpServletRequest request, HttpServletResponse response) {
//		RequestDispatcher rd = request.getRequestDispatcher("/include/user-list/userStudent-list.jsp");
//		try {
//			rd.forward(request, response);
//		} catch (ServletException | IOException e) {
//			e.printStackTrace();
//		}
//	}
}
