package com.java.admin.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.student.bean.UserBean;
import com.java.util.PreparedStatementUtil;

public class UserManagementDao {

	/*  list all role  not admin */
	public ArrayList<UserBean> getAllUserList(){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<UserBean> userBeanList = new ArrayList<UserBean>();
		
		String query = "SELECT tb_user.ID,"
				+ "tb_user.StudentID,"
				+ "tb_title.Name_th AS TitleName,"
				+ "tb_user.FirstName_th,"
				+ "tb_user.LastName_th,"
				+ "tb_faculty.Name AS facultyName,"
				+ "tb_division.Name AS divisionName,"
				+ "tb_user.FacID,"
				+ "tb_user.DivID, "
				+ "tb_role.ID AS RoleID,"
				+ "tb_role.NameTH,"
				+ "tb_role.NameENG"
				+ " FROM tb_user "
				+ " LEFT JOIN tb_title on tb_title.ID = tb_user.TitleID "
				+ " LEFT JOIN tb_faculty on tb_faculty.ID = tb_user.FacID "
				+ " LEFT JOIN tb_division on tb_division.ID = tb_user.DivID "
				+ " LEFT JOIN tb_role on tb_role.ID = tb_user.RoleID "
				+ " WHERE tb_user.RoleID = 1"
				+ " OR tb_user.RoleID = 3"
				+ " OR tb_user.RoleID = 4"
				+ " OR tb_user.RoleID = 5";
	
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			rs = prepareStatementUtil.executeQuery();
			
			while(rs.next()){
				UserBean userBean = new UserBean();
				userBean.setId(rs.getInt("ID"));
				userBean.setStudentid(rs.getString("StudentID"));
				userBean.setTitlename_th(rs.getString("TitleName"));
				userBean.setFirstname_th(rs.getString("FirstName_th"));
				userBean.setLastname_th(rs.getString("LastName_th"));
				userBean.setFacname(rs.getString("facultyName"));
				userBean.setDivname(rs.getString("divisionName"));
				userBean.setFacid(rs.getInt("FacID"));
				userBean.setDivid(rs.getInt("DivID"));
				userBean.setRoleid(rs.getInt("RoleID"));
				userBean.setRolename_th(rs.getString("NameTH"));
				userBean.setRolename_eng(rs.getString("NameENG"));
				userBeanList.add(userBean);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return userBeanList;
	}
  /*  # list all role  not admin */

	/*   update edit profile */
	public void updateProfile(int id, String facid, String divid, String roleid){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "UPDATE tb_user SET "
		   				+ "FacID = :facID,"
		   				+ "DivID = :divID, "
		   				+ "RoleID = :roleID " 
		   				+ "WHERE tb_user.ID = :id";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setString("facID", facid);
		   preparedStatementUtil.setString("divID", divid);
		   preparedStatementUtil.setString("roleID", roleid);
		   preparedStatementUtil.setInt("id", id);
		   preparedStatementUtil.execute();
		   		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	/*  # update edit profile */
	
	/*  update null tb_user  Faculty and Divsion */
	public void updateNullDivsionUser(int divsionid){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "UPDATE tb_user SET "
		   				+ "DivID = null " 
		   				+ "WHERE tb_user.DivID = :divsionid";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setInt("divsionid", divsionid);

		   preparedStatementUtil.execute();
		   		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
	}	
	
	public void updateNullFacultyUser(int facid){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "UPDATE tb_user SET "
				   		+ "FacID = null ,"
		   				+ "DivID = null " 
		   				+ "WHERE tb_user.FacID = :facid";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setInt("facid", facid);

		   preparedStatementUtil.execute();
		   		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
	}
	/*  #update null tb_user  Faculty and Divsion */
}
