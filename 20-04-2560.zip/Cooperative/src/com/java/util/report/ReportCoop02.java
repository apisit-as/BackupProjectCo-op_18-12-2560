package com.java.util.report;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import com.java.student.bean.AddressBean;
import com.java.student.bean.Coop02Bean;
import com.java.student.bean.FamilyBean;
import com.java.student.bean.Language02Bean;
import com.java.student.bean.ProfileBean;
import com.java.student.bean.SelectJob02Bean;
import com.java.student.bean.UserBean;

import com.java.util.report.ThaiExporterManager;


import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;

import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.ooxml.JRDocxExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;

import javax.servlet.http.HttpServletRequest;


public class ReportCoop02{

	public void insertCoop02Pdf(HttpServletRequest request,UserBean userBean,ProfileBean profileBean,AddressBean addressBean1,AddressBean addressBean2,AddressBean addressBean3
			 ,FamilyBean familyBean,Coop02Bean coop02Bean,SelectJob02Bean selectJob02Bean,Language02Bean language02Bean,String date_day,String date_month,String date_year){
		try {
			/* User home directory location */
			String userHomeDirectory = request.getServletContext().getRealPath("/");
			
			String studentid = userBean.getStudentid();
			String userid =  Integer.toString(userBean.getId());
			
			/* Output file location */
			String filename = studentid+"_"+userid;
			String fileShow = "Upload/File/Report/PDF/" + filename +"_coop02.pdf";
			String outputFile = userHomeDirectory + File.separatorChar + "/" + fileShow;

			
			/* Create path  */
		    File file = new File(userHomeDirectory, "Upload/File/Report/PDF/");
		    if (!file.exists()) {
		     file.mkdirs();
		    }
			
			/* Convert List to JRBeanCollectionDataSource */
//			JRBeanCollectionDataSource userList = new JRBeanCollectionDataSource(userBeanList);

			/* Map to hold Jasper report Parameters */
			Map<String, Object> parameters = new HashMap<String, Object>();
			
			// 1
			parameters.put("titleName_th", userBean.getTitlename_th());
			parameters.put("firstName_th",userBean.getFirstname_th());
			parameters.put("lastName_th",userBean.getLastname_th());
			parameters.put("studentID",userBean.getStudentid());
			parameters.put("titleName_eng",userBean.getTitlename_eng());
			parameters.put("firstName_eng",userBean.getFirstname_eng());
			parameters.put("lastName_eng",userBean.getLastname_eng());
			parameters.put("classYear",profileBean.getClassyear());
			parameters.put("groupStudent",profileBean.getGroupstudent());
			parameters.put("divisionName",userBean.getDivname());
			// #1
			
			// 2 3 4
			parameters.put("id_num1",addressBean1.getId_num());
			parameters.put("road1",addressBean1.getRoad());
			parameters.put("districtName1",addressBean1.getDistrictname());
			parameters.put("amphurName1",addressBean1.getAmphurname());
			parameters.put("provinceName1",addressBean1.getProvincename());
			parameters.put("postCode1",addressBean1.getPostcode());
			parameters.put("mobile1",addressBean1.getMobile());
			parameters.put("email1",addressBean1.getEmail());
			
			parameters.put("id_num2",addressBean2.getId_num());
			parameters.put("road2",addressBean2.getRoad());
			parameters.put("districtName2",addressBean2.getDistrictname());
			parameters.put("amphurName2",addressBean2.getAmphurname());
			parameters.put("provinceName2",addressBean2.getProvincename());
			parameters.put("postCode2",addressBean2.getPostcode());
			parameters.put("mobile2",addressBean2.getMobile());
			parameters.put("email2",addressBean2.getEmail());
			
			parameters.put("id_num3",addressBean3.getId_num());
			parameters.put("road3",addressBean3.getRoad());
			parameters.put("districtName3",addressBean3.getDistrictname());
			parameters.put("amphurName3",addressBean3.getAmphurname());
			parameters.put("provinceName3",addressBean3.getProvincename());
			parameters.put("postCode3",addressBean3.getPostcode());
			parameters.put("mobile3",addressBean3.getMobile());
			parameters.put("email3",addressBean3.getEmail());
			
			parameters.put("titleName_parent",familyBean.getTitlename());
			parameters.put("firstName_parent",familyBean.getFirstname());
			parameters.put("lastName_parent",familyBean.getLastname());
			parameters.put("relation_parent",familyBean.getRelation());
			// #2 3 4
			
			// 5  6
			if("".equals(language02Bean.getLeve_eng()))  language02Bean.setLeve_eng("-");
			if("".equals(language02Bean.getLeve_jap()))  language02Bean.setLeve_jap("-");
			if("".equals(language02Bean.getLeve_chi()))	language02Bean.setLeve_chi("-");
			if("".equals(language02Bean.getLeve_other()))	language02Bean.setLeve_other("-");
			if("".equals(language02Bean.getOther()))	language02Bean.setOther("-");
			
			parameters.put("talent",coop02Bean.getTalent());
			parameters.put("level_eng",language02Bean.getLeve_eng());
			parameters.put("level_jap",language02Bean.getLeve_jap());
			parameters.put("level_chi",language02Bean.getLeve_chi());
			parameters.put("level_other",language02Bean.getLeve_other());
			parameters.put("language_other",language02Bean.getOther());
			// #5 6

			// 7  8
			parameters.put("region",coop02Bean.getRegion());
			if(selectJob02Bean.getJob().equals("���� �ô�к�")){
				parameters.put("job_name",selectJob02Bean.getOther());
			}else{
				parameters.put("job_name",selectJob02Bean.getJob());
			}
			// #7  8
			
			// 9 10
			parameters.put("interest",coop02Bean.getInterest());
			parameters.put("term",coop02Bean.getTerm());
			parameters.put("academic_year",coop02Bean.getAcademic_year());
			parameters.put("grade",profileBean.getGrade());
			parameters.put("gradeTotal",profileBean.getGradetotal());
			// #9 10

			// date
			parameters.put("date_day",date_day);
			parameters.put("date_month",date_month);
			parameters.put("date_year",date_year);


			/*
			 * Using compiled version(.jasper) of Jasper report to generate PDF
			 */
			JasperPrint jasperPrint = JasperFillManager.fillReport(request.getServletContext().getRealPath("/views/pages/student/report/Coop02_pdf.jasper")
										, parameters,new JREmptyDataSource());
			
			/* outputStream to create PDF */
			OutputStream outputStream = new FileOutputStream(new File(outputFile));
			ThaiExporterManager.exportReportToPdfStream(jasperPrint, outputStream);


			System.out.println(fileShow);
			//response.sendRedirect(fileShow);    //     Upload/File/Report/PDF/report.pdf

		} catch (JRException ex) {
			ex.printStackTrace();
		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		}
	}
	
	public void insertCoop02Docx(HttpServletRequest request,UserBean userBean,ProfileBean profileBean,AddressBean addressBean1,AddressBean addressBean2,AddressBean addressBean3
			 ,FamilyBean familyBean,Coop02Bean coop02Bean,SelectJob02Bean selectJob02Bean,Language02Bean language02Bean){

			try {
				/* User home directory location */
				String userHomeDirectory = request.getServletContext().getRealPath("/");
				
				String studentid = userBean.getStudentid();
				String userid =  Integer.toString(userBean.getId());
				
				/* Output file location */
				String filename = studentid+"_"+userid;
				String fileShow = "Upload/File/Report/DOCX/" + filename +"_coop02.docx";
				String outputFile = userHomeDirectory + File.separatorChar + "/" + fileShow;
				
				/* Create path  */
			    File file = new File(userHomeDirectory, "Upload/File/Report/PDF/");
			    if (!file.exists()) {
			     file.mkdirs();
			    }

				/* Map to hold Jasper report Parameters */
				Map<String, Object> parameters = new HashMap<String, Object>();
				
				// 1
				parameters.put("titleName_th", userBean.getTitlename_th());
				parameters.put("firstName_th",userBean.getFirstname_th());
				parameters.put("lastName_th",userBean.getLastname_th());
				parameters.put("studentID",userBean.getStudentid());
				parameters.put("titleName_eng",userBean.getTitlename_eng());
				parameters.put("firstName_eng",userBean.getFirstname_eng());
				parameters.put("lastName_eng",userBean.getLastname_eng());
				parameters.put("classYear",profileBean.getClassyear());
				parameters.put("groupStudent",profileBean.getGroupstudent());
				parameters.put("divisionName",userBean.getDivname());
				// #1
				
				// 2 3 4
				parameters.put("id_num1",addressBean1.getId_num());
				parameters.put("road1",addressBean1.getRoad());
				parameters.put("districtName1",addressBean1.getDistrictname());
				parameters.put("amphurName1",addressBean1.getAmphurname());
				parameters.put("provinceName1",addressBean1.getProvincename());
				parameters.put("postCode1",addressBean1.getPostcode());
				parameters.put("mobile1",addressBean1.getMobile());
				parameters.put("email1",addressBean1.getEmail());
				
				parameters.put("id_num2",addressBean2.getId_num());
				parameters.put("road2",addressBean2.getRoad());
				parameters.put("districtName2",addressBean2.getDistrictname());
				parameters.put("amphurName2",addressBean2.getAmphurname());
				parameters.put("provinceName2",addressBean2.getProvincename());
				parameters.put("postCode2",addressBean2.getPostcode());
				parameters.put("mobile2",addressBean2.getMobile());
				parameters.put("email2",addressBean2.getEmail());
				
				parameters.put("id_num3",addressBean3.getId_num());
				parameters.put("road3",addressBean3.getRoad());
				parameters.put("districtName3",addressBean3.getDistrictname());
				parameters.put("amphurName3",addressBean3.getAmphurname());
				parameters.put("provinceName3",addressBean3.getProvincename());
				parameters.put("postCode3",addressBean3.getPostcode());
				parameters.put("mobile3",addressBean3.getMobile());
				parameters.put("email3",addressBean3.getEmail());
				
				parameters.put("titleName_parent",familyBean.getTitlename());
				parameters.put("firstName_parent",familyBean.getFirstname());
				parameters.put("lastName_parent",familyBean.getLastname());
				parameters.put("relation_parent",familyBean.getRelation());
				// #2 3 4
				
				// 5  6
				if("".equals(language02Bean.getLeve_eng()))  language02Bean.setLeve_eng("-");
				if("".equals(language02Bean.getLeve_jap()))  language02Bean.setLeve_jap("-");
				if("".equals(language02Bean.getLeve_chi()))	language02Bean.setLeve_chi("-");
				if("".equals(language02Bean.getLeve_other()))	language02Bean.setLeve_other("-");
				if("".equals(language02Bean.getOther()))	language02Bean.setOther("-");
				
				parameters.put("talent",coop02Bean.getTalent());
				parameters.put("level_eng",language02Bean.getLeve_eng());
				parameters.put("level_jap",language02Bean.getLeve_jap());
				parameters.put("level_chi",language02Bean.getLeve_chi());
				parameters.put("level_other",language02Bean.getLeve_other());
				parameters.put("language_other",language02Bean.getOther());
				// #5 6

				// 7  8
				parameters.put("region",coop02Bean.getRegion());
				parameters.put("job_name",selectJob02Bean.getJob());
				parameters.put("job_other",selectJob02Bean.getOther());
				// #7  8
				
				// 9 10
				parameters.put("interest",coop02Bean.getInterest());
				parameters.put("term",coop02Bean.getTerm());
				parameters.put("academic_year",coop02Bean.getAcademic_year());
				parameters.put("grade",profileBean.getGrade());
				parameters.put("gradeTotal",profileBean.getGradetotal());
				// #9 10

				/*
				 * Using compiled version(.jasper) of Jasper report to generate DOCX
				 */
				JasperPrint jasperPrint = JasperFillManager.fillReport(request.getServletContext().getRealPath("/views/pages/student/report/Coop02.jasper")
											, parameters,new JREmptyDataSource());
				
				/* outputStream to create DOCX */
				OutputStream outputStream = new FileOutputStream(new File(outputFile));

				/* export word  */
				JRDocxExporter docxExporter = new JRDocxExporter();
				docxExporter.setExporterInput(new SimpleExporterInput(jasperPrint));
				docxExporter.setExporterOutput(new SimpleOutputStreamExporterOutput(outputStream));
				docxExporter.exportReport();
				/* #export word  */

				System.out.println(fileShow);

			} catch (JRException ex) {
				ex.printStackTrace();
			} catch (FileNotFoundException ex) {
				ex.printStackTrace();
			}
		
	}
	
}
