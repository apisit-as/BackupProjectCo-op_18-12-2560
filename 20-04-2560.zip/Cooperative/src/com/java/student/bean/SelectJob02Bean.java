package com.java.student.bean;

public class SelectJob02Bean {
	private int id;
	private String job;
	private String other;
	private int coop02id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public String getOther() {
		return other;
	}
	public void setOther(String other) {
		this.other = other;
	}
	public int getCoop02id() {
		return coop02id;
	}
	public void setCoop02id(int coop02id) {
		this.coop02id = coop02id;
	}
	
}
