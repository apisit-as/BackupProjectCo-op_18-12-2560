package com.java.student.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.java.util.FileUploadUtil;
import com.java.util.ImageResize;
import com.java.util.report.ReportCoop03;
import com.java.student.bean.ActivityBean;
import com.java.student.bean.AddressBean;
import com.java.student.bean.CareerBean;
import com.java.student.bean.Coop03Bean;
import com.java.student.bean.EducationBean;
import com.java.student.bean.FamilyBean;
import com.java.student.bean.Language03Bean;
import com.java.student.bean.ProfileBean;
import com.java.student.bean.RelativeBean;
import com.java.student.bean.TrainingBean;
import com.java.student.bean.UserBean;
import com.java.student.dao.TableActivityDao;
import com.java.student.dao.TableAddressDao;
import com.java.student.dao.TableCareerDao;
import com.java.student.dao.TableCoop03Dao;
import com.java.student.dao.TableEducationDao;
import com.java.student.dao.TableFamilyDao;
import com.java.student.dao.TableLanguage03Dao;
import com.java.student.dao.TableProfileDao;
import com.java.student.dao.TableRelativeDao;
import com.java.student.dao.TableTrainingDao;
import com.java.student.dao.TableUserDao;

/**
 * Servlet implementation class Coop03
 */
@WebServlet("/Coop03")
public class Coop03 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Coop03() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		
		HttpSession session = request.getSession();
		TableUserDao tableUserDao = new TableUserDao();
		UserBean userBean = new UserBean();

		if(session.getAttribute("role") != null){
			String role = session.getAttribute("role").toString();
			if(role.equals("student")){
				// student
				// get db   name ...
				String UserID = session.getAttribute("UserID").toString();
				userBean = tableUserDao.getTableUser(Integer.parseInt(UserID));
				request.setAttribute("userBean", userBean);
				session.setAttribute("divID", userBean.getDivid());
				session.setAttribute("divName", userBean.getDivname());
				
				// select  profile dao
				ProfileBean ListProfileBean = new ProfileBean();
				TableProfileDao tableProfileDao = new TableProfileDao();
				ListProfileBean = tableProfileDao.SelectProfile(Integer.parseInt(UserID));
				
				// checkUserid  tb_profile
				boolean checkUserid = tableProfileDao.CheckProfile(Integer.parseInt(UserID));
				request.setAttribute("checkUserid", checkUserid);
				
				// convert date
				if(checkUserid){
					String[] str1 = ListProfileBean.getIssue_date().split("-");    //2016-11-20
					String[] str2 = ListProfileBean.getExpiry_date().split("-");
					String[] str3 = ListProfileBean.getBirthday().split("-");
					ListProfileBean.setIssue_date(str1[2]+"/"+str1[1]+"/"+(Integer.parseInt(str1[0])+543));
					ListProfileBean.setExpiry_date(str2[2]+"/"+str2[1]+"/"+(Integer.parseInt(str2[0])+543));
					ListProfileBean.setBirthday(str3[2]+"/"+str3[1]+"/"+(Integer.parseInt(str3[0])+543));
				}
				
				request.setAttribute("ListProfileBean", ListProfileBean);
				
				// select address type
				TableProfileDao checkKeyProfile = new TableProfileDao();
				int keyProfile = checkKeyProfile.getKeyIDProfile(Integer.parseInt(UserID));
				
				TableAddressDao addressDao = new TableAddressDao();
				AddressBean original_address = new AddressBean();
				original_address = addressDao.SelectAddressType(keyProfile, "original_address");
				
				AddressBean semester_address = new AddressBean();
				semester_address = addressDao.SelectAddressType(keyProfile, "semester_address");
				
				AddressBean parent_address = new AddressBean();
				parent_address = addressDao.SelectAddressType(keyProfile, "parent_address");
				
				request.setAttribute("original_address", original_address);
				request.setAttribute("semester_address", semester_address);
				request.setAttribute("parent_address", parent_address);
	
				session.setAttribute("amphur_original_address_id", original_address.getAmphurid());
				session.setAttribute("amphur_original_address_name", original_address.getAmphurname());
				session.setAttribute("district_original_address_id", original_address.getDistrictid());
				session.setAttribute("district_original_address_name", original_address.getDistrictname());
				
				session.setAttribute("amphur_semester_address_id", semester_address.getAmphurid());
				session.setAttribute("amphur_semester_address_name", semester_address.getAmphurname());
				session.setAttribute("district_semester_address_id", semester_address.getDistrictid());
				session.setAttribute("district_semester_address_name", semester_address.getDistrictname());
	
				session.setAttribute("amphur_parent_address_id", parent_address.getAmphurid());
				session.setAttribute("amphur_parent_address_name", parent_address.getAmphurname());
				session.setAttribute("district_parent_address_id", parent_address.getDistrictid());
				session.setAttribute("district_parent_address_name", parent_address.getDistrictname());
				
				// family
				FamilyBean father_family = new FamilyBean();
				FamilyBean mother_family = new FamilyBean();
				FamilyBean parent_family = new FamilyBean();
				TableFamilyDao tableFamilyDao = new TableFamilyDao();
				father_family = tableFamilyDao.SelectFamilyType(keyProfile, "father_family");
				mother_family = tableFamilyDao.SelectFamilyType(keyProfile, "mother_family");
				parent_family = tableFamilyDao.SelectFamilyType(keyProfile, "parent_family");
				request.setAttribute("father_family", father_family);
				request.setAttribute("mother_family", mother_family);
				request.setAttribute("parent_family", parent_family);
				
				Coop03Bean coop03Bean = new Coop03Bean();
				RelativeBean relativeBean1 = new RelativeBean();
				RelativeBean relativeBean2 = new RelativeBean();
				RelativeBean relativeBean3 = new RelativeBean();
				EducationBean educationBean1 = new EducationBean();
				EducationBean educationBean2 = new EducationBean();
				EducationBean educationBean3 = new EducationBean();
				EducationBean educationBean4 = new EducationBean();
				EducationBean educationBean5 = new EducationBean();
				EducationBean educationBean6 = new EducationBean();
				TrainingBean trainingBean1 = new TrainingBean();
				TrainingBean trainingBean2 = new TrainingBean();
				TrainingBean trainingBean3 = new TrainingBean();
				CareerBean careerBean1 = new CareerBean();
				CareerBean careerBean2 = new CareerBean();
				CareerBean careerBean3 = new CareerBean();
				CareerBean careerBean4 = new CareerBean();
				ActivityBean activityBean1 = new ActivityBean();
				ActivityBean activityBean2 = new ActivityBean();
				ActivityBean activityBean3 = new ActivityBean();
				Language03Bean language03Bean = new Language03Bean();
				
				TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
				TableRelativeDao tableRelativeDao = new TableRelativeDao();
				TableEducationDao tableEducationDao = new TableEducationDao();
				TableTrainingDao tableTrainingDao = new TableTrainingDao();
				TableCareerDao tableCareerDao = new TableCareerDao();
				TableActivityDao tableActivityDao = new TableActivityDao();
				TableLanguage03Dao tableLanguage03Dao = new TableLanguage03Dao();
				
				coop03Bean = tableCoop03Dao.SelectCoop03(Integer.parseInt(UserID));
				int Coop03ID = tableCoop03Dao.getKeyIDCoop03(Integer.parseInt(UserID));
				relativeBean1 = tableRelativeDao.SelectRelative(Coop03ID,"relative_1");
				relativeBean2 = tableRelativeDao.SelectRelative(Coop03ID,"relative_2");
				relativeBean3 = tableRelativeDao.SelectRelative(Coop03ID,"relative_3");
				educationBean1 = tableEducationDao.SelectEducation(Coop03ID,"Primary");
				educationBean2 = tableEducationDao.SelectEducation(Coop03ID,"Secondary");
				educationBean3 = tableEducationDao.SelectEducation(Coop03ID,"HighSchool");
				educationBean4 = tableEducationDao.SelectEducation(Coop03ID,"Vocation_1");
				educationBean5 = tableEducationDao.SelectEducation(Coop03ID,"Vocation_2");
				educationBean6 = tableEducationDao.SelectEducation(Coop03ID,"Bachelor_degree");
				trainingBean1 = tableTrainingDao.SelectTraining(Coop03ID,"training_1");
				trainingBean2 = tableTrainingDao.SelectTraining(Coop03ID,"training_2");
				trainingBean3 = tableTrainingDao.SelectTraining(Coop03ID,"training_3");
				careerBean1 = tableCareerDao.SelectCareer(Coop03ID,"career_1");
				careerBean2 = tableCareerDao.SelectCareer(Coop03ID,"career_2");
				careerBean3 = tableCareerDao.SelectCareer(Coop03ID,"career_3");
				careerBean4 = tableCareerDao.SelectCareer(Coop03ID,"career_4");
				activityBean1 = tableActivityDao.SelectActivity(Coop03ID,"activity_1");
				activityBean2 = tableActivityDao.SelectActivity(Coop03ID,"activity_2");
				activityBean3 = tableActivityDao.SelectActivity(Coop03ID,"activity_3");
				language03Bean = tableLanguage03Dao.SelectLanguage03(Coop03ID);
				

				request.setAttribute("coop03Bean", coop03Bean);
				request.setAttribute("relativeBean1", relativeBean1);
				request.setAttribute("relativeBean2", relativeBean2);
				request.setAttribute("relativeBean3", relativeBean3);
				request.setAttribute("educationBean1", educationBean1);
				request.setAttribute("educationBean2", educationBean2);
				request.setAttribute("educationBean3", educationBean3);
				request.setAttribute("educationBean4", educationBean4);
				request.setAttribute("educationBean5", educationBean5);
				request.setAttribute("educationBean6", educationBean6);
				request.setAttribute("trainingBean1", trainingBean1);
				request.setAttribute("trainingBean2", trainingBean2);
				request.setAttribute("trainingBean3", trainingBean3);
				request.setAttribute("careerBean1", careerBean1);
				request.setAttribute("careerBean2", careerBean2);
				request.setAttribute("careerBean3", careerBean3);
				request.setAttribute("careerBean4", careerBean4);
				request.setAttribute("activityBean1", activityBean1);
				request.setAttribute("activityBean2", activityBean2);
				request.setAttribute("activityBean3", activityBean3);
				request.setAttribute("language03Bean", language03Bean);
	
				
				doViewCoop03(request, response);
			}else{
				System.out.println("ERROR PAGE");
				doViewErrorPage(request, response);
			}
		
		
		}else{
			doViewErrorPage(request, response);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		String UserID = session.getAttribute("UserID").toString();
		

		List<FileItem> items = null;
		String picture;

		Coop03Bean coop03Bean = new Coop03Bean();
		
		RelativeBean relativeBean1 = new RelativeBean();
		RelativeBean relativeBean2 = new RelativeBean();
		RelativeBean relativeBean3 = new RelativeBean();
		
		EducationBean educationBean1 = new EducationBean();
		EducationBean educationBean2 = new EducationBean();
		EducationBean educationBean3 = new EducationBean();
		EducationBean educationBean4 = new EducationBean();
		EducationBean educationBean5 = new EducationBean();
		EducationBean educationBean6 = new EducationBean();
		
		TrainingBean trainingBean1 = new TrainingBean();
		TrainingBean trainingBean2 = new TrainingBean();
		TrainingBean trainingBean3 = new TrainingBean();
		
		CareerBean careerBean1 = new CareerBean();
		CareerBean careerBean2 = new CareerBean();
		CareerBean careerBean3 = new CareerBean();
		CareerBean careerBean4 = new CareerBean();
		
		ActivityBean activityBean1 = new ActivityBean();
		ActivityBean activityBean2 = new ActivityBean();
		ActivityBean activityBean3 = new ActivityBean();
		
		Language03Bean language03Bean = new Language03Bean();

		try{
			items = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
			for (FileItem item : items) {    // loop item
//			      String fieldname = item.getFieldName();
//			      System.out.println(fieldname);
				
			     if (item.isFormField()) {
			    	 // input other!!
			      String fieldname = item.getFieldName();

			      if ("Num_relative".equals(fieldname)) 	    	coop03Bean.setNum_relative(item.getString("UTF-8"));
			      else if("My_relative".equals(fieldname))  		coop03Bean.setMy_relative(item.getString("UTF-8"));
			      
			      
			      ////
			      else if("relative_TitleID_Th1".equals(fieldname)) relativeBean1.setTitleid(Integer.parseInt(item.getString("UTF-8")));
			      else if("relative_FirstName1".equals(fieldname))  relativeBean1.setFirstname(item.getString("UTF-8"));
			      else if("relative_LastName1".equals(fieldname))   relativeBean1.setLastname(item.getString("UTF-8"));
			      else if("relative_Age1".equals(fieldname)) 	  	relativeBean1.setAge(item.getString("UTF-8"));
			      else if("relative_Occupation1".equals(fieldname)) relativeBean1.setOccupation(item.getString("UTF-8"));
			      else if("relative_Position1".equals(fieldname))   relativeBean1.setPosition(item.getString("UTF-8"));
			      
			      else if("relative_TitleID_Th2".equals(fieldname)) relativeBean2.setTitleid(Integer.parseInt(item.getString("UTF-8")));
			      else if("relative_FirstName2".equals(fieldname))  relativeBean2.setFirstname(item.getString("UTF-8"));
			      else if("relative_LastName2".equals(fieldname))   relativeBean2.setLastname(item.getString("UTF-8"));
			      else if("relative_Age2".equals(fieldname))   	    relativeBean2.setAge(item.getString("UTF-8"));
			      else if("relative_Occupation2".equals(fieldname)) relativeBean2.setOccupation(item.getString("UTF-8"));
			      else if("relative_Position2".equals(fieldname))   relativeBean2.setPosition(item.getString("UTF-8"));
			      
			      else if("relative_TitleID_Th3".equals(fieldname)) relativeBean3.setTitleid(Integer.parseInt(item.getString("UTF-8")));
			      else if("relative_FirstName3".equals(fieldname))  relativeBean3.setFirstname(item.getString("UTF-8"));
			      else if("relative_LastName3".equals(fieldname))   relativeBean3.setLastname(item.getString("UTF-8"));
			      else if("relative_Age3".equals(fieldname))    	relativeBean3.setAge(item.getString("UTF-8"));
			      else if("relative_Occupation3".equals(fieldname)) relativeBean3.setOccupation(item.getString("UTF-8"));
			      else if("relative_Position3".equals(fieldname))   relativeBean3.setPosition(item.getString("UTF-8"));
			      /////
			      
			      
			      
			      else if("educatiion_Name1".equals(fieldname))    educationBean1.setName(item.getString("UTF-8"));
			      else if("educatiion_year_attended1".equals(fieldname))   educationBean1.setYear_attended(item.getString("UTF-8"));
			      else if("educatiion_year_graduated1".equals(fieldname))  educationBean1.setYear_graduated(item.getString("UTF-8"));
			      else if("educatiion_certificate1".equals(fieldname)) 	   educationBean1.setCertificate(item.getString("UTF-8"));
			      else if("educatiion_major1".equals(fieldname))  		   educationBean1.setMajor(item.getString("UTF-8"));
			      
			      else if("educatiion_Name2".equals(fieldname))   educationBean2.setName(item.getString("UTF-8"));
			      else if("educatiion_year_attended2".equals(fieldname))  educationBean2.setYear_attended(item.getString("UTF-8"));
			      else if("educatiion_year_graduated2".equals(fieldname)) educationBean2.setYear_graduated(item.getString("UTF-8"));
			      else if("educatiion_certificate2".equals(fieldname))  educationBean2.setCertificate(item.getString("UTF-8"));
			      else if("educatiion_major2".equals(fieldname))      educationBean2.setMajor(item.getString("UTF-8"));
			      
			      else if("educatiion_Name3".equals(fieldname))   educationBean3.setName(item.getString("UTF-8"));
			      else if("educatiion_year_attended3".equals(fieldname))  educationBean3.setYear_attended(item.getString("UTF-8"));
			      else if("educatiion_year_graduated3".equals(fieldname)) educationBean3.setYear_graduated(item.getString("UTF-8"));
			      else if("educatiion_certificate3".equals(fieldname))    educationBean3.setCertificate(item.getString("UTF-8"));
			      else if("educatiion_major3".equals(fieldname))      educationBean3.setMajor(item.getString("UTF-8"));
			      
			      else if("educatiion_Name4".equals(fieldname))  educationBean4.setName(item.getString("UTF-8"));
			      else if("educatiion_year_attended4".equals(fieldname))   educationBean4.setYear_attended(item.getString("UTF-8"));
			      else if("educatiion_year_graduated4".equals(fieldname))  educationBean4.setYear_graduated(item.getString("UTF-8")); 
			      else if("educatiion_certificate4".equals(fieldname))     educationBean4.setCertificate(item.getString("UTF-8"));
			      else if("educatiion_major4".equals(fieldname))      educationBean4.setMajor(item.getString("UTF-8"));
			      
			      else if("educatiion_Name5".equals(fieldname))   educationBean5.setName(item.getString("UTF-8"));
			      else if("educatiion_year_attended5".equals(fieldname))  educationBean5.setYear_attended(item.getString("UTF-8"));
			      else if("educatiion_year_graduated5".equals(fieldname)) educationBean5.setYear_graduated(item.getString("UTF-8"));  
			      else if("educatiion_certificate5".equals(fieldname))    educationBean5.setCertificate(item.getString("UTF-8"));
			      else if("educatiion_major5".equals(fieldname))      educationBean5.setMajor(item.getString("UTF-8"));
			      
			      else if("educatiion_Name6".equals(fieldname))  educationBean6.setName(item.getString("UTF-8"));
			      else if("educatiion_year_attended6".equals(fieldname))   educationBean6.setYear_attended(item.getString("UTF-8"));
			      else if("educatiion_year_graduated6".equals(fieldname))  educationBean6.setYear_graduated(item.getString("UTF-8")); 
			      else if("educatiion_certificate6".equals(fieldname))    educationBean6.setCertificate(item.getString("UTF-8"));
			      else if("educatiion_major6".equals(fieldname))    educationBean6.setMajor(item.getString("UTF-8"));
			      
			      
			      else if("training_StartDate1".equals(fieldname))   trainingBean1.setStart_date(item.getString("UTF-8"));
			      else if("training_StopDate1".equals(fieldname))    trainingBean1.setStop_date(item.getString("UTF-8"));
			      else if("training_Place1".equals(fieldname))   	 trainingBean1.setPlace(item.getString("UTF-8"));
			      else if("training_Position1".equals(fieldname))    trainingBean1.setPosition(item.getString("UTF-8"));
			      
			      else if("training_StartDate2".equals(fieldname))   trainingBean2.setStart_date(item.getString("UTF-8"));
			      else if("training_StopDate2".equals(fieldname))    trainingBean2.setStop_date(item.getString("UTF-8"));
			      else if("training_Place2".equals(fieldname))       trainingBean2.setPlace(item.getString("UTF-8"));
			      else if("training_Position2".equals(fieldname))    trainingBean2.setPosition(item.getString("UTF-8"));
			      
			      else if("training_StartDate3".equals(fieldname))   trainingBean3.setStart_date(item.getString("UTF-8"));
			      else if("training_StopDate3".equals(fieldname))    trainingBean3.setStop_date(item.getString("UTF-8"));
			      else if("training_Place3".equals(fieldname))       trainingBean3.setPlace(item.getString("UTF-8"));
			      else if("training_Position3".equals(fieldname))    trainingBean3.setPosition(item.getString("UTF-8"));
			      
			      
			      
			      else if("career_name1".equals(fieldname))   careerBean1.setName(item.getString("UTF-8"));
			      else if("career_name2".equals(fieldname))   careerBean2.setName(item.getString("UTF-8"));
			      else if("career_name3".equals(fieldname))   careerBean3.setName(item.getString("UTF-8"));
			      else if("career_name4".equals(fieldname))   careerBean4.setName(item.getString("UTF-8"));
			      
			      
			      else if("activity_DateTime1".equals(fieldname))   activityBean1.setDate_time(item.getString("UTF-8"));
			      else if("activity_Position1".equals(fieldname))   activityBean1.setPosition(item.getString("UTF-8"));
			      else if("activity_DateTime2".equals(fieldname))   activityBean2.setDate_time(item.getString("UTF-8"));
			      else if("activity_Position2".equals(fieldname))   activityBean2.setPosition(item.getString("UTF-8"));
			      else if("activity_DateTime3".equals(fieldname))   activityBean3.setDate_time(item.getString("UTF-8"));
			      else if("activity_Position3".equals(fieldname))   activityBean3.setPosition(item.getString("UTF-8"));
			      
			      else if("LanguageID_en".equals(fieldname))     language03Bean.setLanguage_eng(item.getString("UTF-8"));
			      else if("LevelID_Listen_en".equals(fieldname)) language03Bean.setLevel_eng_listen(item.getString("UTF-8"));  
			      else if("LevelID_Speak_en".equals(fieldname))  language03Bean.setLevel_eng_speak(item.getString("UTF-8")); 
			      else if("LevelID_Write_en".equals(fieldname))  language03Bean.setLevel_eng_write(item.getString("UTF-8"));
			      
			      else if("LanguageID_chi".equals(fieldname))    language03Bean.setLanguage_chi(item.getString("UTF-8"));
			      else if("LevelID_Listen_chi".equals(fieldname))  language03Bean.setLevel_chi_listen(item.getString("UTF-8"));
			      else if("LevelID_Speak_chi".equals(fieldname))   language03Bean.setLevel_chi_speak(item.getString("UTF-8")); 
			      else if("LevelID_Write_chi".equals(fieldname))   language03Bean.setLevel_chi_write(item.getString("UTF-8"));
			      else if("LanguageID_other03".equals(fieldname))    language03Bean.setLanguage_other(item.getString("UTF-8"));
			      else if("other".equals(fieldname))               language03Bean.setInput_other(item.getString("UTF-8"));
			      else if("LevelID_Listen_other".equals(fieldname))  language03Bean.setLevel_other_listen(item.getString("UTF-8")); 
			      else if("LevelID_Speak_other".equals(fieldname))   language03Bean.setLevel_other_speak(item.getString("UTF-8")); 
			      else if("LevelID_Write_other".equals(fieldname))  language03Bean.setLevel_other_write(item.getString("UTF-8")); 
			      
			      
			     }else if(!item.isFormField()){  
			    	// file other!!
			    	//String fieldname = item.getFieldName();
			    	 
			    	//String type = item.getName();
			    	//System.out.println(type);  // spongebob_7_150x150_png_by_somemilk.png
			    	
			    	// System.out.println(fieldname);   //  uploadBtn
			         if (!(item.getName().equals(""))) {
			        	 TableUserDao tableUserDao = new TableUserDao();
			        	 UserBean userBean = new UserBean();
			        	 userBean = tableUserDao.getTableUser(Integer.parseInt(UserID));
			        	 
			        	 // delete picture
//			        	 TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
//			        	 String pathPic = tableCoop03Dao.SelectPictureCoop03(userBean.getId());
//			        	 FileUploadUtil.deleteFile(request, pathPic);
			        	 
			        	 String studentID = userBean.getStudentid();
			             picture = FileUploadUtil.uploadFile(request, item,"StudentPic",studentID, UserID,"png");
			             System.out.println(picture);
			             coop03Bean.setPicture(picture);
			         }else{
			        	 TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
			        	 picture = tableCoop03Dao.SelectPictureCoop03(Integer.parseInt(UserID));
			        	 coop03Bean.setPicture(picture);
			         }
			     }
			}
			
		}catch(FileUploadException e){
			e.printStackTrace();
		}

		TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
		TableRelativeDao tableRelativeDao = new TableRelativeDao();
		TableEducationDao tableEducationDao = new TableEducationDao();
		TableTrainingDao tableTrainingDao = new TableTrainingDao();
		TableCareerDao tableCareerDao = new TableCareerDao();
		TableActivityDao tableActivityDao = new TableActivityDao();
		TableLanguage03Dao tableLanguage03Dao = new TableLanguage03Dao();
		
		
		coop03Bean.setUserid(Integer.parseInt(UserID));
		
		if(tableCoop03Dao.CheckCoop03(Integer.parseInt(UserID))){
			//update
			int coop03id = tableCoop03Dao.getKeyIDCoop03(Integer.parseInt(UserID));
			tableCoop03Dao.UpdateCoop03(coop03Bean);
			
			// relative Type 1 - 3
			relativeBean1.setCoop03id(coop03id);
			relativeBean1.setType("relative_1");
			tableRelativeDao.UpdateRelative(relativeBean1);
			relativeBean2.setCoop03id(coop03id);
			relativeBean2.setType("relative_2");
			tableRelativeDao.UpdateRelative(relativeBean2);
			relativeBean3.setCoop03id(coop03id);
			relativeBean3.setType("relative_3");
			tableRelativeDao.UpdateRelative(relativeBean3);
			// # relative Type 1 - 3
			
			// education Type 1 - 6
			educationBean1.setCoop03id(coop03id);
			educationBean1.setType("Primary");
			tableEducationDao.UpdateEducation(educationBean1);
			educationBean2.setCoop03id(coop03id);
			educationBean2.setType("Secondary");
			tableEducationDao.UpdateEducation(educationBean2);
			educationBean3.setCoop03id(coop03id);
			educationBean3.setType("HighSchool");
			tableEducationDao.UpdateEducation(educationBean3);
			educationBean4.setCoop03id(coop03id);
			educationBean4.setType("Vocation_1");
			tableEducationDao.UpdateEducation(educationBean4);
			educationBean5.setCoop03id(coop03id);
			educationBean5.setType("Vocation_2");
			tableEducationDao.UpdateEducation(educationBean5);
			educationBean6.setCoop03id(coop03id);
			educationBean6.setType("Bachelor_degree");
			tableEducationDao.UpdateEducation(educationBean6);
			//# education Type 1 - 6
			
			// Training Type 1 - 3  
			trainingBean1.setCoop03id(coop03id);
			trainingBean1.setType("training_1");
			tableTrainingDao.UpdateTraining(trainingBean1);
			trainingBean2.setCoop03id(coop03id);
			trainingBean2.setType("training_2");
			tableTrainingDao.UpdateTraining(trainingBean2);
			trainingBean3.setCoop03id(coop03id);
			trainingBean3.setType("training_3");
			tableTrainingDao.UpdateTraining(trainingBean3);
			//# Training Type 1 - 3
			
			// career Type 1 - 4  
			careerBean1.setCoop03id(coop03id);
			careerBean1.setType("career_1");
			tableCareerDao.UpdateCareer(careerBean1);
			careerBean2.setCoop03id(coop03id);
			careerBean2.setType("career_2");
			tableCareerDao.UpdateCareer(careerBean2);
			careerBean3.setCoop03id(coop03id);
			careerBean3.setType("career_3");
			tableCareerDao.UpdateCareer(careerBean3);
			careerBean4.setCoop03id(coop03id);
			careerBean4.setType("career_4");
			tableCareerDao.UpdateCareer(careerBean4);
			//# career Type 1 - 4
			
			// activity Type 1 - 3
			activityBean1.setCoop03id(coop03id);
			activityBean1.setType("activity_1");
			tableActivityDao.UpdateActivity(activityBean1);
			activityBean2.setCoop03id(coop03id);
			activityBean2.setType("activity_2");
			tableActivityDao.UpdateActivity(activityBean2);
			activityBean3.setCoop03id(coop03id);
			activityBean3.setType("activity_3");
			tableActivityDao.UpdateActivity(activityBean3);
			//# activity Type 1 - 3
			
			// language 
			language03Bean.setCoop03id(coop03id);
			tableLanguage03Dao.UpdateLanguage03(language03Bean);
			//# language
			
			
			System.out.println("OK Update");
		}else{
			// insert
			tableCoop03Dao.InsertCoop03(coop03Bean);
			int coop03id = tableCoop03Dao.getKeyIDCoop03(Integer.parseInt(UserID));
			
			// relative Type 1 - 3
			relativeBean1.setCoop03id(coop03id);
			relativeBean1.setType("relative_1");
			tableRelativeDao.InsertRelative(relativeBean1);
			relativeBean2.setCoop03id(coop03id);
			relativeBean2.setType("relative_2");
			tableRelativeDao.InsertRelative(relativeBean2);
			relativeBean3.setCoop03id(coop03id);
			relativeBean3.setType("relative_3");
			tableRelativeDao.InsertRelative(relativeBean3);
			// # relative Type 1 - 3
			
			// education Type 1 - 6
			educationBean1.setCoop03id(coop03id);
			educationBean1.setType("Primary");
			tableEducationDao.InsertEducation(educationBean1);
			educationBean2.setCoop03id(coop03id);
			educationBean2.setType("Secondary");
			tableEducationDao.InsertEducation(educationBean2);
			educationBean3.setCoop03id(coop03id);
			educationBean3.setType("HighSchool");
			tableEducationDao.InsertEducation(educationBean3);
			educationBean4.setCoop03id(coop03id);
			educationBean4.setType("Vocation_1");
			tableEducationDao.InsertEducation(educationBean4);
			educationBean5.setCoop03id(coop03id);
			educationBean5.setType("Vocation_2");
			tableEducationDao.InsertEducation(educationBean5);
			educationBean6.setCoop03id(coop03id);
			educationBean6.setType("Bachelor_degree");
			tableEducationDao.InsertEducation(educationBean6);
			//# education Type 1 - 6
			
			// Training Type 1 - 3  
			trainingBean1.setCoop03id(coop03id);
			trainingBean1.setType("training_1");
			tableTrainingDao.InsertTraining(trainingBean1);
			trainingBean2.setCoop03id(coop03id);
			trainingBean2.setType("training_2");
			tableTrainingDao.InsertTraining(trainingBean2);
			trainingBean3.setCoop03id(coop03id);
			trainingBean3.setType("training_3");
			tableTrainingDao.InsertTraining(trainingBean3);
			//# Training Type 1 - 3
			
			// career Type 1 - 4  
			careerBean1.setCoop03id(coop03id);
			careerBean1.setType("career_1");
			tableCareerDao.InsertCareer(careerBean1);
			careerBean2.setCoop03id(coop03id);
			careerBean2.setType("career_2");
			tableCareerDao.InsertCareer(careerBean2);
			careerBean3.setCoop03id(coop03id);
			careerBean3.setType("career_3");
			tableCareerDao.InsertCareer(careerBean3);
			careerBean4.setCoop03id(coop03id);
			careerBean4.setType("career_4");
			tableCareerDao.InsertCareer(careerBean4);
			//# career Type 1 - 4
			
			// activity Type 1 - 3
			activityBean1.setCoop03id(coop03id);
			activityBean1.setType("activity_1");
			tableActivityDao.InsertActivity(activityBean1);
			activityBean2.setCoop03id(coop03id);
			activityBean2.setType("activity_2");
			tableActivityDao.InsertActivity(activityBean2);
			activityBean3.setCoop03id(coop03id);
			activityBean3.setType("activity_3");
			tableActivityDao.InsertActivity(activityBean3);
			//# activity Type 1 - 3
			
			// language 
			language03Bean.setCoop03id(coop03id);
			tableLanguage03Dao.InsertLanguage03(language03Bean);
			//# language
			
			System.out.println("OK Insert");

		}
		

		out.print(coop03Bean.getPicture());
		
		int userid = Integer.parseInt(UserID);
		
		ImageResize imageResize = new ImageResize();
		imageResize.Resize(request, userid);
		
		/* report */
		reportCoop03(request, userid);
		/* report */
		


	}
	private void doViewCoop03(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/student/coop03.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void doViewErrorPage(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/error-page.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	
	private void reportCoop03(HttpServletRequest request,int userid) {
		// tb_user, tb_profile, tb_adddress, tb_family, coop03 all
		TableUserDao tableUserDao = new TableUserDao();
		UserBean userBean = new UserBean();
		userBean = tableUserDao.getTableUser(userid);
		
		TableProfileDao tableProfileDao = new TableProfileDao();
		ProfileBean profileBean = new ProfileBean();
		profileBean = tableProfileDao.SelectProfile(userid);
		
		// convert date
		String[] str1 = profileBean.getIssue_date().split("-");    //2016-11-20
		String[] str2 = profileBean.getExpiry_date().split("-");
		String[] str3 = profileBean.getBirthday().split("-");
		profileBean.setIssue_date(str1[2]+"/"+str1[1]+"/"+(Integer.parseInt(str1[0])+543));
		profileBean.setExpiry_date(str2[2]+"/"+str2[1]+"/"+(Integer.parseInt(str2[0])+543));
		profileBean.setBirthday(str3[2]+"/"+str3[1]+"/"+(Integer.parseInt(str3[0])+543));
		
		// address
		TableAddressDao tableAddressDao = new TableAddressDao();
		List<AddressBean> addressBeanList = new ArrayList<AddressBean>();
		
		AddressBean addressBean1 = new AddressBean();
		AddressBean addressBean2 = new AddressBean();
		AddressBean addressBean3 = new AddressBean();
		addressBean1 = tableAddressDao.SelectAddressType(profileBean.getId(), "original_address");
		addressBean1.setAmphurname(subString(addressBean1.getAmphurname()));
		addressBean1.setDistrictname(subString(addressBean1.getDistrictname()));
		
		addressBean2 = tableAddressDao.SelectAddressType(profileBean.getId(), "semester_address");
		addressBean2.setAmphurname(subString(addressBean2.getAmphurname()));
		addressBean2.setDistrictname(subString(addressBean2.getDistrictname()));
		
		addressBean3 = tableAddressDao.SelectAddressType(profileBean.getId(), "parent_address");
		addressBean3.setAmphurname(subString(addressBean3.getAmphurname()));
		addressBean3.setDistrictname(subString(addressBean3.getDistrictname()));
		
		addressBeanList.add(addressBean1);
		addressBeanList.add(addressBean2);
		addressBeanList.add(addressBean3);
		
		// family
		TableFamilyDao tableFamilyDao = new TableFamilyDao();
		List<FamilyBean> familyBeanList = new ArrayList<FamilyBean>();
		familyBeanList.add(tableFamilyDao.SelectFamilyType(profileBean.getId(), "father_family"));
		familyBeanList.add(tableFamilyDao.SelectFamilyType(profileBean.getId(), "mother_family"));
		familyBeanList.add(tableFamilyDao.SelectFamilyType(profileBean.getId(), "parent_family"));
		
		TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
		Coop03Bean coop03Bean = new Coop03Bean();
		int Coop03ID = tableCoop03Dao.getKeyIDCoop03(userid);
		coop03Bean = tableCoop03Dao.SelectCoop03(userid);
		
		TableEducationDao tableEducationDao = new TableEducationDao();
		List<EducationBean> educationBeansList = new ArrayList<EducationBean>();
		educationBeansList.add(tableEducationDao.SelectEducation(Coop03ID, "Primary"));
		educationBeansList.add(tableEducationDao.SelectEducation(Coop03ID, "Secondary"));
		educationBeansList.add(tableEducationDao.SelectEducation(Coop03ID, "HighSchool"));
		educationBeansList.add(tableEducationDao.SelectEducation(Coop03ID, "Vocation_1"));
		educationBeansList.add(tableEducationDao.SelectEducation(Coop03ID, "Vocation_2"));
		educationBeansList.add(tableEducationDao.SelectEducation(Coop03ID, "Bachelor_degree"));
		
		TableRelativeDao tableRelativeDao = new TableRelativeDao();
		List<RelativeBean> relativeBeansList = new ArrayList<RelativeBean>();
		relativeBeansList.add(tableRelativeDao.SelectRelative(Coop03ID, "relative_1"));
		relativeBeansList.add(tableRelativeDao.SelectRelative(Coop03ID, "relative_2"));
		relativeBeansList.add(tableRelativeDao.SelectRelative(Coop03ID, "relative_3"));
		
		TableTrainingDao tableTrainingDao = new TableTrainingDao();
		List<TrainingBean> trainingBeansList = new ArrayList<TrainingBean>();
		trainingBeansList.add(tableTrainingDao.SelectTraining(Coop03ID, "training_1"));
		trainingBeansList.add(tableTrainingDao.SelectTraining(Coop03ID, "training_2"));
		trainingBeansList.add(tableTrainingDao.SelectTraining(Coop03ID, "training_3"));
		
		TableCareerDao tableCareerDao = new TableCareerDao();
		List<CareerBean> careerBeansList = new ArrayList<CareerBean>();
		careerBeansList.add(tableCareerDao.SelectCareer(Coop03ID, "career_1"));
		careerBeansList.add(tableCareerDao.SelectCareer(Coop03ID, "career_2"));
		careerBeansList.add(tableCareerDao.SelectCareer(Coop03ID, "career_3"));
		careerBeansList.add(tableCareerDao.SelectCareer(Coop03ID, "career_4"));
		
		TableActivityDao tableActivityDao = new TableActivityDao();
		List<ActivityBean> activityBeansList = new ArrayList<ActivityBean>();
		activityBeansList.add(tableActivityDao.SelectActivity(Coop03ID, "activity_1"));
		activityBeansList.add(tableActivityDao.SelectActivity(Coop03ID, "activity_2"));
		activityBeansList.add(tableActivityDao.SelectActivity(Coop03ID, "activity_3"));
		
		TableLanguage03Dao tableLanguage03Dao = new TableLanguage03Dao();
		Language03Bean language03Bean = new Language03Bean();
		language03Bean = tableLanguage03Dao.SelectLanguage03(Coop03ID);
		
		// save report  pdf,docx 
		ReportCoop03 reportCoop03 = new ReportCoop03();
		reportCoop03.insertCoop03Pdf(request,userBean,profileBean,addressBeanList,familyBeanList,coop03Bean,educationBeansList,relativeBeansList,trainingBeansList,careerBeansList,activityBeansList,language03Bean);
		//reportCoop03.insertCoop03Docx(request,userBean,profileBean,addressBeanList,familyBeanList,coop03Bean,educationBeansList,relativeBeansList,trainingBeansList,careerBeansList,activityBeansList,language03Bean);
	}
	
	private String subString(String textData){
		String text = textData.trim();
		int count = 0;
		String data = "";
		String sub = ""+text.charAt(0);
	      if("*".equals(sub)){
	    	  //System.out.println(text.substring(1));
	    	  data = ""+text.substring(1);
	    	  count++;
	      }
	      
	      sub = ""+text.charAt(text.length()-1);
	      if("*".equals(sub)){
	    	  //System.out.println(text.substring(0,text.length()-1));
	    	  data = ""+text.substring(0,text.length()-1);
	    	  count++;
	      }
	      
	      if(count == 0){
	    	  data = ""+text;
	    	 // System.out.println(data);
	      }
		return data;
	}
}
