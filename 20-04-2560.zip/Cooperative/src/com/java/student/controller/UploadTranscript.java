package com.java.student.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.java.student.bean.TranscriptBean;
import com.java.student.bean.UserBean;
import com.java.student.dao.TableCompleteStatusDocument;
import com.java.student.dao.TableTranscriptDao;
import com.java.student.dao.TableUserDao;
import com.java.util.FileUploadUtil;

/**
 * Servlet implementation class CheckStatus
 */
@WebServlet("/UploadTranscript")
public class UploadTranscript extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadTranscript() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();

		List<FileItem> items = null;
		String file;
		TranscriptBean transcriptBean = new TranscriptBean();
		int UserID = Integer.parseInt(session.getAttribute("UserID").toString());
		try{
			items = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
			for (FileItem item : items) {    // loop item
//			      String fieldname = item.getFieldName();
//			      System.out.println(fieldname);
			     if(!item.isFormField()){  

			         if (!(item.getName().equals(""))) {
			        	 TableUserDao tableUserDao = new TableUserDao();
			        	 UserBean userBeanStudentID = new UserBean();
			        	 userBeanStudentID = tableUserDao.getTableUser(UserID);
			        	 String studentID = userBeanStudentID.getStudentid();
			        	 file = FileUploadUtil.uploadFile(request, item,"Transcript",studentID, UserID+"_Transcript","pdf");
			             System.out.println(file);
			             transcriptBean.setFile(file);
			         }else{
			        	 TableTranscriptDao tableTranscriptDao = new TableTranscriptDao();
			        	 file = tableTranscriptDao.SelectTranscript(UserID);
			        	 transcriptBean.setFile(file);
			         }
			     }
			}
			
			TableTranscriptDao tableTranscriptDao = new TableTranscriptDao();
			transcriptBean.setUserid(UserID);
			
			if(tableTranscriptDao.CheckTranscript(UserID)){
				//update
				tableTranscriptDao.UpdateTranscript(transcriptBean);
				System.out.println("OK Update");
			}else{
				// insert
				tableTranscriptDao.InsertTranscript(transcriptBean);
				System.out.println("OK Insert");
			}

			
		}catch(FileUploadException e){
			e.printStackTrace();
		}
		
		// insert,update status document
		TableCompleteStatusDocument tableCompleteStatusDocument = new TableCompleteStatusDocument();
		if(tableCompleteStatusDocument.checkCompleteStatusDocument(UserID)){
			//update
			tableCompleteStatusDocument.UpdateCompleteStatusDoc("DataTranscript", 1, UserID);
		}else{
			//insert
			tableCompleteStatusDocument.InsertCompleteStatusDoc("DataTranscript", 1, UserID);
		}
	}

}
