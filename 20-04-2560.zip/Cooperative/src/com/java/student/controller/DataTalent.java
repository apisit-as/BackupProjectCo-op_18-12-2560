package com.java.student.controller;

import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.java.student.bean.Coop02Bean;
import com.java.student.bean.Language02Bean;
import com.java.student.bean.Language03Bean;
import com.java.student.bean.UserBean;
import com.java.student.dao.TableCompleteStatusDocument;
import com.java.student.dao.TableCoop02Dao;
import com.java.student.dao.TableCoop03Dao;
import com.java.student.dao.TableLanguage02Dao;
import com.java.student.dao.TableLanguage03Dao;
import com.java.student.dao.TableUserDao;

/**
 * Servlet implementation class CheckStatus
 */
@WebServlet("/DataTalent")
public class DataTalent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DataTalent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		
		HttpSession session = request.getSession();
		TableUserDao tableUserDao = new TableUserDao();
		UserBean userBean = new UserBean();

		String role = session.getAttribute("role").toString();
		if(role.equals("student")){
			// student
			// get db   name ...
			int UserID = Integer.parseInt(session.getAttribute("UserID").toString());
			userBean = tableUserDao.getTableUser(UserID);
			request.setAttribute("userBean", userBean);
			session.setAttribute("divID", userBean.getDivid());
			session.setAttribute("divName", userBean.getDivname());
			
			// coop02 detail
			Coop02Bean coop02Bean = new Coop02Bean();
			TableCoop02Dao tableCoop02Dao = new TableCoop02Dao();
			coop02Bean = tableCoop02Dao.SelectCoop02(UserID);
			request.setAttribute("coop02Bean", coop02Bean);
			
			// coop02  language detail
			Language02Bean language02Bean = new Language02Bean();
			TableLanguage02Dao tableLanguage02Dao = new TableLanguage02Dao();
			int Coop02ID = tableCoop02Dao.getKeyIDCoop02(UserID);
			language02Bean = tableLanguage02Dao.SelectLanguage02(Coop02ID);
			request.setAttribute("language02Bean", language02Bean);
			
			// coop03 
			Language03Bean language03Bean = new Language03Bean();
			TableLanguage03Dao tableLanguage03Dao = new TableLanguage03Dao();
			TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
			int Coop03ID = tableCoop03Dao.getKeyIDCoop03(UserID);
			language03Bean = tableLanguage03Dao.SelectLanguage03(Coop03ID);
			request.setAttribute("language03Bean", language03Bean);
			
			doViewDataTalent(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		insertTalent(request, response);
	}
	private void doViewDataTalent(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/student/data_default/data_talent.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void insertTalent(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
		TableCoop02Dao tableCoop02Dao = new TableCoop02Dao();
		TableLanguage02Dao tableLanguage02Dao = new TableLanguage02Dao();
		TableLanguage03Dao tableLanguage03Dao = new TableLanguage03Dao();
		Coop02Bean coop02Bean = new Coop02Bean();
		Language02Bean language02Bean = new Language02Bean();
		Language03Bean language03Bean = new Language03Bean();
		
		int UserID = Integer.parseInt(session.getAttribute("UserID").toString());

		/** check table coop02 talent 5  ,interest 9 **/
		String Talent = request.getParameter("Talent");
		String Interest = request.getParameter("Interest");
		coop02Bean.setTalent(Talent);
		coop02Bean.setInterest(Interest);
		coop02Bean.setUserid(UserID);
		
		int coop02ID;
		if(tableCoop02Dao.CheckCoop02(UserID)){
			// update coop02
			tableCoop02Dao.UpdateCoop02TalentAndInterest(coop02Bean);
			// get key coop02
			coop02ID = tableCoop02Dao.getKeyIDCoop02(UserID);
		}else{
			// insert to coop02
			tableCoop02Dao.InsertCoop02TalentAndInterest(coop02Bean);
			// get key coop02
			coop02ID = tableCoop02Dao.getKeyIDCoop02(UserID);
		}
		
		/** check tb_Language02 6 **/
		language02Bean.setLanguage_eng(request.getParameter("LanguageID_eng02"));
		language02Bean.setLeve_eng(request.getParameter("level_eng02"));
		language02Bean.setLanguage_jap(request.getParameter("LanguageID_jp02"));
		language02Bean.setLeve_jap(request.getParameter("level_jp02"));
		language02Bean.setLanguage_chi(request.getParameter("LanguageID_ca02"));
		language02Bean.setLeve_chi(request.getParameter("level_ca02"));
		language02Bean.setLanguage_other(request.getParameter("LanguageID_other02"));
		language02Bean.setOther(request.getParameter("input_other02"));
		language02Bean.setLeve_other(request.getParameter("level_other02"));
		language02Bean.setCoop02id(coop02ID);
		
		if(tableLanguage02Dao.CheckLanguage02(coop02ID)){
			// update tb_Language02
			tableLanguage02Dao.UpdateLanguage02(language02Bean);
		}else{
			// insert tb_Language02			
			tableLanguage02Dao.InsertLanguage02(language02Bean);
		}
		
		/** check tb_Language03 11 **/
		language03Bean.setLanguage_eng(request.getParameter("LanguageID_en03"));
		language03Bean.setLevel_eng_listen(request.getParameter("LevelID_Listen_en"));
		language03Bean.setLevel_eng_speak(request.getParameter("LevelID_Speak_en"));
		language03Bean.setLevel_eng_write(request.getParameter("LevelID_Write_en"));
		
		language03Bean.setLanguage_chi(request.getParameter("LanguageID_chi03"));
		language03Bean.setLevel_chi_listen(request.getParameter("LevelID_Listen_chi"));
		language03Bean.setLevel_chi_speak(request.getParameter("LevelID_Speak_chi"));
		language03Bean.setLevel_chi_write(request.getParameter("LevelID_Write_chi"));
		
		language03Bean.setLanguage_other(request.getParameter("LanguageID_other03"));
		language03Bean.setInput_other(request.getParameter("other"));
		language03Bean.setLevel_other_listen(request.getParameter("LevelID_Listen_other"));
		language03Bean.setLevel_other_speak(request.getParameter("LevelID_Speak_other"));
		language03Bean.setLevel_other_write(request.getParameter("LevelID_Write_other"));
		
		if(!tableCoop03Dao.CheckCoop03(UserID)) 	tableCoop03Dao.InsertCoop03SetUserid(UserID);
		
		int coop03id = tableCoop03Dao.getKeyIDCoop03(UserID);
		language03Bean.setCoop03id(coop03id);
		
		if(tableLanguage03Dao.CheckLanguage03(coop03id)){
			// update language
			tableLanguage03Dao.UpdateLanguage03(language03Bean);
		}else{
			// insert language
			tableLanguage03Dao.InsertLanguage03(language03Bean);
		}
		
		/** insert,update status document **/
		TableCompleteStatusDocument tableCompleteStatusDocument = new TableCompleteStatusDocument();
		if(tableCompleteStatusDocument.checkCompleteStatusDocument(UserID)){
			//update
			tableCompleteStatusDocument.UpdateCompleteStatusDoc("DataTalent", 1, UserID);
		}else{
			//insert
			tableCompleteStatusDocument.InsertCompleteStatusDoc("DataTalent", 1, UserID);
		}
	}

}
