package com.java.student.dao;

import java.sql.ResultSet;
import java.sql.SQLException;


import com.java.student.bean.SelectJob02Bean;
import com.java.util.PreparedStatementUtil;

public class TableSelectJob02Dao {
	public Boolean CheckSelectJob02(int Coop02ID){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
	
		Boolean value = false;
		String query = "SELECT True as isSelectJob02 FROM cooperative.tb_select_job02 WHERE Coop02ID = :coop02id LIMIT 1";
		
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("coop02id", Coop02ID);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				value = rs.getBoolean("isSelectJob02");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public void InsertSelectJob02(SelectJob02Bean job02Bean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "INSERT INTO tb_select_job02(Job,"
		   									+ "Other,"
		   									+ "Coop02ID) "
					   		+ " VALUES(:job,"   
					   				+ ":other,"
					   				+ ":Coop02ID)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("job", job02Bean.getJob());
		   preparedStatementUtil.setString("other", job02Bean.getOther());
		   preparedStatementUtil.setInt("Coop02ID",job02Bean.getCoop02id());
		   preparedStatementUtil.execute();   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	
	
	public void UpdateSelectJob02(SelectJob02Bean job02Bean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_select_job02 SET "
		   				+ "Job = :job,"
		   				+ "Other = :other "
		   				+ "WHERE Coop02ID = :coop02id";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("job", job02Bean.getJob());
		   preparedStatementUtil.setString("other", job02Bean.getOther());
		   preparedStatementUtil.setInt("coop02id",job02Bean.getCoop02id());
		   preparedStatementUtil.execute();   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public SelectJob02Bean SelectJob02(int Coop02ID){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		SelectJob02Bean job02Bean = new SelectJob02Bean();
		
		String query = "SELECT Job,Other"
				+ " FROM tb_select_job02"
				+ " WHERE Coop02ID = :coop02id"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("coop02id", Coop02ID);
			rs = preparedStatementUtil.executeQuery();
			
			if(rs.next()){
				job02Bean.setJob(rs.getString("Job"));
				job02Bean.setOther(rs.getString("Other"));

			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return job02Bean;
	}
}
