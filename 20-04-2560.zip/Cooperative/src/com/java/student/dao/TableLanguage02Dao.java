package com.java.student.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.student.bean.Language02Bean;
import com.java.util.PreparedStatementUtil;

public class TableLanguage02Dao {
	public Boolean CheckLanguage02(int Coop02ID){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
	
		Boolean value = false;
		String query = "SELECT True as isLanguage02 FROM cooperative.tb_language02 WHERE Coop02ID = :coop02id LIMIT 1";
		
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("coop02id", Coop02ID);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				value = rs.getBoolean("isLanguage02");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public void InsertLanguage02(Language02Bean language02Bean){
		PreparedStatementUtil preparedStatementUtil = null;

		  try{
		   String query = "INSERT INTO tb_language02(Language_eng,"
		   									+ "Level_eng,"
		   									+ "Language_jap,"
		   									+ "Level_jap,"
		   									+ "Language_chi,"
		   									+ "Level_chi,"
		   									+ "Language_other,"
		   									+ "Level_other,"
		   									+ "other,"
		   									+ "Coop02ID) "
					   		+ " VALUES(:language_eng,"   
					   				+ ":level_eng,"
					   				+ ":language_jap,"
					   				+ ":level_jap,"
					   				+ ":language_chi,"
					   				+ ":level_chi,"
					   				+ ":language_other,"
					   				+ ":level_other,"
					   				+ ":other,"
					   				+ ":coop02id)";

		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("language_eng", language02Bean.getLanguage_eng());
		   preparedStatementUtil.setString("level_eng", language02Bean.getLeve_eng());
		   preparedStatementUtil.setString("language_jap", language02Bean.getLanguage_jap());
		   preparedStatementUtil.setString("level_jap", language02Bean.getLeve_jap());
		   preparedStatementUtil.setString("language_chi", language02Bean.getLanguage_chi());
		   preparedStatementUtil.setString("level_chi", language02Bean.getLeve_chi());
		   preparedStatementUtil.setString("language_other", language02Bean.getLanguage_other());
		   preparedStatementUtil.setString("level_other", language02Bean.getLeve_other());
		   preparedStatementUtil.setString("other", language02Bean.getOther());
		   preparedStatementUtil.setInt("coop02id", language02Bean.getCoop02id());
		   preparedStatementUtil.execute();   
		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	
	public void UpdateLanguage02(Language02Bean language02Bean){
		PreparedStatementUtil preparedStatementUtil = null;

		  try{
		   String query = "UPDATE tb_language02 SET "
		   				+ "Language_eng = :language_eng,"
		   				+ "Level_eng = :level_eng,"
		   				+ "Language_jap = :language_jap,"
		   				+ "Level_jap = :level_jap,"
		   				+ "Language_chi = :language_chi,"
		   				+ "Level_chi = :level_chi,"
		   				+ "Language_other = :language_other,"
		   				+ "Level_other = :level_other,"
		   				+ "other = :other "
		   				+ "WHERE Coop02ID = :coop02id";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("language_eng", language02Bean.getLanguage_eng());
		   preparedStatementUtil.setString("level_eng", language02Bean.getLeve_eng());
		   preparedStatementUtil.setString("language_jap", language02Bean.getLanguage_jap());
		   preparedStatementUtil.setString("level_jap", language02Bean.getLeve_jap());
		   preparedStatementUtil.setString("language_chi", language02Bean.getLanguage_chi());
		   preparedStatementUtil.setString("level_chi", language02Bean.getLeve_chi());
		   preparedStatementUtil.setString("language_other", language02Bean.getLanguage_other());
		   preparedStatementUtil.setString("level_other", language02Bean.getLeve_other());
		   preparedStatementUtil.setString("other", language02Bean.getOther());
		   preparedStatementUtil.setInt("coop02id", language02Bean.getCoop02id());
		   preparedStatementUtil.execute();
		   		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public Language02Bean SelectLanguage02(int Coop02ID){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		Language02Bean language02Bean = new Language02Bean();

		String query = "SELECT Language_eng,Level_eng,Language_jap,Level_jap"
				+ ",Language_chi,Level_chi,Language_other,Level_other,other"
				+ " FROM tb_language02"
				+ " WHERE Coop02ID = :coop02id"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("coop02id", Coop02ID);
			rs = preparedStatementUtil.executeQuery();
			
			if(rs.next()){
				language02Bean.setLanguage_eng(rs.getString("Language_eng"));
				language02Bean.setLeve_eng(rs.getString("Level_eng"));
				language02Bean.setLanguage_jap(rs.getString("Language_jap"));
				language02Bean.setLeve_jap(rs.getString("Level_jap"));
				language02Bean.setLanguage_chi(rs.getString("Language_chi"));
				language02Bean.setLeve_chi(rs.getString("Level_chi"));
				language02Bean.setLanguage_other(rs.getString("Language_other"));
				language02Bean.setLeve_other(rs.getString("Level_other"));
				language02Bean.setOther(rs.getString("other"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return language02Bean;
	}
}
