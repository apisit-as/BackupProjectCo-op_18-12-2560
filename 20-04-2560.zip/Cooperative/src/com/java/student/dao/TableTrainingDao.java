package com.java.student.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.student.bean.TrainingBean;
import com.java.util.PreparedStatementUtil;

public class TableTrainingDao {
	public Boolean CheckTraining(int Coop03ID){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
	
		Boolean value = false;
		String query = "SELECT True as isTraining FROM cooperative.tb_training WHERE Coop03ID = :coop03id LIMIT 1";
		
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("coop03id", Coop03ID);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				value = rs.getBoolean("isTraining");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public void InsertTraining(TrainingBean trainingBean){
		PreparedStatementUtil preparedStatementUtil = null;

		  try{
		   String query = "INSERT INTO tb_training(StartDate,"
		   									+ "StopDate,"
		   									+ "Place,"
		   									+ "Position,"
		   									+ "Type,"
		   									+ "Coop03ID) "
					   		+ " VALUES(:startdate,"   
					   				+ ":stopdate,"
					   				+ ":place,"
					   				+ ":position,"
					   				+ ":type,"
					   				+ ":coop03id)";

		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("startdate", trainingBean.getStart_date());
		   preparedStatementUtil.setString("stopdate", trainingBean.getStop_date());
		   preparedStatementUtil.setString("place", trainingBean.getPlace());
		   preparedStatementUtil.setString("position", trainingBean.getPosition());
		   preparedStatementUtil.setString("type", trainingBean.getType());
		   preparedStatementUtil.setInt("coop03id", trainingBean.getCoop03id());
		   preparedStatementUtil.execute();   
		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	
	public void UpdateTraining(TrainingBean trainingBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_training SET "
		   				+ "StartDate = :startdate,"
		   				+ "StopDate = :stopdate,"
		   				+ "Place = :place,"
		   				+ "Position = :position "
		   				+ "WHERE Coop03ID = :coop03id && Type = :type ";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("startdate", trainingBean.getStart_date());
		   preparedStatementUtil.setString("stopdate", trainingBean.getStop_date());
		   preparedStatementUtil.setString("place", trainingBean.getPlace());
		   preparedStatementUtil.setString("position", trainingBean.getPosition());
		   preparedStatementUtil.setString("type", trainingBean.getType());
		   preparedStatementUtil.setInt("coop03id", trainingBean.getCoop03id());
		   preparedStatementUtil.execute();
		   		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public TrainingBean SelectTraining(int Coop03ID, String type){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		TrainingBean trainingBean = new TrainingBean();

		String query = "SELECT StartDate,StopDate,Place,Position,Type"
				+ " FROM tb_training"
				+ " WHERE Coop03ID = :coop03id && Type = :type "; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("coop03id", Coop03ID);
			preparedStatementUtil.setString("type", type);
			rs = preparedStatementUtil.executeQuery();
			
			if(rs.next()){
				trainingBean.setStart_date(rs.getString("StartDate"));
				trainingBean.setStop_date(rs.getString("StopDate"));
				trainingBean.setPlace(rs.getString("Place"));
				trainingBean.setPosition(rs.getString("Position"));
				trainingBean.setType(rs.getString("Type"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return trainingBean;
	}
}
