package com.java.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.list.bean.DivisionBean;
import com.java.list.bean.FacltyBean;
import com.java.list.dao.DivisionSelectListDao;
import com.java.list.dao.FacultySelectListDao;
import com.java.student.bean.UserBean;
import com.java.student.dao.LoginDao;
import com.java.student.dao.TableUserDao;
import com.java.util.Encoding;
import com.java.util.Rpc;


/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		
		// check action = logout
		String action = request.getParameter("action");
		//System.out.println(action);
		if("logout".equals(action)){
			session.invalidate();
			response.sendRedirect("Login");
			return;
		}
		
		// check  role session  != null
		if(session.getAttribute("role") != null){
			
			String role = session.getAttribute("role").toString();
			System.out.println("role = "+role);
			if("student".equals(role)){
				// 1 = role Student
				response.sendRedirect("CheckStatus");
				
			}else if("confirm-student".equals(role)){
				//  doViewConfirmPage
				doViewConfirmStudent(request, response);
			}
			else if("confirm-not-student".equals(role)){
				//  doViewConfirmPage
				//doViewConfirmStudent(request, response);
				ArrayList<FacltyBean> listFaclty = new ArrayList<FacltyBean>();
				FacultySelectListDao facultySelectListDao = new FacultySelectListDao();
				UserBean userBean = new UserBean();
				userBean.setFacid(0);
				
				listFaclty = facultySelectListDao.getFacltyList();
				request.setAttribute("userBean", userBean);
				request.setAttribute("listFaclty", listFaclty);
				
				doViewConfirmNotStudent(request, response);
			}
			
			else if("admin".equals(role)){
				// admin page
				response.sendRedirect("UserManagement");
			}
			else if("staff".equals(role)){
				// staff page
				response.sendRedirect("StudentManagement");
			}
			else if("teacher1".equals(role) || "teacher2".equals(role)){
				// teacher1  teacher2 page
				//doViewTeacher(request, response);
				response.sendRedirect("ApproveDocument");
			}
			
		}else{
			// role session == null
			// doViewLoginPage
			session.invalidate();
			doViewLogin(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		LoginDao loginDao = new LoginDao();
		UserBean loginbean = new UserBean();
		PrintWriter out = response.getWriter();
		Encoding encodeing = new Encoding();
		String action = request.getParameter("action");
		
		if(action.equals("login")){
			String username = request.getParameter("user");
			String password = request.getParameter("pwd");
			
			/** Service RPC **/
			Rpc rpc = new Rpc(username, password);			
			if(rpc.getCheck()){
				/** true Check RPC **/
				loginbean.setStudentid(rpc.getStudentId());
				loginbean.setTitleid(getTitleID(rpc.getPrename()));
				loginbean.setTitlename_th(rpc.getPrename().toUpperCase());
				loginbean.setFirstname_th(rpc.getFirstName().toUpperCase());
				loginbean.setLastname_th(rpc.getLastName().toUpperCase());
				loginbean.setFirstname_eng(rpc.getFirstNameE().toUpperCase());
				loginbean.setLastname_eng(rpc.getLastNameE().toUpperCase());

				/** checklogin in tb_user **/
				UserBean userBean = new UserBean();
				userBean = loginDao.checkLoginUser(loginbean);
				
				if(userBean.getFirstname_th() != null && userBean.getLastname_th() != null){
					/** true check in db **/
					//System.out.println("ok login true in DB");
					if(userBean.getRolename_eng().equals("student")){
						session.setAttribute("role", "student");
						session.setAttribute("UserID", userBean.getId());
					}
//					else if(userBean.getRolename_eng().equals("admin")){
					/** check staff,teacher to Admin  **/
//						session.setAttribute("role", "admin");
//					}
					else if(userBean.getRolename_eng().equals("teacher1") || userBean.getRolename_eng().equals("teacher2") || userBean.getRolename_eng().equals("staff")){
						session.setAttribute("role", userBean.getRolename_eng());
						session.setAttribute("UserID", userBean.getId());
					}
					out.print("goToLogin");
					return;
				}else{
				    /** false check in db 
				     *  to confirm page **/
					if(rpc.getStudentId().equals("NULL")){
						// not student role
						session.setAttribute("titleID", loginbean.getTitleid());
						session.setAttribute("titleName_th", loginbean.getTitlename_th());
						session.setAttribute("firstname_th", loginbean.getFirstname_th());
						session.setAttribute("lastname_th", loginbean.getLastname_th());
						session.setAttribute("role", "confirm-not-student");
					}else{
						//  student  role
						loginbean.setRoleid(1);
						session.setAttribute("studentID", loginbean.getStudentid());
						session.setAttribute("titleID", loginbean.getTitleid());
						session.setAttribute("titleName_th", loginbean.getTitlename_th());
						session.setAttribute("firstname_th", loginbean.getFirstname_th());
						session.setAttribute("lastname_th", loginbean.getLastname_th());
						session.setAttribute("firstname_eng", loginbean.getFirstname_eng());
						session.setAttribute("lastname_eng", loginbean.getLastname_eng());
						session.setAttribute("Roleid", loginbean.getRoleid());
						session.setAttribute("role", "confirm-student");
					}
					out.print("goToLogin");
					return;
				}
			
			}else{
				/** false check rpc  to check admin  **/
				Boolean checkAdmin = loginDao.checkLoginAdminRoot(username, encodeing.Encode(password));
				if(checkAdmin){
					// to admin  role = 2
					session.setAttribute("role", "admin");
					out.print("goToLogin");
					return;
				}else{
					// not user , password
					out.print("Error");
					System.out.println("error");
					return;
				}
			}
			
		}else if(action.equals("confirm-student")){

			// confirm student
			loginbean.setStudentid(session.getAttribute("studentID").toString());
			
			loginbean.setTitleid(Integer.parseInt(session.getAttribute("titleID").toString()));
			loginbean.setFirstname_th(session.getAttribute("firstname_th").toString());
			loginbean.setLastname_th(session.getAttribute("lastname_th").toString());
			loginbean.setFirstname_eng(session.getAttribute("firstname_eng").toString());
			loginbean.setLastname_eng(session.getAttribute("lastname_eng").toString());
			loginbean.setRoleid(Integer.parseInt(session.getAttribute("Roleid").toString()));
			
			session.setAttribute("role","student");
			TableUserDao tableUserDao = new TableUserDao();
			tableUserDao.addUser(loginbean);
			//loginDao.addUser(loginbean);
			
			int keyUserID = loginDao.getID(loginbean);
			session.setAttribute("UserID", keyUserID);
			
			session.removeAttribute("titleName_th");
			session.removeAttribute("firstname_th");
			session.removeAttribute("lastname_th");
			session.removeAttribute("user");
			session.removeAttribute("pass");
			session.removeAttribute("studentID");
			session.removeAttribute("titleID");
			session.removeAttribute("firstname_eng");
			session.removeAttribute("lastname_eng");
			session.removeAttribute("Roleid");
		}
		
		else if(action.equals("confirm-not-student")){
			// confirm-not-student

			int roleID = Integer.parseInt(request.getParameter("roleID"));
			int FacID = Integer.parseInt(request.getParameter("FacID"));
			int DivID = Integer.parseInt(request.getParameter("DivID"));

			if(FacID == 0){
				loginbean.setFacid(0);
			}else{
				loginbean.setFacid(FacID);
			}
			if(DivID == 0){
				loginbean.setDivid(0);
			}else{
				loginbean.setDivid(DivID);
			}
			
			loginbean.setFirstname_th(session.getAttribute("firstname_th").toString());
			loginbean.setLastname_th(session.getAttribute("lastname_th").toString());
			loginbean.setRoleid(roleID);

			loginbean.setTitleid(Integer.parseInt(session.getAttribute("titleID").toString()));

			TableUserDao tableUserDao = new TableUserDao();
			tableUserDao.addUser(loginbean);
			
			int keyUserID = loginDao.getID(loginbean);
			session.setAttribute("UserID", keyUserID);

			if(roleID == 3){
				// staff
				session.setAttribute("role","staff");
				System.out.println("OK staff");
			}else if(roleID == 4){
				//teacher1
				session.setAttribute("role","teacher1");
				System.out.println("OK teacher1");
			}else if(roleID == 5){
				//teacher2
				session.setAttribute("role","teacher2");
				System.out.println("OK teacher2");
			}
			session.removeAttribute("titleName_th");
			session.removeAttribute("firstname_th");
			session.removeAttribute("lastname_th");
			session.removeAttribute("user");
			session.removeAttribute("pass");
			session.removeAttribute("titleID");	

			
		}else if(action.equals("cancel-confirm")){
			session.invalidate();
		}
		
		else if(action.equals("getListDivsion")){
			int facID = Integer.parseInt(request.getParameter("facID"));
			ArrayList<DivisionBean> listDivision = new ArrayList<DivisionBean>();
			DivisionSelectListDao divisionSelectListDao = new DivisionSelectListDao();
			listDivision = divisionSelectListDao.getDivisionList(facID);
			request.setAttribute("divID", 0);
			request.setAttribute("listDivision", listDivision);
			doViewListDivision(request, response);
			return;
		}
		else if(action.equals("getListFaculty")){
			ArrayList<FacltyBean> listFaclty = new ArrayList<FacltyBean>();
			FacultySelectListDao facultySelectListDao = new FacultySelectListDao();
			listFaclty = facultySelectListDao.getFacltyList();
			UserBean userBean = new UserBean();
			request.setAttribute("userBean", userBean);
			request.setAttribute("listFaclty", listFaclty);
			doViewListFaculty(request, response);
			return;
		}
		
		

	}
	
	private int getTitleID(String title){
		int titleid = 0;
		if("���".equals(title)){
			titleid = 1;
		}else if("�ҧ���".equals(title)){
			titleid = 2;
		}else if("�ҧ".equals(title)){
			titleid = 3;
		}
		return titleid;
	}
	

	private void doViewLogin(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/other/login.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	private void doViewConfirmStudent(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/student/data_confirm.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void doViewConfirmNotStudent(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/other/data_confirm_staff_and_teacher.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void doViewStaff(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/error-page.jsp"); ///Cooperative/WebContent/views/error-page.jsp
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void doViewTeacher(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/error-page.jsp"); ///Cooperative/WebContent/views/error-page.jsp
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void doViewListDivision(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/division_list.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void doViewListFaculty(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/faculty_list.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}

	

}
