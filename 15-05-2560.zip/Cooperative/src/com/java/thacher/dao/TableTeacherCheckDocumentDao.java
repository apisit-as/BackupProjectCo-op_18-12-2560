package com.java.thacher.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.thacher.bean.ProfileStudentSendDocumentBean;
import com.java.thacher.bean.TeacherCheckDocumentBean;
import com.java.util.PreparedStatementUtil;

public class TableTeacherCheckDocumentDao {
	
	public void UpdateCheckDocument(TeacherCheckDocumentBean teacherCheckDocumentBean,String coop_name,String checkLevelTeacher){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_teacher_check_document SET "
		   				+checkLevelTeacher+"_"+coop_name+"StatusID = :status_id,"
		   				+checkLevelTeacher+"_"+coop_name+"Note = :note "
		   				+ "WHERE DocID = :doc_id";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("status_id",teacherCheckDocumentBean.getLv_status_id());
		   preparedStatementUtil.setString("note",teacherCheckDocumentBean.getLv_note());
		   preparedStatementUtil.setInt("doc_id",teacherCheckDocumentBean.getDoc_id());
		   preparedStatementUtil.execute();
		   		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public Boolean CheckTable(int facid,int divid,int academic_id,int id_student_send_document){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = 	"SELECT  True as isCheck "
					    + "FROM tb_teacher_check_document "
					    + "JOIN tb_student_send_document  ON tb_student_send_document.ID = tb_teacher_check_document.DocID "
					    + "JOIN tb_user  ON tb_user.ID = tb_student_send_document.UserID "
					     + "WHERE tb_teacher_check_document.DocID = :id_student_send_document "
							 + "AND tb_user.FacID = :facid AND tb_user.DivID = :divid "
					         + "AND tb_student_send_document.Academic_year = :academic_id ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("id_student_send_document", id_student_send_document);
			prepareStatementUtil.setInt("facid", facid);
			prepareStatementUtil.setInt("divid", divid);
			prepareStatementUtil.setInt("academic_id", academic_id);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				value = rs.getBoolean("isCheck");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public TeacherCheckDocumentBean SelectStatusDocument(int facid,int divid,int academic_id,int id_student_send_document,String checkLevelTeacher,String coop_name){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		TeacherCheckDocumentBean teacherCheckDocumentBean = new TeacherCheckDocumentBean();
		
		String query =	"SELECT  tb_teacher_check_document."+checkLevelTeacher+"_"+coop_name+"StatusID,"
						+ "tb_teacher_check_document."+checkLevelTeacher+"_"+coop_name+"Note "
					 + "FROM tb_teacher_check_document "
					 + "JOIN tb_student_send_document  ON tb_student_send_document.ID = tb_teacher_check_document.DocID "
					 + "JOIN tb_user  ON tb_user.ID = tb_student_send_document.UserID "
					 + "WHERE tb_teacher_check_document.DocID = :id_student_send_document "
								+ "AND tb_user.FacID = :facid AND tb_user.DivID = :divid  "
				                + "AND tb_student_send_document.Academic_year = :academic_id ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id_student_send_document", id_student_send_document);
			preparedStatementUtil.setInt("facid", facid);
			preparedStatementUtil.setInt("divid", divid);
			preparedStatementUtil.setInt("academic_id", academic_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				teacherCheckDocumentBean.setLv_status_id(rs.getInt(checkLevelTeacher+"_"+coop_name+"StatusID"));
				teacherCheckDocumentBean.setLv_note(rs.getString(checkLevelTeacher+"_"+coop_name+"Note"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return teacherCheckDocumentBean;
	}
}
