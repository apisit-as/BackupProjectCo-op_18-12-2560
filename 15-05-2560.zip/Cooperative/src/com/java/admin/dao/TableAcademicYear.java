package com.java.admin.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.admin.bean.AcademicYearBean;
import com.java.util.PreparedStatementUtil;

public class TableAcademicYear {
	public void InsertAcademicYear(AcademicYearBean academicYearBean) {
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "INSERT INTO tb_academic_year"
								   		+ "(Semester,"
								   		+ "Academic_year,"
								   		+ "StartDateRecruitment,"
								   		+ "StopDateRecruitment,"
								   		+ "StartDateWorkOut,"
								   		+ "StopDateWorkOut)"

								   		+ " VALUES(:semester,"
								   				+ ":academic_year,"
								   				+ ":start_date_recruitment,"
								   				+ ":stop_date_recruitment,"
								   				+ ":start_date_workout,"
								   				+ ":stop_date_workout)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("semester",academicYearBean.getSemester());
		   preparedStatementUtil.setString("academic_year",academicYearBean.getAcademic_year());
		   preparedStatementUtil.setString("start_date_recruitment",academicYearBean.getStart_date_recruitment());
		   preparedStatementUtil.setString("stop_date_recruitment",academicYearBean.getStop_date_recruitment());
		   preparedStatementUtil.setString("start_date_workout",academicYearBean.getStart_date_workout());
		   preparedStatementUtil.setString("stop_date_workout",academicYearBean.getStop_date_workout());
		   preparedStatementUtil.execute();   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void UpdateAcademicYear(AcademicYearBean academicYearBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_academic_year SET "
		   				+ "Semester = :semester,"
		   				+ "Academic_year = :academic_year, "
		   				+ "StartDateRecruitment = :start_date_recruitment, "
		   				+ "StopDateRecruitment = :stop_date_recruitment, "
		   				+ "StartDateWorkOut = :start_date_workout, "
		   				+ "StopDateWorkOut = :stop_date_workout "
		   				+ "WHERE tb_academic_year.ID = :id";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("semester", academicYearBean.getSemester());
		   preparedStatementUtil.setString("academic_year", academicYearBean.getAcademic_year());
		   preparedStatementUtil.setString("start_date_recruitment", academicYearBean.getStart_date_recruitment());
		   preparedStatementUtil.setString("stop_date_recruitment", academicYearBean.getStop_date_recruitment());
		   preparedStatementUtil.setString("start_date_workout", academicYearBean.getStart_date_workout());
		   preparedStatementUtil.setString("stop_date_workout", academicYearBean.getStop_date_workout());
		   preparedStatementUtil.setInt("id", academicYearBean.getId());
		   preparedStatementUtil.execute();	   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public ArrayList<AcademicYearBean> getAcademicYearBeanList(){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<AcademicYearBean> academicYearBeanList = new ArrayList<AcademicYearBean>();
		String query = "SELECT tb_academic_year.ID,"
				+ "tb_academic_year.Semester,"
				+ "tb_academic_year.Academic_year,"
				+ "tb_academic_year.StartDateRecruitment,"
				+ "tb_academic_year.StopDateRecruitment,"
				+ "tb_academic_year.StartDateWorkOut,"
				+ "tb_academic_year.StopDateWorkOut,"
				+ "tb_academic_year.CheckSelect"
				+ " FROM tb_academic_year"
				+ " order by tb_academic_year.Academic_year desc , tb_academic_year.Semester desc ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			rs = prepareStatementUtil.executeQuery();
			while(rs.next()){
				AcademicYearBean academicYearBean = new AcademicYearBean();
				academicYearBean.setId(rs.getInt("ID"));
				academicYearBean.setSemester(rs.getString("Semester"));
				academicYearBean.setAcademic_year(rs.getString("Academic_year"));
				academicYearBean.setStart_date_recruitment(splitDate(rs.getString("StartDateRecruitment")));
				academicYearBean.setStop_date_recruitment(splitDate(rs.getString("StopDateRecruitment")));
				academicYearBean.setStart_date_workout(splitDate(rs.getString("StartDateWorkOut")));
				academicYearBean.setStop_date_workout(splitDate(rs.getString("StopDateWorkOut")));
				academicYearBean.setCheck_select(rs.getString("CheckSelect"));
				academicYearBeanList.add(academicYearBean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return academicYearBeanList;
	}
	
	private String splitDate(String date){
		String[] str = date.split("-");    
		return str[2]+"/"+str[1]+"/"+(Integer.parseInt(str[0])+543);
	}
	
	public void deleteAcademicYear(int id){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "DELETE FROM tb_academic_year WHERE ID = :id";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("id", id);
		   // �� ź table ����
		   preparedStatementUtil.execute();
		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public int getID(){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		int id = 0;
		String query = "SELECT tb_academic_year.ID "
				+ " FROM tb_academic_year "
				+ " WHERE CheckSelect = 'true' ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			rs = prepareStatementUtil.executeQuery();
			while(rs.next()){
				id = rs.getInt("ID");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return id;
	}
	
	public AcademicYearBean getAcademic(){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		AcademicYearBean academicYearBean = new AcademicYearBean();
		String query = "SELECT tb_academic_year.ID, "
				+ "tb_academic_year.Semester,"
				+ "tb_academic_year.Academic_year,"
				+ "tb_academic_year.StartDateRecruitment,"
				+ "tb_academic_year.StopDateRecruitment,"
				+ "tb_academic_year.StartDateWorkOut,"
				+ "tb_academic_year.StopDateWorkOut,"
				+ "tb_academic_year.CheckSelect"
				+ " FROM tb_academic_year "
				+ " WHERE CheckSelect = 'true' ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			rs = prepareStatementUtil.executeQuery();
			while(rs.next()){
				academicYearBean.setId(rs.getInt("ID"));
				academicYearBean.setSemester(rs.getString("Semester"));
				academicYearBean.setAcademic_year(rs.getString("Academic_year"));
				academicYearBean.setStart_date_recruitment(rs.getString("StartDateRecruitment"));
				academicYearBean.setStop_date_recruitment(rs.getString("StopDateRecruitment"));
				academicYearBean.setStart_date_workout(rs.getString("StartDateWorkOut"));
				academicYearBean.setStop_date_workout(rs.getString("StopDateWorkOut"));
				academicYearBean.setCheck_select(rs.getString("CheckSelect"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return academicYearBean;
	}
	
	public void UpdateCheckSelect(int id){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_academic_year SET "
		   				+ "CheckSelect = null";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.execute();	  
			  
		   query = "UPDATE tb_academic_year SET "
		   				+ "CheckSelect = 'true' "
		   				+ "WHERE tb_academic_year.ID = :id";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("id",id);
		   preparedStatementUtil.execute();	  
		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
}
