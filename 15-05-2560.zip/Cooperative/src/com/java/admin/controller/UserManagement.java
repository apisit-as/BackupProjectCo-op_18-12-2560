package com.java.admin.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.admin.bean.FacultyBean;
import com.java.admin.dao.TableDivisionDao;
import com.java.admin.dao.TableFacultyDao;
import com.java.admin.dao.StudentDeleteUserDao;
import com.java.admin.dao.UserManagementDao;
import com.java.list.bean.FacltyBean;
import com.java.list.dao.FacultySelectListDao;
import com.java.admin.bean.DivisionBean;
import com.java.student.bean.UserBean;
import com.java.student.dao.TableUserDao;
import com.java.util.FileUploadUtil;

/**
 * Servlet implementation class StudentManagement
 */
@WebServlet("/UserManagement")
public class UserManagement extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserManagement() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
		  HttpSession session = request.getSession();
		  String role = session.getAttribute("role").toString();
		
		  // role admin
		  if(role.equals("admin")){
				ArrayList<UserBean> userList = new ArrayList<UserBean>();
				ArrayList<FacultyBean> listFaclty = new ArrayList<FacultyBean>();
				
				UserManagementDao tableUserDao = new UserManagementDao();
				TableFacultyDao tableFacultyDao = new TableFacultyDao();

				userList = tableUserDao.getAllUserList(); // not role admin
				listFaclty = tableFacultyDao.getFacultyList(); 

				request.setAttribute("userList", userList);
				request.setAttribute("listFaclty", listFaclty);
				
				doViewUserManagement(request, response);
		  }

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		ArrayList<DivisionBean> listDivision = new ArrayList<DivisionBean>();
		TableDivisionDao tableDivisionDao = new TableDivisionDao();

		String action = request.getParameter("action");
		
		/* onchang select Fac to select Division  */
		if("GetListDivision".equals(action)){
			int divid = Integer.parseInt(request.getParameter("divid"));
			listDivision = tableDivisionDao.getDivisionList(divid);
			request.setAttribute("listDivision", listDivision);
			
			doGetListDivisionEdit(request, response);

		}
		/* # onchang select Fac to select Division  */
		
		/* onchang select Fac to select DivisionSearch */
		else if("DivisionSearch".equals(action)){
			int divid = Integer.parseInt(request.getParameter("divid"));
			listDivision = tableDivisionDao.getDivisionList(divid);

			request.setAttribute("listDivision", listDivision);
			doGetListDivisionSearch(request, response);
		}
		/* # onchang select Fac to select DivisionSearch  */
		
		
		/* Update  */
		else if("update".equals(action)){
			int id = Integer.parseInt(request.getParameter("id"));
			String facid = request.getParameter("facid");
			String divid = request.getParameter("divid");
			String roleid = request.getParameter("roleid");
			
			if(("".equals(facid)) && ("".equals(divid))){
				facid = null;
				divid = null;
			}
			
			UserManagementDao tableUserDao = new UserManagementDao();

			tableUserDao.updateProfile(id, facid, divid, roleid);
		}
		/* # Update  */
		
		/* Delete  */
		else if("Delete".equals(action)){
			int userid = Integer.parseInt(request.getParameter("id"));  // studentid
			String studentid = request.getParameter("studentid");
			
			//System.out.println("StudentID = "+studentid);
			if(studentid.equals("")){
				
				// studentDeleteUserDao ����¹ class ����ǹ�ͧ staff , teacher
				StudentDeleteUserDao studentDeleteUserDao = new StudentDeleteUserDao();
				System.out.println("OK NOT student");
				studentDeleteUserDao.deleteUser(userid);
				System.out.println("ok delete");
			}else{
				System.out.println("OK student");
				
				StudentDeleteUserDao studentDeleteUserDao = new StudentDeleteUserDao();
				
				if(studentDeleteUserDao.checkIdCoop03(userid)){
					int coop03id = studentDeleteUserDao.getIdCoop03(userid);
					String partPic = studentDeleteUserDao.getPictureCoop03(userid);
					FileUploadUtil.deleteFile(request, partPic);
					studentDeleteUserDao.deleteCoop03(userid, coop03id);
				}
				
				if(studentDeleteUserDao.checkidCoop02(userid)){
					int coop02id = studentDeleteUserDao.getIdCoop02(userid);
					studentDeleteUserDao.deleteCoop02(userid, coop02id);
				}
				
				if(studentDeleteUserDao.checkIdProfile(userid)){
					int profileid = studentDeleteUserDao.getIdProfile(userid);
					studentDeleteUserDao.deleteProfile(userid, profileid);
				}
				
				// delete transcript file
				String partFileTranscript = studentDeleteUserDao.getTranscript(userid);
				FileUploadUtil.deleteFile(request, partFileTranscript);
				studentDeleteUserDao.deleteTranscript(userid);
				
				// delete copmlete status document
				studentDeleteUserDao.deleteCompleteStatusDocument(userid);
				
				//573333013017-1_6_coop02
				UserBean userBean = new UserBean();
				TableUserDao tableUserDao = new TableUserDao();
				userBean = tableUserDao.getTableUser(userid);
				String nameFile = userBean.getStudentid()+"_"+userid;
				FileUploadUtil.deleteReport(request, nameFile+"_coop02");
				FileUploadUtil.deleteReport(request, nameFile+"_coop03");
				studentDeleteUserDao.deleteUser(userid);
				System.out.println("ok delete");
			}


		}
		/* # Delete  */
		
		else if(action.equals("getListFaculty")){
			ArrayList<FacltyBean> listFaclty = new ArrayList<FacltyBean>();
			FacultySelectListDao facultySelectListDao = new FacultySelectListDao();
			listFaclty = facultySelectListDao.getFacltyList();
			UserBean userBean = new UserBean();
			request.setAttribute("userBean", userBean);
			request.setAttribute("listFaclty", listFaclty);
			doViewListFaculty(request, response);
			return;
		}
		
	}
	
	private void doViewUserManagement(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/admin/user_management.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void doGetListDivisionSearch(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/search/division_list_search.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	private void doGetListDivisionEdit(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/admin/divison_list_edit_user.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void doViewListFaculty(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/faculty_list.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}

}
