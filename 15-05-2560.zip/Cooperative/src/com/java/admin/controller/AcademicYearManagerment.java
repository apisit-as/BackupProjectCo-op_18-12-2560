package com.java.admin.controller;

import java.io.IOException;

import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.admin.bean.AcademicYearBean;
import com.java.admin.dao.TableAcademicYear;

/**
 * Servlet implementation class AcademicYearManagerment
 */
@WebServlet("/AcademicYearManagerment")
public class AcademicYearManagerment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AcademicYearManagerment() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
		  HttpSession session = request.getSession();
		  TableAcademicYear tableAcademicYear = new TableAcademicYear();
		  ArrayList<AcademicYearBean> academicBeanList = new ArrayList<AcademicYearBean>();  
		  String role = session.getAttribute("role").toString();
		
		  // role admin
		  if(role.equals("admin")){

			  academicBeanList = tableAcademicYear.getAcademicYearBeanList();
			  request.setAttribute("academicBeanList", academicBeanList);
			  
			  int idCheckSelect = tableAcademicYear.getID();
			  request.setAttribute("idCheckSelect", idCheckSelect);
			  doViewAcademic_year(request, response);
		  }
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");

		AcademicYearBean academicYearBean = new AcademicYearBean();
		TableAcademicYear tableAcademicYear = new TableAcademicYear();

		String action = request.getParameter("action");
		if("add".equals(action)){
			academicYearBean.setSemester(request.getParameter("Semester"));
			academicYearBean.setAcademic_year(request.getParameter("Academic_year"));
			academicYearBean.setStart_date_recruitment(request.getParameter("StartDateRecruitment"));
			academicYearBean.setStop_date_recruitment(request.getParameter("StopDateRecruitment"));
			academicYearBean.setStart_date_workout(request.getParameter("StartDateWorkOut"));
			academicYearBean.setStop_date_workout(request.getParameter("StopDateWorkOut"));
			tableAcademicYear.InsertAcademicYear(academicYearBean);
		}
		else if("edit".equals(action)){
			academicYearBean.setId(Integer.parseInt(request.getParameter("id")));
			academicYearBean.setSemester(request.getParameter("Semester"));
			academicYearBean.setAcademic_year(request.getParameter("Academic_year"));
			academicYearBean.setStart_date_recruitment(request.getParameter("StartDateRecruitment"));
			academicYearBean.setStop_date_recruitment(request.getParameter("StopDateRecruitment"));
			academicYearBean.setStart_date_workout(request.getParameter("StartDateWorkOut"));
			academicYearBean.setStop_date_workout(request.getParameter("StopDateWorkOut"));
			tableAcademicYear.UpdateAcademicYear(academicYearBean);
		}
		else if("delete".equals(action)){
			int id = Integer.parseInt(request.getParameter("id"));
			tableAcademicYear.deleteAcademicYear(id);
		}
		else if("addSelect".equals(action)){
			int id = Integer.parseInt(request.getParameter("id"));
			tableAcademicYear.UpdateCheckSelect(id);
		}
			

		
	}

	private void doViewAcademic_year(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/admin/academic_year.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

}
