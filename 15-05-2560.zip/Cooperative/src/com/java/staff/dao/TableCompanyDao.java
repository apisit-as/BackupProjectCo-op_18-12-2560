package com.java.staff.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.student.bean.Coop02Bean;
import com.java.student.bean.HistoryStatusBean;
import com.java.student.bean.Language02Bean;
import com.java.thacher.bean.ListStudentSendDocumentBean;
import com.java.util.PreparedStatementUtil;

public class TableCompanyDao {
//	public void InsertHistoryStatus(HistoryStatusBean historyStatusBean){
//		PreparedStatementUtil preparedStatementUtil = null;
//		  try{
//		   String query = "INSERT INTO tb_history_status"
//		   									+ "(Date,"
//		   									+ "History,"
//		   									+ "Status,"
//		   									+ "UserID) "
//					   		+ " VALUES(:date,"   
//					   				+ ":history,"
//					   				+ ":status,"
//					   				+ ":userid)";
//		   preparedStatementUtil = new PreparedStatementUtil(query);
//		   preparedStatementUtil.setString("date",historyStatusBean.getDate());
//		   preparedStatementUtil.setString("history",historyStatusBean.getHistory());
//		   preparedStatementUtil.setString("status",historyStatusBean.getStatus());
//		   preparedStatementUtil.setInt("userid",historyStatusBean.getUserid());
//		   preparedStatementUtil.execute();
//		  }catch(Exception e){
//		   e.printStackTrace();
//		  }finally{
//		   if(preparedStatementUtil != null)
//			try {
//				preparedStatementUtil.close();
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//		  }
//	}
	
//	public void UpdateCoop02(Coop02Bean coop02Bean){
//		PreparedStatementUtil preparedStatementUtil = null;
//	  
//		  try{
//		   String query = "UPDATE tb_coop02 SET "
//		   				+ "Talent = :talent,"
//		   				+ "Interest = :interest,"
//		   				+ "Region = :region "
//		   				+ "WHERE UserID = :userid";
//		   preparedStatementUtil = new PreparedStatementUtil(query);
//		   
//		   preparedStatementUtil.setString("talent", coop02Bean.getTalent());
//		   preparedStatementUtil.setString("interest", coop02Bean.getInterest());
//		   preparedStatementUtil.setString("region", coop02Bean.getRegion());
//		   preparedStatementUtil.setInt("userid", coop02Bean.getUserid());
//
//		   preparedStatementUtil.execute();
//		   		   
//		  }catch(Exception e){
//		   e.printStackTrace();
//		  }finally{
//		   if(preparedStatementUtil != null)
//			try {
//				preparedStatementUtil.close();
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//		  }
//	}
	
	
//	public ArrayList<ListStudentSendDocumentBean> SelectListStudentSendDocument(int lv_apStatusID,int facid,int divid,int academic_id,String checkLevelTeacher){
//		PreparedStatementUtil preparedStatementUtil = null;
//		ResultSet rs = null;;
//		ArrayList<ListStudentSendDocumentBean> list = new ArrayList<>();
//		String query =  "SELECT  tb_user.StudentID,"
//						+ "tb_title.Name_th AS titleName_th,"
//				        + "tb_user.FirstName_th,"
//				        + "tb_user.LastName_th,"
//				        + "tb_division.Name AS divName,"
//				        + "tb_profile.GradeTotal,"
//				        + "tb_student_send_document.ID,"
//				        + "tb_student_send_document.UserID,"
//				        + "tb_teacher_check_document."+checkLevelTeacher+"_02Note,"
//				        + "tb_teacher_check_document."+checkLevelTeacher+"_03Note "
//				
//				        + "FROM tb_student_send_document "
//				        + "JOIN tb_user  ON tb_user.ID = tb_student_send_document.UserID "
//				        + "JOIN tb_title  ON tb_title.ID = tb_user.TitleID "
//				        + "JOIN tb_division  ON tb_division.ID = tb_user.DivID "
//				        + "JOIN tb_profile  ON tb_profile.ID = tb_student_send_document.ProfileID "
//						+ "JOIN tb_teacher_check_document  ON tb_student_send_document.ID = tb_teacher_check_document.DocID "
//				
//				        + "WHERE tb_student_send_document."+checkLevelTeacher+"_ApStatusID = :lv_ap_statusid "
//					    	+ "AND tb_user.FacID = :facid AND tb_user.DivID = :divid "
//				            + "AND tb_student_send_document.Academic_year = :academic_id "
//				            + "AND tb_user.RoleID = 1 ";
//		try {
//			preparedStatementUtil = new PreparedStatementUtil(query);
//			preparedStatementUtil.setInt("lv_ap_statusid", lv_apStatusID);
//			preparedStatementUtil.setInt("facid", facid);
//			preparedStatementUtil.setInt("divid", divid);
//			preparedStatementUtil.setInt("academic_id", academic_id);
//			rs = preparedStatementUtil.executeQuery();
//			if(rs.next()){
//				ListStudentSendDocumentBean studentSendDocumentBean = new ListStudentSendDocumentBean();
//				studentSendDocumentBean.setStudent_id(rs.getString("StudentID"));
//				studentSendDocumentBean.setTitle_name_th(rs.getString("titleName_th"));
//				studentSendDocumentBean.setFirstname(rs.getString("FirstName_th"));
//				studentSendDocumentBean.setLastname(rs.getString("LastName_th"));
//				studentSendDocumentBean.setDivision_name(rs.getString("divName"));
//				studentSendDocumentBean.setGrade_total(rs.getString("GradeTotal"));
//				studentSendDocumentBean.setId_student_send_document(rs.getInt("ID"));
//				studentSendDocumentBean.setUserid(rs.getInt("UserID"));
//				studentSendDocumentBean.setLv_02note(rs.getString(checkLevelTeacher+"_02Note"));
//				studentSendDocumentBean.setLv_03note(rs.getString(checkLevelTeacher+"_03Note"));
//				list.add(studentSendDocumentBean);
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally{
//			try {
//				preparedStatementUtil.close();
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//			try {
//				rs.close();
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//		}
//		return list;
//	}
}
