package com.java.staff.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.student.bean.UserBean;
import com.java.student.dao.TableUserDao;

/**
 * Servlet implementation class MatchStudentCompany
 */
@WebServlet("/MatchStudentCompany")
public class MatchStudentCompany extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MatchStudentCompany() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
			HttpSession session = request.getSession();
			TableUserDao tableUserDao = new TableUserDao();
			UserBean userBean = new UserBean();
			String role = session.getAttribute("role").toString();
			if(role.equals("staff")){
				String UserID = session.getAttribute("UserID").toString();
				userBean = tableUserDao.getTableUser(Integer.parseInt(UserID));
				request.setAttribute("userBean", userBean);
				//session.setAttribute("divID", userBean.getDivid());
				session.setAttribute("divName", userBean.getDivname());
				
				String action = request.getParameter("action");
				//String sutdentid = request.getParameter("sutdentid");

				if("MatchCheck".equals(action)){
					System.out.println("OK MatchCheck");
					doViewMatchStudentCompany(request, response);
					return;
				}else{
					//doViewCheckDocument(request, response);
				}
				
				
				//doViewApproveTecher(request, response);
				
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}
	private void doViewMatchStudentCompany(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/staff/match_student_company.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
}
