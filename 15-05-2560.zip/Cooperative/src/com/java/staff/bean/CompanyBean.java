package com.java.staff.bean;

public class CompanyBean {
	private int id;
	private String name_company;
	private int region_company_id;
	private String region_company_name;
	private String address_company;
	private String district_company;
	private String amphur_company;
	private String province_company;
	private String postcode_company;
	private String telephone_company;
	private String fax_company;
	private String email_company;
	private String type_work_company;
	private String pay_yes_company;
	private String type_company;
	private String employees_company;
	private String residence_company;
	private String welfar_company;
	private String name_contact;
	private String telephone_contact;
	private String mobile_contact;
	private String fax_contact;
	private String email_contact;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName_company() {
		return name_company;
	}
	public void setName_company(String name_company) {
		this.name_company = name_company;
	}
	public int getRegion_company_id() {
		return region_company_id;
	}
	public void setRegion_company_id(int region_company_id) {
		this.region_company_id = region_company_id;
	}
	public String getRegion_company_name() {
		return region_company_name;
	}
	public void setRegion_company_name(String region_company_name) {
		this.region_company_name = region_company_name;
	}
	public String getAddress_company() {
		return address_company;
	}
	public void setAddress_company(String address_company) {
		this.address_company = address_company;
	}
	public String getDistrict_company() {
		return district_company;
	}
	public void setDistrict_company(String district_company) {
		this.district_company = district_company;
	}
	public String getAmphur_company() {
		return amphur_company;
	}
	public void setAmphur_company(String amphur_company) {
		this.amphur_company = amphur_company;
	}
	public String getProvince_company() {
		return province_company;
	}
	public void setProvince_company(String province_company) {
		this.province_company = province_company;
	}
	public String getPostcode_company() {
		return postcode_company;
	}
	public void setPostcode_company(String postcode_company) {
		this.postcode_company = postcode_company;
	}
	public String getTelephone_company() {
		return telephone_company;
	}
	public void setTelephone_company(String telephone_company) {
		this.telephone_company = telephone_company;
	}
	public String getFax_company() {
		return fax_company;
	}
	public void setFax_company(String fax_company) {
		this.fax_company = fax_company;
	}
	public String getEmail_company() {
		return email_company;
	}
	public void setEmail_company(String email_company) {
		this.email_company = email_company;
	}
	public String getType_work_company() {
		return type_work_company;
	}
	public void setType_work_company(String type_work_company) {
		this.type_work_company = type_work_company;
	}
	public String getPay_yes_company() {
		return pay_yes_company;
	}
	public void setPay_yes_company(String pay_yes_company) {
		this.pay_yes_company = pay_yes_company;
	}
	public String getType_company() {
		return type_company;
	}
	public void setType_company(String type_company) {
		this.type_company = type_company;
	}
	public String getEmployees_company() {
		return employees_company;
	}
	public void setEmployees_company(String employees_company) {
		this.employees_company = employees_company;
	}
	public String getResidence_company() {
		return residence_company;
	}
	public void setResidence_company(String residence_company) {
		this.residence_company = residence_company;
	}
	public String getWelfar_company() {
		return welfar_company;
	}
	public void setWelfar_company(String welfar_company) {
		this.welfar_company = welfar_company;
	}
	public String getName_contact() {
		return name_contact;
	}
	public void setName_contact(String name_contact) {
		this.name_contact = name_contact;
	}
	public String getTelephone_contact() {
		return telephone_contact;
	}
	public void setTelephone_contact(String telephone_contact) {
		this.telephone_contact = telephone_contact;
	}
	public String getMobile_contact() {
		return mobile_contact;
	}
	public void setMobile_contact(String mobile_contact) {
		this.mobile_contact = mobile_contact;
	}
	public String getFax_contact() {
		return fax_contact;
	}
	public void setFax_contact(String fax_contact) {
		this.fax_contact = fax_contact;
	}
	public String getEmail_contact() {
		return email_contact;
	}
	public void setEmail_contact(String email_contact) {
		this.email_contact = email_contact;
	}

}
