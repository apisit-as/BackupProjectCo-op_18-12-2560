package com.java.student.bean;

public class RelativeBean {
	private int id;
	private int titleid;
	private String title_th;
	private String title_eng;
	private String firstname;
	private String lastname;
	private String age;
	private String occupation;
	private String position;
	private String type;
	private int coop03id;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getTitleid() {
		return titleid;
	}
	public void setTitleid(int titleid) {
		this.titleid = titleid;
	}
	public String getTitle_th() {
		return title_th;
	}
	public void setTitle_th(String title_th) {
		this.title_th = title_th;
	}
	public String getTitle_eng() {
		return title_eng;
	}
	public void setTitle_eng(String title_eng) {
		this.title_eng = title_eng;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getCoop03id() {
		return coop03id;
	}
	public void setCoop03id(int coop03id) {
		this.coop03id = coop03id;
	}
	
	
}
