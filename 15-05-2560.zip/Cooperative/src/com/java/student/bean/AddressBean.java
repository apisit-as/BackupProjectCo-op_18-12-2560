package com.java.student.bean;

public class AddressBean {
	private int id;
	private String id_num;
	private String num_mu;
	private String road;
	private int provinceid;
	private String provincename;
	private int amphurid;
	private String amphurname;
	private int districtid;
	private String districtname;
	private String postcode;
	private String telephone;
	private String mobile;
	private String fax;
	private String email;
	private String type;
	private int profilelid;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getId_num() {
		return id_num;
	}
	public void setId_num(String id_num) {
		this.id_num = id_num;
	}
	public String getNum_mu() {
		return num_mu;
	}
	public void setNum_mu(String num_mu) {
		this.num_mu = num_mu;
	}
	public String getRoad() {
		return road;
	}
	public void setRoad(String road) {
		this.road = road;
	}
	public int getProvinceid() {
		return provinceid;
	}
	public void setProvinceid(int provinceid) {
		this.provinceid = provinceid;
	}
	public String getProvincename() {
		return provincename;
	}
	public void setProvincename(String provincename) {
		this.provincename = provincename;
	}
	public int getAmphurid() {
		return amphurid;
	}
	public void setAmphurid(int amphurid) {
		this.amphurid = amphurid;
	}
	public String getAmphurname() {
		return amphurname;
	}
	public void setAmphurname(String amphurname) {
		this.amphurname = amphurname;
	}
	public int getDistrictid() {
		return districtid;
	}
	public void setDistrictid(int districtid) {
		this.districtid = districtid;
	}
	public String getDistrictname() {
		return districtname;
	}
	public void setDistrictname(String districtname) {
		this.districtname = districtname;
	}
	public String getPostcode() {
		return postcode;
	}
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getProfilelid() {
		return profilelid;
	}
	public void setProfilelid(int profilelid) {
		this.profilelid = profilelid;
	}
	
	
}
