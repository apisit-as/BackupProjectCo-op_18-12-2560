package com.java.student.bean;

public class StudentSendDocumentBean {
	private int id;
	private int academic_year;
	private int coop02id;
	private int coop03id;
	private int transcriptid;
	private int profileid;
	private int lv1_apstatusid;
	private int lv1_apstatusby;
	private String lv1_apStatusdate;
	private int lv2_apstatusid;
	private int lv2_apstatusby;
	private String lv2_apStatusdate;
	private int userid;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAcademic_year() {
		return academic_year;
	}
	public void setAcademic_year(int academic_year) {
		this.academic_year = academic_year;
	}
	public int getCoop02id() {
		return coop02id;
	}
	public void setCoop02id(int coop02id) {
		this.coop02id = coop02id;
	}
	public int getCoop03id() {
		return coop03id;
	}
	public void setCoop03id(int coop03id) {
		this.coop03id = coop03id;
	}
	public int getTranscriptid() {
		return transcriptid;
	}
	public void setTranscriptid(int transcriptid) {
		this.transcriptid = transcriptid;
	}
	public int getProfileid() {
		return profileid;
	}
	public void setProfileid(int profileid) {
		this.profileid = profileid;
	}
	public int getLv1_apstatusid() {
		return lv1_apstatusid;
	}
	public void setLv1_apstatusid(int lv1_apstatusid) {
		this.lv1_apstatusid = lv1_apstatusid;
	}
	public int getLv1_apstatusby() {
		return lv1_apstatusby;
	}
	public void setLv1_apstatusby(int lv1_apstatusby) {
		this.lv1_apstatusby = lv1_apstatusby;
	}
	public String getLv1_apStatusdate() {
		return lv1_apStatusdate;
	}
	public void setLv1_apStatusdate(String lv1_apStatusdate) {
		this.lv1_apStatusdate = lv1_apStatusdate;
	}
	public int getLv2_apstatusid() {
		return lv2_apstatusid;
	}
	public void setLv2_apstatusid(int lv2_apstatusid) {
		this.lv2_apstatusid = lv2_apstatusid;
	}
	public int getLv2_apstatusby() {
		return lv2_apstatusby;
	}
	public void setLv2_apstatusby(int lv2_apstatusby) {
		this.lv2_apstatusby = lv2_apstatusby;
	}
	public String getLv2_apStatusdate() {
		return lv2_apStatusdate;
	}
	public void setLv2_apStatusdate(String lv2_apStatusdate) {
		this.lv2_apStatusdate = lv2_apStatusdate;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}

}
