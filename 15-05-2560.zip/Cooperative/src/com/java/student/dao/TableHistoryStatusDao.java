package com.java.student.dao;

import java.sql.SQLException;

import com.java.student.bean.HistoryStatusBean;
import com.java.util.PreparedStatementUtil;

public class TableHistoryStatusDao {
	
	public void InsertHistoryStatus(HistoryStatusBean historyStatusBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "INSERT INTO tb_history_status"
		   									+ "(Date,"
		   									+ "History,"
		   									+ "Status,"
		   									+ "UserID) "
					   		+ " VALUES(:date,"   
					   				+ ":history,"
					   				+ ":status,"
					   				+ ":userid)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("date",historyStatusBean.getDate());
		   preparedStatementUtil.setString("history",historyStatusBean.getHistory());
		   preparedStatementUtil.setString("status",historyStatusBean.getStatus());
		   preparedStatementUtil.setInt("userid",historyStatusBean.getUserid());
		   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
}
