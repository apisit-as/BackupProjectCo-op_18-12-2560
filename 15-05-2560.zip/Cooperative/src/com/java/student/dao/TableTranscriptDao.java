package com.java.student.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.student.bean.TranscriptBean;
import com.java.util.PreparedStatementUtil;

public class TableTranscriptDao {
	
	public void UpdateTranscript(TranscriptBean transcriptBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_transcript SET "
		   				+ "File = :file "
		   				+ "WHERE UserID = :userid";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("file", transcriptBean.getFile());
		   preparedStatementUtil.setInt("userid", transcriptBean.getUserid());
		   preparedStatementUtil.execute();
		   		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void InsertTranscript(TranscriptBean transcriptBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "INSERT INTO tb_transcript(File,"
		   									+ "UserID) "
					   		+ " VALUES(:file,"  
					   				+ ":userid)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("file", transcriptBean.getFile());
		   preparedStatementUtil.setInt("userid", transcriptBean.getUserid());
		   preparedStatementUtil.execute();   
		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public Boolean CheckTranscript(int UserID){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = "SELECT True as isTranscript FROM cooperative.tb_transcript WHERE UserID = :userid LIMIT 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("userid", UserID);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				value = rs.getBoolean("isTranscript");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public String SelectTranscriptPath(int UserID){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		String file = "";
		String query = "SELECT file"
				+ " FROM tb_transcript"
				+ " WHERE UserID = :userid"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("userid", UserID);
			rs = preparedStatementUtil.executeQuery();
			
			if(rs.next()){
				file = rs.getString("file");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return file;
	}
	
	public int SelectID(int UserID){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		int id = 0;
		String query = "SELECT ID"
				+ " FROM tb_transcript"
				+ " WHERE UserID = :userid"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("userid", UserID);
			rs = preparedStatementUtil.executeQuery();
			
			if(rs.next()){
				id = rs.getInt("ID");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return id;
	}

}
