package com.java.student.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.list.bean.AmphurBean;
import com.java.list.bean.DistrictBean;
import com.java.list.bean.ProvinceBean;
import com.java.list.dao.AmphurSelectListDao;
import com.java.list.dao.DistrictSelectListDao;
import com.java.list.dao.ProvinceSelectListDao;
import com.java.student.bean.AddressBean;
import com.java.student.bean.UserBean;
import com.java.student.dao.TableAddressDao;
import com.java.student.dao.TableCompleteStatusDocument;
import com.java.student.dao.TableProfileDao;
import com.java.student.dao.TableUserDao;

/**
 * Servlet implementation class CheckStatus
 */
@WebServlet("/DataAddress")
public class DataAddress extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DataAddress() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		
		HttpSession session = request.getSession();
		TableUserDao tableUserDao = new TableUserDao();
		UserBean userBean = new UserBean();

		String role = session.getAttribute("role").toString();
		if(role.equals("student")){
			
			int UserID = Integer.parseInt(session.getAttribute("UserID").toString());
			
			/* get tb_user */
			userBean = tableUserDao.getTableUser(UserID);
			request.setAttribute("userBean", userBean);
			session.setAttribute("divID", userBean.getDivid());
			session.setAttribute("divName", userBean.getDivname());
			/* #get tb_user */
			
			
			// select address type
			TableProfileDao checkKeyProfile = new TableProfileDao();
			int keyProfile = checkKeyProfile.getKeyIDProfile(UserID);
			
			TableAddressDao addressDao = new TableAddressDao();
			AddressBean original_address = new AddressBean();
			original_address = addressDao.SelectAddressType(keyProfile, "original_address");
			
			AddressBean semester_address = new AddressBean();
			semester_address = addressDao.SelectAddressType(keyProfile, "semester_address");
			
			request.setAttribute("original_address", original_address);
			request.setAttribute("semester_address", semester_address);

			// select address province  amphur   district
			// original
			{
			ArrayList<ProvinceBean> original_provinceList = new ArrayList<ProvinceBean>(); 
			ProvinceSelectListDao original_provinceSelectListDao = new ProvinceSelectListDao();
			original_provinceList = original_provinceSelectListDao.getProvinceList();
			
			ArrayList<AmphurBean> original_amphurList = new ArrayList<AmphurBean>(); 
			AmphurSelectListDao original_amphurSelectListDao = new AmphurSelectListDao();
			original_amphurList = original_amphurSelectListDao.getAmphurList(original_address.getProvinceid());
			
			ArrayList<DistrictBean> original_districtList = new ArrayList<DistrictBean>(); 
			DistrictSelectListDao original_districtSelectListDao = new DistrictSelectListDao();
			original_districtList = original_districtSelectListDao.getDistrictList(original_address.getAmphurid());
			
			request.setAttribute("listProvince_original_address", original_provinceList);
			request.setAttribute("listAmphur_original_address", original_amphurList);
			request.setAttribute("listDistrict_original_address", original_districtList);
			
			session.setAttribute("amphur_original_address_id", original_address.getAmphurid());
			session.setAttribute("amphur_original_address_name", original_address.getAmphurname());
			session.setAttribute("district_original_address_id", original_address.getDistrictid());
			session.setAttribute("district_original_address_name", original_address.getDistrictname());
			}
			//  # original
			

			// semester_address
			{
			ArrayList<ProvinceBean> semester_provinceList = new ArrayList<ProvinceBean>(); 
			ProvinceSelectListDao semester_provinceSelectListDao = new ProvinceSelectListDao();
			semester_provinceList = semester_provinceSelectListDao.getProvinceList();
			
			ArrayList<AmphurBean> semester_amphurList = new ArrayList<AmphurBean>(); 
			AmphurSelectListDao semester_amphurSelectListDao = new AmphurSelectListDao();
			semester_amphurList = semester_amphurSelectListDao.getAmphurList(semester_address.getProvinceid());
			
			ArrayList<DistrictBean> semester_districtList = new ArrayList<DistrictBean>(); 
			DistrictSelectListDao semester_districtSelectListDao = new DistrictSelectListDao();
			semester_districtList = semester_districtSelectListDao.getDistrictList(semester_address.getAmphurid());
			
			request.setAttribute("listProvince_semester_address", semester_provinceList);
			request.setAttribute("listAmphur_semester_address", semester_amphurList);
			request.setAttribute("listDistrict_semester_address", semester_districtList);
			
			session.setAttribute("amphur_semester_address_id", semester_address.getAmphurid());
			session.setAttribute("amphur_semester_address_name", semester_address.getAmphurname());
			session.setAttribute("district_semester_address_id", semester_address.getDistrictid());
			session.setAttribute("district_semester_address_name", semester_address.getDistrictname());
			}
			//  # semester_address
			
			doViewDataAddress(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		
		String action_address = request.getParameter("action_address");
		String action_onchange = request.getParameter("action_onchange");
		
		// tb_address
		if("address".equals(action_address)){
			insertAddress(request, response);
		}
		
		// get select list Amphur_original
		else if("clickProvince_original".equals(action_onchange)){
			String ProvinceID_original = request.getParameter("ProvinceID_original");
			AmphurSelectListDao amphurSelectListDao = new AmphurSelectListDao();
			ArrayList<AmphurBean> amphurBeans = new ArrayList<AmphurBean>();
			amphurBeans = amphurSelectListDao.getAmphurList(Integer.parseInt(ProvinceID_original));
			request.setAttribute("listAmphur_original_address", amphurBeans);
			session.setAttribute("amphur_original_address_id", 0);
			session.setAttribute("amphur_original_address_name", 0);       //  session
			doViewAmphur_originalList(request, response);
			return;
		}
		
		//get select list District_original
		else if("clickAmphur_original".equals(action_onchange)){
			String AmphurID_original = request.getParameter("AmphurID_original");
			DistrictSelectListDao districtSelectListDao = new DistrictSelectListDao();
			ArrayList<DistrictBean> districtBeans = new ArrayList<DistrictBean>();
			districtBeans = districtSelectListDao.getDistrictList(Integer.parseInt(AmphurID_original));
			request.setAttribute("listDistrict_original_address", districtBeans);
			session.setAttribute("district_original_address_id", 0);
			session.setAttribute("district_original_address_name", 0);       //  session
			doViewDistrict_originalList(request, response);
			return;
		}
		
		// get select list Amphur_semester
		else if("clickProvince_semester".equals(action_onchange)){
			String ProvinceID_semester = request.getParameter("ProvinceID_semester");
			AmphurSelectListDao amphurSelectListDao = new AmphurSelectListDao();
			ArrayList<AmphurBean> amphurBeans = new ArrayList<AmphurBean>();
			amphurBeans = amphurSelectListDao.getAmphurList(Integer.parseInt(ProvinceID_semester));
			request.setAttribute("listAmphur_semester_address", amphurBeans);
			session.setAttribute("amphur_semester_address_id", 0);
			session.setAttribute("amphur_semester_address_name", 0);       //  session
			doViewAmphur_semesterList(request, response);
			return;
		}
		//get select list District_semester
		else if("clickAmphur_semester".equals(action_onchange)){
			String AmphurID_semester = request.getParameter("AmphurID_semester");
			DistrictSelectListDao districtSelectListDao = new DistrictSelectListDao();
			ArrayList<DistrictBean> districtBeans = new ArrayList<DistrictBean>();
			districtBeans = districtSelectListDao.getDistrictList(Integer.parseInt(AmphurID_semester));
			request.setAttribute("listDistrict_semester_address", districtBeans);
			session.setAttribute("district_semester_address_id", 0);
			session.setAttribute("district_semester_address_name", 0);       //  session
			doViewDistrict_semesterlList(request, response);
			return;
		}	
	}
	
	
	private void doViewAmphur_originalList(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/amphur/amphur_original_address.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void doViewAmphur_semesterList(HttpServletRequest request, HttpServletResponse response) {

		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/amphur/amphur_semester_address.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	private void doViewDistrict_originalList(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/district/district_original_address.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void doViewDistrict_semesterlList(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/district/district_semester_address.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	private void doViewDataAddress(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/student/data_default/data_address.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void insertAddress(HttpServletRequest request, HttpServletResponse response){
		
		HttpSession session = request.getSession();
		int UserID = Integer.parseInt(session.getAttribute("UserID").toString());
		TableProfileDao tableProfileDao = new TableProfileDao();

		/* check tb_profile */
		if(tableProfileDao.CheckProfile(UserID)){
			/** update **/
			actionInsert(request, response,UserID);
		}else{
			/** insert **/
			tableProfileDao.InsertProfileSetUserid(UserID);
			actionInsert(request, response,UserID);
		}
		
		/** insert,update status document **/
		TableCompleteStatusDocument tableCompleteStatusDocument = new TableCompleteStatusDocument();
		if(tableCompleteStatusDocument.checkCompleteStatusDocument(UserID)){
			//update
			tableCompleteStatusDocument.UpdateCompleteStatusDoc("DataAddress", 1, UserID);
		}else{
			//insert
			tableCompleteStatusDocument.InsertCompleteStatusDoc("DataAddress", 1, UserID);
		}
	}
	
	private void  actionInsert(HttpServletRequest request, HttpServletResponse response, int UserID) {
		TableProfileDao checkKeyProfile = new TableProfileDao();
		int profileID = checkKeyProfile.getKeyIDProfile(UserID);
		TableAddressDao tableAddressDao = new TableAddressDao();
		
		 boolean checkOriginal_address =   tableAddressDao.CheckAddressParent(profileID, "original_address");
		 boolean checkSemester_address =   tableAddressDao.CheckAddressParent(profileID, "semester_address");
		 
		for(int i=1; i<=2; i++){
			AddressBean addressBean = new AddressBean();
			addressBean.setId_num(request.getParameter("Id_num"+i).toString());
			addressBean.setNum_mu(request.getParameter("Num_Mu"+i).toString());
			addressBean.setRoad(request.getParameter("Road"+i).toString());
			addressBean.setProvinceid(Integer.parseInt(request.getParameter("ProvinceID"+i).toString()));
			addressBean.setAmphurid(Integer.parseInt(request.getParameter("AmphurID"+i).toString()));
			addressBean.setDistrictid(Integer.parseInt(request.getParameter("DistrictID"+i).toString()));
			addressBean.setPostcode(request.getParameter("Postcode"+i).toString());
			addressBean.setTelephone(request.getParameter("Telephone"+i).toString());
			addressBean.setMobile(request.getParameter("Mobile"+i).toString());
			addressBean.setFax(request.getParameter("Fax"+i).toString());
			addressBean.setEmail(request.getParameter("Email"+i).toString());
			
			if(i == 1){
				addressBean.setType("original_address");
			}else if(i == 2){
				addressBean.setType("semester_address");
			}
			addressBean.setProfilelid(profileID);
			
			if(checkOriginal_address && checkSemester_address){
				System.out.println("true update address");
				tableAddressDao.updateAddress(addressBean);
			}else{
				//false
				System.out.println("false insert address");
				tableAddressDao.InsertAddress(addressBean);
			}
		}
	}
}
