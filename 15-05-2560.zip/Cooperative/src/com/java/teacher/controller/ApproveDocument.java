package com.java.teacher.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.admin.bean.AcademicYearBean;
import com.java.admin.dao.TableAcademicYear;
import com.java.student.bean.UserBean;
import com.java.student.dao.TableUserDao;
import com.java.thacher.bean.ListStudentSendDocumentBean;
import com.java.thacher.dao.TableStudentSendDocumentDao;

/**
 * Servlet implementation class ApproveDocument
 */
@WebServlet("/ApproveDocument")
public class ApproveDocument extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ApproveDocument() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
			HttpSession session = request.getSession();
			TableUserDao tableUserDao = new TableUserDao();
			UserBean userBean = new UserBean();
			String role = session.getAttribute("role").toString();
			if((role.equals("teacher1")) || (role.equals("teacher2"))){
				String UserID = session.getAttribute("UserID").toString();
			    userBean = tableUserDao.getTableUser(Integer.parseInt(UserID));
			    session.setAttribute("titlename_th_session", userBean.getTitlename_th());
			    session.setAttribute("firstname_th_session", userBean.getFirstname_th());
			    session.setAttribute("lastname_th_session", userBean.getLastname_th());
			    session.setAttribute("divName", userBean.getDivname());
			    session.setAttribute("rolename_th_session", userBean.getRolename_th());
				
				// set Academic Year
				TableAcademicYear tableAcademicYear = new TableAcademicYear();
				AcademicYearBean academicYearBean = new AcademicYearBean();
				academicYearBean = tableAcademicYear.getAcademic();
				session.setAttribute("Semester", academicYearBean.getSemester());
				session.setAttribute("Academic_year", academicYearBean.getAcademic_year());
				
				session.setAttribute("facID", userBean.getFacid());
				session.setAttribute("divID", userBean.getDivid());
				session.setAttribute("academic_year_id", academicYearBean.getId());
				
				TableStudentSendDocumentDao tableStudentSendDocumentDao = new TableStudentSendDocumentDao();
				ArrayList<ListStudentSendDocumentBean> ListstudentSendDocumentTab1 = new ArrayList<>();
				ArrayList<ListStudentSendDocumentBean> ListstudentSendDocumentTab2 = new ArrayList<>();
				ArrayList<ListStudentSendDocumentBean> ListstudentSendDocumentTab3 = new ArrayList<>();
				ArrayList<ListStudentSendDocumentBean> ListstudentSendDocumentTab4 = new ArrayList<>();
				String checkLevelTeacher = "";
				if(role.equals("teacher1")){
					checkLevelTeacher = "Lv1";
				}else if(role.equals("teacher2")){
					checkLevelTeacher = "Lv2";
				}
	
				ListstudentSendDocumentTab1 = tableStudentSendDocumentDao.SelectListStudentSendDocument(6,userBean.getFacid(),userBean.getDivid(),academicYearBean.getId(),checkLevelTeacher);
				ListstudentSendDocumentTab2 = tableStudentSendDocumentDao.SelectListStudentSendDocument(2,userBean.getFacid(),userBean.getDivid(),academicYearBean.getId(),checkLevelTeacher);
				ListstudentSendDocumentTab3 = tableStudentSendDocumentDao.SelectListStudentSendDocument(4,userBean.getFacid(),userBean.getDivid(),academicYearBean.getId(),checkLevelTeacher);
				ListstudentSendDocumentTab4 = tableStudentSendDocumentDao.SelectListStudentSendDocument(3,userBean.getFacid(),userBean.getDivid(),academicYearBean.getId(),checkLevelTeacher);
				
				request.setAttribute("ListstudentSendDocumentTab1", ListstudentSendDocumentTab1);
				request.setAttribute("ListstudentSendDocumentTab2", ListstudentSendDocumentTab2);
				request.setAttribute("ListstudentSendDocumentTab3", ListstudentSendDocumentTab3);
				request.setAttribute("ListstudentSendDocumentTab4", ListstudentSendDocumentTab4);
				
				/** check role approve document  
				 *  enable or disable
				 */
				String CheckRoleApproveTeacher = userBean.getApprove_teacher();
				session.setAttribute("CheckRoleApproveTeacher",CheckRoleApproveTeacher);
				
				doViewApproveDocument(request, response);
				
			}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String action = request.getParameter("action");
		if("setTab".equals(action)){
			String valueTab = request.getParameter("valueTab");
			session.setAttribute("valueTabApproveDocument",valueTab);
		}
		
		
	}
	
	private void doViewApproveDocument(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/teacher/approve_document.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}

}
