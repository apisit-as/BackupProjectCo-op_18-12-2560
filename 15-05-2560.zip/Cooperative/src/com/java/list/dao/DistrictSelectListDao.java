package com.java.list.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


import com.java.list.bean.DistrictBean;
import com.java.util.PreparedStatementUtil;

public class DistrictSelectListDao {
	public ArrayList<DistrictBean> getDistrictList(int AmphurID) {
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ArrayList<DistrictBean> listDistrict = new ArrayList<DistrictBean>();
		  try{
		   String query = "SELECT ID,Name,AmphurID FROM cooperative.tb_district "
		   		+ " WHERE AmphurID = :amphurid "
		   		+ " ORDER BY Name ASC";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("amphurid", AmphurID);
		   rs = preparedStatementUtil.executeQuery();   
		   
		   while(rs.next()){
			   DistrictBean drstrictBean = new DistrictBean();
			   drstrictBean.setId(rs.getInt("ID"));
			   drstrictBean.setName(rs.getString("Name"));
			   drstrictBean.setAmphurid(rs.getInt("AmphurID"));
			   listDistrict.add(drstrictBean);
			}
		  
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
			  try {
				rs.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
		  return listDistrict;
	}
}




