package com.java.teacher.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.student.bean.ActivityBean;
import com.java.student.bean.CareerBean;
import com.java.student.bean.Coop03Bean;
import com.java.student.bean.EducationBean;
import com.java.student.bean.Language03Bean;
import com.java.student.bean.ProfileBean;
import com.java.student.bean.RelativeBean;
import com.java.student.bean.TrainingBean;
import com.java.student.bean.UserBean;
import com.java.util.PreparedStatementUtil;

public class Coop03Dao {

	public Coop03Bean SelectCoop03(int facid,int divid,int academic_id,int id_student_send_document,String checkLevelTeacher){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		Coop03Bean coop03Bean = new Coop03Bean();
		String query = "SELECT  tb_coop03.Num_relative,"
								+ "tb_coop03.My_relative,"
						        + "tb_coop03.Picture "
						    + "FROM tb_student_send_document "
						    + "JOIN tb_user  ON tb_user.ID = tb_student_send_document.UserID "
							+ "JOIN tb_coop03  ON tb_coop03.ID = tb_student_send_document.Coop03ID "
							+ "WHERE 	tb_student_send_document.ID = :id_student_send_document "
										  + "AND (tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 6 OR tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 3) " 
										  + "AND tb_user.FacID = :facid AND tb_user.DivID = :divid "
							              + "AND tb_student_send_document.Academic_year = :academic_id "
							              + "AND tb_user.RoleID = 1  LIMIT 1 ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id_student_send_document", id_student_send_document);
			preparedStatementUtil.setInt("facid", facid);
			preparedStatementUtil.setInt("divid", divid);
			preparedStatementUtil.setInt("academic_id", academic_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				coop03Bean.setNum_relative(rs.getString("Num_relative"));
				coop03Bean.setMy_relative(rs.getString("My_relative"));
				coop03Bean.setPicture(rs.getString("Picture"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return coop03Bean;
	}
	
	public UserBean SelectUser(int facid,int divid,int academic_id,int id_student_send_document,String checkLevelTeacher){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		UserBean userBean = new UserBean();
		String query = "SELECT  tb_user.StudentID,"
								+ "tb_title.Name_th AS title_name_th,"
								+ "tb_user.FirstName_th,"
								+ "tb_user.LastName_th,"
								+ "tb_title.Name_eng AS title_name_eng,"
								+ "tb_user.FirstName_eng,"
								+ "tb_user.LastName_eng,"
								+ "tb_faculty.Name AS facName,"
								+ "tb_division.Name AS divName "
						    + "FROM tb_student_send_document "
						    + "JOIN tb_user  ON tb_user.ID = tb_student_send_document.UserID "
							+ "JOIN tb_title  ON tb_title.ID = tb_user.TitleID "
							+ "JOIN tb_faculty  ON tb_faculty.ID = tb_user.FacID "
							+ "JOIN tb_division  ON tb_division.ID = tb_user.DivID "
							+ "WHERE 	tb_student_send_document.ID = :id_student_send_document "
										  + "AND (tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 6 OR tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 3) " 
										  + "AND tb_user.FacID = :facid AND tb_user.DivID = :divid "
							              + "AND tb_student_send_document.Academic_year = :academic_id "
							              + "AND tb_user.RoleID = 1  LIMIT 1 ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id_student_send_document", id_student_send_document);
			preparedStatementUtil.setInt("facid", facid);
			preparedStatementUtil.setInt("divid", divid);
			preparedStatementUtil.setInt("academic_id", academic_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				userBean.setStudentid(rs.getString("StudentID"));
				userBean.setTitlename_th(rs.getString("title_name_th"));
				userBean.setFirstname_th(rs.getString("FirstName_th"));
				userBean.setLastname_th(rs.getString("LastName_th"));
				userBean.setTitlename_eng(rs.getString("title_name_eng"));
				userBean.setFirstname_eng(rs.getString("FirstName_eng"));
				userBean.setLastname_eng(rs.getString("LastName_eng"));
				userBean.setFacname(rs.getString("facName"));
				userBean.setDivname(rs.getString("divName"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return userBean;
	}
	
	public ProfileBean SelectProfile(int facid,int divid,int academic_id,int id_student_send_document,String checkLevelTeacher){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ProfileBean profileBean = new ProfileBean();
		String query = "SELECT  tb_profile.ClassYear,"
				
								+ "tb_profile.GroupStudent,"
								+ "tb_title.Name_th AS title_name_th,"
								+ "tb_profile.FirstNameAdvisor,"
								+ "tb_profile.LastNameAdvisor,"
								+ "tb_profile.Grade,"
								+ "tb_profile.GradeTotal,"
		
								+ "tb_profile.Id_card,"
								+ "tb_profile.Issue_at,"
								+ "tb_profile.Issue_date,"
								+ "tb_profile.Expiry_date,"
								+ "tb_profile.Race,"
								+ "tb_profile.Nationality,"
								+ "tb_profile.Religion,"
								+ "tb_profile.Age,"
								+ "tb_profile.Birthday,"
								+ "tb_profile.Place_birth,"
								+ "tb_profile.Sex,"
								+ "tb_profile.Height,"
								+ "tb_profile.Weight,"
								+ "tb_profile.Congenital_disease "
						    + "FROM tb_student_send_document "
						    + "JOIN tb_user  ON tb_user.ID = tb_student_send_document.UserID "
							+ "JOIN tb_profile  ON tb_profile.ID = tb_student_send_document.ProfileID "
							+ "JOIN tb_title  ON tb_title.ID = tb_profile.TitleID "
							+ "WHERE 	tb_student_send_document.ID = :id_student_send_document "
										  + "AND (tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 6 OR tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 3) " 
										  + "AND tb_user.FacID = :facid AND tb_user.DivID = :divid "
							              + "AND tb_student_send_document.Academic_year = :academic_id "
							              + "AND tb_user.RoleID = 1  LIMIT 1  ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id_student_send_document", id_student_send_document);
			preparedStatementUtil.setInt("facid", facid);
			preparedStatementUtil.setInt("divid", divid);
			preparedStatementUtil.setInt("academic_id", academic_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				 profileBean.setClassyear(rs.getString("ClassYear"));
				 profileBean.setGroupstudent(rs.getString("GroupStudent"));
				 profileBean.setTitlename_th(rs.getString("title_name_th"));
				 profileBean.setFirstnameadvisor(rs.getString("FirstNameAdvisor"));
				 profileBean.setLastnameadvisor(rs.getString("LastNameAdvisor"));
				 profileBean.setGrade(rs.getString("Grade"));
				 profileBean.setGradetotal(rs.getString("GradeTotal"));
				 profileBean.setId_card(rs.getString("Id_card"));
				 profileBean.setIssue_at(rs.getString("Issue_at"));
				 profileBean.setIssue_date(splitDate(rs.getString("Issue_date")));
				 profileBean.setExpiry_date(splitDate(rs.getString("Expiry_date")));
				 profileBean.setRace(rs.getString("Race"));
				 profileBean.setNationality(rs.getString("Nationality"));
				 profileBean.setReligion(rs.getString("Religion"));
				 profileBean.setAge(rs.getString("Age"));
				 profileBean.setBirthday(splitDate(rs.getString("Birthday")));
				 profileBean.setPlace_birth(rs.getString("Place_birth"));
				 profileBean.setSex(rs.getString("Sex"));
				 profileBean.setHeight(rs.getString("Height"));
				 profileBean.setWeight(rs.getString("Weight"));
				 profileBean.setCongenital_disease(rs.getString("Congenital_disease"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return profileBean;
	}
	
	public RelativeBean SelectRelative(int facid,int divid,int academic_id,int id_student_send_document,String relative_type,String checkLevelTeacher){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		RelativeBean relativeBean = new RelativeBean();
		String query = "SELECT  tb_title.Name_th AS title_name_th,"
								+ "tb_relative.FirstName,"
								+ "tb_relative.LastName,"
								+ "tb_relative.Age,"
								+ "tb_relative.Occupation,"
								+ "tb_relative.Position "
						    + "FROM tb_student_send_document "
						    + "JOIN tb_user  ON tb_user.ID = tb_student_send_document.UserID "
							+ "JOIN tb_coop03  ON tb_coop03.ID = tb_student_send_document.Coop03ID "
							+ "JOIN tb_relative  ON tb_relative.Coop03ID = tb_coop03.ID "
							+ "JOIN tb_title  ON tb_title.ID = tb_relative.TitleID "
							+ "WHERE 	tb_student_send_document.ID = :id_student_send_document "
										  + "AND (tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 6 OR tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 3) " 
										  + "AND tb_user.FacID = :facid AND tb_user.DivID = :divid "
							              + "AND tb_student_send_document.Academic_year = :academic_id "
							              + "AND tb_relative.Type = :relative_type "
							              + "AND tb_user.RoleID = 1  LIMIT 1  ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id_student_send_document", id_student_send_document);
			preparedStatementUtil.setInt("facid", facid);
			preparedStatementUtil.setInt("divid", divid);
			preparedStatementUtil.setInt("academic_id", academic_id);
			preparedStatementUtil.setString("relative_type", relative_type);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				relativeBean.setTitle_th(rs.getString("title_name_th"));
				relativeBean.setFirstname(rs.getString("FirstName"));
				relativeBean.setLastname(rs.getString("LastName"));
				relativeBean.setAge(rs.getString("Age"));
				relativeBean.setOccupation(rs.getString("Occupation"));
				relativeBean.setPosition(rs.getString("Position"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return relativeBean;
	}
	
	public EducationBean SelectEducation(int facid,int divid,int academic_id,int id_student_send_document,String education_type,String checkLevelTeacher){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		EducationBean educationBean = new EducationBean();
		String query = "SELECT  tb_education.Name,"
								+ "tb_education.Year_attended,"
								+ "tb_education.Year_graduated,"
								+ "tb_education.Certificate,"
								+ "tb_education.Major "
						    + "FROM tb_student_send_document "
						    + "JOIN tb_user  ON tb_user.ID = tb_student_send_document.UserID "
							+ "JOIN tb_coop03  ON tb_coop03.ID = tb_student_send_document.Coop03ID "
							+ "JOIN tb_education  ON tb_education.Coop03ID = tb_coop03.ID "
							+ "WHERE 	tb_student_send_document.ID = :id_student_send_document "
										  + "AND (tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 6 OR tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 3) " 
										  + "AND tb_user.FacID = :facid AND tb_user.DivID = :divid "
							              + "AND tb_student_send_document.Academic_year = :academic_id "
							              + "AND tb_education.Type = :education_type "
							              + "AND tb_user.RoleID = 1  LIMIT 1  ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id_student_send_document", id_student_send_document);
			preparedStatementUtil.setInt("facid", facid);
			preparedStatementUtil.setInt("divid", divid);
			preparedStatementUtil.setInt("academic_id", academic_id);
			preparedStatementUtil.setString("education_type", education_type);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				 educationBean.setName(rs.getString("Name"));
				 educationBean.setYear_attended(rs.getString("Year_attended"));
				 educationBean.setYear_graduated(rs.getString("Year_graduated"));
				 educationBean.setCertificate(rs.getString("Certificate"));
				 educationBean.setMajor(rs.getString("Major"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return educationBean;
	}
	
	public TrainingBean SelectTraining(int facid,int divid,int academic_id,int id_student_send_document,String training_type,String checkLevelTeacher){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		TrainingBean trainingBean = new TrainingBean();
		String query = "SELECT  tb_training.StartDate,"
								+ "tb_training.StopDate,"
								+ "tb_training.Place,"
								+ "tb_training.Position "
						    + "FROM tb_student_send_document "
						    + "JOIN tb_user  ON tb_user.ID = tb_student_send_document.UserID "
							+ "JOIN tb_coop03  ON tb_coop03.ID = tb_student_send_document.Coop03ID "
							+ "JOIN tb_training  ON tb_training.Coop03ID = tb_coop03.ID "
							+ "WHERE 	tb_student_send_document.ID = :id_student_send_document "
										  + "AND (tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 6 OR tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 3) " 
										  + "AND tb_user.FacID = :facid AND tb_user.DivID = :divid "
							              + "AND tb_student_send_document.Academic_year = :academic_id "
							              + "AND tb_training.Type = :training_type "
							              + "AND tb_user.RoleID = 1  LIMIT 1  ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id_student_send_document", id_student_send_document);
			preparedStatementUtil.setInt("facid", facid);
			preparedStatementUtil.setInt("divid", divid);
			preparedStatementUtil.setInt("academic_id", academic_id);
			preparedStatementUtil.setString("training_type", training_type);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				trainingBean.setStart_date(rs.getString("StartDate"));
				trainingBean.setStop_date(rs.getString("StopDate"));
				trainingBean.setPlace(rs.getString("Place"));
				trainingBean.setPosition(rs.getString("Position"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return trainingBean;
	}
	
	public CareerBean SelectCareer(int facid,int divid,int academic_id,int id_student_send_document,String career_type,String checkLevelTeacher){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		CareerBean careerBean = new CareerBean();
		String query = "SELECT  tb_career.Name "
						    + "FROM tb_student_send_document "
						    + "JOIN tb_user  ON tb_user.ID = tb_student_send_document.UserID "
							+ "JOIN tb_coop03  ON tb_coop03.ID = tb_student_send_document.Coop03ID "
							+ "JOIN tb_career  ON tb_career.Coop03ID = tb_coop03.ID "
							+ "WHERE 	tb_student_send_document.ID = :id_student_send_document "
										  + "AND (tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 6 OR tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 3) " 
										  + "AND tb_user.FacID = :facid AND tb_user.DivID = :divid "
							              + "AND tb_student_send_document.Academic_year = :academic_id "
							              + "AND tb_career.Type = :career_type "
							              + "AND tb_user.RoleID = 1   LIMIT 1 ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id_student_send_document", id_student_send_document);
			preparedStatementUtil.setInt("facid", facid);
			preparedStatementUtil.setInt("divid", divid);
			preparedStatementUtil.setInt("academic_id", academic_id);
			preparedStatementUtil.setString("career_type", career_type);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				careerBean.setName(rs.getString("Name"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return careerBean;
	}
	
	public ActivityBean SelectActivity(int facid,int divid,int academic_id,int id_student_send_document,String activity_type,String checkLevelTeacher){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ActivityBean activityBean = new ActivityBean();
		String query = "SELECT  tb_activity.Datetime,"
							+ "tb_activity.Position "
						    + "FROM tb_student_send_document "
						    + "JOIN tb_user  ON tb_user.ID = tb_student_send_document.UserID "
							+ "JOIN tb_coop03  ON tb_coop03.ID = tb_student_send_document.Coop03ID "
							+ "JOIN tb_activity  ON tb_activity.Coop03ID = tb_coop03.ID "
							+ "WHERE 	tb_student_send_document.ID = :id_student_send_document "
										  + "AND (tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 6 OR tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 3) " 
										  + "AND tb_user.FacID = :facid AND tb_user.DivID = :divid "
							              + "AND tb_student_send_document.Academic_year = :academic_id "
							              + "AND tb_activity.Type = :activity_type "
							              + "AND tb_user.RoleID = 1  LIMIT 1 ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id_student_send_document", id_student_send_document);
			preparedStatementUtil.setInt("facid", facid);
			preparedStatementUtil.setInt("divid", divid);
			preparedStatementUtil.setInt("academic_id", academic_id);
			preparedStatementUtil.setString("activity_type", activity_type);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				activityBean.setDate_time(rs.getString("Datetime"));
				activityBean.setPosition(rs.getString("Position"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return activityBean;
	}
	
	public Language03Bean SelectLanguage03(int facid,int divid,int academic_id,int id_student_send_document,String checkLevelTeacher){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		Language03Bean language03Bean = new Language03Bean();
		String query = "SELECT  tb_language03.Language_eng,"
							+ "tb_language03.Level_eng_Listen,"
							+ "tb_language03.Level_eng_Speak,"
							+ "tb_language03.Level_eng_Write,"
							+ "tb_language03.Language_chi,"
							+ "tb_language03.Level_chi_Listen,"
							+ "tb_language03.Level_chi_Speak,"
							+ "tb_language03.Level_chi_Write,"
							+ "tb_language03.Language_other,"
							+ "tb_language03.Level_other_Listen,"
							+ "tb_language03.Level_other_Speak,"
							+ "tb_language03.Level_other_Write,"
							+ "tb_language03.Input_other "
						    + "FROM tb_student_send_document "
						    + "JOIN tb_user  ON tb_user.ID = tb_student_send_document.UserID "
							+ "JOIN tb_coop03  ON tb_coop03.ID = tb_student_send_document.Coop03ID "
							+ "JOIN tb_language03  ON tb_language03.Coop03ID = tb_coop03.ID "
							+ "WHERE 	tb_student_send_document.ID = :id_student_send_document "
										  + "AND (tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 6 OR tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 3) " 
										  + "AND tb_user.FacID = :facid AND tb_user.DivID = :divid "
							              + "AND tb_student_send_document.Academic_year = :academic_id "
							              + "AND tb_user.RoleID = 1  LIMIT 1 ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id_student_send_document", id_student_send_document);
			preparedStatementUtil.setInt("facid", facid);
			preparedStatementUtil.setInt("divid", divid);
			preparedStatementUtil.setInt("academic_id", academic_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				language03Bean.setLanguage_eng(rs.getString("Language_eng"));
				language03Bean.setLevel_eng_listen(rs.getString("Level_eng_Listen"));
				language03Bean.setLevel_eng_speak(rs.getString("Level_eng_Speak"));
				language03Bean.setLevel_eng_write(rs.getString("Level_eng_Write"));
				language03Bean.setLanguage_chi(rs.getString("Language_chi"));
				language03Bean.setLevel_chi_listen(rs.getString("Level_chi_Listen"));
				language03Bean.setLevel_chi_speak(rs.getString("Level_chi_Speak"));
				language03Bean.setLevel_chi_write(rs.getString("Level_chi_Write"));
				language03Bean.setLanguage_other(rs.getString("Language_other"));
				language03Bean.setLevel_other_listen(rs.getString("Level_other_Listen"));
				language03Bean.setLevel_other_speak(rs.getString("Level_other_Speak"));
				language03Bean.setLevel_other_write(rs.getString("Level_other_Write"));
				language03Bean.setInput_other(rs.getString("Input_other"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return language03Bean;
	}
	
	private String splitDate(String date){
		String[] str = date.split("-");    
		return str[2]+"/"+str[1]+"/"+(Integer.parseInt(str[0])+543);
	}
}
