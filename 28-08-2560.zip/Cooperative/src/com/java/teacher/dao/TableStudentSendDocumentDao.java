package com.java.teacher.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.teacher.bean.ListStudentSendDocumentBean;
import com.java.teacher.bean.ProfileStudentSendDocumentBean;
import com.java.util.PreparedStatementUtil;

public class TableStudentSendDocumentDao {
	
	public ArrayList<ListStudentSendDocumentBean> SelectListStudentSendDocument(int lv_apStatusID,int facid,int divid,int academic_id,String checkLevelTeacher){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		ArrayList<ListStudentSendDocumentBean> list = new ArrayList<>();
		String query =  "SELECT  tb_user.StudentID,"
						+ "tb_title.Name_th AS titleName_th,"
				        + "tb_user.FirstName_th,"
				        + "tb_user.LastName_th,"
				        + "tb_division.Name AS divName,"
				        + "tb_profile.GradeTotal,"
				        + "tb_student_send_document.ID,"
				        + "tb_student_send_document.UserID,"
				        + "tb_teacher_check_document."+checkLevelTeacher+"_02Note,"
				        + "tb_teacher_check_document."+checkLevelTeacher+"_03Note "
				
				        + "FROM tb_student_send_document "
				        + "JOIN tb_user  ON tb_user.ID = tb_student_send_document.UserID "
				        + "JOIN tb_title  ON tb_title.ID = tb_user.TitleID "
				        + "JOIN tb_division  ON tb_division.ID = tb_user.DivID "
				        + "JOIN tb_profile  ON tb_profile.ID = tb_student_send_document.ProfileID "
						+ "JOIN tb_teacher_check_document  ON tb_student_send_document.ID = tb_teacher_check_document.DocID "
				
				        + "WHERE tb_student_send_document."+checkLevelTeacher+"_ApStatusID = :lv_ap_statusid "
					    	+ "AND tb_user.FacID = :facid AND tb_user.DivID = :divid "
				            + "AND tb_student_send_document.Academic_year = :academic_id "
				            + "AND tb_user.RoleID = 1 ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("lv_ap_statusid", lv_apStatusID);
			preparedStatementUtil.setInt("facid", facid);
			preparedStatementUtil.setInt("divid", divid);
			preparedStatementUtil.setInt("academic_id", academic_id);
			rs = preparedStatementUtil.executeQuery();
			while(rs.next()){
				ListStudentSendDocumentBean studentSendDocumentBean = new ListStudentSendDocumentBean();
				studentSendDocumentBean.setStudent_id(rs.getString("StudentID"));
				studentSendDocumentBean.setTitle_name_th(rs.getString("titleName_th"));
				studentSendDocumentBean.setFirstname(rs.getString("FirstName_th"));
				studentSendDocumentBean.setLastname(rs.getString("LastName_th"));
				studentSendDocumentBean.setDivision_name(rs.getString("divName"));
				studentSendDocumentBean.setGrade_total(rs.getString("GradeTotal"));
				studentSendDocumentBean.setId_student_send_document(rs.getInt("ID"));
				studentSendDocumentBean.setUserid(rs.getInt("UserID"));
				studentSendDocumentBean.setLv_02note(rs.getString(checkLevelTeacher+"_02Note"));
				studentSendDocumentBean.setLv_03note(rs.getString(checkLevelTeacher+"_03Note"));
				list.add(studentSendDocumentBean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public ProfileStudentSendDocumentBean SelectProfileStudentSendDocument(int facid,int divid,int academic_id,int id_student_send_document,String checkLevelTeacher){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		ProfileStudentSendDocumentBean profileStudentSendDocumentBean = new ProfileStudentSendDocumentBean();
		
		String query =	"SELECT  tb_coop03.Picture,"
						+ "tb_transcript.File AS Transcript,"
						+ "tb_user.StudentID,"
				        + "tb_title.Name_th AS titleName_th,"
				        + "tb_user.FirstName_th,"
				        + "tb_user.LastName_th,"
				        + "tb_title.Name_eng AS titleName_eng,"
				        + "tb_user.FirstName_eng,"
				        + "tb_user.LastName_eng,"
				        + "tb_profile.ClassYear,"
				        + "tb_profile.GroupStudent,"
				        + "tb_division.Name AS divName,"
				        + "tb_teacher_check_document."+checkLevelTeacher+"_02StatusID,"
				        + "tb_teacher_check_document."+checkLevelTeacher+"_03StatusID,"
				        + "tb_teacher_check_document."+checkLevelTeacher+"_02Note,"
				        + "tb_teacher_check_document."+checkLevelTeacher+"_03Note,"
				        + "tb_student_send_document."+checkLevelTeacher+"_ApStatusID,"
				        + "tb_student_send_document.ID "
					 + "FROM tb_student_send_document "
						+ "JOIN tb_coop03  ON tb_coop03.ID = tb_student_send_document.Coop03ID "
				        + "JOIN tb_transcript  ON tb_transcript.ID = tb_student_send_document.TranscriptID "
				        + "JOIN tb_user  ON tb_user.ID = tb_student_send_document.UserID "
				        + "JOIN tb_title  ON tb_title.ID = tb_user.TitleID "
				        + "JOIN tb_division  ON tb_division.ID = tb_user.DivID "
				        + "JOIN tb_profile  ON tb_profile.ID = tb_student_send_document.ProfileID "
						+ "JOIN tb_teacher_check_document  ON tb_student_send_document.ID = tb_teacher_check_document.DocID "
				        
				         + "WHERE  tb_student_send_document.ID = :id_student_send_document  "
								+ "AND (tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 6 OR tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 3) "		
								+ "AND tb_user.FacID = :facid AND tb_user.DivID = :divid  "
				                + "AND tb_student_send_document.Academic_year = :academic_id "
				                + "AND tb_user.RoleID = 1  LIMIT 1 ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id_student_send_document", id_student_send_document);
			preparedStatementUtil.setInt("facid", facid);
			preparedStatementUtil.setInt("divid", divid);
			preparedStatementUtil.setInt("academic_id", academic_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				profileStudentSendDocumentBean.setProfile_pic(rs.getString("Picture"));
				profileStudentSendDocumentBean.setTranscript(rs.getString("Transcript"));
				profileStudentSendDocumentBean.setStudent_id(rs.getString("StudentID"));
				profileStudentSendDocumentBean.setTitle_name_th(rs.getString("titleName_th"));
				profileStudentSendDocumentBean.setFirstname_th(rs.getString("FirstName_th"));
				profileStudentSendDocumentBean.setLastname_th(rs.getString("LastName_th"));
				profileStudentSendDocumentBean.setTitle_name_eng(rs.getString("titleName_eng"));
				profileStudentSendDocumentBean.setFirstname_eng(rs.getString("FirstName_eng"));
				profileStudentSendDocumentBean.setLastname_eng(rs.getString("LastName_eng"));
				profileStudentSendDocumentBean.setClassyear(rs.getString("ClassYear"));
				profileStudentSendDocumentBean.setGroupstudent(rs.getString("GroupStudent"));
				profileStudentSendDocumentBean.setDivision_name(rs.getString("divName"));
				profileStudentSendDocumentBean.setLv_02status_id(rs.getInt(checkLevelTeacher+"_02StatusID"));
				profileStudentSendDocumentBean.setLv_03status_id(rs.getInt(checkLevelTeacher+"_03StatusID"));
				profileStudentSendDocumentBean.setLv_02note(rs.getString(checkLevelTeacher+"_02Note"));
				profileStudentSendDocumentBean.setLv_03note(rs.getString(checkLevelTeacher+"_03Note"));
				profileStudentSendDocumentBean.setLv_ap_status(rs.getInt(checkLevelTeacher+"_ApStatusID"));
				profileStudentSendDocumentBean.setId_student_send_document(rs.getInt("ID"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return profileStudentSendDocumentBean;
	}
	
	public ProfileStudentSendDocumentBean SelectProfileStudentSendDocument(int divid,int academic_id,int student_user_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ProfileStudentSendDocumentBean profileStudentSendDocumentBean = new ProfileStudentSendDocumentBean();
		
		String query =	"SELECT  tb_coop03.Picture,"
						+ "tb_user.StudentID,"
				        + "tb_title.Name_th AS titleName_th,"
				        + "tb_user.FirstName_th,"
				        + "tb_user.LastName_th,"
				        + "tb_title.Name_eng AS titleName_eng,"
				        + "tb_user.FirstName_eng,"
				        + "tb_user.LastName_eng,"
				        + "tb_profile.ClassYear,"
				        + "tb_profile.GroupStudent,"
				        + "tb_division.Name AS divName,"
				        + "tb_user.ID AS UserID "
					 + "FROM tb_student_send_document "
					 	+ "JOIN tb_coop03  ON tb_coop03.ID = tb_student_send_document.Coop03ID "
				        + "JOIN tb_user  ON tb_user.ID = tb_student_send_document.UserID "
				        + "JOIN tb_title  ON tb_title.ID = tb_user.TitleID "
				        + "JOIN tb_division  ON tb_division.ID = tb_user.DivID "
				        + "JOIN tb_profile  ON tb_profile.ID = tb_student_send_document.ProfileID "
				        
				         + "WHERE tb_student_send_document.UserID = :student_user_id "	
								+ "AND tb_user.DivID = :divid  "
				                + "AND tb_student_send_document.Academic_year = :academic_id "
				                + "AND tb_user.RoleID = 1  LIMIT 1 ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("student_user_id", student_user_id);
			preparedStatementUtil.setInt("divid", divid);
			preparedStatementUtil.setInt("academic_id", academic_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				profileStudentSendDocumentBean.setProfile_pic(rs.getString("Picture"));
				profileStudentSendDocumentBean.setStudent_id(rs.getString("StudentID"));
				profileStudentSendDocumentBean.setTitle_name_th(rs.getString("titleName_th"));
				profileStudentSendDocumentBean.setFirstname_th(rs.getString("FirstName_th"));
				profileStudentSendDocumentBean.setLastname_th(rs.getString("LastName_th"));
				profileStudentSendDocumentBean.setTitle_name_eng(rs.getString("titleName_eng"));
				profileStudentSendDocumentBean.setFirstname_eng(rs.getString("FirstName_eng"));
				profileStudentSendDocumentBean.setLastname_eng(rs.getString("LastName_eng"));
				profileStudentSendDocumentBean.setClassyear(rs.getString("ClassYear"));
				profileStudentSendDocumentBean.setGroupstudent(rs.getString("GroupStudent"));
				profileStudentSendDocumentBean.setDivision_name(rs.getString("divName"));
				profileStudentSendDocumentBean.setUser_id(rs.getInt("UserID"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return profileStudentSendDocumentBean;
	}
	
	public int SelectUseridStudent(int id_student_send_document){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		int userid_student = 0;
		
		String query =	"SELECT  tb_student_send_document.UserID "
					 + "FROM tb_student_send_document "
				         + "WHERE  tb_student_send_document.ID = :id_student_send_document  LIMIT 1 ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id_student_send_document", id_student_send_document);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				userid_student = rs.getInt("UserID");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return userid_student;
	}
	
	public void UpdateApprovalStatus(int lv_ap_status_id,int lv_ap_status_by,String date,int id_student_send_document,String checkLevelTeacher){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
			  
			  String query = "UPDATE tb_student_send_document SET "
		   				+ checkLevelTeacher+"_ApStatusID = :lv_ap_status_id,"
		   				+ checkLevelTeacher+"_ApStatusBy = :lv_ap_status_by, "
		   				+ checkLevelTeacher+"_ApStatusDate = :lv_ap_status_date ";
		   				
			  if("Lv1".equals(checkLevelTeacher) && lv_ap_status_id == 2){
				  // lv2_ap_status set  = �ʹ��Թ���
				  query = query +",Lv2_ApStatusID = 6  ";
				  
				  // update  tb_teacher_check_document
				  UpdateWaitingToCheck(id_student_send_document);
			  }
			  
			  query = query +"WHERE tb_student_send_document.ID = :id_student_send_document ";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("lv_ap_status_id",lv_ap_status_id);
			   preparedStatementUtil.setInt("lv_ap_status_by",lv_ap_status_by);
			   preparedStatementUtil.setString("lv_ap_status_date",date);
			   preparedStatementUtil.setInt("id_student_send_document",id_student_send_document);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void UpdateWaitingToCheck(int id_student_send_document){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
			// 4 = �͵�Ǩ�ͺ
			  String query = "UPDATE tb_teacher_check_document SET "
		   				+ "Lv2_02StatusID = 4 , "
		   				+ "Lv2_03StatusID = 4 "
			 			+ "WHERE tb_teacher_check_document.DocID = :id_student_send_document ";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("id_student_send_document",id_student_send_document);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public Boolean checkDivisionStudent(int id_student_send_document,int division_teacher_id,int academic_id,String checkLevelTeacher){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		Boolean check = false;
		String query =	"SELECT True as isTrue "
					 + "FROM tb_student_send_document "
				        + "JOIN tb_user  ON tb_user.ID = tb_student_send_document.UserID "
				         + "WHERE  tb_student_send_document.ID = :id_student_send_document  "
								+ "AND (tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 6 OR tb_student_send_document."+checkLevelTeacher+"_ApStatusID = 3) "		
								+ "AND tb_user.DivID = :divid  "
				                + "AND tb_student_send_document.Academic_year = :academic_id "
				                + "AND tb_user.RoleID = 1"
				                + " LIMIT 1 ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id_student_send_document", id_student_send_document);
			preparedStatementUtil.setInt("divid", division_teacher_id);
			preparedStatementUtil.setInt("academic_id", academic_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				check = rs.getBoolean("isTrue");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return check;
	}
}
