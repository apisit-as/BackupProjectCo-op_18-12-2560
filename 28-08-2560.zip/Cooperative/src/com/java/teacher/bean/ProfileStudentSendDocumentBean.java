package com.java.teacher.bean;

public class ProfileStudentSendDocumentBean {
	private String profile_pic;
	private String coop02;
	private String coop03;
	private String transcript;
	private String student_id;
	private String title_name_th;
	private String firstname_th;
	private String lastname_th;
	private String title_name_eng;
	private String firstname_eng;
	private String lastname_eng;
	private String classyear;
	private String groupstudent;
	private String division_name;
	private int lv_02status_id;
	private int lv_03status_id;
	private String lv_02note;
	private String lv_03note;
	private int lv_ap_status;
	private int id_student_send_document;
	private String role_name;
	private int user_id;
	public String getProfile_pic() {
		return profile_pic;
	}
	public void setProfile_pic(String profile_pic) {
		this.profile_pic = profile_pic;
	}
	public String getCoop02() {
		return coop02;
	}
	public void setCoop02(String coop02) {
		this.coop02 = coop02;
	}
	public String getCoop03() {
		return coop03;
	}
	public void setCoop03(String coop03) {
		this.coop03 = coop03;
	}
	public String getTranscript() {
		return transcript;
	}
	public void setTranscript(String transcript) {
		this.transcript = transcript;
	}
	public String getStudent_id() {
		return student_id;
	}
	public void setStudent_id(String student_id) {
		this.student_id = student_id;
	}
	public String getTitle_name_th() {
		return title_name_th;
	}
	public void setTitle_name_th(String title_name_th) {
		this.title_name_th = title_name_th;
	}
	public String getFirstname_th() {
		return firstname_th;
	}
	public void setFirstname_th(String firstname_th) {
		this.firstname_th = firstname_th;
	}
	public String getLastname_th() {
		return lastname_th;
	}
	public void setLastname_th(String lastname_th) {
		this.lastname_th = lastname_th;
	}
	public String getTitle_name_eng() {
		return title_name_eng;
	}
	public void setTitle_name_eng(String title_name_eng) {
		this.title_name_eng = title_name_eng;
	}
	public String getFirstname_eng() {
		return firstname_eng;
	}
	public void setFirstname_eng(String firstname_eng) {
		this.firstname_eng = firstname_eng;
	}
	public String getLastname_eng() {
		return lastname_eng;
	}
	public void setLastname_eng(String lastname_eng) {
		this.lastname_eng = lastname_eng;
	}
	public String getClassyear() {
		return classyear;
	}
	public void setClassyear(String classyear) {
		this.classyear = classyear;
	}
	public String getGroupstudent() {
		return groupstudent;
	}
	public void setGroupstudent(String groupstudent) {
		this.groupstudent = groupstudent;
	}
	public String getDivision_name() {
		return division_name;
	}
	public void setDivision_name(String division_name) {
		this.division_name = division_name;
	}
	public int getLv_02status_id() {
		return lv_02status_id;
	}
	public void setLv_02status_id(int lv_02status_id) {
		this.lv_02status_id = lv_02status_id;
	}
	public int getLv_03status_id() {
		return lv_03status_id;
	}
	public void setLv_03status_id(int lv_03status_id) {
		this.lv_03status_id = lv_03status_id;
	}
	public String getLv_02note() {
		return lv_02note;
	}
	public void setLv_02note(String lv_02note) {
		this.lv_02note = lv_02note;
	}
	public String getLv_03note() {
		return lv_03note;
	}
	public void setLv_03note(String lv_03note) {
		this.lv_03note = lv_03note;
	}
	public int getLv_ap_status() {
		return lv_ap_status;
	}
	public void setLv_ap_status(int lv_ap_status) {
		this.lv_ap_status = lv_ap_status;
	}
	public int getId_student_send_document() {
		return id_student_send_document;
	}
	public void setId_student_send_document(int id_student_send_document) {
		this.id_student_send_document = id_student_send_document;
	}
	public String getRole_name() {
		return role_name;
	}
	public void setRole_name(String role_name) {
		this.role_name = role_name;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
}
