package com.java.teacher.bean;

public class Coop02Bean {
	private String talent;
	private String region;
	private String select_job;
	private String interest;
	private String grade;
	private String gradetotal;
	private String semester;
	private String academic_year;
	public String getTalent() {
		return talent;
	}
	public void setTalent(String talent) {
		this.talent = talent;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getSelect_job() {
		return select_job;
	}
	public void setSelect_job(String select_job) {
		this.select_job = select_job;
	}
	public String getInterest() {
		return interest;
	}
	public void setInterest(String interest) {
		this.interest = interest;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getGradetotal() {
		return gradetotal;
	}
	public void setGradetotal(String gradetotal) {
		this.gradetotal = gradetotal;
	}
	public String getSemester() {
		return semester;
	}
	public void setSemester(String semester) {
		this.semester = semester;
	}
	public String getAcademic_year() {
		return academic_year;
	}
	public void setAcademic_year(String academic_year) {
		this.academic_year = academic_year;
	}
}
