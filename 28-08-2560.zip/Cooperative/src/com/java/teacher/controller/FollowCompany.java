package com.java.teacher.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.admin.bean.AcademicYearBean;
import com.java.admin.dao.TableAcademicYearDao;
import com.java.teacher.bean.ListFollowCompanyBean;
import com.java.teacher.dao.FollowDocumentDao;
import com.java.util.SessionExpire;

/**
 * Servlet implementation class FollowCompany
 */
@WebServlet("/FollowCompany")
public class FollowCompany extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FollowCompany() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
			HttpSession session = request.getSession();
			
			// check role session expire
		    if(session.getAttribute("role") == null){
			  	SessionExpire sessionExpire = new SessionExpire();
				response.sendRedirect(sessionExpire.getSendRedirect()); // send redirect to Login page
				return;
		    }			
			
			String role = session.getAttribute("role").toString();
			if((role.equals("teacher0")) || (role.equals("teacher1")) || (role.equals("teacher2"))){

				// set Academic Year
				TableAcademicYearDao tableAcademicYear = new TableAcademicYearDao();
				AcademicYearBean academicYearBean = new AcademicYearBean();
				academicYearBean = tableAcademicYear.getAcademic();
				session.setAttribute("Semester", academicYearBean.getSemester());
				session.setAttribute("Academic_year", academicYearBean.getAcademic_year());
				session.setAttribute("academic_year_id", academicYearBean.getId());
				
				// list student
				FollowDocumentDao followDocumentDao = new FollowDocumentDao();
				ArrayList<ListFollowCompanyBean> listFollowCompanyBean = new ArrayList<>();
				int divid = Integer.parseInt(session.getAttribute("divID").toString()); 
				listFollowCompanyBean = followDocumentDao.SelectListStudentSelectCompany(academicYearBean.getId(),divid);
				
				request.setAttribute("listFollowCompanyBean", listFollowCompanyBean);
				
				doViewFollowCompany(request, response);
				
			}
		
	}

	private void doViewFollowCompany(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/teacher/follow_company.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
}
