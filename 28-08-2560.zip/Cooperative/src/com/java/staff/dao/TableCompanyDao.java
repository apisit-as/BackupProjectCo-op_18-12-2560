package com.java.staff.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.staff.bean.CompanyBean;
import com.java.util.PreparedStatementUtil;

public class TableCompanyDao {
	
	public void InsertCompany(CompanyBean companyBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "INSERT INTO tb_company"
		   									+ "(NameCompany,"
		   									+ "RegionCompany,"
		   									+ "AddressCompany,"
		   									+ "DistrictCompany,"
		   									+ "AmphurCompany,"
		   									+ "ProvinceCompany,"
		   									+ "PostcodeCompany,"
		   									+ "TelephoneCompany,"
		   									+ "FaxCompany,"
		   									+ "EmailCompany,"
		   									+ "TypeWorkCompany,"
		   									+ "PayYesCompany,"
		   									+ "TypeCompany,"
		   									+ "EmployeesCompany,"
		   									+ "ResidenceCompany,"
		   									+ "WelfarCompany,"
		   									+ "NameContact,"
		   									+ "TelephoneContact,"
		   									+ "MobileContact,"
		   									+ "FaxContact,"
		   									+ "EmailContact) "
					   		+ " VALUES(:name_company,"   
					   				+ ":region_company,"
					   				+ ":address_company,"
					   				+ ":district_company,"
					   				+ ":amphur_company,"
					   				+ ":province_company,"
					   				+ ":postcode_company,"
					   				+ ":telephone_company,"
					   				+ ":fax_company,"
					   				+ ":email_company,"
					   				+ ":type_work_company,"
					   				+ ":pay_yes_company,"
					   				+ ":type_company,"
					   				+ ":employees_company,"
					   				+ ":residence_company,"
					   				+ ":welfar_company,"
					   				+ ":name_contact,"
					   				+ ":telephone_contact,"
					   				+ ":mobile_contact,"
					   				+ ":fax_contact,"
					   				+ ":email_contact)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("name_company",companyBean.getName_company());
		   preparedStatementUtil.setInt("region_company",companyBean.getRegion_company_id());
		   preparedStatementUtil.setString("address_company",companyBean.getAddress_company());
		   preparedStatementUtil.setString("district_company",companyBean.getDistrict_company());
		   preparedStatementUtil.setString("amphur_company",companyBean.getAmphur_company());
		   preparedStatementUtil.setString("province_company",companyBean.getProvince_company());
		   preparedStatementUtil.setString("postcode_company",companyBean.getPostcode_company());
		   preparedStatementUtil.setString("telephone_company",companyBean.getTelephone_company());
		   preparedStatementUtil.setString("fax_company",companyBean.getFax_company());
		   preparedStatementUtil.setString("email_company",companyBean.getEmail_company());
		   preparedStatementUtil.setString("type_work_company",companyBean.getType_work_company());
		   preparedStatementUtil.setString("pay_yes_company",companyBean.getPay_yes_company());
		   preparedStatementUtil.setString("type_company",companyBean.getType_company());
		   preparedStatementUtil.setString("employees_company",companyBean.getEmployees_company());
		   preparedStatementUtil.setString("residence_company",companyBean.getResidence_company());
		   preparedStatementUtil.setString("welfar_company",companyBean.getWelfar_company());
		   preparedStatementUtil.setString("name_contact",companyBean.getName_contact());
		   preparedStatementUtil.setString("telephone_contact",companyBean.getTelephone_contact());
		   preparedStatementUtil.setString("mobile_contact",companyBean.getMobile_contact());
		   preparedStatementUtil.setString("fax_contact",companyBean.getFax_contact());
		   preparedStatementUtil.setString("email_contact",companyBean.getEmail_contact());
		   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void UpdateCompany(CompanyBean companyBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_company SET "
		   				+ "NameCompany = :name_company,"
		   				+ "RegionCompany = :region_company,"
		   				+ "AddressCompany = :address_company,"
		   				+ "DistrictCompany = :district_company,"
		   				+ "AmphurCompany = :amphur_company,"
		   				+ "ProvinceCompany = :province_company,"
		   				+ "PostcodeCompany = :postcode_company,"
		   				+ "TelephoneCompany = :telephone_company,"
		   				+ "FaxCompany = :fax_company,"
		   				+ "EmailCompany = :email_company,"
		   				+ "TypeWorkCompany = :type_work_company,"
		   				+ "PayYesCompany = :pay_yes_company,"
		   				+ "TypeCompany = :type_company,"
		   				+ "EmployeesCompany = :employees_company,"
		   				+ "ResidenceCompany = :residence_company,"
		   				+ "WelfarCompany = :welfar_company,"
		   				+ "NameContact = :name_contact,"
		   				+ "TelephoneContact = :telephone_contact,"
		   				+ "MobileContact = :mobile_contact,"
		   				+ "FaxContact = :fax_contact,"
		   				+ "EmailContact = :email_contact "
		   				+ "WHERE ID = :id ";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("name_company",companyBean.getName_company());
		   preparedStatementUtil.setInt("region_company",companyBean.getRegion_company_id());
		   preparedStatementUtil.setString("address_company",companyBean.getAddress_company());
		   preparedStatementUtil.setString("district_company",companyBean.getDistrict_company());
		   preparedStatementUtil.setString("amphur_company",companyBean.getAmphur_company());
		   preparedStatementUtil.setString("province_company",companyBean.getProvince_company());
		   preparedStatementUtil.setString("postcode_company",companyBean.getPostcode_company());
		   preparedStatementUtil.setString("telephone_company",companyBean.getTelephone_company());
		   preparedStatementUtil.setString("fax_company",companyBean.getFax_company());
		   preparedStatementUtil.setString("email_company",companyBean.getEmail_company());
		   preparedStatementUtil.setString("type_work_company",companyBean.getType_work_company());
		   preparedStatementUtil.setString("pay_yes_company",companyBean.getPay_yes_company());
		   preparedStatementUtil.setString("type_company",companyBean.getType_company());
		   preparedStatementUtil.setString("employees_company",companyBean.getEmployees_company());
		   preparedStatementUtil.setString("residence_company",companyBean.getResidence_company());
		   preparedStatementUtil.setString("welfar_company",companyBean.getWelfar_company());
		   preparedStatementUtil.setString("name_contact",companyBean.getName_contact());
		   preparedStatementUtil.setString("telephone_contact",companyBean.getTelephone_contact());
		   preparedStatementUtil.setString("mobile_contact",companyBean.getMobile_contact());
		   preparedStatementUtil.setString("fax_contact",companyBean.getFax_contact());
		   preparedStatementUtil.setString("email_contact",companyBean.getEmail_contact());
		   preparedStatementUtil.setInt("id",companyBean.getId());

		   preparedStatementUtil.execute();   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public ArrayList<CompanyBean> SelectListCompany(){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<CompanyBean> list = new ArrayList<>();
		String query =  "SELECT  tb_company.ID,"
				+ " tb_company.NameCompany,"
				+ " tb_company.AddressCompany,"
				+ " tb_company.RegionCompany AS regionID,"
				+ " tb_region.Name AS regionName,"
				+ " tb_company.ProvinceCompany,"
				+ " tb_company.TypeWorkCompany "
		        + "FROM tb_company "
		        + "JOIN tb_region  ON tb_region.ID = tb_company.RegionCompany ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			rs = prepareStatementUtil.executeQuery();
			while(rs.next()){
				CompanyBean companyBean = new CompanyBean();
				companyBean.setId(rs.getInt("ID"));
				companyBean.setName_company(rs.getString("NameCompany"));
				companyBean.setAddress_company(rs.getString("AddressCompany"));
				companyBean.setRegion_company_id(rs.getInt("regionID"));
				companyBean.setRegion_company_name(rs.getString("regionName"));
				companyBean.setProvince_company(rs.getString("ProvinceCompany"));
				companyBean.setType_work_company(rs.getString("TypeWorkCompany"));
				list.add(companyBean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}	
	
	public ArrayList<CompanyBean> SelectListCompanyExportExcel(){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<CompanyBean> list = new ArrayList<>();
		String query =  "SELECT  tb_company.NameCompany,"
				+ " tb_region.Name AS regionName,"
				+ " tb_company.AddressCompany,"
				+ " tb_company.DistrictCompany,"
				+ " tb_company.AmphurCompany,"
				+ " tb_company.ProvinceCompany,"
				+ " tb_company.PostcodeCompany,"
				+ " tb_company.TelephoneCompany,"
				+ " tb_company.FaxCompany,"
				+ " tb_company.EmailCompany,"
				+ " tb_company.TypeWorkCompany,"
				+ " tb_company.PayYesCompany,"
				+ " tb_company.TypeCompany,"
				+ " tb_company.EmployeesCompany,"
				+ " tb_company.ResidenceCompany,"
				+ " tb_company.WelfarCompany,"
				+ " tb_company.NameContact,"
				+ " tb_company.TelephoneContact,"
				+ " tb_company.MobileContact,"
				+ " tb_company.FaxContact,"
				+ " tb_company.EmailContact "
		        + "FROM tb_company "
		        + "JOIN tb_region  ON tb_region.ID = tb_company.RegionCompany ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			rs = prepareStatementUtil.executeQuery();
			while(rs.next()){
				CompanyBean companyBean = new CompanyBean();
				companyBean.setName_company(rs.getString("NameCompany"));
				companyBean.setRegion_company_name(rs.getString("regionName"));
				companyBean.setAddress_company(rs.getString("AddressCompany"));
				companyBean.setDistrict_company(rs.getString("DistrictCompany"));
				companyBean.setAmphur_company(rs.getString("AmphurCompany"));
				companyBean.setProvince_company(rs.getString("ProvinceCompany"));
				companyBean.setPostcode_company(rs.getString("PostcodeCompany"));
				companyBean.setTelephone_company(rs.getString("TelephoneCompany"));
				companyBean.setFax_company(rs.getString("FaxCompany"));
				companyBean.setEmail_company(rs.getString("EmailCompany"));
				companyBean.setType_work_company(rs.getString("TypeWorkCompany"));
				companyBean.setPay_yes_company(rs.getString("PayYesCompany"));
				companyBean.setType_company(rs.getString("TypeCompany"));
				companyBean.setEmployees_company(rs.getString("EmployeesCompany"));
				companyBean.setResidence_company(rs.getString("ResidenceCompany"));
				companyBean.setWelfar_company(rs.getString("WelfarCompany"));
				companyBean.setName_contact(rs.getString("NameContact"));
				companyBean.setTelephone_contact(rs.getString("TelephoneContact"));
				companyBean.setMobile_contact(rs.getString("MobileContact"));
				companyBean.setFax_contact(rs.getString("FaxContact"));
				companyBean.setEmail_contact(rs.getString("EmailContact"));
				list.add(companyBean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	
	public CompanyBean SelectCompany(int id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		CompanyBean companyBean = new CompanyBean();
		String query =  "SELECT * "
				        + "FROM tb_company "
						+ "WHERE ID = :id LIMIT 1";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("id",id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				companyBean.setId(rs.getInt("ID"));
				companyBean.setName_company(rs.getString("NameCompany"));
				companyBean.setRegion_company_id(rs.getInt("RegionCompany"));
				companyBean.setAddress_company(rs.getString("AddressCompany"));
				companyBean.setDistrict_company(rs.getString("DistrictCompany"));
				companyBean.setAmphur_company(rs.getString("AmphurCompany"));
				companyBean.setProvince_company(rs.getString("ProvinceCompany"));
				companyBean.setPostcode_company(rs.getString("PostcodeCompany"));
				companyBean.setTelephone_company(rs.getString("TelephoneCompany"));
				companyBean.setFax_company(rs.getString("FaxCompany"));
				companyBean.setEmail_company(rs.getString("EmailCompany"));
				companyBean.setType_work_company(rs.getString("TypeWorkCompany"));
				companyBean.setPay_yes_company(rs.getString("PayYesCompany"));
				companyBean.setType_company(rs.getString("TypeCompany"));
				companyBean.setEmployees_company(rs.getString("EmployeesCompany"));
				companyBean.setResidence_company(rs.getString("ResidenceCompany"));
				companyBean.setWelfar_company(rs.getString("WelfarCompany"));
				companyBean.setName_contact(rs.getString("NameContact"));
				companyBean.setTelephone_contact(rs.getString("TelephoneContact"));
				companyBean.setMobile_contact(rs.getString("MobileContact"));
				companyBean.setFax_contact(rs.getString("FaxContact"));
				companyBean.setEmail_contact(rs.getString("EmailContact"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return companyBean;
	}
	
	public void deleteCompany(int id){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "DELETE FROM tb_company WHERE ID = :id ";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("id", id);
		   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public ArrayList<String> getListTypeCompany(){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ArrayList<String> lsit = new ArrayList<>();
		String query = "SELECT type_company FROM tb_type_company_select "; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			rs = preparedStatementUtil.executeQuery();
			while(rs.next()){
				lsit.add(rs.getString("type_company"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return lsit;
	}
	
	public ArrayList<String> getListResidenceCompany(){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ArrayList<String> lsit = new ArrayList<>();
		String query = "SELECT Name FROM tb_residence_company_select "; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			rs = preparedStatementUtil.executeQuery();
			while(rs.next()){
				lsit.add(rs.getString("Name"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return lsit;
	}
}
