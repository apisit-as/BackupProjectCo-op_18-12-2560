package com.java.staff.bean;

public class StudentSelectComapnyApStatusBean {
	private int staff_ap_status_id;
	private int staff_ap_status_by;
	private String staff_ap_status_date;
	private String comment;
	private String file;
	private int user_student_id;
	public int getStaff_ap_status_id() {
		return staff_ap_status_id;
	}
	public void setStaff_ap_status_id(int staff_ap_status_id) {
		this.staff_ap_status_id = staff_ap_status_id;
	}
	public int getStaff_ap_status_by() {
		return staff_ap_status_by;
	}
	public void setStaff_ap_status_by(int staff_ap_status_by) {
		this.staff_ap_status_by = staff_ap_status_by;
	}
	public String getStaff_ap_status_date() {
		return staff_ap_status_date;
	}
	public void setStaff_ap_status_date(String staff_ap_status_date) {
		this.staff_ap_status_date = staff_ap_status_date;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public int getUser_student_id() {
		return user_student_id;
	}
	public void setUser_student_id(int user_student_id) {
		this.user_student_id = user_student_id;
	}
}
