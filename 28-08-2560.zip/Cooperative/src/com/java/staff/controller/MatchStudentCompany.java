package com.java.staff.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.admin.bean.AcademicYearBean;
import com.java.admin.dao.TableAcademicYearDao;
import com.java.staff.bean.RateCompanyListBean;
import com.java.staff.bean.RegionBean;
import com.java.staff.dao.TableRegionDao;
import com.java.student.dao.TableStudentSelectCompanyDao;
import com.java.teacher.bean.ProfileStudentSendDocumentBean;
import com.java.teacher.dao.TableStudentSendDocumentDao;
import com.java.util.SessionExpire;

/**
 * Servlet implementation class MatchStudentCompany
 */
@WebServlet("/MatchStudentCompany")
public class MatchStudentCompany extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MatchStudentCompany() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
			HttpSession session = request.getSession();
			
			// check role session expire
		    if(session.getAttribute("role") == null){
			  	SessionExpire sessionExpire = new SessionExpire();
				response.sendRedirect(sessionExpire.getSendRedirect()); // send redirect to Login page
				return;
		    }			
			
		    // check role approve staff
			String CheckRoleApproveStaff = "";
			if(session.getAttribute("CheckRoleApproveStaff") != null){
				CheckRoleApproveStaff =  session.getAttribute("CheckRoleApproveStaff").toString();
			}
			
			String role = session.getAttribute("role").toString();
			if(role.equals("staff") && ("true".equals(CheckRoleApproveStaff))){
				String action = request.getParameter("action");
				int sutdentid = Integer.parseInt(request.getParameter("studentid"));
				int division_id = Integer.parseInt(request.getParameter("division_id"));

				if("MatchCheck".equals(action)){
					
					/** set student_user_id  㹡óս��  �� post
					 *  com.java.student.controller
					 *  SelectCompany
					 */
					session.setAttribute("studnet_user_id",sutdentid);
					
					// set academic_year
					TableStudentSelectCompanyDao tableStudentSelectCompanyDao = new TableStudentSelectCompanyDao();
					TableAcademicYearDao tableAcademicYear = new TableAcademicYearDao();
					AcademicYearBean academicYearBean = new AcademicYearBean();
					
					// set start_data_workout , stop
					academicYearBean = tableAcademicYear.getAcademic();
					session.setAttribute("start_date_workout",splitDate(academicYearBean.getStart_date_workout()));
					session.setAttribute("stop_date_workout",splitDate(academicYearBean.getStop_date_workout()));
					
					/** get academic **/
					int academic_year_id = tableStudentSelectCompanyDao.getAcademicID(sutdentid);
					academicYearBean = tableAcademicYear.getAcademic(academic_year_id);
					request.setAttribute("get_semester",academicYearBean.getSemester());
					request.setAttribute("get_academic_year",academicYearBean.getAcademic_year());
					/** #get academic **/
					
					/** get profile student  **/
					ProfileStudentSendDocumentBean profileStudentSendDocumentBean = new ProfileStudentSendDocumentBean();
					TableStudentSendDocumentDao tableStudentSendDocumentDao = new TableStudentSendDocumentDao();
					profileStudentSendDocumentBean = tableStudentSendDocumentDao.SelectProfileStudentSendDocument(division_id, academic_year_id, sutdentid);
					request.setAttribute("profileStudentSendDocumentBean", profileStudentSendDocumentBean);
					session.setAttribute("checkButtonSelectCompany","enable_button");
					/** #get profile student  **/
					
					/** list rate company **/
					ArrayList<RateCompanyListBean> rateCompanyListBeans = new ArrayList<>();
					rateCompanyListBeans = tableStudentSelectCompanyDao.SelectListRateCompany(academic_year_id, division_id);
					request.setAttribute("rateCompanyListBeans", rateCompanyListBeans);
					request.setAttribute("rate_company_id",0);
					/** #list rate company **/
					
					/** listRegionCompany to select region data_table **/
					ArrayList<RegionBean> listRegionCompany = new ArrayList<>();
					TableRegionDao tableRegionDao = new TableRegionDao();
					listRegionCompany = tableRegionDao.SelectListRegion();
					request.setAttribute("listRegionCompany", listRegionCompany);
					/** #listRegionCompany to select region data_table **/
					
					doViewMatchStudentCompany(request, response);
					return;
				}
			}
	}

	private void doViewMatchStudentCompany(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/staff/match_student_company.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	private String splitDate(String date){
		String[] str = date.split("-");    
		return str[2]+"/"+str[1]+"/"+(Integer.parseInt(str[0])+543);
	}
}
