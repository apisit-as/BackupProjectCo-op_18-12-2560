package com.java.staff.controller;

import java.io.IOException;
import java.lang.reflect.Type;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.java.admin.bean.AcademicYearBean;
import com.java.admin.dao.TableAcademicYearDao;
import com.java.staff.bean.CompanyBean;
import com.java.staff.bean.DivisionBean;
import com.java.staff.bean.RateCompanyListCompanyBean;
import com.java.staff.bean.RateCompanyListStudentBean;
import com.java.staff.bean.RegionBean;

import com.java.staff.bean.UserListStudentRateCompanyBean;
import com.java.staff.dao.TableCompanyDao;
import com.java.staff.dao.TableDivisionDao;
import com.java.staff.dao.TableRateCompanyDao;
import com.java.staff.dao.TableRegionDao;
import com.java.student.bean.HistoryStatusBean;
import com.java.student.bean.StudentSelectCompanyBean;
import com.java.student.controller.CreateReport;
import com.java.student.dao.TableApprovalStatusDao;
import com.java.student.dao.TableDocumentStatusDao;
import com.java.student.dao.TableHistoryStatusDao;
import com.java.student.dao.TableStudentSelectCompanyDao;
import com.java.util.FileUploadUtil;
import com.java.util.SessionExpire;

/**
 * Servlet implementation class RateCompanyManagement
 */
@WebServlet("/RateCompanyManagement")
public class RateCompanyManagement extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RateCompanyManagement() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
			HttpSession session = request.getSession();
			
			// check role session expire
		    if(session.getAttribute("role") == null){
			  	SessionExpire sessionExpire = new SessionExpire();
				response.sendRedirect(sessionExpire.getSendRedirect()); // send redirect to Login page
				return;
		    }			
			
			String role = session.getAttribute("role").toString();
			if(role.equals("staff")){

				String action = request.getParameter("action");
				if("AddRate".equals(action)){
					
					// list data company
					TableCompanyDao tableCompanyDao = new TableCompanyDao();
					ArrayList<CompanyBean> ListDataCompany = new ArrayList<>();
					ListDataCompany = tableCompanyDao.SelectListCompany();
					request.setAttribute("ListDataCompany", ListDataCompany);
					
					// list division
					TableDivisionDao tableDivisionDao = new TableDivisionDao();
					ArrayList<DivisionBean> ListDivisionBean = new ArrayList<>();
					ListDivisionBean = tableDivisionDao.SelectListDivision();
					request.setAttribute("ListDivisionBean", ListDivisionBean);
					
					// set Academic Year
					TableAcademicYearDao tableAcademicYear = new TableAcademicYearDao();
					AcademicYearBean academicYearBean = new AcademicYearBean();
					academicYearBean = tableAcademicYear.getAcademic();
					session.setAttribute("Semester", academicYearBean.getSemester());
					session.setAttribute("Academic_year", academicYearBean.getAcademic_year());
					session.setAttribute("academic_year_id", academicYearBean.getId());
					
					// set start_data_workout , stop
					session.setAttribute("start_date_workout",splitDate(academicYearBean.getStart_date_workout()));
					session.setAttribute("stop_date_workout",splitDate(academicYearBean.getStop_date_workout()));
					
					doViewRateCompanyManagement(request, response);
					return;
				}	
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		String role = session.getAttribute("role").toString();
		
		if(role.equals("staff")){
			
			String action = request.getParameter("action");
			if("search_company".equals(action)){
				
				/** search_company */
				TableCompanyDao tableCompanyDao = new TableCompanyDao();
				CompanyBean companyBean = new CompanyBean();
				int id_company = Integer.parseInt(request.getParameter("id"));
				companyBean = tableCompanyDao.SelectCompany(id_company);
				request.setAttribute("companyBean", companyBean);
				
				ArrayList<RegionBean> listRegionCompany = new ArrayList<>();
				TableRegionDao tableRegionDao = new TableRegionDao();
				listRegionCompany = tableRegionDao.SelectListRegion();
				request.setAttribute("listRegionCompany", listRegionCompany);
				
				// data  select list  type_company_select,residence_company_select
				CompanyManagement companyManagement = new CompanyManagement();
				companyManagement.listSelectComapny(request, response);

				getPageDataCompany(request, response);
			}
			else if("search_student_company".equals(action)){
				
				/** search_student_company */
		        int number = Integer.parseInt(request.getParameter("number"));
		        int faculty_id = Integer.parseInt(request.getParameter("faculty_id"));
				int division_id = Integer.parseInt(request.getParameter("division_id"));
				int academic_year_id = Integer.parseInt(session.getAttribute("academic_year_id").toString());
				TableRateCompanyDao tableRateCompanyDao = new TableRateCompanyDao();
				ArrayList<UserListStudentRateCompanyBean> listStudent = new ArrayList<>();
				listStudent = tableRateCompanyDao.SelectListStudent(faculty_id, division_id, academic_year_id);
				request.setAttribute("listStudent", listStudent);
				request.setAttribute("number", number);
				
				getPagelistStudent(request, response);
			}
			else if("save_rate_company".equals(action)){
				
				 /** save_rate_company */
				 int company_id = Integer.parseInt(request.getParameter("company_id"));
				 int academic_year_id = Integer.parseInt(session.getAttribute("academic_year_id").toString());
				 String array_fac_div = request.getParameter("array_fac_div");
				 String array_list_student = request.getParameter("array_list_student");
				 //System.out.println(array_fac_div);
				 //System.out.println(array_list_student);
				 Gson gson = new Gson();
				 Type listTypeRateCompanyListCompanyBean = new TypeToken<ArrayList<RateCompanyListCompanyBean>>() {	}.getType();
				 Type listTypeRateCompanyListStudentBean = new TypeToken<ArrayList<RateCompanyListStudentBean>>() { }.getType();
				 /**  json to bean list */
				 List<RateCompanyListCompanyBean> listCompanyBean = gson.fromJson(array_fac_div, listTypeRateCompanyListCompanyBean);
				 List<RateCompanyListStudentBean> listStudentBean = gson.fromJson(array_list_student, listTypeRateCompanyListStudentBean);
				 TableRateCompanyDao tableRateCompanyDao = new TableRateCompanyDao();
				 
				 /** set coop03 **/
				 TableStudentSelectCompanyDao tableStudentSelectCompanyDao = new TableStudentSelectCompanyDao();
				 StudentSelectCompanyBean studentSelectCompanyBean = new StudentSelectCompanyBean();
				 studentSelectCompanyBean.setPosition("");
				 studentSelectCompanyBean.setSend_documents("���ҧ���������͡���");
				 String start_date_workout = session.getAttribute("start_date_workout").toString();
				 String stop_date_workout = session.getAttribute("stop_date_workout").toString();
				 studentSelectCompanyBean.setStart_date_workout(start_date_workout);
				 studentSelectCompanyBean.setStop_date_workout(stop_date_workout);
				 
				 /**
				  *  insert rate_company
				  *  update matching student select copmpany 
				  */
				 for(RateCompanyListCompanyBean companyBean : listCompanyBean) {
					 companyBean.setCompany_id(company_id);
					 companyBean.setAcademic_year_id(academic_year_id);
					 // insert get key
					 int rate_company_id = tableRateCompanyDao.InsertRateCompany(companyBean);
				 	 for(RateCompanyListStudentBean studentBean : listStudentBean){
				 		 if(companyBean.getNumber() == studentBean.getNumber()){
				 			 /** update table student select company */
				 			 
				 			 // set user_id  , rate_company_id
				 			studentSelectCompanyBean.setUser_id(studentBean.getUser_id());
				 			studentSelectCompanyBean.setRate_company_id(rate_company_id);
				 			
							// delete file company
							String partFile_Company = tableStudentSelectCompanyDao.getPathFile(studentBean.getUser_id());
							FileUploadUtil.deleteFile(request, partFile_Company);
							
							// update
				 			tableStudentSelectCompanyDao.updateStudentSelectCompany(studentSelectCompanyBean);
				 			
							// update  report coop03
							CreateReport createReport = new CreateReport();
							createReport.reportCoop03(request, studentBean.getUser_id());
				 			 
				 			 /** 
				 			  *   status document  =  1   (����ó�)
				 			  *   status approval  =  1   ��͹��ѵ� (�ʴ����ǹ�ͧ�Ҩ����)  ,  6 = �ʹ��Թ��� (�ʴ����ǹ�ѡ�֡��)
				 			  */
				 			 String date = getDateDefaultToString();
				 			 TableApprovalStatusDao tableApprovalStatusDao = new TableApprovalStatusDao();
				 			 TableDocumentStatusDao tableDocumentStatus = new TableDocumentStatusDao();
				 			 InsertHistory(date, "���͡ʶҹ��Сͺ���", tableDocumentStatus.getStatusDocument(1),studentBean.getUser_id());
				 			 InsertHistory(date, "�Ҩ�������ҹ�ҹ�ˡԨ�֡�ҵ�Ǩ�ͺʶҹ��Сͺ���", tableApprovalStatusDao.getStatusApproval(6),studentBean.getUser_id());
				 		 }
				 	 }
				  }
			}
		}
	}
	private void InsertHistory(String date,String history,String status,int userid){
		HistoryStatusBean historyStatusBean = new HistoryStatusBean();
		historyStatusBean.setDate(date);
		historyStatusBean.setHistory(history);
		historyStatusBean.setStatus(status);
		historyStatusBean.setUserid(userid);
		TableHistoryStatusDao tableHistoryStatus = new TableHistoryStatusDao();
		tableHistoryStatus.InsertHistoryStatus(historyStatusBean);
	}
	
	private String getDateDefaultToString(){
		LocalDate localDate = LocalDate.now();
		String date = DateTimeFormatter.ofPattern("dd/MM/yyy").format(localDate);
		String[] dateSplit = date.split("/");
		date = "";
		date = dateSplit[0]+"/"+dateSplit[1]+"/"+(Integer.parseInt(dateSplit[2])+543);
		return date;
	}
	private void getPageDataCompany(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/element/data_company.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void getPagelistStudent(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/element/modal_select_student_company.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void doViewRateCompanyManagement(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/staff/rate_company_management.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private String splitDate(String date){
		String[] str = date.split("-");    
		return str[2]+"/"+str[1]+"/"+(Integer.parseInt(str[0])+543);
	}
}
