package com.java.student.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.java.student.bean.TranscriptBean;
import com.java.student.bean.UserBean;
import com.java.student.dao.TableCompleteStatusDocument;
import com.java.student.dao.TableTranscriptDao;
import com.java.student.dao.TableUserDao;
import com.java.util.FileUploadUtil;

/**
 * Servlet implementation class CheckStatus
 */
@WebServlet("/UploadTranscript")
public class UploadTranscript extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadTranscript() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();

		List<FileItem> items = null;
		String file;
		TranscriptBean transcriptBean = new TranscriptBean();
		int UserID = Integer.parseInt(session.getAttribute("UserID").toString());
		
		String ClickSave = session.getAttribute("CheckClickSave").toString();
		if("True Save".equals(ClickSave)){
			try{
				items = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
				for (FileItem item : items) {
					/** loop item */
					//System.out.println(item.getFieldName());
					
				     if(!item.isFormField()){  
				    	 /** file */
				         if (!(item.getName().equals(""))) {
				        	 /**
				        	  * 	item.getName() != ""
				        	  * 	item.getName()  = get name file
				        	  * 	item.getFieldName() = get input name=uploadBtn
				        	  */
				        	 TableUserDao tableUserDao = new TableUserDao();
				        	 UserBean userBeanStudentID = new UserBean();
				        	 userBeanStudentID = tableUserDao.getTableUser(UserID);
				        	 String studentID = userBeanStudentID.getStudentid();
				        	 file = FileUploadUtil.uploadFile(request, item,"Transcript",studentID, UserID+"_Transcript","pdf");
				             transcriptBean.setFile(file);
				         }else{
				        	 /** item.getName() == "" */
				        	 TableTranscriptDao tableTranscriptDao = new TableTranscriptDao();
				        	 file = tableTranscriptDao.SelectTranscriptPath(UserID);
				        	 transcriptBean.setFile(file);
				         }
				         //System.out.println(file);
				     }
				}
				
				TableTranscriptDao tableTranscriptDao = new TableTranscriptDao();
				transcriptBean.setUserid(UserID);
				
				if(tableTranscriptDao.CheckTranscript(UserID)){
					//update
					tableTranscriptDao.UpdateTranscript(transcriptBean);
				}else{
					// insert
					tableTranscriptDao.InsertTranscript(transcriptBean);
				}

				out.print("True Save");
			}catch(FileUploadException e){
				e.printStackTrace();
			}
		}
		else if("False Save".equals(ClickSave)){
			out.print("False Save");
			return;
		}
		
		// insert,update status document
		TableCompleteStatusDocument tableCompleteStatusDocument = new TableCompleteStatusDocument();
		if(tableCompleteStatusDocument.checkCompleteStatusDocument(UserID)){
			//update
			tableCompleteStatusDocument.UpdateCompleteStatusDoc("DataTranscript", 1, UserID);
		}else{
			//insert
			tableCompleteStatusDocument.InsertCompleteStatusDoc("DataTranscript", 1, UserID);
		}
	}

}
