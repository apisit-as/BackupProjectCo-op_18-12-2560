package com.java.student.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.student.bean.ActivityBean;
import com.java.student.bean.TrainingBean;
import com.java.student.bean.UserBean;
import com.java.student.dao.TableActivityDao;
import com.java.student.dao.TableCompleteStatusDocument;
import com.java.student.dao.TableCoop03Dao;
import com.java.student.dao.TableTrainingDao;
import com.java.student.dao.TableUserDao;
import com.java.util.SessionExpire;

/**
 * Servlet implementation class CheckStatus
 */
@WebServlet("/DataActivity")
public class DataActivity extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DataActivity() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		
		HttpSession session = request.getSession();
		TableUserDao tableUserDao = new TableUserDao();
		UserBean userBean = new UserBean();
		
		// check role session expire
	    if(session.getAttribute("role") == null){
		  	SessionExpire sessionExpire = new SessionExpire();
			response.sendRedirect(sessionExpire.getSendRedirect()); // send redirect to Login page
			return;
	    }

		String role = session.getAttribute("role").toString();
		if(role.equals("student")){

			int UserID = Integer.parseInt(session.getAttribute("UserID").toString());
			userBean = tableUserDao.getTableUser(UserID);
			request.setAttribute("userBean", userBean);
			session.setAttribute("divID", userBean.getDivid());
			session.setAttribute("divName", userBean.getDivname());
			
			// get coop03
			TableTrainingDao tableTrainingDao = new TableTrainingDao();
			TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
			TableActivityDao tableActivityDao = new TableActivityDao();
			int Coop03ID = tableCoop03Dao.getKeyIDCoop03(UserID);
			for(int i=1; i<=3; i++){
				TrainingBean trainingBean = new TrainingBean();
				trainingBean = tableTrainingDao.SelectTraining(Coop03ID,"training_"+i);
				
				ActivityBean activityBean = new ActivityBean();
				activityBean = tableActivityDao.SelectActivity(Coop03ID,"activity_"+i);
				
				request.setAttribute("trainingBean"+i, trainingBean);
				request.setAttribute("activityBean"+i, activityBean);
			}
			doViewDataActivity(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");

		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		
		String ClickSave = session.getAttribute("CheckClickSave").toString();
		if("True Save".equals(ClickSave)){
			out.print("True Save");
			insertActivity(request, response);
		}
		else if("False Save".equals(ClickSave)){
			out.print("False Save");
			return;
		}
	}
	private void doViewDataActivity(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/student/data_default/data_activity.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void insertActivity(HttpServletRequest request, HttpServletResponse response) {

		HttpSession session = request.getSession();
		
		TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
		int UserID = Integer.parseInt(session.getAttribute("UserID").toString());
		
		/** check table coop03 **/
		int coop03ID;
		if(tableCoop03Dao.CheckCoop03(UserID)){
			coop03ID = tableCoop03Dao.getKeyIDCoop03(UserID);
		}else{
			tableCoop03Dao.InsertCoop03SetUserid(UserID);
			coop03ID = tableCoop03Dao.getKeyIDCoop03(UserID);
		}
		
		/** check table tarining coop03 **/
		TableTrainingDao tableTrainingDao = new TableTrainingDao();
		Boolean checkTraining;
		if(tableTrainingDao.CheckTraining(coop03ID)){
			checkTraining = true;
		}else{
			checkTraining = false;
		}
		
		/** check table activity coop03 **/
		TableActivityDao tableActivityDao = new TableActivityDao();
		Boolean checkActivity;
		if(tableActivityDao.CheckActivity(coop03ID)){
			checkActivity = true;
		}else{
			checkActivity = false;
		}
		
		/** set value to insert,update database **/
		for(int i=1; i<=3; i++){

			// trining
			TrainingBean trainingBean = new TrainingBean();
			trainingBean.setStart_date(request.getParameter("training_StartDate"+i).toString());
			trainingBean.setStop_date(request.getParameter("training_StopDate"+i).toString());
			trainingBean.setPlace(request.getParameter("training_Place"+i).toString());
			trainingBean.setPosition(request.getParameter("training_Position"+i).toString());
			trainingBean.setType("training_"+i);
			trainingBean.setCoop03id(coop03ID);
			
			// activity
			ActivityBean activityBean = new ActivityBean();
			activityBean.setDate_time(request.getParameter("activity_DateTime"+i).toString());
			activityBean.setPosition(request.getParameter("activity_Position"+i).toString());
			activityBean.setType("activity_"+i);
			activityBean.setCoop03id(coop03ID);
			
			if(checkTraining){
				// update table training
				tableTrainingDao.UpdateTraining(trainingBean);
			}else{
				// insert table training
				tableTrainingDao.InsertTraining(trainingBean);
			}
			
			if(checkActivity){
				// update  table activity
				tableActivityDao.UpdateActivity(activityBean);
			}else{
				// insert table activity
				tableActivityDao.InsertActivity(activityBean);
			}
		}
		/** #set value to insert,update database **/
		
		/** insert,update status document **/
		TableCompleteStatusDocument tableCompleteStatusDocument = new TableCompleteStatusDocument();
		if(tableCompleteStatusDocument.checkCompleteStatusDocument(UserID)){
			//update
			tableCompleteStatusDocument.UpdateCompleteStatusDoc("DataActivity", 1, UserID);
		}else{
			//insert
			tableCompleteStatusDocument.InsertCompleteStatusDoc("DataActivity", 1, UserID);
		}
	}

}
