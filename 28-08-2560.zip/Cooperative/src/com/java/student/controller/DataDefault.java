package com.java.student.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.admin.bean.AcademicYearBean;
import com.java.admin.dao.TableAcademicYearDao;
import com.java.student.bean.Coop02Bean;
import com.java.student.bean.DataReportBean;
import com.java.student.bean.HistoryStatusBean;
import com.java.student.bean.StudentSendDocumentBean;
import com.java.student.dao.TableApprovalStatusDao;
import com.java.student.dao.TableCompleteStatusDocument;
import com.java.student.dao.TableCoop02Dao;
import com.java.student.dao.TableCoop03Dao;
import com.java.student.dao.TableDataReportDao;
import com.java.student.dao.TableDocumentStatusDao;
import com.java.student.dao.TableHistoryStatusDao;
import com.java.student.dao.TableProfileDao;
import com.java.student.dao.TableStudentSelectCompanyDao;
import com.java.student.dao.TableStudentSendDocumentDao;
import com.java.student.dao.TableTranscriptDao;
import com.java.util.SessionExpire;
/**
 * Servlet implementation class CheckStatus
 */
@WebServlet("/DataDefault")
public class DataDefault extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DataDefault() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
			HttpSession session = request.getSession();
	
			// check role session expire
		    if(session.getAttribute("role") == null){
			  	SessionExpire sessionExpire = new SessionExpire();
				response.sendRedirect(sessionExpire.getSendRedirect()); // send redirect to Login page
				return;
		    }
			
			String role = session.getAttribute("role").toString();
			if(role.equals("student")){
				int UserID = Integer.parseInt(session.getAttribute("UserID").toString());	
				
				/** check status  tb_complete_status_document */
				int key = 0;
				Boolean check;
				String []fieldName = {"DataStudent","DataAddress","DataFamily","DataEducation","DataActivity","DataTalent","DataCareer","DataTranscript"};
				String []keyCheck = {"DataStudentKey","DataAddressKey","DataFamilyKey","DataEducationKey","DataActivityKey","DataTalentKey","DataCareerKey","DataTranscriptKey"};
				TableCompleteStatusDocument tableCompleteStatusDocument = new TableCompleteStatusDocument();
				if(tableCompleteStatusDocument.checkCompleteStatusDocument(UserID)){
					check = true;
				}else{
					check = false;
				}
				
				for(int i=0; i<=7; i++){
					/**
					 *   (1 =  ����ó� )    ,   (2,0 = �������ó�)   ,   (3 = ���)
					 */
					key = 0;
					if(check){
						key = tableCompleteStatusDocument.getCompleteStatusDocument(fieldName[i], UserID);
						request.setAttribute(keyCheck[i], key);
					}else{
						request.setAttribute(keyCheck[i], key);
					}
				}
				/** #check status  tb_complete_status_document */
				
				// get transcript
				TableTranscriptDao transcriptDao = new TableTranscriptDao();
				String TranScript = transcriptDao.SelectTranscriptPath(UserID);
				request.setAttribute("TranScript", TranScript);

				
				// select academic
				TableAcademicYearDao tableAcademicYear = new TableAcademicYearDao();
				AcademicYearBean academicYearBean = new AcademicYearBean();
				academicYearBean = tableAcademicYear.getAcademic();
				session.setAttribute("Semester", academicYearBean.getSemester());
				session.setAttribute("Academic_year", academicYearBean.getAcademic_year());
				request.setAttribute("StartDateRecruitment", splitDate(academicYearBean.getStart_date_recruitment()));
				request.setAttribute("StopDateRecruitment", splitDate(academicYearBean.getStop_date_recruitment()));
				
				/** insert,update  academic_year to coop02 */
				TableStudentSendDocumentDao tableStudentSendDocumentDao = new TableStudentSendDocumentDao();
				if(!tableStudentSendDocumentDao.CheckTable(UserID)){
					TableCoop02Dao tableCoop02Dao = new TableCoop02Dao();
					Coop02Bean coop02Bean = new Coop02Bean();
					coop02Bean.setTerm(academicYearBean.getSemester());
					coop02Bean.setAcademic_year(academicYearBean.getAcademic_year());
					coop02Bean.setUserid(UserID);
					if(tableCoop02Dao.CheckCoop02(UserID)){
						tableCoop02Dao.UpdateCoop02TermAcademicYear(coop02Bean);
						//System.out.println("Update Academic");
					}else{
						tableCoop02Dao.InsertCoop02TermAcademicYear(coop02Bean);
						//System.out.println("Insert Academic");
					}
				}
				/** #insert,update  academic_year to coop02 */
				
				
				/*** check button send document ***/
				/**  get Date  check date **/
				String CheckMessage="",CheckButton="",CheckClickSave="";
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				Date defaultDate = new Date();
				
				//System.out.println("defaultDate == "+dateFormat.format(defaultDate));  // to String
				String defaultDateToString = dateFormat.format(defaultDate);
				
				String startDateToString = academicYearBean.getStart_date_recruitment();
				String stopDateToString = academicYearBean.getStop_date_recruitment();
				Boolean checkSet = false;
				
				// check date String == String
				if((defaultDateToString.equals(startDateToString) && defaultDateToString.equals(stopDateToString))  || defaultDateToString.equals(stopDateToString)){
					/**
					 *  case  1. defaultDate == startDate,stopDate
					 *  case  2. defaultDate == stopDateToString
					 */
					//System.out.println("true == date");
					checkSet = true;
				}

					// check date  > , <
					Date startDate = stringToDate(startDateToString);
					Date stopDate = stringToDate(stopDateToString);
					Boolean checkStartDate = defaultDate.after(startDate);   // not  ==
					Boolean checkStopDate =  defaultDate.before(stopDate);   // not  ==
					//System.out.println(checkStartDate+"  &&   "+checkStopDate+"    ||  "+checkSet);

					// ������ �Ѩ�غѹ     ��������� , ����ش
					if((checkStartDate && checkStopDate) || checkSet){
						//System.out.println("True Date");
						Boolean checkTable = tableStudentSendDocumentDao.CheckTable(UserID);
						if(checkTable){
							// ��   true tableStudentSendDocument
							checkTable = null;
							checkTable =  tableStudentSendDocumentDao.CheckTable(UserID, academicYearBean.getId());
							//  ��Ǩ�ͺ key ��� , userid ��ҵç������    key �ç�������
							if(checkTable){
								// key �ç
								StudentSendDocumentBean studentSendDocumentBean = new StudentSendDocumentBean();
								studentSendDocumentBean = tableStudentSendDocumentDao.SelectTableCheckStatus(UserID);
								if(studentSendDocumentBean.getLv1_apstatusid() == 2 || studentSendDocumentBean.getLv1_apstatusid() == 3 || studentSendDocumentBean.getLv1_apstatusid() == 6){
									/**
									 *   ͹��ѵ�  = 2  , ���͹��ѵ�����͡��Ժѵԧҹ�ˡԨ�֡��  = 3  ,  �ʹ��Թ��� = 6 
									 */
									if(studentSendDocumentBean.getLv1_apstatusid() == 2 && studentSendDocumentBean.getLv2_apstatusid() == 4 ){
										/**
										 *   �觡�Ѻ���  = 4   
										 *   ���͡�����
										 *   lv1 ͹��ѵ�     lv2 �觡�Ѻ���   
										 */
										CheckMessage = "";
										CheckButton = "True Click";
										CheckClickSave = "True Save";
										
									}else{
										/**
										 *   ͹��ѵ�  = 2  , ���͹��ѵ�����͡��Ժѵԧҹ�ˡԨ�֡��  = 3  ,  �ʹ��Թ��� = 6 
										 *   ���͡��������
										 */
										CheckMessage = "False";
										CheckButton = "False Click";
										CheckClickSave = "False Save";
									}
								}
								else if(studentSendDocumentBean.getLv1_apstatusid() == 4 || studentSendDocumentBean.getLv1_apstatusid() == 0){
									/**
									 *   �觡�Ѻ���  = 4  , null = 0    
									 *   ���͡�����
									 */
									CheckMessage = "";
									CheckButton = "True Click";
									CheckClickSave = "True Save";
								}

							}else{
								// key ���ç   ʶҹ�   ���͡�������    ���͡��������
								CheckMessage = "False";
								CheckButton = "False Click";
								CheckClickSave = "False Save";
							}
						}else{
							// ��辺    ���͡�����
							CheckMessage = "";
							CheckButton = "True Click";
							CheckClickSave = "True Save";
						}
					}else{
						//System.out.println("False Date");
						// ���͡��������  �ѹ�����¡�˹�
						CheckMessage = "False Date";
						CheckButton = "False Click";
						CheckClickSave = "False Save";
						
						Boolean checkTable =  tableStudentSendDocumentDao.CheckTable(UserID);
						if(checkTable){
							// 㹡ó� �ѹ����Թ��˹�  �����͡�������   ���ʶҹ����  ���͡�������
							CheckMessage = "False";
							CheckButton = "False Click";
							CheckClickSave = "False Save";
						}
					}
					
					/**
					 *    CheckMessage  = False (���͡�������)   ,  False Date (���������㹪�ǧ�ѹ���͡���  �������ö���͡�����)
					 *    CheckButton   = True Click , False Click    (enable/disable button) 
					 *    CheckClickSave = True Save , False Save     (��Ǩ�ͺ�ա�յ͹�� save � do post)
					 */
					request.setAttribute("CheckMessage", CheckMessage);
					session.setAttribute("CheckButton", CheckButton);
					session.setAttribute("CheckClickSave", CheckClickSave);
				/**  #get Date  check date **/
				/*** #check button send document ***/

				doViewDataDefault(request, response);
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		
		int UserID = Integer.parseInt(session.getAttribute("UserID").toString());
		String role = session.getAttribute("role").toString();
		if(role.equals("student")){
			
			String ClickSave = session.getAttribute("CheckClickSave").toString();
			if("True Save".equals(ClickSave)){
				String action = request.getParameter("action");
				if("SendDocument".equals(action)){
					// SendDocument
					TableCompleteStatusDocument tableCompleteStatusDocument = new TableCompleteStatusDocument();
					TableStudentSendDocumentDao tableStudentSendDocumentDao = new TableStudentSendDocumentDao();
					if(tableCompleteStatusDocument.checkSend(UserID)){
						
						// get data
						TableAcademicYearDao tableAcademicYear = new TableAcademicYearDao();
						TableCoop02Dao tableCoop02Dao = new TableCoop02Dao();
						TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
						TableTranscriptDao tableTranscriptDao = new TableTranscriptDao();
						TableProfileDao tableProfileDao = new TableProfileDao();

						StudentSendDocumentBean studentSendDocumentBean = new StudentSendDocumentBean();
						studentSendDocumentBean.setAcademic_year(tableAcademicYear.getID());
						studentSendDocumentBean.setCoop02id(tableCoop02Dao.getKeyIDCoop02(UserID));
						studentSendDocumentBean.setCoop03id(tableCoop03Dao.getKeyIDCoop03(UserID));
						studentSendDocumentBean.setTranscriptid(tableTranscriptDao.SelectID(UserID));
						studentSendDocumentBean.setProfileid(tableProfileDao.getKeyIDProfile(UserID));
						studentSendDocumentBean.setLv1_apstatusid(6);  //  6 = �ʹ��Թ���
						studentSendDocumentBean.setUserid(UserID);
						
						TableDocumentStatusDao tableDocumentStatus = new TableDocumentStatusDao();
						TableApprovalStatusDao tableApprovalStatusDao = new TableApprovalStatusDao();
						String date = getDateDefaultToString();
						
						/**   insert , update  Report date,teacher_name */
						TableDataReportDao tableDataReportDao = new TableDataReportDao();

						String teacher1_name =  tableDataReportDao.getNameTeacher(UserID, "teacher1");
						String teacher2_name =  tableDataReportDao.getNameTeacher(UserID, "teacher2");
						
						DataReportBean dataReportBean = new DataReportBean();
						dataReportBean.setDate(date);
						dataReportBean.setTeacher1_name(teacher1_name);
						dataReportBean.setTeacher2_name(teacher2_name);
						dataReportBean.setUser_id(UserID);
						
						if(tableDataReportDao.CheckTable(UserID)){
							// update
							tableDataReportDao.UpdateDataReport(dataReportBean);
						}else{
							// insert
							tableDataReportDao.InsertDataReport(dataReportBean);
						}
						/**   #insert , update  Report date,teacher_name */

						// insert,update   send document student, student select company
						if(tableStudentSendDocumentDao.CheckTable(UserID)){
							/** update */
							tableStudentSendDocumentDao.UpdateDocumentStudent(studentSendDocumentBean);
							
							/**
							 *     㹡ó� �Ҩ���� �觡�Ѻ��� �ѡ�֡�Ҩ����ҧ���� 2 ʶҹ�
							 *     1.����ó�      6.�ʹ��Թ���
							 */
							// insert history
							InsertHistory(date, "���Ẻ����������ž�鹰ҹ", tableDocumentStatus.getStatusDocument(1),UserID);
							InsertHistory(date, "�Ҩ�������ҹ�ҹ�ˡԨ�֡�ҵ�Ǩ�ͺ�͡���",tableApprovalStatusDao.getStatusApproval(6),UserID);
						}else{
							/** insert */
							tableStudentSendDocumentDao.InsertSeandDocumentStudent(studentSendDocumentBean);
							TableStudentSelectCompanyDao tableStudentSelectCompanyDao = new TableStudentSelectCompanyDao();
							tableStudentSelectCompanyDao.InsertStudentSelectCompany(UserID,tableAcademicYear.getID());
							
							/**
							 *     㹡ó����͡��ä���á ������ 3 ʶҹ�
							 *     2.�������ó�      1.����ó�    6.�ʹ��Թ���
							 */
							// insert history
							InsertHistory(date, "��͡Ẻ����������ž�鹰ҹ", tableDocumentStatus.getStatusDocument(2),UserID);
							InsertHistory(date, "��͡Ẻ����������ž�鹰ҹ", tableDocumentStatus.getStatusDocument(1),UserID);
							InsertHistory(date, "�Ҩ�������ҹ�ҹ�ˡԨ�֡�ҵ�Ǩ�ͺ�͡���",tableApprovalStatusDao.getStatusApproval(6),UserID);
						}
						
						out.print("True Save");
					}else{
						out.print("False Save");
					}
				}
			}
			else if("False Save".equals(ClickSave)){
				out.print("False Save Click");
			}
		}
	}
	
	private void doViewDataDefault(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/student/data_default.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private Date stringToDate(String dateInString){
		Date date = null;
		 SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		 try {
			Date typeDate = formatter.parse(dateInString); // to Date   , to String     formatter.format(typeDate)
			date = typeDate;  // to Date
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	private String getDateDefaultToString(){
		LocalDate localDate = LocalDate.now();
		String date = DateTimeFormatter.ofPattern("dd/MM/yyy").format(localDate);
		String[] dateSplit = date.split("/");
		date = "";
		date = dateSplit[0]+"/"+dateSplit[1]+"/"+(Integer.parseInt(dateSplit[2])+543);
		return date;
	}
	
	private void InsertHistory(String date,String history,String status,int userid){
		HistoryStatusBean historyStatusBean = new HistoryStatusBean();
		historyStatusBean.setDate(date);
		historyStatusBean.setHistory(history);
		historyStatusBean.setStatus(status);
		historyStatusBean.setUserid(userid);
		TableHistoryStatusDao tableHistoryStatus = new TableHistoryStatusDao();
		tableHistoryStatus.InsertHistoryStatus(historyStatusBean);
	}
	
	private String splitDate(String date){
		String[] str = date.split("-");    
		return str[2]+"/"+str[1]+"/"+(Integer.parseInt(str[0])+543);
	}
	
}
