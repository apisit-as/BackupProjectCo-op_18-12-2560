package com.java.student.dao;

import com.java.student.bean.UserBean;
import com.java.util.PreparedStatementUtil;
import java.sql.ResultSet;
import java.sql.SQLException;


public class LoginDao {

	public UserBean checkLoginUser(UserBean loginbean){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rec = null;
		UserBean bean = new UserBean();
		String sql = "SELECT tb_user.ID,"
				+ "tb_user.StudentID,"
				+ " tb_title.Name_th,"
				+ " tb_user.FirstName_th,"		
				+ " tb_user.LastName_th,"
				+ " tb_user.RoleID,"
				+ " tb_role.NameTH AS RoleNameTH,"
				+ " tb_role.NameENG AS RoleNameENG,"
				+ " tb_user.Username  "
				+ " FROM tb_user "
				+ " LEFT JOIN tb_title ON tb_user.TitleID = tb_title.ID"
				+ " JOIN tb_role  ON tb_user.RoleID = tb_role.ID"
				+ " WHERE tb_user.Username = :username LIMIT 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(sql);
			prepareStatementUtil.setString("username", loginbean.getUsername());
			rec = prepareStatementUtil.executeQuery();
			if ((rec.next()) && (rec != null)) {
				bean.setId(rec.getInt("ID"));
				bean.setStudentid(rec.getString("StudentID"));
				bean.setTitlename_th(rec.getString("Name_th"));
				bean.setFirstname_th(rec.getString("FirstName_th"));
				bean.setLastname_th(rec.getString("LastName_th"));
				bean.setRoleid(rec.getInt("RoleID"));
				bean.setRolename_th(rec.getString("RoleNameTH"));
				bean.setRolename_eng(rec.getString("RoleNameENG"));
				bean.setUsername(rec.getString("Username"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rec.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return bean;
	}
	
	public Boolean checkLoginAdminRoot(String user,String pass){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = "SELECT True as isAdmin FROM cooperative.tb_user "
					+ " WHERE Username = :username AND Password = :password AND RoleID = 2 LIMIT 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setString("username", user);
			prepareStatementUtil.setString("password", pass);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getBoolean("isAdmin");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}	
	
	public int getID(UserBean loginbean){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rec = null;
		int id = 0;
		String sql = "SELECT tb_user.ID FROM tb_user"
				+ " WHERE tb_user.FirstName_th = :firstname_th and tb_user.LastName_th = :lastname_th LIMIT 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(sql);
			prepareStatementUtil.setString("firstname_th", loginbean.getFirstname_th());
			prepareStatementUtil.setString("lastname_th", loginbean.getLastname_th());
			rec = prepareStatementUtil.executeQuery();
			if ((rec.next()) && (rec != null)) {
				id = rec.getInt("ID");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rec.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return id;
	}
	
	public void UpdateNameTableUser(UserBean userBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_user SET "
		   				+ "TitleID = :title_id,"
		   				+ "FirstName_th = :first_name_th, "
		   				+ "LastName_th = :last_name_th, "
		   				+ "FirstName_eng = :first_name_eng, "
		   				+ "LastName_eng = :last_name_eng  "
		   				+ "WHERE tb_user.ID = :user_id ";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("title_id", userBean.getTitleid());
		   preparedStatementUtil.setString("first_name_th",userBean.getFirstname_th());
		   preparedStatementUtil.setString("last_name_th",userBean.getLastname_th());
		   preparedStatementUtil.setString("first_name_eng",userBean.getFirstname_eng());
		   preparedStatementUtil.setString("last_name_eng",userBean.getLastname_eng());
		   preparedStatementUtil.setInt("user_id", userBean.getId());
		   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
}
