package com.java.student.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.student.bean.RelativeBean;
import com.java.util.PreparedStatementUtil;

public class TableRelativeDao {
	public Boolean CheckRelative(int Coop03ID){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = "SELECT True as isRelative FROM cooperative.tb_relative WHERE Coop03ID = :coop03id LIMIT 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("coop03id", Coop03ID);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getBoolean("isRelative");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public void InsertRelative(RelativeBean relativeBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "INSERT INTO tb_relative(TitleID,"
		   									+ "FirstName,"
		   									+ "LastName,"
		   									+ "Age,"
		   									+ "Occupation,"
		   									+ "Position,"
		   									+ "Type,"
		   									+ "Coop03ID) "
					   		+ " VALUES(:titleid,"   
					   				+ ":firstname,"
					   				+ ":lastname,"
					   				+ ":age,"
					   				+ ":occupation,"
					   				+ ":position,"
					   				+ ":type,"
					   				+ ":coop03id)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("titleid", relativeBean.getTitleid());
		   preparedStatementUtil.setString("firstname", relativeBean.getFirstname());
		   preparedStatementUtil.setString("lastname", relativeBean.getLastname());
		   preparedStatementUtil.setString("age", relativeBean.getAge());
		   preparedStatementUtil.setString("occupation", relativeBean.getOccupation());
		   preparedStatementUtil.setString("position", relativeBean.getPosition());
		   preparedStatementUtil.setString("type", relativeBean.getType());
		   preparedStatementUtil.setInt("coop03id", relativeBean.getCoop03id());
		   preparedStatementUtil.execute();   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void UpdateRelative(RelativeBean relativeBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_relative SET "
		   				+ "TitleID = :titleid,"
		   				+ "FirstName = :firstname,"
		   				+ "LastName = :lastname,"
		   				+ "Age = :age,"
		   				+ "Occupation = :occupation,"
		   				+ "Position = :position "
		   				+ "WHERE Coop03ID = :coop03id && Type = :type ";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("titleid", relativeBean.getTitleid());
		   preparedStatementUtil.setString("firstname", relativeBean.getFirstname());
		   preparedStatementUtil.setString("lastname", relativeBean.getLastname());
		   preparedStatementUtil.setString("age", relativeBean.getAge());
		   preparedStatementUtil.setString("occupation", relativeBean.getOccupation());
		   preparedStatementUtil.setString("position", relativeBean.getPosition());
		   preparedStatementUtil.setString("type", relativeBean.getType());
		   preparedStatementUtil.setInt("coop03id", relativeBean.getCoop03id());
		   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public RelativeBean SelectRelative(int Coop03ID , String type){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		RelativeBean relativeBean = new RelativeBean();
		String query = "SELECT TitleID,FirstName,LastName,Age"
				+ ",Occupation,Position,Type,tb_title.Name_th AS titleNameTH"
				+ " FROM tb_relative "
				+ " LEFT JOIN tb_title on tb_relative.TitleID = tb_title.ID"
				+ " WHERE Coop03ID = :coop03id && Type = :type  LIMIT 1"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("coop03id", Coop03ID);
			preparedStatementUtil.setString("type", type);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				relativeBean.setTitleid(rs.getInt("TitleID"));
				relativeBean.setFirstname(rs.getString("FirstName"));
				relativeBean.setLastname(rs.getString("LastName"));
				relativeBean.setAge(rs.getString("Age"));
				relativeBean.setOccupation(rs.getString("Occupation"));
				relativeBean.setPosition(rs.getString("Position"));
				relativeBean.setType(rs.getString("Type"));
				relativeBean.setTitle_th(rs.getString("titleNameTH"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return relativeBean;
	}
}
