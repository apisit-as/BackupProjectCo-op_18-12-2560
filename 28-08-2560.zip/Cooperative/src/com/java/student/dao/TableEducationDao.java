package com.java.student.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.student.bean.EducationBean;
import com.java.util.PreparedStatementUtil;

public class TableEducationDao {
	
	public Boolean CheckEducation(int Coop03ID){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = "SELECT True as isEducation FROM cooperative.tb_education WHERE Coop03ID = :coop03id LIMIT 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("coop03id", Coop03ID);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getBoolean("isEducation");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public void InsertEducation(EducationBean educationBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "INSERT INTO tb_education(Name,"
		   									+ "Year_attended,"
		   									+ "Year_graduated,"
		   									+ "Certificate,"
		   									+ "Major,"
		   									+ "Type,"
		   									+ "Coop03ID) "
					   		+ " VALUES(:name,"   
					   				+ ":year_attended,"
					   				+ ":year_graduated,"
					   				+ ":certificate,"
					   				+ ":major,"
					   				+ ":type,"
					   				+ ":coop03id)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("name", educationBean.getName());
		   preparedStatementUtil.setString("year_attended", educationBean.getYear_attended());
		   preparedStatementUtil.setString("year_graduated", educationBean.getYear_graduated());
		   preparedStatementUtil.setString("certificate", educationBean.getCertificate());
		   preparedStatementUtil.setString("major", educationBean.getMajor());
		   preparedStatementUtil.setString("type", educationBean.getType());
		   preparedStatementUtil.setInt("coop03id", educationBean.getCoop03id());
		   preparedStatementUtil.execute();   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	
	public void UpdateEducation(EducationBean educationBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_education SET "
		   				+ "Name = :name,"
		   				+ "Year_attended = :year_attended,"
		   				+ "Year_graduated = :year_graduated,"
		   				+ "Certificate = :certificate,"
		   				+ "Major = :major "
		   				+ "WHERE Coop03ID = :coop03id && Type = :type ";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("name", educationBean.getName());
		   preparedStatementUtil.setString("year_attended", educationBean.getYear_attended());
		   preparedStatementUtil.setString("year_graduated", educationBean.getYear_graduated());
		   preparedStatementUtil.setString("certificate", educationBean.getCertificate());
		   preparedStatementUtil.setString("major", educationBean.getMajor());
		   preparedStatementUtil.setString("type", educationBean.getType());
		   preparedStatementUtil.setInt("coop03id", educationBean.getCoop03id());
		   preparedStatementUtil.execute();	   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public EducationBean SelectEducation(int Coop03ID, String type){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		EducationBean educationBean = new EducationBean();
		String query = "SELECT Name,Year_attended,Year_graduated,Certificate"
				+ ",Major,Type"
				+ " FROM tb_education"
				+ " WHERE Coop03ID = :coop03id && Type = :type  LIMIT 1"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("coop03id", Coop03ID);
			preparedStatementUtil.setString("type", type);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				educationBean.setName(rs.getString("Name"));
				educationBean.setYear_attended(rs.getString("Year_attended"));
				educationBean.setYear_graduated(rs.getString("Year_graduated"));
				educationBean.setCertificate(rs.getString("Certificate"));
				educationBean.setMajor(rs.getString("Major"));
				educationBean.setType(rs.getString("Type"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return educationBean;
	}
}
