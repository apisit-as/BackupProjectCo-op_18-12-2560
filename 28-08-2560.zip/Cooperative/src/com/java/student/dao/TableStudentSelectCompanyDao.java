package com.java.student.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.staff.bean.RateCompanyBean;
import com.java.staff.bean.RateCompanyListBean;
import com.java.student.bean.StudentSelectCompanyBean;
import com.java.util.PreparedStatementUtil;

public class TableStudentSelectCompanyDao {

	public void InsertStudentSelectCompany(int userid,int academic_id){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "INSERT INTO tb_student_select_company"
						+ "(UserID,Academic_year) "
				+ " VALUES(:userid,:academic_id)";
				preparedStatementUtil = new PreparedStatementUtil(query);
				preparedStatementUtil.setInt("userid",userid);
				preparedStatementUtil.setInt("academic_id",academic_id);
				preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public int getAcademicID(int user_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		int academic_id = 0;
		String query = "SELECT Academic_year "
				+ " FROM tb_student_select_company"
				+ " WHERE UserID = :userid  LIMIT 1"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("userid", user_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				academic_id = rs.getInt("Academic_year");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return academic_id;
	} 
	public int SelectRateCompanyID(int user_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		int rate_company_id = 0;
		String query = "SELECT  RateCompanyID "
					   +"FROM tb_student_select_company  "
					   +"WHERE UserID = :user_id  LIMIT 1";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("user_id", user_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				rate_company_id = rs.getInt("RateCompanyID");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return rate_company_id;
	}
	
	public ArrayList<RateCompanyListBean> SelectListRateCompany(int academic_id,int divisioin_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ArrayList<RateCompanyListBean> list = new ArrayList<>();
		String query = "SELECT  tb_rate_company.ID AS rate_company_id,"
							   +"tb_company.ID AS company_id,"
							   +"tb_company.NameCompany,"
							   +"tb_company.ProvinceCompany,"
							   +"tb_region.Name AS region_name,"
							   +"tb_faculty.Name AS faculty_name,"
							   +"tb_division.Name AS divison_name,"
							   +"tb_rate_company.Type_offerjob,"
							   +"tb_rate_company.Num_student AS num_studnet_total,"
							   +"tb_academic_year.Semester,"
							   +"tb_academic_year.Academic_year	"
					   +"FROM tb_rate_company  "
					   +"JOIN tb_academic_year  ON tb_academic_year.ID = tb_rate_company.Academic_yearID "
					   +"JOIN tb_faculty  ON tb_faculty.ID = tb_rate_company.FacID "
					   +"JOIN tb_division  ON tb_division.ID = tb_rate_company.DivID "
					   +"JOIN tb_company  ON tb_company.ID = tb_rate_company.CompanyID  "
					   +"JOIN tb_region  ON tb_region.ID = tb_company.RegionCompany "
					   +"WHERE tb_rate_company.Academic_yearID = :academic_id "
					   		+ " AND tb_rate_company.DivID = :divisioin_id  ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("academic_id", academic_id);
			preparedStatementUtil.setInt("divisioin_id", divisioin_id);
			rs = preparedStatementUtil.executeQuery();
			while(rs.next()){
				RateCompanyListBean bean = new RateCompanyListBean();
				bean.setRate_company_id(rs.getInt("rate_company_id"));
				bean.setCompany_id(rs.getInt("company_id"));
				bean.setName_company(rs.getString("NameCompany"));
				bean.setProvice_company(rs.getString("ProvinceCompany"));
				bean.setRegion_company_name(rs.getString("region_name"));
				bean.setFac_name(rs.getString("faculty_name"));
				bean.setDiv_name(rs.getString("divison_name"));
				bean.setType_offer_job(rs.getString("Type_offerjob"));
				bean.setNum_student(getNumberStudent(bean.getRate_company_id()));
				bean.setNum_student_total(rs.getInt("num_studnet_total"));
				bean.setSemester(rs.getString("Semester"));
				bean.setAcademic_year(rs.getString("Academic_year"));
				list.add(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public int getNumberStudent(int rate_company_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		int num_student = 0;
		String query = "SELECT  COUNT(tb_student_select_company.RateCompanyID) AS num_student "
							+"FROM tb_student_select_company "
							+"WHERE tb_student_select_company.RateCompanyID = :rate_company_id  LIMIT 1";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("rate_company_id", rate_company_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				num_student = rs.getInt("num_student");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return num_student;
	}
	
	public int getNumberTotalStudent(int rate_company_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		int number_total_student = 0;
		String query = "SELECT tb_rate_company.Num_student AS num_studnet_total "  
					   +"FROM tb_rate_company  "
					   +"WHERE tb_rate_company.ID = :rate_company_id  LIMIT 1";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("rate_company_id", rate_company_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				number_total_student = rs.getInt("num_studnet_total");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return number_total_student;
	}
	
	public Boolean checkDivision(int rate_company_id,int student_user_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		Boolean value = true;
		int division_rate_company = 0;
		int division_user = 0;
		int academic_id_rate_company = 0;
		
		// check division rate_company
		String query = "SELECT  tb_rate_company.DivID,"
							 + "tb_rate_company.Academic_yearID "
					+ " FROM tb_rate_company "
					+ " WHERE  tb_rate_company.ID = :rate_company_id  LIMIT 1";	
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("rate_company_id", rate_company_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				division_rate_company = rs.getInt("DivID");
				academic_id_rate_company = rs.getInt("Academic_yearID");
			}	
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
		// check division user
		try {
			query = "SELECT  tb_user.DivID "
					+ " FROM tb_user "
					+ " WHERE  tb_user.ID = :student_user_id  LIMIT 1";	
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("student_user_id", student_user_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				division_user = rs.getInt("DivID");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		// get academic id  
		int academic_year_id = getAcademicID(student_user_id);
		if(division_rate_company != division_user  ||  division_rate_company == 0 || division_user == 0 || academic_year_id != academic_id_rate_company){
			/**
			 *   division_rate_company != division_user   �Ң��Ԫ� rate_company ���ç�Ѻ  �ҢҢͧ�ѡ�֡��
			 *   division_rate_company == 0   ||   division_user == 0    ��辺�Ң��Ԫ�
			 *   academic_year_id != academic_id_rate_company   �շ����Ѥ�   ���ç�ѹ�Ѻ   �շ������ rate_company  
			 */
			value = false;
		}
		return value;
	}
	
	public Boolean checkSelectCompany(int user_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = "SELECT  True as isCheck "
				+ " FROM tb_student_select_company "
				+ " JOIN tb_user  ON tb_user.ID = tb_student_select_company.UserID "
				+ " JOIN tb_student_send_document  ON tb_student_send_document.UserID = tb_user.ID "
				+ " WHERE (tb_student_select_company.RateCompanyID IS null OR tb_student_select_company.Lv1_ApStatusID = 5 OR tb_student_select_company.Staff_ApStatusID = 12)"
						+ " AND (tb_student_select_company.UserID = :user_id) AND (tb_student_send_document.Lv2_ApStatusID = 2)  LIMIT 1";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("user_id", user_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getBoolean("isCheck");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public void updateStudentSelectCompany(StudentSelectCompanyBean bean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
			  /**
			   *   status approval  =  1   ��͹��ѵ�
			   */
		   String query = "UPDATE tb_student_select_company SET "
		   				+ "RateCompanyID = :rate_company_id,"
		   				+ "RateCompanyID_Temp = :rate_company_id_temp,"
		   				+ "Lv1_ApStatusID = 1 ,"
		   				+ "Staff_ApStatusID = null , "
		   				+ "Comment = null ,"
		   				+ "File = null "
		   				+ "WHERE UserID = :user_id ";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("rate_company_id", bean.getRate_company_id());
		   preparedStatementUtil.setInt("rate_company_id_temp", bean.getRate_company_id());
		   preparedStatementUtil.setInt("user_id", bean.getUser_id());
		   preparedStatementUtil.execute(); 
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
		  
		  try{
			   String query = "UPDATE tb_coop03 SET "
			   				+ "PreTime = :pre_time,"
			   				+ "Posttime = :post_time ,"
			   				+ "Position = :position , "
			   				+ "CodeJob = :code_job , "
			   				+ "SendDocuments = :send_documents "
			   				+ "WHERE UserID = :user_id ";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setString("pre_time", bean.getStart_date_workout());
			   preparedStatementUtil.setString("post_time", bean.getStop_date_workout());
			   preparedStatementUtil.setString("position", bean.getPosition());
			   preparedStatementUtil.setString("code_job", bean.getCodeJob());
			   preparedStatementUtil.setString("send_documents", bean.getSend_documents());
			   preparedStatementUtil.setInt("user_id", bean.getUser_id());
			   preparedStatementUtil.execute(); 
			  }catch(Exception e){
			   e.printStackTrace();
			  }finally{
			   if(preparedStatementUtil != null)
				try {
					preparedStatementUtil.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			  }
	}
	
	public int SelectCompanyID(int user_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		int company_id = 0;
		String query = "SELECT  tb_rate_company.CompanyID "
					   +"FROM tb_student_select_company  "
					   +"JOIN tb_rate_company  ON tb_rate_company.ID = tb_student_select_company.RateCompanyID "
					   +"WHERE tb_student_select_company.UserID = :user_id  LIMIT 1";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("user_id", user_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				company_id  = rs.getInt("CompanyID");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return company_id;
	}
	
	public RateCompanyBean SelectRateCompany(int user_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		RateCompanyBean bean = new RateCompanyBean();
		String query = "SELECT  tb_academic_year.Semester,"
							   +"tb_academic_year.Academic_year,"
							   +"tb_rate_company.Num_student AS num_studnet_total,"
							   +"tb_faculty.Name AS faculty_name,"
							   +"tb_division.Name AS divison_name,"
							   +"tb_rate_company.Type_offerjob "
					   +"FROM tb_student_select_company  "
					   +"JOIN tb_rate_company  ON tb_rate_company.ID = tb_student_select_company.RateCompanyID "
					   +"JOIN tb_academic_year  ON tb_academic_year.ID = tb_rate_company.Academic_yearID "
					   +"JOIN tb_faculty  ON tb_faculty.ID = tb_rate_company.FacID "
					   +"JOIN tb_division  ON tb_division.ID = tb_rate_company.DivID "
					   +"WHERE tb_student_select_company.UserID = :user_id  LIMIT 1";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("user_id", user_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				bean.setSemester(rs.getString("Semester"));
				bean.setAcademic_year(rs.getString("Academic_year"));
				bean.setNum_student_total(rs.getInt("num_studnet_total"));
				bean.setFac_name(rs.getString("faculty_name"));
				bean.setDiv_name(rs.getString("divison_name"));
				bean.setType_offer_job(rs.getString("Type_offerjob"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return bean;
	}
	
	public String getPathFile(int user_id){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		String file = "";
		String query = "SELECT File "
				+ " FROM tb_student_select_company"
				+ " WHERE UserID = :userid   LIMIT 1"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("userid", user_id);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				file = rs.getString("File");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return file;
	}
}
