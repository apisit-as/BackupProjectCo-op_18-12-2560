package com.java.student.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.util.PreparedStatementUtil;

public class CheckStepDao {

	public String CheckStep(int student_user_id){
		String step = ""; 
		if(!CheckTableSendDocument(student_user_id) || CheckStep1(student_user_id)){
			step = "1";
		}else if(CheckStep2(student_user_id)){
			step = "2";
		}else if(CheckStep3(student_user_id)){
			step = "3";
		}else if(CheckStep4(student_user_id)){
			step = "4";
		}else if(CheckStep5(student_user_id)){
			step = "5";
		}else if(CheckStep6(student_user_id)){
			step = "6";
		}else if(CheckStep7(student_user_id)){
			step = "7";
		}
		return step;
	}
	
	public Boolean CheckTableSendDocument(int student_user_id){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = "SELECT True as isTable FROM tb_student_send_document WHERE UserID = :student_user_id LIMIT 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("student_user_id", student_user_id);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getBoolean("isTable");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public Boolean CheckStep1(int student_user_id){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		/**
		 *    Lv1_ApStatusID = 4   �觡�Ѻ���
		 *    Lv2_ApStatusID = 4   �觡�Ѻ���
		 */
		String query = "SELECT True as isTable "
					 + "FROM tb_student_send_document "
					 + "WHERE (UserID = :student_user_id) "
					 + " AND (Lv1_ApStatusID = 4 OR Lv2_ApStatusID = 4) LIMIT 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("student_user_id", student_user_id);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getBoolean("isTable");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public Boolean CheckStep2(int student_user_id){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		/**
		 *     Lv1_ApStatusID = 6  �ʹ��Թ���    ,  3    ���͹��ѵ�����͡��ԺѵԧҹʡԨ�֡�� 
		 */
		String query = "SELECT True as isTable "
					 + "FROM tb_student_send_document "
					 + "WHERE (UserID = :student_user_id) "
					 + " AND (Lv1_ApStatusID = 6 OR Lv1_ApStatusID = 3) LIMIT 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("student_user_id", student_user_id);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getBoolean("isTable");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public Boolean CheckStep3(int student_user_id){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		/**
		 *   Lv1_ApStatusID = 2   ͹��ѵ�
		 *   Lv2_ApStatusID = 6 �ʹ��Թ���      ,  3  ���͹��ѵ�����͡��ԺѵԧҹʡԨ�֡��
		 */
		String query = "SELECT True as isTable "
					 + "FROM tb_student_send_document "
					 + "WHERE (UserID = :student_user_id) "
					 + " AND (Lv1_ApStatusID = 2) AND (Lv2_ApStatusID = 6 OR Lv2_ApStatusID = 3) LIMIT 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("student_user_id", student_user_id);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getBoolean("isTable");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public Boolean CheckStep4(int student_user_id){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		/**
		 *   tb_student_send_document.Lv2_ApStatusID = 2   ͹��ѵ�
		 *   tb_student_select_company.Lv1_ApStatusID = 5  ���͹��ѵ�
		 *   tb_student_select_company.Staff_ApStatusID = 12  ���ͺ�Ѻ
		 *   tb_student_select_company.Lv1_ApStatusID IS null 
		 */
		String query = "SELECT True as isTable "
					 + "FROM tb_student_send_document "
					 + "JOIN tb_student_select_company  ON tb_student_select_company.UserID = tb_student_send_document.UserID "
					 + "WHERE (tb_student_select_company.UserID = :student_user_id) "
					 + " AND (tb_student_send_document.Lv2_ApStatusID = 2) "
					 + " AND (tb_student_select_company.Lv1_ApStatusID = 5 "
					 		+ "OR tb_student_select_company.Staff_ApStatusID = 12 "
					 		+ "OR tb_student_select_company.Lv1_ApStatusID IS null) LIMIT 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("student_user_id", student_user_id);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getBoolean("isTable");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public Boolean CheckStep5(int student_user_id){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		/**
		 *   tb_student_select_company.Lv1_ApStatusID = 1  ��͹��ѵ�
		 */
		String query = "SELECT True as isTable "
					 + "FROM tb_student_select_company "
					 + "WHERE (tb_student_select_company.UserID = :student_user_id) "
					 + " AND (tb_student_select_company.Lv1_ApStatusID = 1) LIMIT 1 ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("student_user_id", student_user_id);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getBoolean("isTable");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public Boolean CheckStep6(int student_user_id){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		/**
		 *   tb_student_select_company.Lv1_ApStatusID = 2   ͹��ѵ�
		 *   tb_student_select_company.Staff_ApStatusID = 6  �ʹ��Թ���
		 *   tb_student_select_company.Staff_ApStatusID = 7   ���ѧ���Թ���
		 *   tb_student_select_company.Staff_ApStatusID = 9   �Դ����Ѻ������
		 *   tb_student_select_company.Staff_ApStatusID = 10   �͵ͺ�Ѻ
		 *   tb_student_select_company.Staff_ApStatusID = 13   �ѡ�֡�ҵԴ������˹�ҷ��
		 */
		String query = "SELECT True as isTable "
					 + "FROM tb_student_select_company "
					 + "WHERE (tb_student_select_company.UserID = :student_user_id) "
					 + " AND (tb_student_select_company.Lv1_ApStatusID = 2) "
					 + " AND (tb_student_select_company.Staff_ApStatusID = 6 "
					 		+ "OR tb_student_select_company.Staff_ApStatusID = 7 "
					 		+ "OR tb_student_select_company.Staff_ApStatusID = 9 "
					 		+ "OR tb_student_select_company.Staff_ApStatusID = 10 "
					 		+ "OR tb_student_select_company.Staff_ApStatusID = 13 ) LIMIT 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("student_user_id", student_user_id);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getBoolean("isTable");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public Boolean CheckStep7(int student_user_id){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		/**
		 *   tb_student_select_company.Staff_ApStatusID = 11   �ͺ�Ѻ
		 */
		String query = "SELECT True as isTable "
					 + "FROM tb_student_select_company "
					 + "WHERE (tb_student_select_company.UserID = :student_user_id) "
					 + " AND (tb_student_select_company.Staff_ApStatusID = 11) LIMIT 1 ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("student_user_id", student_user_id);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getBoolean("isTable");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
}
