package com.java.student.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.student.bean.CareerBean;
import com.java.util.PreparedStatementUtil;

public class TableCareerDao {
	public Boolean CheckCareer(int Coop03ID){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = "SELECT True as isCareer FROM cooperative.tb_career WHERE Coop03ID = :coop03id LIMIT 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("coop03id", Coop03ID);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getBoolean("isCareer");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public void InsertCareer(CareerBean careerBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "INSERT INTO tb_career(Name,"
		   									+ "Type,"
		   									+ "Coop03ID) "
					   		+ " VALUES(:name,"   
					   				+ ":type,"
					   				+ ":coop03id)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("name", careerBean.getName());
		   preparedStatementUtil.setString("type", careerBean.getType());
		   preparedStatementUtil.setInt("coop03id", careerBean.getCoop03id());
		   preparedStatementUtil.execute();   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void UpdateCareer(CareerBean careerBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_career SET "
		   				+ "Name = :name "
		   				+ "WHERE Coop03ID = :coop03id && Type = :type ";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("name", careerBean.getName());
		   preparedStatementUtil.setString("type", careerBean.getType());
		   preparedStatementUtil.setInt("coop03id", careerBean.getCoop03id());
		   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public CareerBean SelectCareer(int Coop03ID,String type){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		CareerBean careerBean = new CareerBean();
		String query = "SELECT Name,Type"
				+ " FROM tb_career"
				+ " WHERE Coop03ID = :coop03id && Type = :type LIMIT 1"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("coop03id", Coop03ID);
			preparedStatementUtil.setString("type", type);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				careerBean.setName(rs.getString("Name"));
				careerBean.setType(rs.getString("Type"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return careerBean;
	}
}
