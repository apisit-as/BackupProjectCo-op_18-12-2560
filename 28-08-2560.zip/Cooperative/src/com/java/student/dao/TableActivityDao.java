package com.java.student.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.student.bean.ActivityBean;
import com.java.util.PreparedStatementUtil;

public class TableActivityDao {
	public Boolean CheckActivity(int Coop03ID){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = "SELECT True as isActivity FROM cooperative.tb_activity WHERE Coop03ID = :coop03id LIMIT 1";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("coop03id", Coop03ID);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getBoolean("isActivity");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public void InsertActivity(ActivityBean activityBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "INSERT INTO tb_activity(Datetime,"
		   									+ "Position,"
		   									+ "Type,"
		   									+ "Coop03ID) "
					   		+ " VALUES(:datetime,"   
					   				+ ":position,"
					   				+ ":type,"
					   				+ ":coop03id)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("datetime", activityBean.getDate_time());
		   preparedStatementUtil.setString("position", activityBean.getPosition());
		   preparedStatementUtil.setString("type", activityBean.getType());
		   preparedStatementUtil.setInt("coop03id", activityBean.getCoop03id());
		   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void UpdateActivity(ActivityBean activityBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_activity SET "
		   				+ "Datetime = :datetime,"
		   				+ "Position = :position "
		   				+ "WHERE Coop03ID = :coop03id && Type = :type ";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("datetime", activityBean.getDate_time());
		   preparedStatementUtil.setString("position", activityBean.getPosition());
		   preparedStatementUtil.setString("type", activityBean.getType());
		   preparedStatementUtil.setInt("coop03id", activityBean.getCoop03id());
		   preparedStatementUtil.execute();   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public ActivityBean SelectActivity(int Coop03ID,String type){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		ActivityBean activityBean = new ActivityBean();
		String query = "SELECT Datetime,Position,Type"
				+ " FROM tb_activity"
				+ " WHERE Coop03ID = :coop03id && Type = :type  LIMIT 1"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("coop03id", Coop03ID);
			preparedStatementUtil.setString("type", type);
			rs = preparedStatementUtil.executeQuery();
			if(rs.next()){
				activityBean.setDate_time(rs.getString("Datetime"));
				activityBean.setPosition(rs.getString("Position"));
				activityBean.setType(rs.getString("Type"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return activityBean;
	}
}
