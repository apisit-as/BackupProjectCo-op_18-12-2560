package com.java.student.bean;

public class CheckStatusCompanyBean {
	private String teacher_lv1_status;
	private String staff_status;
	private String comment;
	private String file;
	public String getTeacher_lv1_status() {
		return teacher_lv1_status;
	}
	public void setTeacher_lv1_status(String teacher_lv1_status) {
		this.teacher_lv1_status = teacher_lv1_status;
	}
	public String getStaff_status() {
		return staff_status;
	}
	public void setStaff_status(String staff_status) {
		this.staff_status = staff_status;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
}
