package com.java.student.bean;

public class DataReportBean {
	private int id;
	private String date;
	private String teacher1_name;
	private String teacher2_name;
	private int user_id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTeacher1_name() {
		return teacher1_name;
	}
	public void setTeacher1_name(String teacher1_name) {
		this.teacher1_name = teacher1_name;
	}
	public String getTeacher2_name() {
		return teacher2_name;
	}
	public void setTeacher2_name(String teacher2_name) {
		this.teacher2_name = teacher2_name;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
}
