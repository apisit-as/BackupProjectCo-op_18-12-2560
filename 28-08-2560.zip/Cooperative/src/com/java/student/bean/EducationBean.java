package com.java.student.bean;

public class EducationBean {
	private int id;
	private String name;
	private String year_attended;
	private String year_graduated;
	private String certificate;
	private String major;
	private String type;
	private int coop03id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getYear_attended() {
		return year_attended;
	}
	public void setYear_attended(String year_attended) {
		this.year_attended = year_attended;
	}
	public String getYear_graduated() {
		return year_graduated;
	}
	public void setYear_graduated(String year_graduated) {
		this.year_graduated = year_graduated;
	}
	public String getCertificate() {
		return certificate;
	}
	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getCoop03id() {
		return coop03id;
	}
	public void setCoop03id(int coop03id) {
		this.coop03id = coop03id;
	}
}
