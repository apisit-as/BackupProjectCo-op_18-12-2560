package com.java.student.bean;

public class StudentSelectCompanyBean {
	private int user_id;
	private String position;
	private String codeJob;
	private String send_documents;
	private String start_date_workout;
	private String stop_date_workout;
	private int rate_company_id;
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getCodeJob() {
		return codeJob;
	}
	public void setCodeJob(String codeJob) {
		this.codeJob = codeJob;
	}
	public String getSend_documents() {
		return send_documents;
	}
	public void setSend_documents(String send_documents) {
		this.send_documents = send_documents;
	}
	public String getStart_date_workout() {
		return start_date_workout;
	}
	public void setStart_date_workout(String start_date_workout) {
		this.start_date_workout = start_date_workout;
	}
	public String getStop_date_workout() {
		return stop_date_workout;
	}
	public void setStop_date_workout(String stop_date_workout) {
		this.stop_date_workout = stop_date_workout;
	}
	public int getRate_company_id() {
		return rate_company_id;
	}
	public void setRate_company_id(int rate_company_id) {
		this.rate_company_id = rate_company_id;
	}
}
