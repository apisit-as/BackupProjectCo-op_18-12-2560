package com.java.student.bean;

public class TrainingBean {
	private int id;
	private String start_date;
	private String stop_date;
	private String place;
	private String position;
	private String type;
	private int coop03id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getStart_date() {
		return start_date;
	}
	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}
	public String getStop_date() {
		return stop_date;
	}
	public void setStop_date(String stop_date) {
		this.stop_date = stop_date;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getCoop03id() {
		return coop03id;
	}
	public void setCoop03id(int coop03id) {
		this.coop03id = coop03id;
	}
}
