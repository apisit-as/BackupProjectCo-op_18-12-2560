package com.java.list.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


import com.java.list.bean.ProvinceBean;
import com.java.util.PreparedStatementUtil;

public class ProvinceSelectListDao {

		public ArrayList<ProvinceBean> getProvinceList() {
			PreparedStatementUtil preparedStatementUtil = null;
			ResultSet rs = null;
			ArrayList<ProvinceBean> listProvince = new ArrayList<ProvinceBean>();
			  try{
			   String query = "SELECT ID,Name FROM cooperative.tb_province"
			   		+ " ORDER BY Name ASC";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   rs = preparedStatementUtil.executeQuery();   
			   
			   while(rs.next()){
				   ProvinceBean provinceBean = new ProvinceBean();
				   provinceBean.setId(rs.getInt("ID"));
				   provinceBean.setName(rs.getString("Name"));
				   listProvince.add(provinceBean);
				}
			   
			  }catch(Exception e){
			   e.printStackTrace();
			  }finally{
				  try {
					rs.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			   if(preparedStatementUtil != null)
				try {
					preparedStatementUtil.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			  }
			  return listProvince;
		}
}
