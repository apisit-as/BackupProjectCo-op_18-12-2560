package com.java.util;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;

import com.java.student.bean.Coop03Bean;
import com.java.student.dao.TableCoop03Dao;
public class ImageResize {

	public void ResizeStudentProfile(HttpServletRequest request,int userid,String typeFile,int width,int height){
		TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
		Coop03Bean coop03Bean = new Coop03Bean();
		coop03Bean = tableCoop03Dao.SelectCoop03(userid);
		
		 String path = request.getServletContext().getRealPath("/");
		 path = path+""+coop03Bean.getPicture();
		try{
			BufferedImage originalImage = ImageIO.read(new File(path));
			
			int type = originalImage.getType() == 0? BufferedImage.TYPE_INT_ARGB : originalImage.getType();
			BufferedImage resizeImagePng = resizeImage(originalImage, type,width,height);
			ImageIO.write(resizeImagePng, typeFile, new File(path));

		}catch(IOException e){
			System.out.println(e.getMessage());
		}
	}
	
	public void ResizeSlideImage(HttpServletRequest request,String pathFile,String typeFile,int width,int height){
		 String path = request.getServletContext().getRealPath("/");
		 path = path+""+pathFile;
		try{
			BufferedImage originalImage = ImageIO.read(new File(path));
			
			int type = originalImage.getType() == 0? BufferedImage.TYPE_INT_ARGB : originalImage.getType();
			BufferedImage resizeImagePng = resizeImage(originalImage, type,width,height);
			ImageIO.write(resizeImagePng, typeFile, new File(path));

		}catch(IOException e){
			System.out.println(e.getMessage());
		}
	}
	
    private static BufferedImage resizeImage(BufferedImage originalImage, int type, int IMG_WIDTH, int IMG_HEIGHT ){
		BufferedImage resizedImage = new BufferedImage(IMG_WIDTH, IMG_HEIGHT, type);
		Graphics2D g = resizedImage.createGraphics();
		g.drawImage(originalImage, 0, 0, IMG_WIDTH, IMG_HEIGHT, null);
		g.dispose();
	
		return resizedImage;
    }
}
