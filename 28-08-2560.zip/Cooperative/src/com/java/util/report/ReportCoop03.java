package com.java.util.report;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.java.student.bean.ActivityBean;
import com.java.student.bean.AddressBean;
import com.java.student.bean.CareerBean;

import com.java.student.bean.Coop03Bean;
import com.java.student.bean.EducationBean;
import com.java.student.bean.FamilyBean;

import com.java.student.bean.Language03Bean;
import com.java.student.bean.ProfileBean;
import com.java.student.bean.RelativeBean;

import com.java.student.bean.TrainingBean;
import com.java.student.bean.UserBean;

import com.java.util.report.ThaiExporterManager;


import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;

import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;

import javax.servlet.http.HttpServletRequest;

public class ReportCoop03{

	public void insertCoop03Pdf(HttpServletRequest request,UserBean userBean,ProfileBean profileBean,List<AddressBean> addressBeanList,List<FamilyBean> familyBeanList,Coop03Bean coop03Bean,List<EducationBean> educationBeansList
								,List<RelativeBean> relativeBeansList,List<TrainingBean> trainingBeansList,List<CareerBean> careerBeansList,List<ActivityBean> activityBeansList,Language03Bean language03Bean){
		try {
			/* User home directory location */
			String userHomeDirectory = request.getServletContext().getRealPath("/");
			String studentid = userBean.getStudentid();
			String userid =  Integer.toString(userBean.getId());
			
			/* Output file location */
			String filename = studentid+"_"+userid;
			String fileShow = "Upload/File/Report/PDF/" + filename +"_coop03.pdf";
			String outputFile = userHomeDirectory + File.separatorChar + "/" + fileShow;
			
			
			/* Create path  */
		    File file = new File(userHomeDirectory, "Upload/File/Report/PDF/");
		    if (!file.exists()) {
		     file.mkdirs();
		    }
			
			/* Convert List to JRBeanCollectionDataSource */
//			JRBeanCollectionDataSource userList = new JRBeanCollectionDataSource(userBeanList);

			/* Map to hold Jasper report Parameters */
			Map<String, Object> parameters = new HashMap<String, Object>();
			
			// company
			if(coop03Bean.getCompany_name() == null) coop03Bean.setCompany_name("");
			if(coop03Bean.getPosition() == null) coop03Bean.setPosition("");
			if(coop03Bean.getPre_time() == null) coop03Bean.setPre_time("");
			if(coop03Bean.getPost_time() == null) coop03Bean.setPost_time("");
			parameters.put("Company_Name", coop03Bean.getCompany_name());
			parameters.put("Company_Position", coop03Bean.getPosition());
			parameters.put("Company_PreTime", coop03Bean.getPre_time());
			parameters.put("Company_PostTime", coop03Bean.getPost_time());

			// 1
			String pciturePath = request.getServletContext().getRealPath(coop03Bean.getPicture());
			parameters.put("picture",pciturePath);
			parameters.put("studentid", userBean.getStudentid() );
			parameters.put("titleName_th", userBean.getTitlename_th());
			parameters.put("firstName_th",userBean.getFirstname_th());
			parameters.put("lastName_th",userBean.getLastname_th());
			parameters.put("titleName_eng",userBean.getTitlename_eng());
			parameters.put("firstName_eng",userBean.getFirstname_eng());
			parameters.put("lastName_eng",userBean.getLastname_eng());
			parameters.put("classYear",profileBean.getClassyear());
			parameters.put("groupStudent",profileBean.getGroupstudent());
			parameters.put("facName",userBean.getFacname());
			parameters.put("divisionName",userBean.getDivname());
			parameters.put("titleAdvisor",profileBean.getTitlename_th());
			parameters.put("FirstNameAdvisor",profileBean.getFirstnameadvisor());
			parameters.put("LastNameAdvisor",profileBean.getLastnameadvisor());
			parameters.put("grade",profileBean.getGrade());
			parameters.put("gradeTotal",profileBean.getGradetotal());
			// #1

			// 2
			parameters.put("id_card",profileBean.getId_card());
			parameters.put("issue_at",profileBean.getIssue_at());
			parameters.put("issue_date",profileBean.getIssue_date());
			parameters.put("expiry_date",profileBean.getExpiry_date());
			parameters.put("race",profileBean.getRace());
			parameters.put("nationality",profileBean.getNationality());
			parameters.put("religion",profileBean.getReligion());
			parameters.put("age",profileBean.getAge());
			parameters.put("birthday",profileBean.getBirthday());
			parameters.put("place_birth",profileBean.getPlace_birth());
			parameters.put("sex",profileBean.getSex());
			parameters.put("height",profileBean.getHeight());
			parameters.put("weight",profileBean.getWeight());
			parameters.put("congenital_disease",profileBean.getCongenital_disease());
			// #2
			
			// 3  4
				// semester_address
			parameters.put("id_num2",addressBeanList.get(1).getId_num());
			parameters.put("num_mu2",addressBeanList.get(1).getNum_mu());
			parameters.put("road2",addressBeanList.get(1).getRoad());
			parameters.put("provinceName2",addressBeanList.get(1).getProvincename());
			parameters.put("amphurName2",addressBeanList.get(1).getAmphurname());
			parameters.put("districtName2",addressBeanList.get(1).getDistrictname());
			parameters.put("postCode2",addressBeanList.get(1).getPostcode());
			parameters.put("telephone2",addressBeanList.get(1).getTelephone());
			parameters.put("mobile2",addressBeanList.get(1).getMobile());
			parameters.put("fax2",addressBeanList.get(1).getFax());
			parameters.put("email2",addressBeanList.get(1).getEmail());
			
				// original_address
			parameters.put("id_num1",addressBeanList.get(0).getId_num());
			parameters.put("num_mu1",addressBeanList.get(0).getNum_mu());
			parameters.put("road1",addressBeanList.get(0).getRoad());
			parameters.put("provinceName1",addressBeanList.get(0).getProvincename());
			parameters.put("amphurName1",addressBeanList.get(0).getAmphurname());
			parameters.put("districtName1",addressBeanList.get(0).getDistrictname());
			parameters.put("postCode1",addressBeanList.get(0).getPostcode());
			parameters.put("telephone1",addressBeanList.get(0).getTelephone());
			parameters.put("mobile1",addressBeanList.get(0).getMobile());
			parameters.put("fax1",addressBeanList.get(0).getFax());
			parameters.put("email1",addressBeanList.get(0).getEmail());
			// #3   4
			
			// 5
			parameters.put("titleName_parent",familyBeanList.get(2).getTitlename());
			parameters.put("firstName_parent",familyBeanList.get(2).getFirstname());
			parameters.put("lastName_parent",familyBeanList.get(2).getLastname());
			
			parameters.put("relation_parent",familyBeanList.get(2).getRelation());
			parameters.put("occupation_parent",familyBeanList.get(2).getOccupation());
			parameters.put("placeOccupation_parent",familyBeanList.get(2).getPlace_occupation());
			
				// parent_address
			parameters.put("id_num3",addressBeanList.get(2).getId_num());
			parameters.put("num_mu3",addressBeanList.get(2).getNum_mu());
			parameters.put("road3",addressBeanList.get(2).getRoad());
			parameters.put("provinceName3",addressBeanList.get(2).getProvincename());
			parameters.put("amphurName3",addressBeanList.get(2).getAmphurname());
			parameters.put("districtName3",addressBeanList.get(2).getDistrictname());
			parameters.put("postCode3",addressBeanList.get(2).getPostcode());
			parameters.put("telephone3",addressBeanList.get(2).getTelephone());
			parameters.put("mobile3",addressBeanList.get(2).getMobile());
			parameters.put("fax3",addressBeanList.get(2).getFax());
			parameters.put("email3",addressBeanList.get(2).getEmail());
			// #5
			
			
			// 6
			parameters.put("titleName_father",familyBeanList.get(0).getTitlename());
			parameters.put("firstName_father",familyBeanList.get(0).getFirstname());
			parameters.put("lastName_father",familyBeanList.get(0).getLastname());
			parameters.put("age_father",familyBeanList.get(0).getAge());
			parameters.put("occupation_father",familyBeanList.get(0).getOccupation());
			
			parameters.put("titleName_mother",familyBeanList.get(1).getTitlename());
			parameters.put("firstName_mother",familyBeanList.get(1).getFirstname());
			parameters.put("lastName_mother",familyBeanList.get(1).getLastname());
			parameters.put("age_mother",familyBeanList.get(1).getAge());
			parameters.put("occupation_mother",familyBeanList.get(1).getOccupation());

			parameters.put("num_relative",coop03Bean.getNum_relative());
			parameters.put("my_relative",coop03Bean.getMy_relative());
			

			for(int i=0; i<=2; i++){
				if(relativeBeansList.get(i).getTitle_th() == null) relativeBeansList.get(i).setTitle_th("");
				if(relativeBeansList.get(i).getFirstname() == null)	relativeBeansList.get(i).setFirstname("");
				if(relativeBeansList.get(i).getLastname() == null)	relativeBeansList.get(i).setLastname("");
				if(relativeBeansList.get(i).getAge() == null)  relativeBeansList.get(i).setAge("");
				if(relativeBeansList.get(i).getOccupation() == null)  relativeBeansList.get(i).setOccupation("");
				if(relativeBeansList.get(i).getPosition() == null)  relativeBeansList.get(i).setPosition("");
			}
			parameters.put("titleNameTH_relative1",relativeBeansList.get(0).getTitle_th());
			parameters.put("firstNameTH_relative1",relativeBeansList.get(0).getFirstname());
			parameters.put("lastNameTH_relative1",relativeBeansList.get(0).getLastname());
			parameters.put("age_relative1",relativeBeansList.get(0).getAge());
			parameters.put("occupation_relative1",relativeBeansList.get(0).getOccupation());
			parameters.put("position_relative1",relativeBeansList.get(0).getPosition());
			
			parameters.put("titleNameTH_relative2",relativeBeansList.get(1).getTitle_th());
			parameters.put("firstNameTH_relative2",relativeBeansList.get(1).getFirstname());
			parameters.put("lastNameTH_relative2",relativeBeansList.get(1).getLastname());
			parameters.put("age_relative2",relativeBeansList.get(1).getAge());
			parameters.put("occupation_relative2",relativeBeansList.get(1).getOccupation());
			parameters.put("position_relative2",relativeBeansList.get(1).getPosition());
			
			parameters.put("titleNameTH_relative3",relativeBeansList.get(2).getTitle_th());
			parameters.put("firstNameTH_relative3",relativeBeansList.get(2).getFirstname());
			parameters.put("lastNameTH_relative3",relativeBeansList.get(2).getLastname());
			parameters.put("age_relative3",relativeBeansList.get(2).getAge());
			parameters.put("occupation_relative3",relativeBeansList.get(2).getOccupation());
			parameters.put("position_relative3",relativeBeansList.get(2).getPosition());
			// #6
			
			// 7
			parameters.put("name_primary",educationBeansList.get(0).getName());
			parameters.put("yearAttended_primary",educationBeansList.get(0).getYear_attended());
			parameters.put("yearGraduated_primary",educationBeansList.get(0).getYear_graduated());
			parameters.put("Certificate_primary",educationBeansList.get(0).getCertificate());
			parameters.put("major_primary",educationBeansList.get(0).getMajor());
			
			parameters.put("name_secondary",educationBeansList.get(1).getName());
			parameters.put("yearAttended_secondary",educationBeansList.get(1).getYear_attended());
			parameters.put("yearGraduated_secondary",educationBeansList.get(1).getYear_graduated());
			parameters.put("Certificate_secondary",educationBeansList.get(1).getCertificate());
			parameters.put("major_secondary",educationBeansList.get(1).getMajor());
			
			parameters.put("name_HighSchool",educationBeansList.get(2).getName());
			parameters.put("yearAttended_HighSchool",educationBeansList.get(2).getYear_attended());
			parameters.put("yearGraduated_HighSchool",educationBeansList.get(2).getYear_graduated());
			parameters.put("Certificate_HighSchool",educationBeansList.get(2).getCertificate());
			parameters.put("major_HighSchool",educationBeansList.get(2).getMajor());
			
			parameters.put("name_vocation1",educationBeansList.get(3).getName());
			parameters.put("yearAttended_vocation1",educationBeansList.get(3).getYear_attended());
			parameters.put("yearGraduated_vocation1",educationBeansList.get(3).getYear_graduated());
			parameters.put("Certificate_vocation1",educationBeansList.get(3).getCertificate());
			parameters.put("major_vocation1",educationBeansList.get(3).getMajor());
			
			parameters.put("name_vocation2",educationBeansList.get(4).getName());
			parameters.put("yearAttended_vocation2",educationBeansList.get(4).getYear_attended());
			parameters.put("yearGraduated_vocation2",educationBeansList.get(4).getYear_graduated());
			parameters.put("Certificate_vocation2",educationBeansList.get(4).getCertificate());
			parameters.put("major_vocation2",educationBeansList.get(4).getMajor());
			
			parameters.put("name_BachelorDegree",educationBeansList.get(5).getName());
			parameters.put("yearAttended_BachelorDegree",educationBeansList.get(5).getYear_attended());
			parameters.put("yearGraduated_BachelorDegree",educationBeansList.get(5).getYear_graduated());
			parameters.put("Certificate_BachelorDegree",educationBeansList.get(5).getCertificate());
			parameters.put("major_BachelorDegree",educationBeansList.get(5).getMajor());
			// #7
			
			// 8
			parameters.put("startDate_training1",trainingBeansList.get(0).getStart_date());
			parameters.put("stopDate_training1",trainingBeansList.get(0).getStop_date());
			parameters.put("place_training1",trainingBeansList.get(0).getPlace());
			parameters.put("position_training1",trainingBeansList.get(0).getPosition());
			
			parameters.put("startDate_training2",trainingBeansList.get(1).getStart_date());
			parameters.put("stopDate_training2",trainingBeansList.get(1).getStop_date());
			parameters.put("place_training2",trainingBeansList.get(1).getPlace());
			parameters.put("position_training2",trainingBeansList.get(1).getPosition());
			
			parameters.put("startDate_training3",trainingBeansList.get(2).getStart_date());
			parameters.put("stopDate_training3",trainingBeansList.get(2).getStop_date());
			parameters.put("place_training3",trainingBeansList.get(2).getPlace());
			parameters.put("position_training3",trainingBeansList.get(2).getPosition());
			// #8
			
			// 9
			parameters.put("career_1",careerBeansList.get(0).getName());
			parameters.put("career_2",careerBeansList.get(1).getName());
			parameters.put("career_3",careerBeansList.get(2).getName());
			parameters.put("career_4",careerBeansList.get(3).getName());
			// #9
			
			// 10
			parameters.put("dateTime_activity1", activityBeansList.get(0).getDate_time());
			parameters.put("position_activity1", activityBeansList.get(0).getPosition());
			
			parameters.put("dateTime_activity2", activityBeansList.get(1).getDate_time());
			parameters.put("position_activity2", activityBeansList.get(1).getPosition());
			
			parameters.put("dateTime_activity3", activityBeansList.get(2).getDate_time());
			parameters.put("position_activity3", activityBeansList.get(2).getPosition());
			// #10
			
			// 11
			if(language03Bean.getLevel_eng_listen() == null) language03Bean.setLevel_eng_listen("-");
			if(language03Bean.getLevel_eng_speak() == null) language03Bean.setLevel_eng_speak("-");
			if(language03Bean.getLevel_eng_write() == null) language03Bean.setLevel_eng_write("-");
			if(language03Bean.getLevel_chi_listen() == null) language03Bean.setLevel_chi_listen("-");
			if(language03Bean.getLevel_chi_speak() == null) language03Bean.setLevel_chi_speak("-");
			if(language03Bean.getLevel_chi_write() == null) language03Bean.setLevel_chi_write("-");
			if(language03Bean.getLevel_other_listen() == null) language03Bean.setLevel_other_listen("-");
			if(language03Bean.getLevel_other_speak() == null) language03Bean.setLevel_other_speak("-");
			if(language03Bean.getLevel_other_write() == null) language03Bean.setLevel_other_write("-");
			if(language03Bean.getInput_other() == null) language03Bean.setInput_other("-");
			
			parameters.put("levelEng_listen", language03Bean.getLevel_eng_listen());
			parameters.put("levelEng_speak", language03Bean.getLevel_eng_speak());
			parameters.put("levelEng_write", language03Bean.getLevel_eng_write());
			
			parameters.put("levelChi_listen", language03Bean.getLevel_chi_listen());
			parameters.put("levelChi_speak", language03Bean.getLevel_chi_speak());
			parameters.put("levelChi_write", language03Bean.getLevel_chi_write());
			
			parameters.put("levelOther_listen", language03Bean.getLevel_other_listen());
			parameters.put("levelOther_speak", language03Bean.getLevel_other_speak());
			parameters.put("levelOther_write", language03Bean.getLevel_other_write());
			parameters.put("inputOther", language03Bean.getInput_other());
			// #11
			
			/*
			 * Using compiled version(.jasper) of Jasper report to generate PDF
			 */
			JasperPrint jasperPrint = JasperFillManager.fillReport(request.getServletContext().getRealPath("/views/pages/student/report/Coop03_pdf.jasper")
										, parameters,new JREmptyDataSource());
			
			/* outputStream to create PDF */
			OutputStream outputStream = new FileOutputStream(new File(outputFile));
			ThaiExporterManager.exportReportToPdfStream(jasperPrint, outputStream);

			//System.out.println(fileShow);

		} catch (JRException ex) {
			ex.printStackTrace();
		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		}
	}
}
