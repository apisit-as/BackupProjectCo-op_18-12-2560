package com.java.util;
public class SessionExpire {
	public String getSendRedirect(){
		// send redirect to Login page
		return "Login";
	}
}