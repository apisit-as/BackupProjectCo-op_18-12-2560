package com.java.admin.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.java.admin.bean.DivisionBean;
import com.java.admin.bean.FacAndDivBean;
import com.java.admin.bean.FacultyBean;
import com.java.admin.dao.TableDivisionDao;
import com.java.admin.dao.TableFacultyDao;
import com.java.util.SessionExpire;

/**
 * Servlet implementation class FacultyManagerment
 */
@WebServlet("/FacultyManagerment")
public class FacultyManagerment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FacultyManagerment() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
		  request.setCharacterEncoding("UTF-8");
		  response.setCharacterEncoding("UTF-8");
		  
		  HttpSession session = request.getSession();
		  
		  // check role session expire
		  if(session.getAttribute("role") == null){
			  	SessionExpire sessionExpire = new SessionExpire();
				response.sendRedirect(sessionExpire.getSendRedirect()); // send redirect to Login page
				return;
		  }
		  
		  // check role admin
		  String role = session.getAttribute("role").toString();
		  if(role.equals("admin")){
			  session.setAttribute("role_admin", "false");
		  }
		  String role_admin = session.getAttribute("role_admin").toString();
		
		 // role admin
		 if(role.equals("admin") || role_admin.equals("true")){
				String action = request.getParameter("action");
				if ("Edit".equals(action)) {
					session.setAttribute("actionFac", "Edit");
					session.setAttribute("facid", request.getParameter("facid"));
					response.sendRedirect("FacultyManagerment");
				} else if ("Add".equals(action)) {
					session.setAttribute("actionFac", "Add");
					session.setAttribute("facid", 0);
					response.sendRedirect("FacultyManagerment");
				} else {
					doViewFacultyManagement(request, response);
				}
		 }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		
		  // check role admin
		  String role = session.getAttribute("role").toString();
		  if(role.equals("admin")){
			  session.setAttribute("role_admin", "false");
		  }
		  String role_admin = session.getAttribute("role_admin").toString();
		  if(!(role.equals("admin") || role_admin.equals("true"))){
			  return;
		  }
		
		String action = request.getParameter("action");
		PrintWriter out = response.getWriter();
		TableFacultyDao tablefacultyDao = new TableFacultyDao();
		TableDivisionDao tableDivisionDao = new TableDivisionDao();
		Gson gson = new Gson();
		
		// load table  add & edit  page edit_faculty.jsp
		if(("retrieve".equals(action))){
			int facid = Integer.parseInt(request.getParameter("facid"));
			FacAndDivBean facAndDivBean = new FacAndDivBean();
			facAndDivBean.setFacultyBean(tablefacultyDao.getFacultyList(facid));
			facAndDivBean.setDivisionBeans(tableDivisionDao.getDivisionList(facid));
			//System.out.println(gson.toJson(facAndDivBean));
			out.print(gson.toJson(facAndDivBean));
			return;
		}
		
		Type listType = new TypeToken<ArrayList<DivisionBean>>() {}.getType();

		FacultyBean facultyBean = gson.fromJson(request.getParameter("jsonFac"), FacultyBean.class); // bean Ẻ ������ 
		List<DivisionBean> list = gson.fromJson(request.getParameter("dataJson"), listType);  //  json to bean list
		
		if ("Add".equals(action)) {
			int facid = tablefacultyDao.addFaculty(facultyBean);
			for (DivisionBean bean : list) {
				bean.setFacid(facid);
				tableDivisionDao.addDivision(bean);
			}
		   // out.print(gson.toJson(tableDivisionDao.getDivisionList(facid)));

		} else if ("Edit".equals(action)) {
			
			// DELETE
			Type listType2 = new TypeToken<ArrayList<Integer>>(){}.getType();
			List<Integer> jsonObjList = gson.fromJson(request.getParameter("numberDelete"), listType2);  // array to list obj
			for(Integer i:jsonObjList){
				/**
				 *   get list rate_company_id 
				 *   insrt history
				 *   set null  tb_student_select_company  (RateCompanyID,RateCompanyID_temmp)
				 *   delete tb_rate_company
				 *   set null tb_user  DivID
				 *   delete tb_divison
				 */
				//System.out.println(i);
				// i = divid
				tableDivisionDao.deleteDivision(i,request);
			}
			
			//UPDATE  code & name faculy
			facultyBean.setId(Integer.parseInt((String) session.getAttribute("facid")));
			tablefacultyDao.editFaculty(facultyBean);
			
			// ADD & UPDATE  Division
			for (DivisionBean bean : list) {
				//System.out.println("Edit = "+bean.getId());
				//  id = 0  new add
				if(bean.getId() == 0){
					bean.setFacid(Integer.parseInt((String) session.getAttribute("facid")));
					tableDivisionDao.addDivision(bean);
				}else if(bean.getId() > 0){
					tableDivisionDao.editDivision(bean);
				}
			}
		}
	}
	private void doViewFacultyManagement(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/admin/faculty_managerment.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
}
