package com.java.admin.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.admin.dao.AdminManagementDao;
import com.java.student.bean.UserBean;
import com.java.util.SessionExpire;

/**
 * Servlet implementation class StudentManagement
 */
@WebServlet("/AdminApproveManagement")
public class AdminApproveManagement extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminApproveManagement() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
		  HttpSession session = request.getSession();
		  
		  // check role session expire
		  if(session.getAttribute("role") == null){
			  	SessionExpire sessionExpire = new SessionExpire();
				response.sendRedirect(sessionExpire.getSendRedirect()); // send redirect to Login page
				return;
		  }
		  
		  // check role admin
		  String role = session.getAttribute("role").toString();
		  if(role.equals("admin")){
			  session.setAttribute("role_admin", "false");
		  }
		  String role_admin = session.getAttribute("role_admin").toString();
		
		  // role admin
		  if(role.equals("admin") || role_admin.equals("true")){

			  //get list  teacher0,teacher1,teacher2,staff  Not ApproveAdmin
			  ArrayList<UserBean> userList = new ArrayList<UserBean>();
			  AdminManagementDao managementDao = new AdminManagementDao();
			  userList = managementDao.getUserListNotStudent();
			  request.setAttribute("userList", userList);
			  doViewApproveAddminManagement(request, response);
		  }

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		 HttpSession session = request.getSession();
		  String role = session.getAttribute("role").toString();
		  String role_admin = session.getAttribute("role_admin").toString();
		  if("admin".equals(role) || role_admin.equals("true")){
				String action = request.getParameter("action");
				int user_id = Integer.parseInt(request.getParameter("id"));
				if("approve_admin".equals(action)){
					// approve admin
					AdminManagementDao adminManagementDao = new AdminManagementDao();
					adminManagementDao.UpdateApproveAdmin(user_id);
				}
		  }
	}
	
	private void doViewApproveAddminManagement(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/admin/approve_admin_management.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
}
