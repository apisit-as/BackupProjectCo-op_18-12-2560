package com.java.admin.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.admin.bean.AcademicYearBean;
import com.java.admin.dao.TableAcademicYearDao;
import com.java.util.SessionExpire;

/**
 * Servlet implementation class AcademicYearManagerment
 */
@WebServlet("/AcademicYearManagerment")
public class AcademicYearManagerment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AcademicYearManagerment() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
		  HttpSession session = request.getSession();
		  TableAcademicYearDao tableAcademicYear = new TableAcademicYearDao();
		  ArrayList<AcademicYearBean> academicBeanList = new ArrayList<AcademicYearBean>();
		  
		  // check role session expire
		  if(session.getAttribute("role") == null){
			  	SessionExpire sessionExpire = new SessionExpire();
				response.sendRedirect(sessionExpire.getSendRedirect()); // send redirect to Login page
				return;
		  }
		  
		  // check role admin
		  String role = session.getAttribute("role").toString();
		  if(role.equals("admin")){
			  session.setAttribute("role_admin", "false");
		  }
		  String role_admin = session.getAttribute("role_admin").toString();
		
		  // role admin
		  if(role.equals("admin") || role_admin.equals("true")){
			  
			  // academicBeanList
			  academicBeanList = tableAcademicYear.getAcademicYearBeanList();
			  request.setAttribute("academicBeanList", academicBeanList);
			  
			  // idCheckSelect
			  int idCheckSelect = tableAcademicYear.getID();
			  request.setAttribute("idCheckSelect", idCheckSelect);
			  
			  // list semester select
			  ArrayList<Integer> SemesterList = new ArrayList<>();
			  SemesterList = tableAcademicYear.getSemesterSelect();
			  request.setAttribute("SemesterList", SemesterList);
			  
			  doViewAcademic_year(request, response);
		  }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		
		  // check role admin
		  String role = session.getAttribute("role").toString();
		  if(role.equals("admin")){
			  session.setAttribute("role_admin", "false");
		  }
		  String role_admin = session.getAttribute("role_admin").toString();
		  if(!(role.equals("admin") || role_admin.equals("true"))){
			  return;
		  }

		AcademicYearBean academicYearBean = new AcademicYearBean();
		TableAcademicYearDao tableAcademicYear = new TableAcademicYearDao();
		PrintWriter out = response.getWriter();

		String action = request.getParameter("action");
		
		/** check repeat value **/
		if("add".equals(action)){
			if(tableAcademicYear.CheckAcademic(request.getParameter("Semester"), request.getParameter("Academic_year"))){
				out.print("Repeat value");
				return;
			}
		}
		else if("edit".equals(action)){
			String Semester = request.getParameter("Semester");
			String Academic_year = request.getParameter("Academic_year");
			int id = Integer.parseInt(request.getParameter("id"));
			
			String check = tableAcademicYear.CheckAcademic(id, Semester, Academic_year);
			if(!"is_equals_academic".equals(check)){
				// 1. check id
				if(tableAcademicYear.CheckAcademic(Semester, Academic_year)){
					// 2. check in db
					out.print("Repeat value");
					return;
				}
			}
		}
		/** #check repeat value **/
		
		/** add,edit,delete,add_select **/
		if("add".equals(action)){
			academicYearBean.setSemester(request.getParameter("Semester"));
			academicYearBean.setAcademic_year(request.getParameter("Academic_year"));
			academicYearBean.setStart_date_recruitment(request.getParameter("StartDateRecruitment"));
			academicYearBean.setStop_date_recruitment(request.getParameter("StopDateRecruitment"));
			academicYearBean.setStart_date_workout(request.getParameter("StartDateWorkOut"));
			academicYearBean.setStop_date_workout(request.getParameter("StopDateWorkOut"));
			tableAcademicYear.InsertAcademicYear(academicYearBean);
		}
		else if("edit".equals(action)){
			academicYearBean.setId(Integer.parseInt(request.getParameter("id")));
			academicYearBean.setSemester(request.getParameter("Semester"));
			academicYearBean.setAcademic_year(request.getParameter("Academic_year"));
			academicYearBean.setStart_date_recruitment(request.getParameter("StartDateRecruitment"));
			academicYearBean.setStop_date_recruitment(request.getParameter("StopDateRecruitment"));
			academicYearBean.setStart_date_workout(request.getParameter("StartDateWorkOut"));
			academicYearBean.setStop_date_workout(request.getParameter("StopDateWorkOut"));
			tableAcademicYear.UpdateAcademicYear(academicYearBean);
		}
		else if("delete".equals(action)){
			/**
			 *  select id tb_student_send_document
			 *  insert history , update status complete status document (�觡�Ѻ���)
			 *  delete   tb_teacher_check_document , tb_student_send_document
			 *  delete   tb_student_select_company
			 *  delete   tb_rate_company
			 *  delete  tb_academic_year
			 */   
			int academic_year_id = Integer.parseInt(request.getParameter("id"));
			
			//  delete  tb_academic_year
			tableAcademicYear.deleteAcademicYear(academic_year_id);
		}
		else if("addSelect".equals(action)){
			int id = Integer.parseInt(request.getParameter("id"));
			tableAcademicYear.UpdateCheckSelect(id);
		}
		/** add,edit,delete,add_select **/
	}

	private void doViewAcademic_year(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/admin/academic_year.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
}
