package com.java.admin.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.admin.bean.ListApproveStaffBean;
import com.java.util.PreparedStatementUtil;

public class ApproveStaffDao {

	public ArrayList<ListApproveStaffBean> SelectListStaffApprove(){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		ArrayList<ListApproveStaffBean> list = new ArrayList<>();
		String query =  "SELECT  tb_user.ID,"
						+ "tb_title.Name_th AS titleName_th,"
				        + "tb_user.FirstName_th,"
				        + "tb_user.LastName_th,"
						+ "tb_role.NameTH AS RoleNameTH, "
						+ "tb_user.ApproveRole "
				        + "FROM tb_user "
				        + "JOIN tb_title  ON tb_title.ID = tb_user.TitleID "
				        + "JOIN tb_role  ON tb_role.ID = tb_user.RoleID "
						+ "WHERE tb_user.RoleID = 3 ";
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			rs = preparedStatementUtil.executeQuery();
			while(rs.next()){
				ListApproveStaffBean bean = new ListApproveStaffBean();	
				bean.setUser_id(rs.getInt("ID"));
				bean.setTitle_name_th(rs.getString("titleName_th"));
				bean.setFirstname_th(rs.getString("FirstName_th"));
				bean.setLastname_th(rs.getString("LastName_th"));
				bean.setRole_name(rs.getString("RoleNameTH"));
				bean.setApprove_staff(rs.getString("ApproveRole"));
				list.add(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public void UpdateApproveRole(String status,int user_id){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_user SET "
		   				+ "ApproveRole = :status "
		   				+ "WHERE ID = :user_id AND RoleID =  3";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setString("status",status);
		   preparedStatementUtil.setInt("user_id",user_id);
		   preparedStatementUtil.execute();	   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
}
