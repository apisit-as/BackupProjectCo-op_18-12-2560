package com.java.admin.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import com.java.admin.bean.FacultyBean;
import com.java.staff.dao.TableRateCompanyDao;
import com.java.util.PreparedStatementUtil;

public class TableFacultyDao {
	public int addFaculty(FacultyBean facultyBean) {
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		int key = 0;
		try {
			String query = "INSERT INTO tb_faculty(Code,Name) VALUES(:code,:name)";
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setString("code", facultyBean.getCode());
			preparedStatementUtil.setString("name", facultyBean.getName());
			rs = preparedStatementUtil.executeInsertGetKeys();
			if (rs.next()) {
				key = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (preparedStatementUtil != null)
				try {
					preparedStatementUtil.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return key;
	}

	public void editFaculty(FacultyBean facultyBean) {
		PreparedStatementUtil preparedStatementUtil = null;
		try {
			String query = "UPDATE tb_faculty SET Code = :code,Name = :name Where ID = :id";
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setString("code", facultyBean.getCode());
			preparedStatementUtil.setString("name", facultyBean.getName());
			preparedStatementUtil.setInt("id", facultyBean.getId());
			preparedStatementUtil.execute();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (preparedStatementUtil != null)
				try {
					preparedStatementUtil.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
	}

	public void deleteFaculty(int facid,HttpServletRequest request){
		DeleteRateCompanyDao deleteRateCompanyDao = new DeleteRateCompanyDao();
		TableRateCompanyDao tableRateCompanyDao = new TableRateCompanyDao();
		
		ArrayList<Integer> list_rate_company_id = new ArrayList<>();
		list_rate_company_id = deleteRateCompanyDao.getIdRateCompany(facid, "FacID");

		for (Integer rate_company_id : list_rate_company_id) {
			/**
			 *  loop multi id rate_comapny
			 */
			// insrt history
			 ArrayList<Integer> user_id_list = new ArrayList<>();
			 user_id_list = tableRateCompanyDao.SelectListUserID(rate_company_id, request);
			 tableRateCompanyDao.insertHistory(user_id_list);
			 
			// set null  tb_student_select_company  (RateCompanyID,RateCompanyID_temmp)
			deleteRateCompanyDao.updateNullStuentSelectCompany(rate_company_id);
			
			// delete tb_rate_company
			deleteRateCompanyDao.deleteRateCompany(rate_company_id);
		}

		 // set null tb_user  FacID,DivID
		UserManagementDao userManagementDao = new UserManagementDao();
		userManagementDao.updateNullFacultyUser(facid);
		
		// delete tb_divison ,  tb_Faculty
		deleteDivisionAndFaculty(facid);

	}
	
	public ArrayList<FacultyBean> getFacultyList(){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<FacultyBean> facultyBeanList = new ArrayList<FacultyBean>();
		String query = "SELECT ID,Code,Name FROM tb_faculty ORDER BY Code ASC ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			rs = prepareStatementUtil.executeQuery();
			while(rs.next()){
				FacultyBean facultyBean = new FacultyBean();
				facultyBean.setId(rs.getInt("ID"));
				facultyBean.setCode(rs.getString("Code"));
				facultyBean.setName(rs.getString("Name"));
				facultyBeanList.add(facultyBean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return facultyBeanList;
	}
	
public FacultyBean getFacultyList(int id){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		FacultyBean facultyBean = new FacultyBean();
		String query = "SELECT ID,Code,Name FROM tb_faculty Where ID = :Facid LIMIT 1 ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("Facid", id);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				facultyBean.setId(rs.getInt("ID"));
				facultyBean.setCode(rs.getString("Code"));
				facultyBean.setName(rs.getString("Name"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return facultyBean;
	}

public Boolean getDeleteFaculty(int index){
	PreparedStatementUtil prepareStatementUtil = null;
	ResultSet rs = null;
	Boolean value = false;
	String query = "SELECT True as isDelete FROM tb_division where FacId = :FacID LIMIT 1";
	try {
		prepareStatementUtil = new PreparedStatementUtil(query);
		prepareStatementUtil.setInt("FacID", index);
		rs = prepareStatementUtil.executeQuery();
		if(rs.next()){
			value = rs.getBoolean("isDelete");
		}
	} catch (Exception e) {
		e.printStackTrace();
	}finally{
		try {
			prepareStatementUtil.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	return value;
}	

	public void deleteDivisionAndFaculty(int facid){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
			   String query = "DELETE FROM tb_division WHERE FacID = :facid";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("facid", facid);

			   preparedStatementUtil.execute();
			   
			  }catch(Exception e){
			   e.printStackTrace();
			  }finally{
			   if(preparedStatementUtil != null)
				try {
					preparedStatementUtil.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			  }
		  
		  try{
			   String query = "DELETE FROM tb_faculty WHERE ID = :facid";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("facid", facid);
			   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
}
