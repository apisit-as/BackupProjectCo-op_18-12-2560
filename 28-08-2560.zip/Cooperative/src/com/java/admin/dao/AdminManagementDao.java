package com.java.admin.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.student.bean.UserBean;
import com.java.util.PreparedStatementUtil;

public class AdminManagementDao {
	
	public void UpdateApproveAdmin(int user_id){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_user SET "
					   		+ "ApproveAdmin = 'true' "
					   		+ "WHERE ID = :user_id ";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("user_id",user_id);
		   preparedStatementUtil.execute(); 
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void UpdateNullAdmin(int user_id){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_user SET "
					   		+ "ApproveAdmin = null "
					   		+ "WHERE ID = :user_id ";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("user_id",user_id);
		   preparedStatementUtil.execute(); 
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public ArrayList<UserBean> getUserListNotStudent(){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<UserBean> userBeanList = new ArrayList<UserBean>();
		String query = "SELECT tb_user.ID,"
				+ "tb_title.Name_th AS TitleName,"
				+ "tb_user.FirstName_th,"
				+ "tb_user.LastName_th,"
				+ "tb_faculty.Name AS facultyName,"
				+ "tb_division.Name AS divisionName,"
				+ "tb_role.NameTH "
				+ " FROM tb_user "
				+ " LEFT JOIN tb_title on tb_title.ID = tb_user.TitleID "
				+ " LEFT JOIN tb_faculty on tb_faculty.ID = tb_user.FacID "
				+ " LEFT JOIN tb_division on tb_division.ID = tb_user.DivID "
				+ " LEFT JOIN tb_role on tb_role.ID = tb_user.RoleID "
				+ " WHERE (tb_user.RoleID = 3  OR tb_user.RoleID = 6 OR  tb_user.RoleID = 4  OR tb_user.RoleID = 5 ) "
						+ " AND (NOT tb_user.ApproveAdmin = 'true' OR tb_user.ApproveAdmin IS NULL ) ";
				/**  staff = 3  , teacher0 = 6 , teacher1 = 4  ,  teacher2 = 5 **/
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			rs = prepareStatementUtil.executeQuery();
			while(rs.next()){
				UserBean userBean = new UserBean();
				userBean.setId(rs.getInt("ID"));
				userBean.setTitlename_th(rs.getString("TitleName"));
				userBean.setFirstname_th(rs.getString("FirstName_th"));
				userBean.setLastname_th(rs.getString("LastName_th"));
				userBean.setFacname(rs.getString("facultyName"));
				userBean.setDivname(rs.getString("divisionName"));
				userBean.setRolename_th(rs.getString("NameTH"));
				userBeanList.add(userBean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return userBeanList;
	}
	
	public ArrayList<UserBean> getUserListAdmin(){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<UserBean> userBeanList = new ArrayList<UserBean>();
		String query = "SELECT tb_user.ID,"
				+ "tb_title.Name_th AS TitleName,"
				+ "tb_user.FirstName_th,"
				+ "tb_user.LastName_th,"
				+ "tb_faculty.Name AS facultyName,"
				+ "tb_division.Name AS divisionName,"
				+ "tb_role.NameTH "
				+ " FROM tb_user "
				+ " LEFT JOIN tb_title on tb_title.ID = tb_user.TitleID "
				+ " LEFT JOIN tb_faculty on tb_faculty.ID = tb_user.FacID "
				+ " LEFT JOIN tb_division on tb_division.ID = tb_user.DivID "
				+ " LEFT JOIN tb_role on tb_role.ID = tb_user.RoleID "
				+ " WHERE (tb_user.RoleID = 3  OR tb_user.RoleID = 6 OR tb_user.RoleID = 4  OR tb_user.RoleID = 5 ) "
						+ " AND (tb_user.ApproveAdmin = 'true') ";
				/**  staff = 3  , teacher0 = 6 , teacher1 = 4  ,  teacher2 = 5 **/
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			rs = prepareStatementUtil.executeQuery();
			while(rs.next()){
				UserBean userBean = new UserBean();
				userBean.setId(rs.getInt("ID"));
				userBean.setTitlename_th(rs.getString("TitleName"));
				userBean.setFirstname_th(rs.getString("FirstName_th"));
				userBean.setLastname_th(rs.getString("LastName_th"));
				userBean.setFacname(rs.getString("facultyName"));
				userBean.setDivname(rs.getString("divisionName"));
				userBean.setRolename_th(rs.getString("NameTH"));
				userBeanList.add(userBean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return userBeanList;
	}
	
	public Boolean CheckRoleAdmin(int user_id){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = "SELECT True as isAdmin "
					+ " FROM tb_user "
					+ " WHERE ApproveAdmin = 'true' AND ID = :user_id LIMIT 1 ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("user_id", user_id);
			rs = prepareStatementUtil.executeQuery();
			if(rs.next()){
				value = rs.getBoolean("isAdmin");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return value;
	}
}
