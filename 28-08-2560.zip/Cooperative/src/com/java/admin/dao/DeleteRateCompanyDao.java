package com.java.admin.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.util.PreparedStatementUtil;

public class DeleteRateCompanyDao {
	
	public ArrayList<Integer> getIdRateCompany(int id,String type_column){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<Integer> number = new ArrayList<>();
		String query = "SELECT ID FROM tb_rate_company WHERE "+type_column+" = :id ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("id", id);
			rs = prepareStatementUtil.executeQuery();
			while(rs.next()){
				number.add(rs.getInt("ID"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return number;
	}
	public void updateNullStuentSelectCompany(int rate_company_id){
		PreparedStatementUtil preparedStatementUtil = null;
		/**
		 *  update null RateCompanyID
		 *  RateCompanyID  , RateCompanyID_Temp
		 */
	  try{
		   String query = "UPDATE tb_student_select_company SET "
		   				+ "RateCompanyID = null ,"
		   				+ "Lv1_ApStatusID = null " 
		   				+ "WHERE RateCompanyID = :rate_company_id";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("rate_company_id", rate_company_id);
		   preparedStatementUtil.execute();   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	  
	  try{
		   String query = "UPDATE tb_student_select_company SET "
		   				+ "RateCompanyID_Temp = null " 
		   				+ "WHERE RateCompanyID_Temp = :rate_company_id";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("rate_company_id", rate_company_id);
		   preparedStatementUtil.execute();   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	public void deleteRateCompany(int rate_company_id){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "DELETE FROM tb_rate_company WHERE ID = :rate_company_id";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("rate_company_id", rate_company_id);
		   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	public void deleteRateCompanyAcademiceYear(int academic_year_id){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "DELETE FROM tb_rate_company WHERE Academic_yearID = :academic_year_id";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("academic_year_id", academic_year_id);
		   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
}
