package com.java.admin.bean;

import java.util.List;

public class FacAndDivBean {
	
 	private List<DivisionBean> ListDivisionBeans;
 	private FacultyBean facultyBean;

	public List<DivisionBean> getDivisionBeans() {
		return ListDivisionBeans;
	}
	public void setDivisionBeans(List<DivisionBean> divisionBeans) {
		this.ListDivisionBeans = divisionBeans;
	}
	public FacultyBean getFacultyBean() {
		return facultyBean;
	}
	public void setFacultyBean(FacultyBean facultyBean) {
		this.facultyBean = facultyBean;
	}
}
