package com.java.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.list.bean.DivisionBean;
import com.java.list.bean.FacltyBean;
import com.java.list.dao.DivisionSelectListDao;
import com.java.list.dao.FacultySelectListDao;
import com.java.student.bean.UserBean;
import com.java.student.dao.LoginDao;
import com.java.student.dao.TableUserDao;
import com.java.util.Encoding;
import com.java.util.Rpc;
import com.sun.org.apache.xalan.internal.xsltc.compiler.sym;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		
		// check action = logout
		String action = request.getParameter("action");
		//System.out.println(action);
		if("logout".equals(action)){
			session.invalidate();
			response.sendRedirect("Login");
			return;
		}
		
		// check  role session  != null
		if(session.getAttribute("role") != null){
			
			String role = session.getAttribute("role").toString();
			System.out.println("role = "+role);
			if("student".equals(role)){
				// 1 = role Student
				response.sendRedirect("DataStudent");
				
			}else if("confirm-student".equals(role)){
				//  doViewConfirmPage
				doViewConfirmStudent(request, response);
			}
			else if("confirm-not-student".equals(role)){
				//  doViewConfirmPage
				//doViewConfirmStudent(request, response);
				ArrayList<FacltyBean> listFaclty = new ArrayList<FacltyBean>();
				FacultySelectListDao facultySelectListDao = new FacultySelectListDao();
				UserBean userBean = new UserBean();
				userBean.setFacid(0);
				
				listFaclty = facultySelectListDao.getFacltyList();
				request.setAttribute("userBean", userBean);
				request.setAttribute("listFaclty", listFaclty);
				
				doViewConfirmNotStudent(request, response);
				
			}
			
			else if("admin".equals(role)){
				// admin page
				response.sendRedirect("UserManagement");
			}
			else if("staff".equals(role)){
				// staff page
				doViewStaff(request, response);
			}
			else if("teacher1".equals(role) || "teacher2".equals(role)){
				// teacher1  teacher2 page
				doViewTeacher(request, response);
				
			}
			
		}else{
			// role session == null
			// doViewLoginPage
			session.invalidate();
			doViewLogin(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		LoginDao loginDao = new LoginDao();
		UserBean loginbean = new UserBean();
		PrintWriter out = response.getWriter();
		Encoding encodeing = new Encoding();
		String action = request.getParameter("action");
		
		if(action.equals("login")){
			String username = request.getParameter("user");
			String password = request.getParameter("pwd");
			System.out.println("user =  "+username);
			System.out.println("pass =  "+password);
			
			loginbean.setUsername(username);
			loginbean.setPassword(encodeing.Encode(password));

			// checklogin in tb_user
			UserBean userBean = new UserBean();
			userBean = loginDao.checkLogin(loginbean);
		
			// getRolename != null
			if(userBean.getRolename_eng() != null){

				if(userBean.getRolename_eng().equals("student")){
					// student  role = 1
					session.setAttribute("role", "student");
					session.setAttribute("UserID", userBean.getId());
					out.print("goToLogin");
					
				}else if(userBean.getRolename_eng().equals("admin")){
					// admin role = 2
					session.setAttribute("role", "admin");
					out.print("goToaAdmin");
				}else if(userBean.getRolename_eng().equals("teacher1") || userBean.getRolename_eng().equals("teacher2") || userBean.getRolename_eng().equals("staff")){
					out.print("goToLogin");
					session.setAttribute("role", userBean.getRolename_eng());
				}
				
				//  role = 3  teacher , role = 4  staff
				// check role   studet , teacher , staff , admin
				
			}else{
				
				// Service RPC
				Rpc rpc = new Rpc(username, password);
				
				//  ture
				if(rpc.getCheck()){
					
					// set  rpc  to  loginbean
					loginbean.setStudentid(rpc.getStudentId());
					if("���".equals(rpc.getPrename())){
						loginbean.setTitleid(1);
					}else if("�ҧ���".equals(rpc.getPrename())){
						loginbean.setTitleid(2);
					}else if("�ҧ".equals(rpc.getPrename())){
						loginbean.setTitleid(3);
					}
					loginbean.setTitlename_th(rpc.getPrename());
					loginbean.setFirstname_th(rpc.getFirstName());
					loginbean.setLastname_th(rpc.getLastName());
					loginbean.setFirstname_eng(rpc.getFirstNameE().toUpperCase());
					loginbean.setLastname_eng(rpc.getLastNameE().toUpperCase());

					// check  role   teacher, staff , student, admin
					if(rpc.getStudentId().equals("NULL")){
						// check role not student
						//System.out.println("True Straff");
						//session.setAttribute("role", "straff");
						session.setAttribute("user", loginbean.getUsername());
						session.setAttribute("pass", encodeing.Encode(password));
						session.setAttribute("titleID", loginbean.getTitleid());
						session.setAttribute("titleName_th", loginbean.getTitlename_th());
						session.setAttribute("firstname_th", loginbean.getFirstname_th());
						session.setAttribute("lastname_th", loginbean.getLastname_th());
						session.setAttribute("role", "confirm-not-student");
						out.print("goToLogin");
						// inser user pass to db
						
						//  teacher , staff
						// get  page  teacher , staff   to select role next
					}else{
						//  student  role
						
						loginbean.setRoleid(1);
						session.setAttribute("user", loginbean.getUsername());
						session.setAttribute("pass", encodeing.Encode(password));
						session.setAttribute("studentID", loginbean.getStudentid());
						session.setAttribute("titleID", loginbean.getTitleid());
						session.setAttribute("titleName_th", loginbean.getTitlename_th());
						session.setAttribute("firstname_th", loginbean.getFirstname_th());
						session.setAttribute("lastname_th", loginbean.getLastname_th());
						session.setAttribute("firstname_eng", loginbean.getFirstname_eng());
						session.setAttribute("lastname_eng", loginbean.getLastname_eng());
						session.setAttribute("Roleid", loginbean.getRoleid());
						
						session.setAttribute("role", "confirm-student");
						out.print("goToLogin");
					}

				}else{
					// not user , password
					out.print("Error");
					System.out.println("error");
				}	
			}
		}else if(action.equals("confirm-student")){

			// confirm student
			String firstname_th = request.getParameter("firstname_th");
			String lastname_th = request.getParameter("lastname_th");
			
			loginbean.setFirstname_th(firstname_th);
			loginbean.setLastname_th(lastname_th);
			loginbean.setUsername(session.getAttribute("user").toString());
			loginbean.setPassword(session.getAttribute("pass").toString());
			loginbean.setStudentid(session.getAttribute("studentID").toString());
			
			loginbean.setTitleid(Integer.parseInt(session.getAttribute("titleID").toString()));
			loginbean.setFirstname_eng(session.getAttribute("firstname_eng").toString());
			loginbean.setLastname_eng(session.getAttribute("lastname_eng").toString());
			loginbean.setRoleid(Integer.parseInt(session.getAttribute("Roleid").toString()));
			
			session.setAttribute("role","student");
			TableUserDao tableUserDao = new TableUserDao();
			tableUserDao.addUser(loginbean);
			//loginDao.addUser(loginbean);
			
			UserBean keyUserID = new UserBean();
			keyUserID = loginDao.checkLogin(loginbean);
			
			session.setAttribute("UserID", keyUserID.getId());
			
			session.removeAttribute("titleName_th");
			session.removeAttribute("firstname_th");
			session.removeAttribute("lastname_th");
			session.removeAttribute("user");
			session.removeAttribute("pass");
			session.removeAttribute("studentID");
			session.removeAttribute("titleID");
			session.removeAttribute("firstname_eng");
			session.removeAttribute("lastname_eng");
			session.removeAttribute("Roleid");
		}
		
		else if(action.equals("confirm-not-student")){
			// confirm-not-student
			String firstname_th = request.getParameter("firstname_th");
			String lastname_th = request.getParameter("lastname_th");
			int roleID = Integer.parseInt(request.getParameter("roleID"));
			int FacID = Integer.parseInt(request.getParameter("FacID"));
			int DivID = Integer.parseInt(request.getParameter("DivID"));

			if(FacID == 0){
				loginbean.setFacid(0);
			}else{
				loginbean.setFacid(FacID);
			}
			if(DivID == 0){
				loginbean.setDivid(0);
			}else{
				loginbean.setDivid(DivID);
			}
			
			loginbean.setFirstname_th(firstname_th);
			loginbean.setLastname_th(lastname_th);
			loginbean.setRoleid(roleID);

			loginbean.setUsername(session.getAttribute("user").toString());
			loginbean.setPassword(session.getAttribute("pass").toString());
			loginbean.setTitleid(Integer.parseInt(session.getAttribute("titleID").toString()));

			TableUserDao tableUserDao = new TableUserDao();
			tableUserDao.addUser(loginbean);
			
			UserBean keyUserID = new UserBean();
			keyUserID = loginDao.checkLogin(loginbean);
			
			session.setAttribute("UserID", keyUserID.getId());
			
			
			if(roleID == 3){
				// staff
				session.setAttribute("role","staff");
				System.out.println("OK staff");
			}else if(roleID == 4){
				//teacher1
				session.setAttribute("role","teacher1");
				System.out.println("OK teacher1");
			}else if(roleID == 5){
				//teacher2
				session.setAttribute("role","teacher2");
				System.out.println("OK teacher2");
			}
			session.removeAttribute("titleName_th");
			session.removeAttribute("firstname_th");
			session.removeAttribute("lastname_th");
			session.removeAttribute("user");
			session.removeAttribute("pass");
			session.removeAttribute("titleID");	

			
		}else if(action.equals("cancel-confirm")){
			session.removeAttribute("role");
		}
		
		else if(action.equals("getListDivsion")){
			int facID = Integer.parseInt(request.getParameter("facID"));
			ArrayList<DivisionBean> listDivision = new ArrayList<DivisionBean>();
			DivisionSelectListDao divisionSelectListDao = new DivisionSelectListDao();
			listDivision = divisionSelectListDao.getDivisionList(facID);
			request.setAttribute("divID", 0);
			request.setAttribute("listDivision", listDivision);
			doViewListDivision(request, response);
			return;
		}
		else if(action.equals("getListFaculty")){
			ArrayList<FacltyBean> listFaclty = new ArrayList<FacltyBean>();
			FacultySelectListDao facultySelectListDao = new FacultySelectListDao();
			listFaclty = facultySelectListDao.getFacltyList();
			UserBean userBean = new UserBean();
			request.setAttribute("userBean", userBean);
			request.setAttribute("listFaclty", listFaclty);
			doViewListFaculty(request, response);
			return;
		}
		
		

	}
	

	private void doViewLogin(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/other/login.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void doViewConfirmStudent(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/student/data_confirm.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void doViewConfirmNotStudent(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/other/data_confirm_staff_and_teacher.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void doViewStaff(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/error-page.jsp"); ///Cooperative/WebContent/views/error-page.jsp
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void doViewTeacher(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/error-page.jsp"); ///Cooperative/WebContent/views/error-page.jsp
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void doViewListDivision(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/division_list.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void doViewListFaculty(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/faculty_list.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	

}
