package com.java.admin.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.admin.bean.FacultyBean;
import com.java.admin.dao.UserManagementDao;
import com.java.admin.dao.TableFacultyDao;
import com.java.student.bean.UserBean;

/**
 * Servlet implementation class SystemBoot
 */
@WebServlet("/SystemBoot")
public class SystemBoot extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SystemBoot() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  HttpSession session = request.getSession();
		  String role = session.getAttribute("role").toString();
		
		  // role admin
		  if(role.equals("admin")){
//				ArrayList<UserBean> userList = new ArrayList<UserBean>();
//				ArrayList<FacultyBean> listFaclty = new ArrayList<FacultyBean>();
//				
//				UserManagementDao tableUserDao = new UserManagementDao();
//				TableFacultyDao tableFacultyDao = new TableFacultyDao();
//
//				userList = tableUserDao.getStudentUserList();
//				listFaclty = tableFacultyDao.getFacultyList(); 
//
//				request.setAttribute("userList", userList);
//				request.setAttribute("listFaclty", listFaclty);
				
				doViewSystemBoot(request, response);
		  }
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}
	
	
	private void doViewSystemBoot(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/admin/system_boot.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
}
