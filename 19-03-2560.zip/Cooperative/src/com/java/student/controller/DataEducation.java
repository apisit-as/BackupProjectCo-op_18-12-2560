package com.java.student.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.list.bean.DivisionBean;
import com.java.list.bean.FacltyBean;
import com.java.list.dao.DivisionSelectListDao;
import com.java.list.dao.FacultySelectListDao;
import com.java.student.bean.EducationBean;
import com.java.student.bean.ProfileBean;
import com.java.student.bean.UserBean;
import com.java.student.dao.TableCompleteStatusDocument;
import com.java.student.dao.TableCoop03Dao;
import com.java.student.dao.TableEducationDao;
import com.java.student.dao.TableProfileDao;
import com.java.student.dao.TableUserDao;

/**
 * Servlet implementation class CheckStatus
 */
@WebServlet("/DataEducation")
public class DataEducation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DataEducation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		
		HttpSession session = request.getSession();
		TableUserDao tableUserDao = new TableUserDao();
		UserBean userBean = new UserBean();

		String role = session.getAttribute("role").toString();
		if(role.equals("student")){
			// student
			// get db   name ...
			int UserID = Integer.parseInt(session.getAttribute("UserID").toString());
			userBean = tableUserDao.getTableUser(UserID);
			request.setAttribute("userBean", userBean);
			session.setAttribute("divID", userBean.getDivid());
			session.setAttribute("divName", userBean.getDivname());
			
			// select list Faclty
			ArrayList<FacltyBean> listFaclty = new ArrayList<FacltyBean>();
			FacultySelectListDao facultySelectListDao = new FacultySelectListDao();			
			listFaclty = facultySelectListDao.getFacltyList();
			request.setAttribute("listFaclty", listFaclty);

			// select list Division
 			DivisionSelectListDao divisionSelectListDao = new DivisionSelectListDao();
			ArrayList<DivisionBean> listDivision = new ArrayList<DivisionBean>();
			listDivision = divisionSelectListDao.getDivisionList((userBean.getFacid()));
			request.setAttribute("listDivision", listDivision);
			
			// select  profile dao
			ProfileBean ListProfileBean = new ProfileBean();
			TableProfileDao tableProfileDao = new TableProfileDao();
			
			if(tableProfileDao.CheckProfile(UserID)){
				ListProfileBean = tableProfileDao.SelectProfile(UserID);
				request.setAttribute("EditProfile", "false");
			}else{
				request.setAttribute("EditProfile", "true");
			}
			request.setAttribute("ListProfileBean", ListProfileBean);
			
			/** Education **/
			TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
			TableEducationDao tableEducationDao = new TableEducationDao();
			int Coop03ID = tableCoop03Dao.getKeyIDCoop03(UserID);
			String [] typeEducation = {"Primary","Secondary","HighSchool","Vocation_1","Vocation_2","Bachelor_degree"};
			String [] beanEducation = {"educationBean1","educationBean2","educationBean3","educationBean4","educationBean5","educationBean6"};
			for(int i=0; i<=5; i++){
				EducationBean educationBean = new EducationBean();
				educationBean = tableEducationDao.SelectEducation(Coop03ID,typeEducation[i]);
				request.setAttribute(""+beanEducation[i], educationBean);
			}
			/** #Education **/

			
			doViewDataEducation(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		
		String action_onchange = request.getParameter("action_onchange");
		String action_education = request.getParameter("action_education");
		
		// get select list
		if("getDivision".equals(action_onchange)){
			String FacID = request.getParameter("FacID");
			DivisionSelectListDao divisionSelectListDao = new DivisionSelectListDao();
			ArrayList<DivisionBean> listDivision = new ArrayList<DivisionBean>();
			listDivision = divisionSelectListDao.getDivisionList(Integer.parseInt(FacID));
			request.setAttribute("listDivision", listDivision);

			session.setAttribute("divID", 0);
			session.setAttribute("divName", 0);       //  session
			doViewDivisionList(request, response);
			return;
		}
		
		else if("action_education".equals(action_education)){
			insertEducation(request, response);
		}
		
	}
	private void doViewDataEducation(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/student/data_default/data_education.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void doViewDivisionList(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/division_list.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void insertEducation(HttpServletRequest request, HttpServletResponse response) {
		 	HttpSession session = request.getSession();
			int userid = Integer.parseInt(session.getAttribute("UserID").toString());
	
			/** data education **/
			/* tb_profile */
			ProfileBean profileBean = new ProfileBean();
			TableProfileDao tableProfileDao = new TableProfileDao();

			profileBean.setUserid(userid);
			profileBean.setClassyear(request.getParameter("ClassYear").toString());
			profileBean.setGroupstudent(request.getParameter("GroupStudent").toString());
			profileBean.setTitleid(Integer.parseInt(request.getParameter("TitleID_Advisor").toString()));
			profileBean.setFirstnameadvisor(request.getParameter("firstname_advisor").toString());
			profileBean.setLastnameadvisor(request.getParameter("lastname_advisor").toString());
			profileBean.setGrade(request.getParameter("Grade").toString());
			profileBean.setGradetotal(request.getParameter("GradeTotal").toString());
			
			if(tableProfileDao.CheckProfile(profileBean.getUserid())){
				// update
				tableProfileDao.UpdateProfileEducation(profileBean);
				//System.out.println("true update profile");
			}else{
				// insert
				tableProfileDao.InsertProfileEducation(profileBean);
				//System.out.println("false insert profile");
			}
			/* #tb_profile */
			
			/* update  tb_user */
			UserBean userBean = new UserBean();
			userBean.setFacid(Integer.parseInt(request.getParameter("FacID").toString()));
			userBean.setDivid(Integer.parseInt(request.getParameter("DivID").toString()));
			userBean.setId(userid);
			TableUserDao tableUserDao = new TableUserDao();
			tableUserDao.updateUserFacAndDiv(userBean);
			/* #update  tb_user */
			/** #data education **/
			
			/** education background coop03 **/
			TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
			if(tableCoop03Dao.CheckCoop03(userid)){
				// update
				//System.out.println("OK Update");
				actionEducation(request, response, userid);
			}else{
				// insert
				//System.out.println("OK Insert");
				tableCoop03Dao.InsertCoop03SetUserid(userid);
				actionEducation(request, response, userid);
			}
			/** #education background coop03 **/
			
			/** insert,update status document **/
			TableCompleteStatusDocument tableCompleteStatusDocument = new TableCompleteStatusDocument();
			if(tableCompleteStatusDocument.checkCompleteStatusDocument(userid)){
				//update
				tableCompleteStatusDocument.UpdateCompleteStatusDoc("DataEducation", 1, userid);
			}else{
				//insert
				tableCompleteStatusDocument.InsertCompleteStatusDoc("DataEducation", 1, userid);
			}
	}
	
	private void actionEducation(HttpServletRequest request, HttpServletResponse response, int userid) {
		TableEducationDao tableEducationDao = new TableEducationDao();
		TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
		int coop03id = tableCoop03Dao.getKeyIDCoop03(userid);
		Boolean checkEducation = tableCoop03Dao.CheckCoop03Education(coop03id);
		String [] typeEducation = {"Primary","Secondary","HighSchool","Vocation_1","Vocation_2","Bachelor_degree"};
		for(int i=1; i<=6; i++){
			EducationBean educationBean = new EducationBean();
			educationBean.setName(request.getParameter("educatiion_Name"+i).toString());
			educationBean.setYear_attended(request.getParameter("educatiion_year_attended"+i).toString());
			educationBean.setYear_graduated(request.getParameter("educatiion_year_graduated"+i).toString());
			educationBean.setCertificate(request.getParameter("educatiion_certificate"+i).toString());
			educationBean.setMajor(request.getParameter("educatiion_major"+i).toString());
			educationBean.setType(typeEducation[i-1]);
			educationBean.setCoop03id(coop03id);
			if(checkEducation){
				//System.out.println("update coop03 education");
				tableEducationDao.UpdateEducation(educationBean);
			}else{
				//System.out.println("insert coop03 education");
				tableEducationDao.InsertEducation(educationBean);
			}
		}
	}

}
