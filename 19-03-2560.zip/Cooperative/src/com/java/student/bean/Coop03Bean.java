package com.java.student.bean;

public class Coop03Bean {
	
	private int id;
	private String num_relative;
	private String my_relative;
	private String picture;
	private int userid;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNum_relative() {
		return num_relative;
	}
	public void setNum_relative(String num_relative) {
		this.num_relative = num_relative;
	}
	public String getMy_relative() {
		return my_relative;
	}
	public void setMy_relative(String my_relative) {
		this.my_relative = my_relative;
	}
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	
	
}
