package com.java.student.bean;

public class ActivityBean {
	private int id;
	private String date_time;
	private String position;
	private String type;
	private int coop03id;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDate_time() {
		return date_time;
	}
	public void setDate_time(String date_time) {
		this.date_time = date_time;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getCoop03id() {
		return coop03id;
	}
	public void setCoop03id(int coop03id) {
		this.coop03id = coop03id;
	}
	
	
}
