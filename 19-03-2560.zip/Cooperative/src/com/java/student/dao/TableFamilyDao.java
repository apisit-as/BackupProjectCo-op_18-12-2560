package com.java.student.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.student.bean.FamilyBean;
import com.java.util.PreparedStatementUtil;

public class TableFamilyDao {
	
	public Boolean CheckFamily(int profileID){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
	
		Boolean value = false;
		String query = "SELECT True as isFamily FROM cooperative.tb_family WHERE ProfileID = :profileid LIMIT 1";
		
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("profileid", profileID);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				value = rs.getBoolean("isFamily");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return value;
	}
	
	
	public void InsertFamily(FamilyBean familyBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "INSERT INTO tb_family(TitleID,"
		   									+ "FirstName,"
		   									+ "LastName,"
		   									+ "Age,"
		   									+ "Relation,"
		   									+ "Occupation,"
		   									+ "PlaceOccupation,"
		   									+ "Type,"
		   									+ "ProfileID) "
					   		+ " VALUES(:titleid,"
					   				+ ":firstname,"
					   				+ ":lastname,"
					   				+ ":age,"
					   				+ ":relation,"
					   				+ ":occupation,"
					   				+ ":place_occupation,"
					   				+ ":type,"
					   				+ ":profileid)";

		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setInt("titleid", familyBean.getTitleid());
		   preparedStatementUtil.setString("firstname", familyBean.getFirstname());
		   preparedStatementUtil.setString("lastname", familyBean.getLastname());
		   preparedStatementUtil.setString("age", familyBean.getAge());
		   preparedStatementUtil.setString("relation", familyBean.getRelation());
		   preparedStatementUtil.setString("occupation", familyBean.getOccupation());
		   preparedStatementUtil.setString("place_occupation", familyBean.getPlace_occupation());
		   preparedStatementUtil.setString("type", familyBean.getType());
		   preparedStatementUtil.setInt("profileid", familyBean.getProfileid());
		   
		   preparedStatementUtil.execute();   
		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
	}	
	
	public void updateFamily(FamilyBean familyBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "UPDATE tb_family SET "
		   				+ "TitleID = :titleid,"
		   				+ "FirstName = :firstname,"
		   				+ "LastName = :lastname,"
		   				+ "Age = :age,"
		   				+ "Relation = :relation,"
		   				+ "Occupation = :occupation, " 
		   				+ "PlaceOccupation = :place_occupation " 
		   				+ "WHERE tb_family.ProfileID = :profileid && tb_family.Type = :type ";

		   preparedStatementUtil = new PreparedStatementUtil(query);

		   preparedStatementUtil.setInt("titleid", familyBean.getTitleid());
		   preparedStatementUtil.setString("firstname", familyBean.getFirstname());
		   preparedStatementUtil.setString("lastname", familyBean.getLastname());
		   preparedStatementUtil.setString("age", familyBean.getAge());
		   preparedStatementUtil.setString("relation", familyBean.getRelation());
		   preparedStatementUtil.setString("occupation", familyBean.getOccupation());
		   preparedStatementUtil.setString("place_occupation", familyBean.getPlace_occupation());
		   preparedStatementUtil.setString("type", familyBean.getType());
		   preparedStatementUtil.setInt("profileid", familyBean.getProfileid());
		   
		   preparedStatementUtil.execute();
		   		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
	}
	
	
	public FamilyBean SelectFamilyType(int profileID,String type){
		
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		FamilyBean familyBean = new FamilyBean();
		
		String query = "SELECT TitleID,"
				+ "tb_title.Name_th AS TitleName,"
				+ "FirstName,"
				+ "LastName,"
				+ "Age,"
				+ "Relation,"
				+ "Occupation,"
				+ "PlaceOccupation,"
				+ "Type,"
				+ "ProfileID"
				+ " FROM tb_family"
				+ " LEFT JOIN tb_title on tb_family.TitleID = tb_title.ID"
				+ " WHERE tb_family.ProfileID = :profileid && tb_family.Type = :type"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("profileid", profileID);
			preparedStatementUtil.setString("type", type);
			rs = preparedStatementUtil.executeQuery();
			
			if(rs.next()){
				familyBean.setTitleid(rs.getInt("TitleID"));
				familyBean.setTitlename(rs.getString("TitleName"));
				familyBean.setFirstname(rs.getString("FirstName"));
				familyBean.setLastname(rs.getString("LastName"));
				familyBean.setAge(rs.getString("Age"));
				familyBean.setRelation(rs.getString("Relation"));
				familyBean.setOccupation(rs.getString("Occupation"));
				familyBean.setPlace_occupation(rs.getString("PlaceOccupation"));
				familyBean.setType(rs.getString("Type"));
				familyBean.setProfileid(rs.getInt("ProfileID"));

			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return familyBean;
	} 
}
