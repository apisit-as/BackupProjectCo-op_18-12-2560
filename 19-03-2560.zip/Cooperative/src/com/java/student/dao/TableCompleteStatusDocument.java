package com.java.student.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.student.bean.EducationBean;
import com.java.util.PreparedStatementUtil;

public class TableCompleteStatusDocument {
	
	public Boolean checkCompleteStatusDocument(int UserID){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		Boolean value = false;
		String query = "SELECT True as isCheck FROM cooperative.tb_complete_status_document WHERE UserID = :userid LIMIT 1";
		
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("userid", UserID);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				value = rs.getBoolean("isCheck");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return value;
	}
	
	public int getCompleteStatusDocument(String fieldName,int userid){
		int data =0;
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rec = null;
		String sql = "SELECT "+fieldName
				+ " FROM tb_complete_status_document "
				+ " WHERE UserID = :userid ";
		try {
			prepareStatementUtil = new PreparedStatementUtil(sql);
			prepareStatementUtil.setInt("userid", userid);
			rec = prepareStatementUtil.executeQuery();
			while ((rec.next()) && (rec != null)) {
				data = rec.getInt(fieldName);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rec.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return data;
	}
	
	public void InsertCompleteStatusDoc(String fieldName,int status,int userid){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "INSERT INTO tb_complete_status_document("+fieldName+",UserID) "
					   		+ " VALUES(:status,:userid)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("status", status);
		   preparedStatementUtil.setInt("userid", userid);
		   preparedStatementUtil.execute();   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public void UpdateCompleteStatusDoc(String fieldName,int status,int userid){
		PreparedStatementUtil preparedStatementUtil = null;
		  try{
		   String query = "UPDATE tb_complete_status_document SET "+fieldName+" = :status "
		   				+ "WHERE UserID = :userid ";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("status", status);
		   preparedStatementUtil.setInt("userid", userid);
		   preparedStatementUtil.execute();
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
}
